import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, path.resolve(__dirname, ".."), "");
  const backendUrl = env.VITE_BACKEND_URL || env.VITE_API_BASE_URL || "http://localhost:3000";

  return {
    envDir: path.resolve(__dirname, ".."),
    server: {
      host: "::",
      port: 5173,
      proxy: {
        "/api": {
          target: backendUrl,
          changeOrigin: true,
        },
        "/uploads": {
          target: backendUrl,
          changeOrigin: true,
        },
      },
    },
    build: {
      outDir: "dist",
    },
    plugins: [
      react(),
      mode === "development" && componentTagger(),
      // viteApiPlugin(), // Disabled - using standalone backend server
    ].filter(Boolean),
    resolve: {
      alias: {
        "@": path.resolve(__dirname, "./src"),
      },
    },
  };
});

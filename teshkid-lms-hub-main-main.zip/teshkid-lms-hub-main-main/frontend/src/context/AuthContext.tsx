import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../lib/api';
import { getImageUrl } from '../lib/imageUtils';

interface User {
    id: string;
    name: string;
    email: string;
    role: string;
    profilePicture?: string;
}

interface AuthContextType {
    user: User | null;
    login: (token: string, user: User) => void;
    logout: () => void;
    refreshUser: () => Promise<void>;
    isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
    const [user, setUser] = useState<User | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        refreshUser();
    }, []);

    const refreshUser = async () => {
        const token = localStorage.getItem('token');
        if (token) {
            try {
                const res = await api.get('/auth/me');
                const userData = res.data;
                
                // Ensure profile picture has proper URL
                if (userData.profilePicture) {
                    userData.profilePicture = getImageUrl(userData.profilePicture);
                }
                
                setUser(userData);
            } catch (error) {
                localStorage.removeItem('token');
                setUser(null);
            } finally {
                setIsLoading(false);
            }
        } else {
            setIsLoading(false);
        }
    };

    const login = (token: string, userData: User) => {
        localStorage.setItem('token', token);
        
        // Ensure profile picture has proper URL
        if (userData.profilePicture) {
            userData.profilePicture = getImageUrl(userData.profilePicture);
        }
        
        setUser(userData);
    };

    const logout = () => {
        localStorage.removeItem('token');
        setUser(null);
    };

    return (
        <AuthContext.Provider value={{ user, login, logout, refreshUser, isLoading }}>
            {children}
        </AuthContext.Provider>
    );
}

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};

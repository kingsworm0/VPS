import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Eye, EyeOff, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import api from "@/lib/api";

const passwordRules = "At least 12 characters, including uppercase, lowercase, number, and special character.";

export default function ResetPassword() {
  const { token } = useParams();
  const navigate = useNavigate();
  const [validating, setValidating] = useState(true);
  const [isValid, setIsValid] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!token) {
      setValidating(false);
      return;
    }
    api.get(`/auth/verify-reset-token/${token}`)
      .then((response) => setIsValid(response.data.valid === true))
      .catch(() => setIsValid(false))
      .finally(() => setValidating(false));
  }, [token]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setIsLoading(true);
    try {
      await api.post("/auth/reset-password", { token, password, confirmPassword });
      toast({ title: "Password reset", description: "Your password has been updated." });
      navigate("/student/login");
    } catch (error: any) {
      toast({
        title: "Unable to reset password",
        description: error.response?.data?.error || "The reset link may have expired.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-hero-pattern opacity-50" />
      <Card variant="glass" className="relative w-full max-w-md backdrop-blur-xl border-primary/20">
        <CardHeader className="text-center">
          <div className="mx-auto mb-2 rounded-full bg-primary/10 p-3 w-fit"><Lock className="h-7 w-7 text-primary" /></div>
          <CardTitle className="font-display text-2xl">Set a new password</CardTitle>
          <CardDescription>{validating ? "Checking your reset link..." : isValid ? passwordRules : "This reset link is invalid or has expired."}</CardDescription>
        </CardHeader>
        <CardContent>
          {!validating && !isValid ? (
            <Button asChild className="w-full"><Link to="/forgot-password">Request a new link</Link></Button>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="password">New password</Label>
                <div className="relative">
                  <Input id="password" type={showPassword ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} className="pr-10" required minLength={12} />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-label="Toggle password visibility">
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm password</Label>
                <Input id="confirmPassword" type={showPassword ? "text" : "password"} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required minLength={12} />
              </div>
              <Button type="submit" className="w-full" disabled={isLoading || validating || !isValid}>{isLoading ? "Updating..." : "Reset password"}</Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

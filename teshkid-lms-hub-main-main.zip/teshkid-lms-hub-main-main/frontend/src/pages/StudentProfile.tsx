import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { getImageUrl } from "@/lib/imageUtils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "sonner";
import { 
  X, Camera, CreditCard, Shield, Lock, Bell, User, Monitor, UserRound
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";

interface StudentProfile {
  id: string;
  name: string;
  email: string;
  username: string;
  profilePicture?: string;
  bio?: string;
  timezone: string;
  language: string;
  courseReminders: boolean;
  privacyVisibility: string;
  privacyActivityStatus: boolean;
  privacyAppearInSearch: boolean;
  privacyAnalyticsTracking: boolean;
  creditCard?: string;
  mpesaPhone?: string;
  phone?: string;
  address?: string;
  city?: string;
  state?: string;
  country?: string;
  postalCode?: string;
  joinedAt: string;
}

const SIDEBAR_SECTIONS = [
  {
    title: "USER SETTINGS",
    tabs: [
      { id: "account", label: "My Account" },
      { id: "profile", label: "Profiles" },
      { id: "privacy", label: "Privacy & Safety" },
    ]
  },
  {
    title: "APP SETTINGS",
    tabs: [
      { id: "appearance", label: "Appearance" },
      { id: "notifications", label: "Notifications" },
    ]
  },
  {
    title: "BILLING SETTINGS",
    tabs: [
      { id: "subscriptions", label: "Subscriptions" },
      { id: "billing", label: "Billing" },
    ]
  }
];

export default function StudentProfile() {
  const navigate = useNavigate();
  const { refreshUser } = useAuth();
  
  const [profile, setProfile] = useState<StudentProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("account");
  const [announcements, setAnnouncements] = useState<any[]>([]);
  
  // Profile form state
  const [formData, setFormData] = useState({ name: "", bio: "", username: "" });
  const [profileFile, setProfileFile] = useState<File | null>(null);
  const [savingProfile, setSavingProfile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Password form state
  const [passwordData, setPasswordData] = useState({ currentPassword: "", newPassword: "", confirmPassword: "" });
  const [passwordLoading, setPasswordLoading] = useState(false);

  // States for other tabs
  const [timezone, setTimezone] = useState("Europe/Amsterdam");
  const [language, setLanguage] = useState("English (UK)");
  const [courseReminders, setCourseReminders] = useState(true);
  const [privacySettings, setPrivacySettings] = useState({
    visibility: "public",
    activityStatus: true,
    appearInSearch: true,
    analyticsTracking: true
  });
  
  // Billing state
  const [creditCard, setCreditCard] = useState("");
  const [mpesaPhone, setMpesaPhone] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [state, setState] = useState("");
  const [country, setCountry] = useState("");
  const [postalCode, setPostalCode] = useState("");

  // UI state for revealing edits
  const [editingField, setEditingField] = useState<string | null>(null);

  useEffect(() => {
    loadProfile();
    loadAnnouncements();
  }, []);

  const loadAnnouncements = async () => {
    try {
      const response = await api.get("/announcements");
      if (response.data && Array.isArray(response.data)) {
        setAnnouncements(response.data);
      }
    } catch (error) {
      console.error("Failed to load announcements:", error);
    }
  };

  const loadProfile = async () => {
    try {
      const response = await api.get("/student/profile");
      const profileData = response.data;
      
      // Ensure profile picture has proper URL
      if (profileData.profilePicture) {
        profileData.profilePicture = getImageUrl(profileData.profilePicture);
      }
      
      setProfile(profileData);
      setFormData({ 
        name: profileData.name || "", 
        bio: profileData.bio || "",
        username: profileData.username || "" 
      });
      setTimezone(profileData.timezone || "Europe/Amsterdam");
      setLanguage(profileData.language || "English (UK)");
      setCourseReminders(profileData.courseReminders ?? true);
      setPrivacySettings({
        visibility: profileData.privacyVisibility || "public",
        activityStatus: profileData.privacyActivityStatus ?? true,
        appearInSearch: profileData.privacyAppearInSearch ?? true,
        analyticsTracking: profileData.privacyAnalyticsTracking ?? true
      });
      setCreditCard(profileData.creditCard || "");
      setMpesaPhone(profileData.mpesaPhone || "");
      setPhone(profileData.phone || "");
      setAddress(profileData.address || "");
      setCity(profileData.city || "");
      setState(profileData.state || "");
      setCountry(profileData.country || "");
      setPostalCode(profileData.postalCode || "");
    } catch (error) {
      console.error("Failed to load profile:", error);
      toast.error("Failed to load profile");
      navigate("/dashboard");
    } finally {
      setLoading(false);
    }
  };

  const handleProfileUpdate = async () => {
    setSavingProfile(true);
    try {
      await api.put("/student/profile", { name: formData.name, bio: formData.bio, username: formData.username });
      setProfile({ ...profile, name: formData.name, bio: formData.bio, username: formData.username } as StudentProfile);
      toast.success("Profile updated successfully");
      setEditingField(null);
    } catch (error: any) {
      console.error("Failed to update profile:", error);
      toast.error(error.response?.data?.message || "Failed to update profile");
    } finally {
      setSavingProfile(false);
    }
  };

  const handleSettingsUpdate = async () => {
    try {
      await api.put("/student/profile", { 
        timezone,
        language,
        courseReminders,
        privacyVisibility: privacySettings.visibility,
        privacyActivityStatus: privacySettings.activityStatus,
        privacyAppearInSearch: privacySettings.appearInSearch,
        privacyAnalyticsTracking: privacySettings.analyticsTracking,
        creditCard,
        mpesaPhone,
        phone,
        address,
        city,
        state,
        country,
        postalCode
      });
      toast.success("Settings saved successfully");
    } catch (error: any) {
      toast.error(error.response?.data?.message || "Failed to save settings");
    }
  };

  const handleProfilePictureUpload = async (file: File) => {
    try {
      const formDataObj = new FormData();
      formDataObj.append("profilePicture", file);

      const response = await api.post("/student/profile-picture", formDataObj, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      const newProfilePicture = getImageUrl(response.data.profilePicture);

      setProfile({
        ...profile,
        profilePicture: newProfilePicture,
      } as StudentProfile);
      setProfileFile(null);
      await refreshUser();
      toast.success("Profile picture updated successfully");
    } catch (error) {
      console.error("Failed to upload profile picture:", error);
      toast.error("Failed to upload profile picture");
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast.error("New passwords do not match");
      return;
    }
    if (passwordData.newPassword.length < 6) {
      toast.error("Password must be at least 6 characters");
      return;
    }

    setPasswordLoading(true);
    try {
      await api.put("/student/password", {
        currentPassword: passwordData.currentPassword,
        newPassword: passwordData.newPassword
      });
      toast.success("Password changed successfully");
      setPasswordData({ currentPassword: "", newPassword: "", confirmPassword: "" });
    } catch (error: any) {
      console.error("Failed to change password:", error);
      toast.error(error.response?.data?.message || "Failed to change password");
    } finally {
      setPasswordLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans">
      <Navbar />
      {announcements.length > 0 && (
        <div className="mt-16 w-full bg-primary/10 border-b border-primary/20 p-4">
          <div className="max-w-7xl mx-auto space-y-3">
            {announcements.map((ann, idx) => (
              <div key={ann.id || idx} className="bg-background rounded-lg border border-primary/20 p-4 flex gap-4 shadow-sm">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <Bell className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-bold text-foreground">{ann.title}</h4>
                  <p className="text-sm text-muted-foreground mt-1">{ann.content}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      <div className={cn("flex flex-1 min-h-[calc(100vh-4rem)]", announcements.length === 0 ? "mt-16" : "")}>
      
      {/* Sidebar */}
      <aside className="w-60 md:w-72 bg-card/30 border-r border-border/60 flex-shrink-0 flex flex-col items-end pt-8 pb-6 overflow-y-auto hidden sm:flex">
        <div className="w-full max-w-[218px] px-2 pr-4 space-y-4">
          {SIDEBAR_SECTIONS.map((section, idx) => (
            <div key={idx} className="mb-4">
              <h3 className="px-2.5 text-[11px] font-bold text-muted-foreground mb-1.5 uppercase tracking-wide">
                {section.title}
              </h3>
              <div className="space-y-0.5">
                {section.tabs.map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={cn(
                      "w-full text-left px-2.5 py-1.5 rounded text-[15px] font-medium transition-colors",
                      activeTab === tab.id 
                        ? "bg-primary text-primary-foreground" 
                        : "text-muted-foreground hover:bg-secondary/50 hover:text-foreground"
                    )}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
              {idx < SIDEBAR_SECTIONS.length - 1 && (
                <div className="mx-2.5 h-[1px] bg-border mt-4" />
              )}
            </div>
          ))}
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative min-w-0 bg-background">
        {/* ESC Button (Close) */}
        <div className="absolute top-8 right-10 z-10 hidden md:flex flex-col items-center group cursor-pointer" onClick={() => navigate("/dashboard")}>
          <div className="w-9 h-9 rounded-full border-2 border-muted-foreground group-hover:bg-secondary flex items-center justify-center mb-1 transition-colors">
            <X className="w-4 h-4 text-muted-foreground group-hover:text-foreground" />
          </div>
          <span className="text-[12px] font-bold text-muted-foreground group-hover:text-foreground">ESC</span>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar">
          <div className="max-w-[740px] px-6 md:px-10 py-10 pb-20">
            
            {/* 1. My Account Tab */}
            {activeTab === "account" && (
              <div className="animate-in fade-in duration-200">
                <h2 className="text-[20px] font-bold text-foreground mb-5">My Account</h2>
                
                <div className="bg-muted rounded-xl overflow-hidden mb-8">
                  <div className="h-24 bg-primary/30"></div>
                  <div className="px-4 pb-4 flex justify-between items-start relative">
                    <div className="relative -mt-12 mb-4">
                      <div className="w-20 h-20 rounded-full border-[6px] border-muted bg-background overflow-hidden flex items-center justify-center">
                        {profile?.profilePicture ? (
                          <img src={profile.profilePicture} alt="Avatar" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-primary/10">
                            <UserRound className="w-10 h-10 text-primary" />
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="mt-4">
                      <Button onClick={() => setActiveTab("profile")} className="h-8 text-sm font-medium px-4">
                        Edit User Profile
                      </Button>
                    </div>
                  </div>
                  
                  <div className="bg-card m-4 mt-0 rounded-lg p-4 space-y-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-[12px] font-bold text-muted-foreground uppercase">Display Name</p>
                        {editingField === "name" ? (
                          <Input 
                            value={formData.name} 
                            onChange={e => setFormData({...formData, name: e.target.value})}
                            className="bg-muted border-none h-8 mt-1 text-foreground text-sm"
                          />
                        ) : (
                          <p className="text-foreground text-[15px]">{profile?.name}</p>
                        )}
                      </div>
                      {editingField === "name" ? (
                        <div className="flex gap-2">
                          <Button size="sm" variant="ghost" onClick={() => setEditingField(null)} className="h-8 text-sm text-muted-foreground hover:text-foreground">Cancel</Button>
                          <Button size="sm" onClick={handleProfileUpdate} disabled={savingProfile} className="h-8 text-sm">Save</Button>
                        </div>
                      ) : (
                        <Button size="sm" variant="secondary" className="h-8 text-sm font-medium" onClick={() => setEditingField("name")}>Edit</Button>
                      )}
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-[12px] font-bold text-muted-foreground uppercase">Username</p>
                        {editingField === "username" ? (
                          <Input 
                            value={formData.username} 
                            onChange={e => setFormData({...formData, username: e.target.value})}
                            className="bg-muted border-none h-8 mt-1 text-foreground text-sm"
                          />
                        ) : (
                          <p className="text-foreground text-[15px]">{profile?.username}</p>
                        )}
                      </div>
                      {editingField === "username" ? (
                        <div className="flex gap-2">
                          <Button size="sm" variant="ghost" onClick={() => setEditingField(null)} className="h-8 text-sm text-muted-foreground hover:text-foreground">Cancel</Button>
                          <Button size="sm" onClick={handleProfileUpdate} disabled={savingProfile} className="h-8 text-sm">Save</Button>
                        </div>
                      ) : (
                        <Button size="sm" variant="secondary" className="h-8 text-sm font-medium" onClick={() => setEditingField("username")}>Edit</Button>
                      )}
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-[12px] font-bold text-muted-foreground uppercase">Email</p>
                        <div className="flex items-center gap-2">
                          <p className="text-foreground text-[15px]">{profile?.email.replace(/(.{2})(.*)(?=@)/, '$1***')}</p>
                          <span className="text-[11px] text-primary font-semibold cursor-pointer hover:underline">Reveal</span>
                        </div>
                      </div>
                      <Button size="sm" variant="secondary" className="h-8 text-sm font-medium" onClick={() => toast.info("Coming soon!")}>Edit</Button>
                    </div>
                  </div>
                </div>

                <div className="h-[1px] bg-border my-8" />
                
                <h2 className="text-[20px] font-bold text-foreground mb-5">Password and Authentication</h2>
                <div className="space-y-4">
                  <form onSubmit={handlePasswordChange} className="space-y-4 bg-card p-5 rounded-lg border border-border">
                    <div>
                      <p className="text-[12px] font-bold text-muted-foreground uppercase mb-2">Current Password</p>
                      <Input 
                        type="password"
                        value={passwordData.currentPassword}
                        onChange={e => setPasswordData({...passwordData, currentPassword: e.target.value})}
                        className="bg-muted border-none text-foreground focus-visible:ring-1 focus-visible:ring-primary"
                      />
                    </div>
                    <div>
                      <p className="text-[12px] font-bold text-muted-foreground uppercase mb-2">New Password</p>
                      <Input 
                        type="password"
                        value={passwordData.newPassword}
                        onChange={e => setPasswordData({...passwordData, newPassword: e.target.value})}
                        className="bg-muted border-none text-foreground focus-visible:ring-1 focus-visible:ring-primary"
                      />
                    </div>
                    <div>
                      <p className="text-[12px] font-bold text-muted-foreground uppercase mb-2">Confirm New Password</p>
                      <Input 
                        type="password"
                        value={passwordData.confirmPassword}
                        onChange={e => setPasswordData({...passwordData, confirmPassword: e.target.value})}
                        className="bg-muted border-none text-foreground focus-visible:ring-1 focus-visible:ring-primary"
                      />
                    </div>
                    <Button 
                      type="submit" 
                      disabled={passwordLoading}
                      className="w-full md:w-auto mt-2"
                    >
                      {passwordLoading ? "Updating..." : "Update Password"}
                    </Button>
                  </form>
                </div>
              </div>
            )}

            {/* 2. Profiles Tab */}
            {activeTab === "profile" && (
              <div className="animate-in fade-in duration-200">
                <h2 className="text-[20px] font-bold text-foreground mb-5">Profiles</h2>
                <div className="bg-card p-6 rounded-lg border border-border">
                  
                  <div className="flex flex-col md:flex-row gap-8">
                    <div className="flex-1 space-y-6">
                      <div>
                        <h3 className="text-[12px] font-bold text-muted-foreground uppercase mb-2">Display Name</h3>
                        <Input 
                          value={formData.name} 
                          onChange={e => setFormData({...formData, name: e.target.value})}
                          className="bg-muted border-none text-foreground focus-visible:ring-1 focus-visible:ring-primary"
                        />
                      </div>
                      <div className="h-[1px] bg-border" />
                      <div>
                        <h3 className="text-[12px] font-bold text-muted-foreground uppercase mb-2">About Me</h3>
                        <textarea 
                          value={formData.bio} 
                          onChange={e => setFormData({...formData, bio: e.target.value})}
                          className="w-full h-32 bg-muted rounded-md p-3 text-sm text-foreground resize-none focus:outline-none focus:ring-1 focus:ring-primary"
                          placeholder="You can use markdown here."
                        />
                      </div>
                      <Button 
                        onClick={handleProfileUpdate} 
                        disabled={savingProfile}
                        className="w-full md:w-auto"
                      >
                        {savingProfile ? "Saving..." : "Save Changes"}
                      </Button>
                    </div>

                    <div className="w-full md:w-[300px]">
                      <h3 className="text-[12px] font-bold text-muted-foreground uppercase mb-3">Preview</h3>
                      <div className="bg-muted rounded-xl overflow-hidden shadow-lg border border-border">
                        <div className="h-16 bg-primary/30"></div>
                        <div className="px-4 pb-4 relative">
                          <div className="relative -mt-8 mb-3 w-16 h-16 rounded-full border-4 border-muted bg-background overflow-hidden group">
                            {profile?.profilePicture ? (
                              <img src={profile.profilePicture} alt="Avatar" className="w-full h-full object-cover" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center bg-primary/10">
                                <UserRound className="w-8 h-8 text-primary" />
                              </div>
                            )}
                            <div 
                              className="absolute inset-0 bg-black/50 hidden group-hover:flex items-center justify-center cursor-pointer"
                              onClick={() => fileInputRef.current?.click()}
                            >
                              <Camera className="w-5 h-5 text-white" />
                            </div>
                            <input 
                              type="file" 
                              ref={fileInputRef}
                              accept="image/*"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) handleProfilePictureUpload(file);
                              }}
                              className="hidden" 
                            />
                          </div>
                          <div className="bg-background p-3 rounded-lg border border-border/50">
                            <h4 className="font-bold text-foreground text-[16px] leading-tight">{formData.name}</h4>
                            <p className="text-[13px] text-muted-foreground mb-2">{formData.username}</p>
                            <div className="h-[1px] bg-border my-2" />
                            <h5 className="text-[11px] font-bold text-muted-foreground uppercase mb-1">About Me</h5>
                            <p className="text-[13px] text-muted-foreground whitespace-pre-wrap">
                              {formData.bio || "No bio set."}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            )}

            {/* 3. Privacy & Safety */}
            {activeTab === "privacy" && (
              <div className="animate-in fade-in duration-200">
                <h2 className="text-[20px] font-bold text-foreground mb-5">Privacy & Safety</h2>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-[12px] font-bold text-muted-foreground uppercase mb-4">Discoverability</h3>
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <p className="text-foreground text-base">Appear in search</p>
                        <p className="text-[13px] text-muted-foreground">Let others find you by your username or email.</p>
                      </div>
                      <Switch 
                        checked={privacySettings.appearInSearch}
                        onCheckedChange={(v) => {
                          setPrivacySettings({...privacySettings, appearInSearch: v});
                          handleSettingsUpdate();
                        }}
                      />
                    </div>
                  </div>

                  <div className="h-[1px] bg-border" />

                  <div>
                    <h3 className="text-[12px] font-bold text-muted-foreground uppercase mb-4">Activity Status</h3>
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <p className="text-foreground text-base">Display current activity as a status message</p>
                        <p className="text-[13px] text-muted-foreground">Let others see when you are online and active.</p>
                      </div>
                      <Switch 
                        checked={privacySettings.activityStatus}
                        onCheckedChange={(v) => {
                          setPrivacySettings({...privacySettings, activityStatus: v});
                          handleSettingsUpdate();
                        }}
                      />
                    </div>
                  </div>

                  <div className="h-[1px] bg-border" />
                  
                  <div>
                    <h3 className="text-[12px] font-bold text-muted-foreground uppercase mb-4">Data Privacy</h3>
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <p className="text-foreground text-base">Use data to improve Teshkid LMS</p>
                        <p className="text-[13px] text-muted-foreground">This setting allows us to use and process information about how you navigate and use Teshkid for analytical purposes.</p>
                      </div>
                      <Switch 
                        checked={privacySettings.analyticsTracking}
                        onCheckedChange={(v) => {
                          setPrivacySettings({...privacySettings, analyticsTracking: v});
                          handleSettingsUpdate();
                        }}
                      />
                    </div>
                  </div>

                </div>
              </div>
            )}

            {/* 4. Appearance & App Settings */}
            {activeTab === "appearance" && (
              <div className="animate-in fade-in duration-200">
                <h2 className="text-[20px] font-bold text-foreground mb-5">Appearance</h2>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-[12px] font-bold text-muted-foreground uppercase mb-4">Theme</h3>
                    <RadioGroup defaultValue="dark" className="flex gap-4">
                      <label className="cursor-pointer">
                        <div className="w-32 h-20 bg-card rounded-md border-2 border-primary flex items-center justify-center mb-2 shadow-lg">
                          <div className="w-20 h-10 bg-background rounded shadow-sm flex items-center justify-center border border-border">
                            <span className="text-muted-foreground text-xs">Dark</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 justify-center">
                          <RadioGroupItem value="dark" id="dark" className="text-primary" />
                          <span className="text-[14px] text-foreground">Dark</span>
                        </div>
                      </label>
                      <label className="cursor-pointer opacity-50">
                        <div className="w-32 h-20 bg-gray-100 rounded-md border-2 border-transparent flex items-center justify-center mb-2 shadow-lg">
                          <div className="w-20 h-10 bg-white rounded shadow-sm flex items-center justify-center">
                            <span className="text-gray-800 text-xs">Light</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 justify-center">
                          <RadioGroupItem value="light" id="light" disabled />
                          <span className="text-[14px] text-foreground">Light</span>
                        </div>
                      </label>
                    </RadioGroup>
                  </div>

                  <div className="h-[1px] bg-border" />

                  <div>
                    <h3 className="text-[12px] font-bold text-muted-foreground uppercase mb-4">Language</h3>
                    <Select value={language} onValueChange={(v) => { setLanguage(v); handleSettingsUpdate(); }}>
                      <SelectTrigger className="bg-muted border-none text-foreground h-10 focus:ring-1 focus:ring-primary w-[300px]">
                        <SelectValue placeholder="Select Language" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-border text-foreground">
                        <SelectItem value="English (UK)">English (UK)</SelectItem>
                        <SelectItem value="English (US)">English (US)</SelectItem>
                        <SelectItem value="Spanish">Spanish</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <h3 className="text-[12px] font-bold text-muted-foreground uppercase mb-4">Timezone</h3>
                    <Select value={timezone} onValueChange={(v) => { setTimezone(v); handleSettingsUpdate(); }}>
                      <SelectTrigger className="bg-muted border-none text-foreground h-10 focus:ring-1 focus:ring-primary w-[300px]">
                        <SelectValue placeholder="Select Timezone" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-border text-foreground">
                        <SelectItem value="Europe/Amsterdam">Europe/Amsterdam</SelectItem>
                        <SelectItem value="Europe/London">Europe/London</SelectItem>
                        <SelectItem value="America/New_York">America/New_York</SelectItem>
                        <SelectItem value="Africa/Nairobi">Africa/Nairobi</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {/* 5. Notifications */}
            {activeTab === "notifications" && (
              <div className="animate-in fade-in duration-200">
                <h2 className="text-[20px] font-bold text-foreground mb-5">Notifications</h2>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-[12px] font-bold text-muted-foreground uppercase mb-4">Course Alerts</h3>
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <p className="text-foreground text-base">Course Reminders</p>
                        <p className="text-[13px] text-muted-foreground">Receive notifications and emails about your enrolled courses and upcoming live sessions.</p>
                      </div>
                      <Switch 
                        checked={courseReminders}
                        onCheckedChange={(v) => {
                          setCourseReminders(v);
                          handleSettingsUpdate();
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 6. Subscriptions & Billing */}
            {activeTab === "subscriptions" && (
              <div className="animate-in fade-in duration-200">
                <h2 className="text-[20px] font-bold text-foreground mb-5">Subscriptions</h2>
                <div className="bg-card rounded-xl p-6 border border-border flex flex-col items-center text-center">
                  <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mb-4">
                    <Monitor className="w-8 h-8 text-primary-foreground" />
                  </div>
                  <h3 className="text-xl font-bold text-foreground mb-2">Teshkid Pro</h3>
                  <p className="text-[14px] text-muted-foreground mb-6 max-w-md">
                    You are currently on the Pro plan. You have access to all premium courses, live sessions, and priority support.
                  </p>
                  <div className="bg-muted w-full rounded-lg p-4 flex justify-between items-center text-left">
                    <div>
                      <p className="text-[14px] font-bold text-foreground">Current Plan: Pro (Monthly)</p>
                      <p className="text-[13px] text-muted-foreground">Renews on Aug 14, 2026 for €12.00</p>
                    </div>
                    <Button variant="secondary" onClick={() => toast.info("Coming soon!")}>Manage</Button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "billing" && (
              <div className="animate-in fade-in duration-200">
                <h2 className="text-[20px] font-bold text-foreground mb-5">Billing</h2>
                
                <div className="space-y-8">
                  {/* Contact Information */}
                  <div>
                    <h3 className="text-[12px] font-bold text-muted-foreground uppercase mb-4">Contact Information</h3>
                    <div className="space-y-3">
                      <div className="bg-card rounded-lg p-4 border border-border">
                        <label className="text-[12px] font-bold text-muted-foreground uppercase block mb-2">
                          Phone Number
                        </label>
                        <Input 
                          value={phone}
                          onChange={e => setPhone(e.target.value)}
                          onBlur={handleSettingsUpdate}
                          placeholder="+1 (555) 123-4567"
                          className="bg-muted border-none text-foreground focus-visible:ring-1 focus-visible:ring-primary"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="h-[1px] bg-border" />

                  {/* Billing Address */}
                  <div>
                    <h3 className="text-[12px] font-bold text-muted-foreground uppercase mb-4">Billing Address</h3>
                    <div className="space-y-3">
                      <div className="bg-card rounded-lg p-4 border border-border">
                        <label className="text-[12px] font-bold text-muted-foreground uppercase block mb-2">
                          Street Address
                        </label>
                        <Input 
                          value={address}
                          onChange={e => setAddress(e.target.value)}
                          onBlur={handleSettingsUpdate}
                          placeholder="123 Main St, Apt 4B"
                          className="bg-muted border-none text-foreground focus-visible:ring-1 focus-visible:ring-primary"
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="bg-card rounded-lg p-4 border border-border">
                          <label className="text-[12px] font-bold text-muted-foreground uppercase block mb-2">
                            City
                          </label>
                          <Input 
                            value={city}
                            onChange={e => setCity(e.target.value)}
                            onBlur={handleSettingsUpdate}
                            placeholder="New York"
                            className="bg-muted border-none text-foreground focus-visible:ring-1 focus-visible:ring-primary"
                          />
                        </div>

                        <div className="bg-card rounded-lg p-4 border border-border">
                          <label className="text-[12px] font-bold text-muted-foreground uppercase block mb-2">
                            State / Province
                          </label>
                          <Input 
                            value={state}
                            onChange={e => setState(e.target.value)}
                            onBlur={handleSettingsUpdate}
                            placeholder="NY"
                            className="bg-muted border-none text-foreground focus-visible:ring-1 focus-visible:ring-primary"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="bg-card rounded-lg p-4 border border-border">
                          <label className="text-[12px] font-bold text-muted-foreground uppercase block mb-2">
                            Country
                          </label>
                          <Input 
                            value={country}
                            onChange={e => setCountry(e.target.value)}
                            onBlur={handleSettingsUpdate}
                            placeholder="United States"
                            className="bg-muted border-none text-foreground focus-visible:ring-1 focus-visible:ring-primary"
                          />
                        </div>

                        <div className="bg-card rounded-lg p-4 border border-border">
                          <label className="text-[12px] font-bold text-muted-foreground uppercase block mb-2">
                            Postal / ZIP Code
                          </label>
                          <Input 
                            value={postalCode}
                            onChange={e => setPostalCode(e.target.value)}
                            onBlur={handleSettingsUpdate}
                            placeholder="10001"
                            className="bg-muted border-none text-foreground focus-visible:ring-1 focus-visible:ring-primary"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="h-[1px] bg-border" />

                  {/* Payment Methods */}
                  <div>
                    <h3 className="text-[12px] font-bold text-muted-foreground uppercase mb-4">Payment Methods</h3>
                    <div className="space-y-3">
                      <div className="bg-card rounded-lg p-4 flex justify-between items-center border border-border">
                        <div className="flex items-center gap-4 flex-1">
                          <div className="w-12 h-8 bg-white rounded flex items-center justify-center shrink-0">
                            <CreditCard className="w-6 h-6 text-gray-800" />
                          </div>
                          <div className="flex-1">
                            {creditCard ? (
                              <p className="text-foreground font-medium text-[15px]">{creditCard}</p>
                            ) : (
                              <div className="flex items-center">
                                <Input 
                                  value={creditCard}
                                  onChange={e => setCreditCard(e.target.value)}
                                  onBlur={handleSettingsUpdate}
                                  placeholder="•••• •••• •••• 4242"
                                  className="bg-transparent border-none text-foreground h-6 p-0 focus-visible:ring-0 text-[15px]"
                                />
                              </div>
                            )}
                            <p className="text-[12px] text-muted-foreground">Credit/Debit Card</p>
                          </div>
                        </div>
                        {creditCard ? (
                          <Button variant="ghost" className="text-red-500 hover:bg-red-500/10 hover:text-red-500 shrink-0" onClick={() => { setCreditCard(""); handleSettingsUpdate(); }}>Remove</Button>
                        ) : (
                          <Button variant="ghost" className="text-primary hover:bg-primary/10 hover:text-primary shrink-0" onClick={handleSettingsUpdate}>Save</Button>
                        )}
                      </div>
                      
                      <div className="bg-card rounded-lg p-4 flex justify-between items-center border border-border">
                        <div className="flex items-center gap-4 flex-1">
                          <div className="w-12 h-8 bg-green-600 rounded flex items-center justify-center shrink-0">
                            <span className="text-[10px] font-bold text-white">M-PESA</span>
                          </div>
                          <div className="flex-1">
                            {mpesaPhone ? (
                              <p className="text-foreground font-medium text-[15px]">{mpesaPhone}</p>
                            ) : (
                              <div className="flex items-center">
                                <Input 
                                  value={mpesaPhone}
                                  onChange={e => setMpesaPhone(e.target.value)}
                                  onBlur={handleSettingsUpdate}
                                  placeholder="+254 7XX XXX XXX"
                                  className="bg-transparent border-none text-foreground h-6 p-0 focus-visible:ring-0 text-[15px]"
                                />
                              </div>
                            )}
                            <p className="text-[12px] text-muted-foreground">Mobile Money</p>
                          </div>
                        </div>
                        {mpesaPhone ? (
                          <Button variant="ghost" className="text-red-500 hover:bg-red-500/10 hover:text-red-500 shrink-0" onClick={() => { setMpesaPhone(""); handleSettingsUpdate(); }}>Remove</Button>
                        ) : (
                          <Button variant="ghost" className="text-primary hover:bg-primary/10 hover:text-primary shrink-0" onClick={handleSettingsUpdate}>Save</Button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>
      </main>
      </div>
      <Footer />
    </div>
  );
}

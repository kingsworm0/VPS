import React, { useEffect, useState, useRef } from "react";
import { useParams, Link } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import api from "@/lib/api";
import { updateMetaTags } from "@/lib/seo";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { getImageUrl } from "@/lib/imageUtils";
import {
  ArrowLeft, ThumbsDown, Share2, ThumbsUp,
  Clock, User, Loader2, Eye, MessageCircle, Send, Bookmark,
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

// ─── Types ────────────────────────────────────────────────────────────────────
interface Blog {
  id: string;
  slug?: string;
  title: string;
  content: string;
  category: string;
  featuredImage?: string;
  coverImage?: string;
  tags: string[];
  viewCount: number;
  likeCount?: number;
  dislikeCount?: number;
  userLiked?: boolean;
  userDisliked?: boolean;
  createdAt: string;
  updatedAt: string;
  status: string;
  description?: string;
  authorName?: string;
  authorProfilePicture?: string;
  keyTakeaways?: string[];
  contentBlocks?: any[];
  gallery?: string[];
}

interface TOCItem { id: string; text: string; level: number; }
interface BlogComment { id: string; content: string; createdAt: string; authorName: string; authorProfilePicture?: string; }

// ─── Helpers ──────────────────────────────────────────────────────────────────
const getReadingTime = (content: string) =>
  Math.max(1, Math.ceil(content.replace(/<[^>]*>/g, " ").trim().split(/\s+/).filter(Boolean).length / 220));

const CATEGORY_LABELS: Record<string, string> = {
  "admin-thoughts": "Admin Thoughts",
  "mcrypto-analysis": "MCrypto Analysis",
  "previous-day": "Daily Digest",
  "trading-ideas": "Trading Strategies",
};

const CATEGORY_COLORS: Record<string, string> = {
  "admin-thoughts": "bg-blue-500",
  "mcrypto-analysis": "bg-indigo-600",
  "previous-day": "bg-emerald-500",
  "trading-ideas": "bg-amber-500",
};

/**
 * Detects whether a string is plain-text HTML (tags not parsed by the browser).
 * Quill sometimes stores content with un-escaped angle brackets that browsers
 * display as literal characters instead of rendering as HTML.
 * We check for common patterns like "h1" or "/p" at word boundaries.
 */
function sanitizeContent(raw: string): string {
  if (!raw) return "";

  // If the string contains real < and > (proper HTML), return as-is
  if (/<[a-zA-Z\/][^>]*>/.test(raw)) return raw;

  // Otherwise the tags are stored as plain text — wrap each block in <p>
  // and replace common plain-text tag patterns with their HTML equivalents
  let fixed = raw
    // Headings
    .replace(/\bh1([^<\n]*?)\/h1/g,  "<h2>$1</h2>")
    .replace(/\bh2([^<\n]*?)\/h2/g,  "<h3>$1</h3>")
    .replace(/\bh3([^<\n]*?)\/h3/g,  "<h4>$1</h4>")
    // Paragraphs
    .replace(/\bp([^<\n]*?)\/p/g,    "<p>$1</p>")
    // Strong / em
    .replace(/\bstrong([^<]*?)\/strong/g, "<strong>$1</strong>")
    .replace(/\bem([^<]*?)\/em/g,    "<em>$1</em>")
    // Lists
    .replace(/\bul\b/g, "<ul>")
    .replace(/\/ul\b/g, "</ul>")
    .replace(/\bol\b/g, "<ol>")
    .replace(/\/ol\b/g, "</ol>")
    .replace(/\bli([^<]*?)\/li/g,    "<li>$1</li>")
    // br
    .replace(/\bbr\b\/?/g, "<br/>");

  // Wrap bare lines that still aren't inside tags in <p>
  if (!/<[a-zA-Z]/.test(fixed)) {
    fixed = fixed
      .split(/\n+/)
      .filter(l => l.trim())
      .map(l => `<p>${l.trim()}</p>`)
      .join("\n");
  }

  return fixed;
}

// ─── Component ────────────────────────────────────────────────────────────────
export default function BlogDetail() {
  const { slug } = useParams<{ slug: string }>();
  const [blog, setBlog]           = useState<Blog | null>(null);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState<string | null>(null);
  const [liked, setLiked]         = useState(false);
  const [disliked, setDisliked]   = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [dislikeCount, setDislikeCount] = useState(0);
  const [toc, setToc]             = useState<TOCItem[]>([]);
  const [activeId, setActiveId]   = useState("");
  const [comments, setComments]   = useState<BlogComment[]>([]);
  const [commentText, setCommentText] = useState("");
  const [commentLoading, setCommentLoading] = useState(false);
  const [readingProgress, setReadingProgress] = useState(0);
  const [relatedBlogs, setRelatedBlogs] = useState<Blog[]>([]);
  const [saved, setSaved]         = useState(false);
  const [selectedImage, setSelectedImage] = useState<{ src: string; alt: string } | null>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  // ── Fetch ──────────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!slug) return;
    (async () => {
      try {
        setLoading(true);
        const res  = await api.get(`/blogs/${slug}`);
        const data = res.data;

        const parseArr = (f: any) => {
          if (!f) return [];
          if (typeof f === "string") { try { return JSON.parse(f); } catch { return []; } }
          return Array.isArray(f) ? f : [];
        };

        const processed = {
          ...data,
          content:      sanitizeContent(data.content || ""),
          keyTakeaways: parseArr(data.keyTakeaways),
          gallery:      parseArr(data.gallery),
          tags:         parseArr(data.tags),
        };

        setBlog(processed);

        // Related + comments in parallel
        const [relRes, comRes] = await Promise.allSettled([
          api.get("/blogs"),
          api.get(`/blogs/${data.id}/comments`),
        ]);
        if (relRes.status === "fulfilled") {
          setRelatedBlogs(
            (relRes.value.data || [])
              .filter((b: Blog) => b.id !== data.id && b.category === data.category)
              .slice(0, 3)
          );
        }
        if (comRes.status === "fulfilled") setComments(comRes.value.data || []);

        setLikeCount(data.likeCount || 0);
        setDislikeCount(data.dislikeCount || 0);
        setLiked(!!data.userLiked);
        setDisliked(!!data.userDisliked);
        setError(null);

        const desc  = processed.description || processed.content.replace(/<[^>]*>/g, "").substring(0, 160);
        const img   = getImageUrl(processed.featuredImage || processed.coverImage);
        updateMetaTags(`${processed.title} | Teshkid`, desc, `${window.location.origin}/blog/${slug}`, img);
      } catch {
        setError("Article not found");
      } finally {
        setLoading(false);
      }
    })();
  }, [slug]);

  // Cleanup schema tag on unmount
  useEffect(() => () => { document.querySelector('script[data-blog-schema]')?.remove(); }, []);

  // ── ToC injection ─────────────────────────────────────────────────────────
  useEffect(() => {
    if (!blog?.content || !contentRef.current) return;
    const headings = contentRef.current.querySelectorAll("h1,h2,h3,h4");
    const items: TOCItem[] = [];
    headings.forEach((h, i) => {
      const id = `h-${i}`;
      h.id = id;
      items.push({ id, text: h.textContent || "", level: parseInt(h.tagName[1]) });
    });
    setToc(items);
  }, [blog]);

  // ── ToC intersection observer ────────────────────────────────────────────
  useEffect(() => {
    const obs = new IntersectionObserver(
      entries => entries.forEach(e => { if (e.isIntersecting) setActiveId(e.target.id); }),
      { rootMargin: "-80px 0px -60% 0px" }
    );
    contentRef.current?.querySelectorAll("h1,h2,h3,h4").forEach(h => obs.observe(h));
    return () => obs.disconnect();
  }, [toc]);

  // ── Reading progress ──────────────────────────────────────────────────────
  useEffect(() => {
    const update = () => {
      const el = contentRef.current;
      if (!el) return;
      const top  = el.getBoundingClientRect().top + window.scrollY;
      const avail = Math.max(1, el.offsetHeight - window.innerHeight);
      setReadingProgress(Math.min(100, Math.max(0, ((window.scrollY - top) / avail) * 100)));
    };
    update();
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, [blog]);

  // ── Actions ───────────────────────────────────────────────────────────────
  const handleLike = async () => {
    try {
      if (liked) {
        const r = await api.post(`/blogs/${blog?.id}/unlike`);
        setLiked(false); setLikeCount(r.data.likeCount || 0);
      } else {
        const r = await api.post(`/blogs/${blog?.id}/like`);
        setLiked(true); setDisliked(false);
        setLikeCount(r.data.likeCount || 0); setDislikeCount(r.data.dislikeCount || 0);
      }
    } catch {}
  };

  const handleDislike = async () => {
    try {
      if (disliked) {
        const r = await api.post(`/blogs/${blog?.id}/undislike`);
        setDisliked(false); setDislikeCount(r.data.dislikeCount || 0);
      } else {
        const r = await api.post(`/blogs/${blog?.id}/dislike`);
        setDisliked(true); setLiked(false);
        setDislikeCount(r.data.dislikeCount || 0); setLikeCount(r.data.likeCount || 0);
      }
    } catch {}
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success("Link copied to clipboard!");
  };

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault();
    const text = commentText.trim();
    if (!text || !blog) return;
    setCommentLoading(true);
    try {
      const r = await api.post(`/blogs/${blog.id}/comments`, { content: text });
      setComments(c => [r.data, ...c]);
      setCommentText("");
      toast.success("Comment posted!");
    } catch (err: any) {
      toast.error(err?.response?.status === 401 ? "Sign in to comment" : "Could not post comment");
    } finally { setCommentLoading(false); }
  };

  // ── Loading / Error states ────────────────────────────────────────────────
  if (loading) return (
    <div className="min-h-screen bg-[#05070a] flex flex-col items-center justify-center gap-4">
      <Loader2 className="w-10 h-10 text-primary animate-spin" />
      <p className="text-white/40 text-sm font-bold tracking-widest">Loading article…</p>
    </div>
  );

  if (error || !blog) return (
    <div className="min-h-screen bg-[#05070a]">
      <Navbar />
      <div className="flex flex-col items-center justify-center min-h-[70vh] gap-6 text-center px-4">
        <p className="text-2xl font-black text-white">Article not found</p>
        <Link to="/blog" className="inline-flex items-center gap-2 text-primary text-sm font-bold hover:underline">
          <ArrowLeft className="w-4 h-4" /> Back to Blog
        </Link>
      </div>
      <Footer />
    </div>
  );

  const coverImage = blog.featuredImage || blog.coverImage;

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-[#05070a] text-white">
      <Navbar />

      {/* Reading progress */}
      <div className="fixed top-0 left-0 right-0 z-[70] h-[3px] bg-white/10">
        <div className="h-full bg-primary transition-[width] duration-100 ease-linear" style={{ width: `${readingProgress}%` }} />
      </div>

      {/* Subtle ambient glow */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-15">
        <div className="absolute -top-1/4 -right-1/4 w-1/2 h-1/2 bg-primary/30 rounded-full blur-[140px]" />
      </div>

      <main className="relative mx-auto px-4 sm:px-6 lg:px-8 max-w-[1100px] pt-24 pb-24">

        {/* Back link */}
        <Link to="/blog"
          className="inline-flex items-center gap-2 text-white/50 hover:text-primary transition-colors mb-10 text-sm font-semibold group">
          <div className="w-7 h-7 rounded-full border border-white/20 flex items-center justify-center group-hover:border-primary/50 transition-colors">
            <ArrowLeft className="w-3.5 h-3.5" />
          </div>
          Back to Blog
        </Link>

        {/* Mobile ToC */}
        {toc.length > 0 && (
          <details className="mb-8 rounded-xl border border-white/10 bg-white/[0.03] p-4 lg:hidden">
            <summary className="cursor-pointer text-sm font-bold text-white/70 list-none flex items-center justify-between">
              <span>Contents</span>
              <span className="text-xs text-primary">{toc.length} sections</span>
            </summary>
            <nav className="mt-3 space-y-2 border-t border-white/10 pt-3">
              {toc.map(item => (
                <a key={item.id} href={`#${item.id}`}
                  onClick={e => { e.preventDefault(); document.getElementById(item.id)?.scrollIntoView({ behavior: "smooth" }); }}
                  className={`block text-sm py-0.5 ${item.level >= 3 ? "pl-4" : ""} ${activeId === item.id ? "text-primary font-semibold" : "text-white/50 hover:text-white/80"}`}>
                  {item.text}
                </a>
              ))}
            </nav>
          </details>
        )}

        {/* Two-column layout */}
        <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,680px)_260px] gap-12 xl:gap-16 items-start">

          {/* ── MAIN ARTICLE COLUMN ───────────────────────────────────────── */}
          <article className="min-w-0">

            {/* Category + date */}
            <div className="flex flex-wrap items-center gap-3 mb-5">
              <span className={`px-3 py-1 rounded-full text-[11px] font-black uppercase tracking-wider text-white ${CATEGORY_COLORS[blog.category] || "bg-primary"}`}>
                {CATEGORY_LABELS[blog.category] || blog.category}
              </span>
              <span className="text-white/40 text-xs font-medium">
                {format(new Date(blog.createdAt), "MMMM d, yyyy")}
              </span>
            </div>

            {/* Title */}
            <h1 className="text-[clamp(1.75rem,4vw,2.75rem)] font-black leading-[1.15] tracking-tight text-white mb-6">
              {blog.title}
            </h1>

            {/* Author row */}
            <div className="flex flex-wrap items-center gap-4 pb-6 border-b border-white/10 mb-8">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full border border-primary/30 overflow-hidden bg-white/5 shrink-0">
                  {blog.authorProfilePicture
                    ? <img src={blog.authorProfilePicture} alt={blog.authorName} className="w-full h-full object-cover" />
                    : <div className="w-full h-full flex items-center justify-center"><User className="w-4 h-4 text-white/30" /></div>
                  }
                </div>
                <div>
                  <p className="text-sm font-bold text-white/90 leading-none">{blog.authorName || "Teshkid Is Crypto"}</p>
                  <p className="text-[10px] text-primary/70 font-semibold mt-0.5">Market Analyst</p>
                </div>
              </div>
              <div className="flex items-center gap-4 text-xs font-medium text-white/40 ml-auto">
                <span className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" />{getReadingTime(blog.content)} min</span>
                <span className="flex items-center gap-1.5"><Eye className="w-3.5 h-3.5" />{blog.viewCount}</span>
                <button onClick={() => setSaved(v => !v)}
                  className={`p-1.5 rounded-lg border transition-colors ${saved ? "border-primary/40 text-primary" : "border-white/10 text-white/30 hover:text-white/60"}`}>
                  <Bookmark className={`w-3.5 h-3.5 ${saved ? "fill-current" : ""}`} />
                </button>
              </div>
            </div>

            {/* Cover image */}
            {coverImage && (
              <button type="button" onClick={() => setSelectedImage({ src: coverImage, alt: blog.title })}
                className="block w-full rounded-2xl overflow-hidden border border-white/10 mb-8 relative aspect-video group cursor-zoom-in">
                <img src={coverImage} alt={blog.title} loading="eager"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.02]" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                <span className="absolute bottom-3 right-3 bg-black/60 text-white text-[10px] font-bold px-2.5 py-1 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-sm">
                  View image
                </span>
              </button>
            )}

            {/* Key takeaways */}
            {blog.keyTakeaways && blog.keyTakeaways.length > 0 && (
              <div className="rounded-xl border border-primary/20 bg-primary/[0.06] p-5 mb-8">
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-primary mb-2">Key Takeaways</p>
                <ul className="space-y-2">
                  {blog.keyTakeaways.map((t, i) => (
                    <li key={i} className="flex gap-2.5 text-sm text-white/75 leading-relaxed">
                      <span className="mt-2 w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                      {t}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* ── ARTICLE BODY ─────────────────────────────────────────────── */}
            <div
              ref={contentRef}
              className="blog-content prose prose-invert max-w-none
                prose-headings:font-bold prose-headings:tracking-tight prose-headings:text-white prose-headings:leading-snug
                prose-h1:text-2xl prose-h1:mt-8 prose-h1:mb-3
                prose-h2:text-xl prose-h2:mt-8 prose-h2:mb-3 prose-h2:pt-6 prose-h2:border-t prose-h2:border-white/10
                prose-h3:text-lg prose-h3:mt-6 prose-h3:mb-2
                prose-p:text-base prose-p:leading-[1.9] prose-p:text-white/80 prose-p:my-4
                prose-a:text-primary prose-a:font-medium prose-a:no-underline hover:prose-a:underline
                prose-strong:text-white prose-strong:font-semibold
                prose-em:text-white/80
                prose-ul:text-white/80 prose-ul:my-4 prose-ul:pl-5
                prose-ol:text-white/80 prose-ol:my-4 prose-ol:pl-5
                prose-li:text-base prose-li:leading-relaxed prose-li:my-1.5
                prose-blockquote:border-l-[3px] prose-blockquote:border-primary prose-blockquote:bg-white/[0.03]
                  prose-blockquote:px-5 prose-blockquote:py-3 prose-blockquote:rounded-r-xl
                  prose-blockquote:not-italic prose-blockquote:text-white/75 prose-blockquote:my-6
                prose-code:text-primary prose-code:bg-white/8 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:text-[0.875em]
                prose-pre:bg-white/5 prose-pre:border prose-pre:border-white/10 prose-pre:rounded-xl prose-pre:my-6
                prose-img:rounded-xl prose-img:border prose-img:border-white/10 prose-img:my-6
                prose-hr:border-white/10 prose-hr:my-8"
              dangerouslySetInnerHTML={{ __html: blog.content }}
            />

            {/* Gallery */}
            {blog.gallery && blog.gallery.length > 0 && (
              <div className="grid grid-cols-2 gap-3 mt-8">
                {blog.gallery.map((img, i) => (
                  <button key={i} type="button"
                    onClick={() => setSelectedImage({ src: getImageUrl(img) || img, alt: `Gallery image ${i + 1}` })}
                    className="group relative aspect-[4/3] overflow-hidden rounded-xl border border-white/10 cursor-zoom-in">
                    <img src={getImageUrl(img) || img} alt={`Image ${i + 1}`} loading="lazy"
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                  </button>
                ))}
              </div>
            )}

            {/* Like / Dislike / Share */}
            <div className="flex items-center gap-3 mt-10 pt-8 border-t border-white/10 flex-wrap">
              <button onClick={handleLike}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-bold transition-all ${
                  liked ? "bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/20" : "bg-white/5 border-white/10 text-white/60 hover:border-primary/40 hover:text-white"
                }`}>
                <ThumbsUp className={`w-4 h-4 ${liked ? "fill-current" : ""}`} /> {likeCount}
              </button>
              <button onClick={handleDislike}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-bold transition-all ${
                  disliked ? "bg-destructive text-white border-destructive" : "bg-white/5 border-white/10 text-white/60 hover:border-destructive/40 hover:text-white"
                }`}>
                <ThumbsDown className={`w-4 h-4 ${disliked ? "fill-current" : ""}`} /> {dislikeCount}
              </button>
              <button onClick={handleShare}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-white/10 bg-white/5 text-white/60 hover:text-white text-sm font-bold transition-all">
                <Share2 className="w-4 h-4" /> Share
              </button>
              {/* Tags */}
              <div className="flex flex-wrap gap-2 ml-auto">
                {blog.tags?.map((tag, i) => (
                  <span key={i} className="px-3 py-1 rounded-lg border border-white/10 bg-white/5 text-[11px] font-medium text-white/50">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Comments */}
            <section className="mt-12 pt-10 border-t border-white/10">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-black text-white">Comments</h2>
                <span className="text-xs font-medium text-white/40 flex items-center gap-1.5">
                  <MessageCircle className="w-3.5 h-3.5" /> {comments.length}
                </span>
              </div>

              {/* Comment form */}
              <form onSubmit={handleComment} className="relative mb-8">
                <textarea value={commentText} onChange={e => setCommentText(e.target.value)}
                  maxLength={1000} rows={4}
                  placeholder="Share your thoughts on this article..."
                  className="w-full rounded-xl border border-white/10 bg-white/[0.04] p-4 pr-12 text-sm text-white/90 placeholder:text-white/25 resize-none outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/30 transition-colors" />
                <button type="submit" disabled={!commentText.trim() || commentLoading}
                  className="absolute bottom-3 right-3 w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground disabled:opacity-40 transition-opacity">
                  {commentLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                </button>
              </form>

              {/* Comment list */}
              <div className="space-y-4">
                {comments.map(c => (
                  <div key={c.id} className="flex gap-3 p-4 rounded-xl border border-white/8 bg-white/[0.02]">
                    <div className="w-8 h-8 rounded-full bg-white/10 overflow-hidden shrink-0">
                      {c.authorProfilePicture
                        ? <img src={c.authorProfilePicture} alt="" className="w-full h-full object-cover" />
                        : <User className="m-2 w-4 h-4 text-white/30" />}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-bold text-white/90">{c.authorName}</span>
                        <span className="text-[10px] text-white/30">{format(new Date(c.createdAt), "MMM d, yyyy")}</span>
                      </div>
                      <p className="text-sm text-white/70 leading-relaxed whitespace-pre-wrap">{c.content}</p>
                    </div>
                  </div>
                ))}
                {comments.length === 0 && (
                  <p className="text-center text-sm text-white/30 py-8 border border-dashed border-white/10 rounded-xl">
                    No comments yet. Be the first!
                  </p>
                )}
              </div>
            </section>

            {/* Related articles */}
            {relatedBlogs.length > 0 && (
              <section className="mt-12 pt-10 border-t border-white/10">
                <p className="text-[10px] font-black uppercase tracking-[0.25em] text-primary mb-1">More to read</p>
                <h2 className="text-xl font-black text-white mb-6">Related Articles</h2>
                <div className="grid gap-4 sm:grid-cols-3">
                  {relatedBlogs.map(r => (
                    <Link key={r.id} to={`/blog/${r.slug}`}
                      className="group rounded-xl overflow-hidden border border-white/10 bg-white/[0.02] hover:border-primary/30 transition-all hover:-translate-y-0.5">
                      <div className="aspect-[16/9] overflow-hidden">
                        <img src={r.featuredImage || r.coverImage || "/placeholder.svg"} alt={r.title} loading="lazy"
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                      </div>
                      <div className="p-3.5">
                        <p className="text-[9px] font-black uppercase tracking-widest text-primary mb-1">
                          {CATEGORY_LABELS[r.category] || r.category}
                        </p>
                        <h3 className="text-sm font-bold text-white/85 group-hover:text-primary leading-snug line-clamp-2">
                          {r.title}
                        </h3>
                      </div>
                    </Link>
                  ))}
                </div>
              </section>
            )}

          </article>

          {/* ── SIDEBAR ──────────────────────────────────────────────────── */}
          <aside className="hidden lg:block">
            <div className="sticky top-28 space-y-6">

              {/* Like widget */}
              <div className="rounded-xl border border-white/10 bg-white/[0.03] p-5 text-center">
                <button onClick={handleLike}
                  className={`mx-auto w-12 h-12 rounded-xl flex items-center justify-center transition-all ${
                    liked ? "bg-primary text-primary-foreground shadow-lg shadow-primary/30" : "bg-white/5 text-primary border border-white/10 hover:bg-white/10"
                  }`}>
                  <ThumbsUp className={`w-5 h-5 ${liked ? "fill-current" : ""}`} />
                </button>
                <p className="text-2xl font-black text-white mt-3">{likeCount}</p>
                <p className="text-[10px] text-white/35 font-medium uppercase tracking-wider mt-1">Reactions</p>
              </div>

              {/* ToC */}
              {toc.length > 0 && (
                <div className="rounded-xl border border-white/10 bg-white/[0.03] p-5">
                  <p className="text-[10px] font-black uppercase tracking-[0.25em] text-white/40 mb-4">In this article</p>
                  <nav className="space-y-1">
                    {toc.map(item => (
                      <a key={item.id} href={`#${item.id}`}
                        onClick={e => { e.preventDefault(); document.getElementById(item.id)?.scrollIntoView({ behavior: "smooth" }); }}
                        className={`flex items-start gap-2 py-1 text-sm transition-all rounded-lg px-2 ${
                          activeId === item.id
                            ? "text-primary font-semibold bg-primary/5"
                            : "text-white/45 hover:text-white/80"
                        } ${item.level >= 3 ? "pl-5" : ""}`}>
                        {activeId === item.id && <span className="mt-1.5 w-1 h-1 rounded-full bg-primary shrink-0" />}
                        <span className="leading-snug">{item.text}</span>
                      </a>
                    ))}
                  </nav>
                </div>
              )}

            </div>
          </aside>

        </div>
      </main>

      {/* Image lightbox */}
      <Dialog open={!!selectedImage} onOpenChange={open => !open && setSelectedImage(null)}>
        <DialogContent className="max-w-4xl border-0 bg-black/95 p-2 shadow-2xl">
          <DialogTitle className="sr-only">Article image</DialogTitle>
          {selectedImage && (
            <img src={selectedImage.src} alt={selectedImage.alt}
              className="max-h-[85vh] w-full rounded-lg object-contain" />
          )}
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
}

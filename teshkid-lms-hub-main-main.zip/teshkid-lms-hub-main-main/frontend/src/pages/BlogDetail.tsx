import React, { useEffect, useState, useRef } from "react";
import { useParams, Link } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import api from "@/lib/api";
import { updateMetaTags } from "@/lib/seo";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  ArrowLeft,
  Heart,
  ThumbsDown,
  ChevronDown,
  ChevronUp,
  Share2,
  Search,
  ThumbsUp,
  Clock,
  User,
  ExternalLink,
  Loader2,
  Eye,
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

interface Blog {
  id: string;
  title: string;
  content: string;
  category: string;
  featuredImage?: string;
  coverImage?: string;
  tags: string[];
  viewCount: number;
  likeCount?: number;
  dislikeCount?: number;
  userLiked?: boolean;
  userDisliked?: boolean;
  createdAt: string;
  updatedAt: string;
  status: string;
  description?: string;
  authorName?: string;
  authorProfilePicture?: string;
  keyTakeaways?: string[];
  contentBlocks?: any[];
}

interface TOCItem {
  id: string;
  text: string;
  level: number;
}

const categoryLabels: Record<string, string> = {
  "admin-thoughts": "Admin Thoughts",
  "mcrypto-analysis": "MCrypto Analysis",
  "previous-day": "Daily Digest",
  "trading-ideas": "Trading Strategies",
};

const categoryColors: Record<string, string> = {
  "admin-thoughts": "bg-blue-500",
  "mcrypto-analysis": "bg-indigo-600",
  "previous-day": "bg-emerald-500",
  "trading-ideas": "bg-amber-500",
};

export default function BlogDetail() {
  const { slug } = useParams<{ slug: string }>();
  const [blog, setBlog] = useState<Blog | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [liked, setLiked] = useState(false);
  const [disliked, setDisliked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [dislikeCount, setDislikeCount] = useState(0);
  const [toc, setToc] = useState<TOCItem[]>([]);
  const [activeId, setActiveId] = useState<string>("");
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchBlog = async () => {
      try {
        setLoading(true);
        const res = await api.get(`/blogs/${slug}`);
        const data = res.data;

        const getArrayField = (field: any) => {
          if (!field) return [];
          if (typeof field === "string") {
            try {
              return JSON.parse(field);
            } catch {
              return [];
            }
          }
          return Array.isArray(field) ? field : [];
        };

        const processedBlog = {
          ...data,
          keyTakeaways: getArrayField(data.keyTakeaways),
          gallery: getArrayField(data.gallery),
          tags: getArrayField(data.tags)
        };

        setBlog(processedBlog);
        setLikeCount(data.likeCount || 0);
        setDislikeCount(data.dislikeCount || 0);
        setLiked(data.userLiked || false);
        setDisliked(data.userDisliked || false);
        setError(null);

        const description = processedBlog.description ||
          processedBlog.content.replace(/<[^>]*>/g, "").substring(0, 160) ||
          "Professional crypto analysis and trading insights.";
        const image = processedBlog.featuredImage || processedBlog.coverImage;
        updateMetaTags(
          `${processedBlog.title} | Teshkid Alpha`,
          description,
          `${window.location.origin}/blog/${slug}`,
          image
        );
      } catch (err) {
        setError("Article not found");
        console.error("Failed to fetch blog", err);
      } finally {
        setLoading(false);
      }
    };
    if (slug) {
      fetchBlog();
    }
  }, [slug]);

  useEffect(() => {
    if (blog?.content && contentRef.current) {
      const headings = contentRef.current.querySelectorAll("h2, h3");
      const items: TOCItem[] = [];
      headings.forEach((heading, index) => {
        const id = `heading-${index}`;
        heading.id = id;
        items.push({
          id,
          text: heading.textContent || "",
          level: parseInt(heading.tagName[1])
        });
      });
      setToc(items);
    }
  }, [blog]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveId(entry.target.id);
          }
        });
      },
      { rootMargin: "-100px 0px -60% 0px" }
    );

    const headings = contentRef.current?.querySelectorAll("h2, h3");
    headings?.forEach((h) => observer.observe(h));

    return () => {
      headings?.forEach((h) => observer.unobserve(h));
    };
  }, [toc]);

  const handleLike = async () => {
    try {
      if (liked) {
        const res = await api.post(`/blogs/${blog?.id}/unlike`);
        setLiked(false);
        setLikeCount(res.data.likeCount || 0);
      } else {
        const res = await api.post(`/blogs/${blog?.id}/like`);
        setLiked(true);
        setDisliked(false);
        setLikeCount(res.data.likeCount || 0);
        setDislikeCount(res.data.dislikeCount || 0);
      }
    } catch (err) {
      console.error("Failed to update like", err);
    }
  };

  const handleDislike = async () => {
    try {
      if (disliked) {
        const res = await api.post(`/blogs/${blog?.id}/undislike`);
        setDisliked(false);
        setDislikeCount(res.data.dislikeCount || 0);
      } else {
        const res = await api.post(`/blogs/${blog?.id}/dislike`);
        setDisliked(true);
        setLiked(false);
        setDislikeCount(res.data.dislikeCount || 0);
        setLikeCount(res.data.likeCount || 0);
      }
    } catch (err) {
      console.error("Failed to update dislike", err);
    }
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success("Intelligence Link Copied", {
      description: "Direct URL shared to your system clipboard."
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#05070a] flex flex-col items-center justify-center space-y-6">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
        <p className="text-white/40 font-black uppercase tracking-[0.3em] text-[10px] animate-pulse">Establishing Secure Uplink</p>
      </div>
    );
  }

  if (error || !blog) {
    return (
      <div className="min-h-screen bg-[#05070a]">
        <Navbar />
        <div className="container mx-auto px-4 py-40 text-center">
          <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-8">
            <ArrowLeft className="w-8 h-8 text-white/20" />
          </div>
          <h2 className="text-4xl font-black mb-6">Signal Lost</h2>
          <Button asChild className="rounded-2xl h-14 px-10 font-black uppercase tracking-widest">
            <Link to="/"><ArrowLeft className="mr-3 h-5 w-5" /> All Signals</Link>
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  const image = blog.featuredImage || blog.coverImage;

  return (
    <div className="min-h-screen bg-[#05070a] text-white selection:bg-primary/30">
      <Navbar />

      <div className="fixed inset-0 overflow-hidden pointer-events-none opacity-20">
        <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] bg-primary/20 rounded-full blur-[120px]" />
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/10 rounded-full blur-[100px]" />
      </div>

      <main className="relative container mx-auto px-4 pt-32 sm:pt-40 pb-20 max-w-[1400px]">

        <Link to="/" className="inline-flex items-center gap-3 text-white/40 hover:text-primary transition-all mb-10 group font-black uppercase tracking-widest text-[10px]">
          <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors border border-white/20">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          </div>
          Back to Terminal
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-16">

          <div className="space-y-12">

            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <Badge className={`${categoryColors[blog.category] || "bg-primary"} text-white border-none py-1.5 px-4 rounded-full text-[10px] font-black uppercase tracking-widest shadow-2xl`}>
                  {categoryLabels[blog.category] || blog.category}
                </Badge>
                <span className="text-white/40 text-xs font-black uppercase tracking-widest">
                  {format(new Date(blog.createdAt), "MMMM d, yyyy")}
                </span>
              </div>

              <h1 className="text-4xl md:text-6xl font-black tracking-tight leading-[1.05] text-balance">
                {blog.title}
              </h1>

              <div className="flex flex-wrap items-center gap-8 pt-8 border-b border-white/5 pb-10">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full border-2 border-primary/30 p-0.5 overflow-hidden bg-white/5 shadow-xl shadow-primary/5">
                    {blog.authorProfilePicture ? (
                      <img src={blog.authorProfilePicture} alt={blog.authorName} className="w-full h-full object-cover rounded-full" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-white/5">
                        <User className="w-6 h-6 text-white/20" />
                      </div>
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-black text-white">{blog.authorName || "Teshkid is Crypto"}</p>
                    <p className="text-[10px] text-white/40 font-black uppercase tracking-widest">Market Analyst</p>
                  </div>
                </div>

                <div className="h-10 w-px bg-white/10 hidden sm:block"></div>

                <div className="flex items-center gap-6 text-[10px] font-black uppercase tracking-widest text-white/40">
                  <span className="flex items-center gap-2"><Clock className="w-4 h-4 text-primary" /> 6 min read</span>
                  <span className="flex items-center gap-2"><Eye className="w-4 h-4 text-primary" /> {blog.viewCount} Signals</span>
                </div>
              </div>
            </div>

            {image && (
              <div className="rounded-[2.5rem] overflow-hidden border border-white/20 shadow-2xl relative aspect-video group">
                <img
                  src={image}
                  alt={blog.title}
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#05070a]/60 to-transparent" />
              </div>
            )}

            <div
              ref={contentRef}
              className="prose prose-invert prose-lg max-w-none 
                prose-headings:font-black prose-headings:tracking-tighter
                prose-h2:text-4xl prose-h2:mt-16 prose-h2:mb-8 prose-h2:text-white
                prose-h3:text-2xl prose-h3:mt-10 prose-h3:mb-6 prose-h3:text-white/80
                prose-p:text-white/60 prose-p:leading-[1.8] prose-p:mb-10 prose-p:font-medium
                prose-img:rounded-[2rem] prose-img:border prose-img:border-white/20 prose-img:my-16
                prose-strong:text-white prose-strong:font-black
                prose-ul:list-disc prose-ul:pl-8 prose-ul:mb-10 prose-ul:marker:text-primary
                prose-blockquote:border-l-[6px] prose-blockquote:border-primary/50 prose-blockquote:bg-white/5 prose-blockquote:p-10 prose-blockquote:rounded-[2rem] prose-blockquote:italic prose-blockquote:text-white/80 prose-blockquote:my-12 prose-blockquote:border-white/20"
              style={{
                '--tw-prose-body': 'rgba(255, 255, 255, 0.6)',
                '--tw-prose-headings': 'white',
              } as React.CSSProperties}
              dangerouslySetInnerHTML={{ __html: blog.content }}
            />

            <div className="pt-16 border-t border-white/5 flex flex-wrap items-center justify-between gap-10">
              <div className="flex items-center gap-4">
                <Button
                  variant={liked ? "default" : "ghost"}
                  className={`rounded-2xl h-16 px-8 gap-3 font-black uppercase tracking-widest text-xs border border-white/20 transition-all ${liked ? 'shadow-xl shadow-primary/20 scale-105' : 'bg-white/5 hover:bg-white/10'}`}
                  onClick={handleLike}
                >
                  <ThumbsUp className={`w-5 h-5 ${liked ? "fill-current" : "text-white/40"}`} />
                  {likeCount}
                </Button>
                <Button
                  variant={disliked ? "destructive" : "ghost"}
                  className={`rounded-2xl h-16 px-8 gap-3 font-black uppercase tracking-widest text-xs border border-white/20 transition-all ${disliked ? 'shadow-xl shadow-destructive/20 scale-105' : 'bg-white/5 hover:bg-white/10'}`}
                  onClick={handleDislike}
                >
                  <ThumbsDown className={`w-5 h-5 ${disliked ? "fill-current" : "text-white/40"}`} />
                  {dislikeCount}
                </Button>
                <Button
                  variant="ghost"
                  className="rounded-2xl h-16 w-16 border border-white/20 bg-white/5 hover:bg-white/10 transition-all"
                  onClick={handleShare}
                >
                  <Share2 className="w-5 h-5 text-white/40" />
                </Button>
              </div>

              <div className="flex flex-wrap gap-3">
                {blog.tags?.map((tag, idx) => (
                  <Badge key={idx} variant="outline" className="rounded-xl px-4 py-2 border-white/20 bg-white/5 text-[10px] font-black uppercase tracking-[0.1em] text-white/40 hover:text-primary hover:border-primary/30 transition-all cursor-pointer">
                    #{tag}
                  </Badge>
                ))}
              </div>
            </div>

          </div>

          <aside className="space-y-12">
            <div className="sticky top-40 space-y-12">

              <div className="bg-white/5 border border-white/20 backdrop-blur-xl rounded-[2rem] p-8 text-center relative overflow-hidden group">
                <div className="absolute inset-0 bg-primary/10 opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
                <div
                  className={`mx-auto w-20 h-20 rounded-2xl flex items-center justify-center cursor-pointer transition-all duration-500 relative z-10 ${liked ? 'bg-primary text-black shadow-2xl shadow-primary/50 rotate-3' : 'bg-white/5 hover:bg-white/10 text-primary border border-white/20'}`}
                  onClick={handleLike}
                >
                  <ThumbsUp className={`w-10 h-10 ${liked ? 'fill-current' : ''}`} />
                </div>
                <div className="mt-8 relative z-10">
                  <p className="text-4xl font-black text-white tracking-tighter tabular-nums">{likeCount}</p>
                  <p className="text-[10px] text-white/40 font-black uppercase tracking-[0.2em] mt-2">Verified Signals</p>
                </div>
              </div>

              <div className="space-y-8">
                <h4 className="flex items-center gap-3 font-black text-[10px] uppercase tracking-[0.3em] text-white/30">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary shadow-[0_0_10px_rgba(20,184,166,1)]" />
                  Mission Profile
                </h4>
                <div className="relative pl-6 space-y-6">
                  <div className="absolute left-0 top-0 bottom-0 w-[1px] bg-white/10" />
                  {toc.map((item) => (
                    <a
                      key={item.id}
                      href={`#${item.id}`}
                      onClick={(e) => {
                        e.preventDefault();
                        document.getElementById(item.id)?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className={`block text-xs font-black uppercase tracking-widest transition-all hover:text-white relative group ${activeId === item.id ? 'text-primary translate-x-2' : 'text-white/40'
                        }`}
                    >
                      {activeId === item.id && (
                        <div className="absolute -left-[27px] top-1/2 -translate-y-1/2 w-1.5 h-1.5 bg-primary rounded-full shadow-[0_0_10px_rgba(20,184,166,1)]" />
                      )}
                      {item.text}
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </aside>

        </div>
      </main>

      <Footer />
    </div>
  );
}

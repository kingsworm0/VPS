import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import api from "@/lib/api";
import { toast } from "sonner";
import {
  Plus,
  Trash2,
  Edit,
  PlayCircle,
  ChevronLeft,
  DollarSign,
  Video,
  Clock,
  BarChart3,
  Layers,
  ArrowRight
} from "lucide-react";
import { ConfirmDialog } from "@/components/ui/ConfirmDialog";
import { Badge } from "@/components/ui/badge";
import { Linkify } from "@/components/ui/Linkify";

export default function AdminCourseDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [course, setCourse] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [confirmState, setConfirmState] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    onConfirm: () => void;
    variant?: "default" | "destructive";
  }>({
    isOpen: false,
    title: "",
    description: "",
    onConfirm: () => { },
  });

  const fetch = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const res = await api.get(`/admin/courses/${id}`);
      setCourse(res.data);
    } catch (err) {
      console.error(err);
      toast.error("Could not load course details.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetch();
  }, [id]);

  const deleteLesson = async (lessonId: string) => {
    setConfirmState({
      isOpen: true,
      title: "Delete Content Part",
      description: "Are you sure you want to delete this part of the course? This action cannot be undone.",
      variant: "destructive",
      onConfirm: async () => {
        try {
          await api.delete(`/admin/lessons/${lessonId}`);
          toast.success("Part removed successfully.");
          fetch();
        } catch (err) {
          console.error(err);
          toast.error("Could not delete part.");
        }
      },
    });
  };

  if (loading)
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-muted-foreground font-bold italic animate-pulse">Scanning Curriculum Assets...</p>
      </div>
    );

  if (!course)
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="p-10 text-center border-dashed border-2">
          <p className="text-xl font-bold mb-4">Course not found</p>
          <Button onClick={() => navigate("/admin/courses")}>Back to Inventory</Button>
        </Card>
      </div>
    );

  // Flatten modules for "Parts" view
  const allParts = course.modules.flatMap((m: any) => m.lessons.map((l: any) => ({ ...l, moduleTitle: m.title })));

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="pt-32 sm:pt-40 pb-20 container mx-auto px-4 max-w-6xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-10 gap-4">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="icon"
              onClick={() => navigate("/admin/courses")}
              className="rounded-full h-12 w-12 border-border/50 hover:bg-primary/10 hover:border-primary/50 transition-all"
            >
              <ChevronLeft className="w-6 h-6" />
            </Button>
            <div>
              <h1 className="text-4xl font-black gradient-text">{course.title}</h1>
              <div className="flex items-center gap-3 mt-1">
                <Badge variant="secondary" className="bg-primary/10 text-primary border-none font-bold">
                  {course.level}
                </Badge>
                <span className="text-muted-foreground text-sm font-medium flex items-center gap-1">
                  <Clock className="w-4 h-4" /> {course.duration}
                </span>
                <span className="text-muted-foreground text-sm font-medium flex items-center gap-1">
                  <Layers className="w-4 h-4" /> {allParts.length} Parts
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button
              onClick={() => navigate(`/admin/courses/${id}/edit`)}
              className="gap-2 h-12 px-6 rounded-xl shadow-lg shadow-primary/20 text-lg font-bold"
            >
              <Edit className="w-5 h-5" />
              Manage Configuration
            </Button>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Sidebar / Overview */}
          <div className="space-y-6">
            <Card className="border-none shadow-2xl bg-card/50 backdrop-blur-sm overflow-hidden rounded-2xl">
              <div className="aspect-video w-full relative">
                <img src={course.bannerUrl || course.thumbnail} alt="" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-6">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-8 h-8 text-primary font-black" />
                    <span className="text-4xl font-black text-white">{Number(course.price).toFixed(2)}</span>
                    <span className="text-xs font-bold text-white/60 mb-1 ml-1 uppercase tracking-widest">USD</span>
                  </div>
                </div>
              </div>
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center justify-between py-2 border-b border-border/50">
                  <span className="text-muted-foreground font-bold text-xs uppercase tracking-widest">Instructor</span>
                  <span className="font-black text-primary">{course.instructor}</span>
                </div>
                <div className="flex items-center justify-between py-2 border-b border-border/50">
                  <span className="text-muted-foreground font-bold text-xs uppercase tracking-widest">Active Members</span>
                  <span className="font-black">{course.students || 0} Students</span>
                </div>
                <div className="pt-2">
                  <p className="text-sm leading-relaxed text-muted-foreground line-clamp-6 whitespace-pre-wrap">
                    <Linkify text={course.description} />
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-xl bg-primary/5 rounded-2xl p-6 border border-primary/10">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center shadow-lg shadow-primary/30">
                  <BarChart3 className="w-5 h-5 text-primary-foreground" />
                </div>
                <div>
                  <h4 className="font-black text-lg">Performance Index</h4>
                  <p className="text-[10px] uppercase font-black tracking-tighter text-muted-foreground">Course Health Metrics</p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground italic mb-4">
                This course is performing within the top 15% of academy assets.
              </p>
              <Button variant="outline" className="w-full rounded-xl border-primary/30 text-primary hover:bg-primary/10">
                View Analytics <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Card>
          </div>

          {/* Parts List */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-2xl font-black flex items-center gap-2">
                <Video className="w-6 h-6 text-emerald-500" /> Curriculum Parts
              </h3>
              <Badge className="bg-emerald-500/10 text-emerald-500 border-none px-3 font-bold">
                {allParts.length} Videos Active
              </Badge>
            </div>

            {allParts.length === 0 ? (
              <Card className="p-20 text-center border-dashed border-2 bg-muted/5">
                <p className="text-muted-foreground font-bold">No content parts added yet.</p>
                <Button onClick={() => navigate(`/admin/courses/${id}/edit`)} className="mt-4 gap-2">
                  <Plus className="w-4 h-4" /> Add First Part
                </Button>
              </Card>
            ) : (
              <div className="grid gap-4">
                {allParts.map((l: any, idx: number) => (
                  <Card
                    key={l.id}
                    className="group border-border/50 bg-card/40 backdrop-blur-sm hover:border-primary/50 transition-all hover:shadow-xl hover:shadow-primary/5 rounded-2xl overflow-hidden"
                  >
                    <CardContent className="p-0">
                      <div className="flex items-center gap-4 p-4">
                        <div className="w-12 h-12 rounded-xl bg-muted/50 flex flex-col items-center justify-center border border-border shrink-0 group-hover:bg-primary/10 group-hover:border-primary/30 transition-colors">
                          <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest leading-none">Part</span>
                          <span className="text-xl font-black text-primary leading-none mt-1">{idx + 1}</span>
                        </div>

                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-lg truncate group-hover:text-primary transition-colors">{l.title}</h4>
                          <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                            <span className="flex items-center gap-1 font-medium">
                              <Clock className="w-3 h-3 text-emerald-500" /> {l.duration}
                            </span>
                            {l.videoUrl && (
                              <span className="text-[10px] font-black uppercase text-emerald-600 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                                Video Linked
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity pr-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => navigate(`/admin/courses/${id}/edit`)}
                            className="h-10 w-10 text-primary hover:bg-primary/10 rounded-xl"
                          >
                            <Edit className="w-5 h-5" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteLesson(l.id)}
                            className="h-10 w-10 text-destructive hover:bg-destructive/10 rounded-xl"
                          >
                            <Trash2 className="w-5 h-5" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                <Button
                  onClick={() => navigate(`/admin/courses/${id}/edit`)}
                  variant="ghost"
                  className="w-full border-2 border-dashed border-border py-10 h-auto rounded-2xl hover:bg-primary/5 hover:border-primary/30 transition-all gap-2"
                >
                  <Plus className="w-6 h-6 text-primary" />
                  <span className="font-black text-muted-foreground group-hover:text-primary text-lg">Append Content Parts</span>
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
      <ConfirmDialog
        isOpen={confirmState.isOpen}
        onOpenChange={(open) => setConfirmState(prev => ({ ...prev, isOpen: open }))}
        title={confirmState.title}
        description={confirmState.description}
        onConfirm={confirmState.onConfirm}
        variant={confirmState.variant}
      />
    </div>
  );
}

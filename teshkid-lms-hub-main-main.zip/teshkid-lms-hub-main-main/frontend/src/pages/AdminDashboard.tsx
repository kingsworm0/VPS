import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/context/AuthContext";
import AdminBlogManager from "@/components/dashboard/AdminBlogManager";
import { ConfirmDialog } from "@/components/ui/ConfirmDialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import {
  Users,
  BookOpen,
  GraduationCap,
  Activity,
  TrendingUp,
  Mail,
  Check,
  X,
  Clock,
  Eye,
  MessageSquare,
  Settings,
  DollarSign,
  Trash2,
  Video,
} from "lucide-react";

interface SystemAnalytics {
  totalStudents: number;
  totalCourses: number;
  totalEnrollments: number;
  activeStudents: number;
  averageCompletionRate: number;
  popularCourses: Array<{
    id: string;
    title: string;
    enrollmentCount: number;
  }>;
  pendingEnrollments?: number;
  forfeitedEnrollments?: number;
  totalRevenue?: number;
  recentActivity?: Array<any>;
}

interface Enrollment {
  id: string;
  userId: string;
  courseId: string;
  status: string;
  createdAt: string;
  user: {
    name: string;
    email: string;
    profilePicture?: string;
    bio?: string;
  };
  course: { title: string };
  studentMessage?: string;
}

interface StudentProgress {
  id: string;
  name: string;
  email: string;
  profilePicture?: string;
  enrolledCourses: number;
  completedLessons: number;
  totalLessons: number;
  progressPercentage: number;
}

export default function AdminDashboard() {
  const { user, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [analytics, setAnalytics] = useState<SystemAnalytics | null>(null);
  const [students, setStudents] = useState<StudentProgress[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<StudentProgress[]>(
    [],
  );
  const [searchQuery, setSearchQuery] = useState("");
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedEnrollment, setSelectedEnrollment] = useState<Enrollment | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [confirmState, setConfirmState] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    onConfirm: () => void;
    variant?: "default" | "destructive";
  }>({
    isOpen: false,
    title: "",
    description: "",
    onConfirm: () => { },
  });

  useEffect(() => {
    if (!authLoading && (!user || user.role !== "ADMIN")) {
      navigate("/");
      return;
    }

    if (user?.role === "ADMIN") {
      fetchData();
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (searchQuery) {
      setFilteredStudents(
        students.filter(
          (s) =>
            s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            s.email.toLowerCase().includes(searchQuery.toLowerCase()),
        ),
      );
    } else {
      setFilteredStudents(students);
    }
  }, [searchQuery, students]);

  const fetchData = async () => {
    try {
      setLoading(true);
      // Fetch data from multiple endpoints
      // Note: We are combining logic from both dashboards here.
      // Ideally these endpoints returns consistent structures.
      const [analyticsRes, studentsRes, enrollmentsRes, statsRes] = await Promise.all([
        api.get("/admin/progress/analytics/system"),
        api.get("/admin/progress/students/progress"),
        api.get("/admin/enrollments/pending"),
        api.get("/admin/stats") // Fetch original dashboard stats
      ]);

      const mergedAnalytics = {
        ...analyticsRes.data,
        ...statsRes.data // Merge revenue and recent activity
      };

      setAnalytics(mergedAnalytics);
      setStudents(studentsRes.data);
      setFilteredStudents(studentsRes.data);
      setEnrollments(enrollmentsRes.data);
    } catch (error) {
      console.error("Failed to load data:", error);
      toast.error("Failed to load dashboard data");
    } finally {
      setLoading(false);
    }
  };

  const handleEnrollmentStatus = async (id: string, status: 'APPROVED' | 'REJECTED') => {
    try {
      await api.put(`/admin/enrollments/${id}/status`, { status });
      toast.success(`Enrollment ${status.toLowerCase()} successfully`);
      // Update local state
      setEnrollments(prev => prev.filter(e => e.id !== id));
      // Refresh analytics to update stats
      fetchData();
    } catch (error) {
      console.error(error);
      toast.error(`Failed to update enrollment`);
    }
  };

  const handleDeleteEnrollment = async (enrollmentId: string) => {
    setConfirmState({
      isOpen: true,
      title: "Delete Enrollment",
      description: "Are you sure you want to delete this enrollment record? This action cannot be undone.",
      variant: "destructive",
      onConfirm: async () => {
        try {
          setDeletingId(enrollmentId);
          await api.delete(`/admin/enrollments/${enrollmentId}`);
          // Refresh stats after deletion
          fetchData();
          setDeletingId(null);
        } catch (err) {
          console.error("Failed to delete enrollment:", err);
          toast.error("Failed to delete enrollment");
          setDeletingId(null);
        }
      },
    });
  };


  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        Loading...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <div className="flex-1 container mx-auto px-4 pt-32 sm:pt-40 pb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="font-display text-4xl font-bold tracking-tight">
              Teshkid is <span className="text-primary italic">Crypto</span>
            </h1>
            <p className="text-muted-foreground font-medium">Management & Analytics Dashboard</p>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              className="gap-2 border-primary/20 hover:bg-primary/5 transition-colors"
              onClick={() => navigate("/admin/profile")}
            >
              <Settings className="w-4 h-4" />
              Settings
            </Button>
            <Button
              variant="default"
              className="gap-2"
              onClick={() => navigate("/admin/courses/new")}
            >
              <DollarSign className="w-4 h-4" />
              New Course
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 border-b border-border/50 overflow-x-auto">
          <button
            onClick={() => setActiveTab("overview")}
            className={`pb-3 px-4 whitespace-nowrap font-medium transition-colors border-b-2 text-sm ${activeTab === "overview"
              ? "border-primary text-primary font-bold"
              : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab("students")}
            className={`pb-3 px-4 whitespace-nowrap font-medium transition-colors border-b-2 text-sm ${activeTab === "students"
              ? "border-primary text-primary font-bold"
              : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
          >
            Student Progress
          </button>
          <button
            onClick={() => setActiveTab("enrollments")}
            className={`pb-3 px-4 whitespace-nowrap font-medium transition-colors border-b-2 text-sm relative ${activeTab === "enrollments"
              ? "border-primary text-primary font-bold"
              : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
          >
            Enrollments
            {enrollments.length > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] text-destructive-foreground font-bold">
                {enrollments.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab("blog")}
            className={`pb-3 px-4 whitespace-nowrap font-medium transition-colors border-b-2 text-sm ${activeTab === "blog"
              ? "border-primary text-primary font-bold"
              : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
          >
            Blog Management
          </button>
          <button
            onClick={() => navigate("/admin/live-sessions")}
            className="pb-3 px-4 whitespace-nowrap flex items-center gap-1.5 font-medium text-sm text-muted-foreground hover:text-primary transition-colors border-b-2 border-transparent"
          >
            <Video className="w-3.5 h-3.5" />
            Live Sessions
          </button>
        </div>

        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div>
            {/* System Analytics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {/* Quick Actions Card moved to top for better access */}
              <Card className="md:col-span-2 lg:col-span-4 bg-card/50 backdrop-blur-sm border-border/50">
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-wrap gap-2">
                  <Button
                    variant="outline"
                    onClick={() => navigate("/admin/courses/new")}
                  >
                    Create New Course
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => navigate("/admin/users")}
                  >
                    Manage Users
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => navigate("/admin/messages")}
                  >
                    View Messages
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => navigate("/admin/content")}
                  >
                    Manage Content
                  </Button>
                </CardContent>
              </Card>

              <Card
                className="cursor-pointer hover:shadow-lg transition-shadow bg-card/50 backdrop-blur-sm border-border/50"
                onClick={() => navigate("/admin/users")}
              >
                <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
                  <CardTitle className="text-sm font-medium">
                    Total Students
                  </CardTitle>
                  <Users className="w-4 h-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {analytics?.totalStudents || 0}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    +20.1% from last month
                  </p>
                </CardContent>
              </Card>

              <Card
                className="cursor-pointer hover:shadow-lg transition-shadow bg-card/50 backdrop-blur-sm border-border/50"
                onClick={() => navigate("/admin/courses")}
              >
                <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
                  <CardTitle className="text-sm font-medium">
                    Active Courses
                  </CardTitle>
                  <BookOpen className="w-4 h-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {analytics?.totalCourses || 0}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    +2 new since last week
                  </p>
                </CardContent>
              </Card>

              <Card
                className="cursor-pointer hover:shadow-lg transition-shadow bg-card/50 backdrop-blur-sm border-border/50"
                onClick={() => setActiveTab("enrollments")}
              >
                <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
                  <CardTitle className="text-sm font-medium">
                    Enrollments
                  </CardTitle>
                  <GraduationCap className="w-4 h-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {analytics?.totalEnrollments || 0}
                  </div>
                  {analytics?.pendingEnrollments !== undefined && analytics.pendingEnrollments > 0 ? (
                    <p className="text-xs text-destructive font-bold mt-1">
                      {analytics.pendingEnrollments} pending approval
                    </p>
                  ) : (
                    <p className="text-xs text-muted-foreground mt-1">
                      +19% from last month
                    </p>
                  )}
                </CardContent>
              </Card>

              <Card
                className="hover:shadow-lg transition-shadow bg-card/50 backdrop-blur-sm border-border/50"
              >
                <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
                  <CardTitle className="text-sm font-medium">
                    Forfeited Courses
                  </CardTitle>
                  <Trash2 className="w-4 h-4 text-destructive" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-destructive">
                    {analytics?.forfeitedEnrollments || 0}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Canceled by students
                  </p>
                </CardContent>
              </Card>

              <Card
                className="cursor-pointer hover:shadow-lg transition-shadow bg-card/50 backdrop-blur-sm border-border/50"
              >
                <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
                  <CardTitle className="text-sm font-medium">
                    Total Revenue
                  </CardTitle>
                  <DollarSign className="w-4 h-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    ${analytics?.totalRevenue || 0}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    +12% from last month
                  </p>
                </CardContent>
              </Card>

              <Card
                className="cursor-pointer hover:shadow-lg transition-shadow bg-card/50 backdrop-blur-sm border-border/50"
                onClick={() => setActiveTab("students")}
              >
                <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
                  <CardTitle className="text-sm font-medium">
                    Avg Completion
                  </CardTitle>
                  <TrendingUp className="w-4 h-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {(Number(analytics?.averageCompletionRate) || 0).toFixed(1)}%
                  </div>
                </CardContent>
              </Card>

              <Card className="md:col-span-1 lg:col-span-1 bg-card/50 backdrop-blur-sm border-border/50">
                <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
                  <CardTitle className="text-sm font-medium">
                    Active Students
                  </CardTitle>
                  <Activity className="w-4 h-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {analytics?.activeStudents || 0}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Currently learning
                  </p>
                </CardContent>
              </Card>

            </div>

            <div className="grid lg:grid-cols-2 gap-8">
              {/* Recent Activity */}
              <Card className="bg-card/50 backdrop-blur-sm border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5" />
                    Recent Enrollments
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analytics?.recentActivity?.map((enrollment: any) => (
                      <div
                        key={enrollment.id}
                        className="flex items-center justify-between pb-4 border-b border-border last:border-0 last:pb-0 group hover:bg-muted/30 p-2 rounded-lg transition-colors"
                      >
                        <Link
                          to={`/admin/student/${enrollment.userId}`}
                          className="flex-1 hover:text-primary transition-colors"
                        >
                          <div>
                            <p className="font-semibold text-sm">
                              {enrollment.user.name}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {enrollment.user.email}
                            </p>
                          </div>
                        </Link>
                        <div className="text-right mr-3">
                          <p className="text-sm font-medium">
                            {enrollment.course.title}
                          </p>
                          <p className="text-xs text-muted-foreground font-mono">
                            {new Date(enrollment.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive hover:bg-destructive/10"
                          onClick={() => handleDeleteEnrollment(enrollment.id)}
                          disabled={deletingId === enrollment.id}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                    {(!analytics?.recentActivity || analytics.recentActivity.length === 0) && (
                      <p className="text-sm text-muted-foreground">No recent activity.</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Most Popular Courses */}
              <Card className="bg-card/50 backdrop-blur-sm border-border/50">
                <CardHeader>
                  <CardTitle>Most Popular Courses</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {(analytics?.popularCourses || []).map((course, idx) => (
                      <div key={course.id} className="flex items-center gap-4">
                        <div className="flex-1">
                          <div className="flex justify-between mb-2">
                            <span className="font-medium">{course.title}</span>
                            <span className="text-sm text-muted-foreground">
                              {course.enrollmentCount} enrollments
                            </span>
                          </div>
                          <Progress
                            value={
                              (Number(course.enrollmentCount) /
                                (Number(analytics?.totalEnrollments) || 1)) *
                              100
                            }
                          />
                        </div>
                      </div>
                    ))}
                    {(!analytics?.popularCourses || analytics.popularCourses.length === 0) && (
                      <p className="text-sm text-muted-foreground">No courses available.</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Students Tab */}
        {activeTab === "students" && (
          <div>
            {/* Search Bar */}
            <div className="mb-6">
              <Input
                placeholder="Search students by name or email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full"
              />
            </div>

            {/* Students List */}
            <Card>
              <CardHeader>
                <CardTitle>Student Progress Overview</CardTitle>
              </CardHeader>
              <CardContent>
                {filteredStudents.length === 0 ? (
                  <p className="text-muted-foreground">No students found</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b bg-muted/30">
                          <th className="text-left py-4 px-4 font-semibold text-sm">
                            <div className="flex items-center gap-2">
                              <Users className="w-4 h-4" />
                              Student
                            </div>
                          </th>
                          <th className="text-left py-4 px-4 font-semibold text-sm">
                            <div className="flex items-center gap-2">
                              <Mail className="w-4 h-4" />
                              Email
                            </div>
                          </th>
                          <th className="text-center py-4 px-4 font-semibold text-sm">
                            Courses
                          </th>
                          <th className="text-center py-4 px-4 font-semibold text-sm">
                            Progress
                          </th>
                          <th className="text-right py-4 px-4 font-semibold text-sm text-muted-foreground">
                            Details
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredStudents.map((student) => (
                          <tr
                            key={student.id}
                            className="border-b hover:bg-muted/50 transition-colors group cursor-pointer"
                            onClick={() => navigate(`/admin/student/${student.id}`)}
                          >
                            <td className="py-4 px-4">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold shrink-0 overflow-hidden">
                                  {student.profilePicture ? (
                                    <img src={student.profilePicture} alt={student.name} className="w-full h-full object-cover" />
                                  ) : (
                                    student.name.charAt(0)
                                  )}
                                </div>
                                <div>
                                  <p className="font-semibold text-sm">{student.name}</p>
                                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Student</p>
                                </div>
                              </div>
                            </td>
                            <td className="py-4 px-4 text-sm text-muted-foreground font-medium">
                              {student.email}
                            </td>
                            <td className="py-4 px-4 text-center">
                              <span className="inline-flex items-center justify-center px-2 py-1 rounded-md bg-secondary text-secondary-foreground text-xs font-bold">
                                {student.enrolledCourses}
                              </span>
                            </td>
                            <td className="py-4 px-4">
                              <div className="flex flex-col gap-1.5 min-w-[140px]">
                                <div className="flex justify-between text-[10px] font-bold uppercase text-muted-foreground px-0.5">
                                  <span>{student.completedLessons}/{student.totalLessons}</span>
                                  <span>{Number(student.progressPercentage) || 0}%</span>
                                </div>
                                <div className="relative">
                                  <Progress
                                    value={Number(student.progressPercentage) || 0}
                                    className="h-1.5 group-hover:h-2 transition-all"
                                  />
                                </div>
                              </div>
                            </td>
                            <td className="py-4 px-4 text-right">
                              <Button variant="ghost" size="sm" className="opacity-50 group-hover:opacity-100 transition-opacity">
                                View Details
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Enrollments Tab */}
        {activeTab === "enrollments" && (
          <div>
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Pending Enrollment Requests</CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">
                      Review and approve student course enrollment requests
                    </p>
                  </div>
                  <Badge className="text-lg px-3 py-1">
                    {enrollments.length} Pending
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                {enrollments.length === 0 ? (
                  <div className="text-center py-16 px-4">
                    <Check className="w-16 h-16 text-green-500/30 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">All Caught Up!</h3>
                    <p className="text-muted-foreground">No pending enrollment requests at this time.</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border bg-muted/50">
                          <th className="text-left py-4 px-6 font-semibold text-sm text-muted-foreground">
                            Student
                          </th>
                          <th className="text-left py-4 px-6 font-semibold text-sm text-muted-foreground">
                            Email
                          </th>
                          <th className="text-left py-4 px-6 font-semibold text-sm text-muted-foreground">
                            Course
                          </th>
                          <th className="text-left py-4 px-6 font-semibold text-sm text-muted-foreground">
                            Requested
                          </th>
                          <th className="text-left py-4 px-6 font-semibold text-sm text-muted-foreground">
                            Status
                          </th>
                          <th className="text-right py-4 px-6 font-semibold text-sm text-muted-foreground">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {enrollments.map((e) => (
                          <tr
                            key={e.id}
                            className="border-b border-border hover:bg-muted/50 transition-colors"
                          >
                            {/* Student Name & Avatar */}
                            <td className="py-4 px-6">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold shrink-0 overflow-hidden border border-border">
                                  {e.user.profilePicture ? (
                                    <img src={e.user.profilePicture} alt={e.user.name} className="w-full h-full object-cover" />
                                  ) : (
                                    e.user.name.charAt(0).toUpperCase()
                                  )}
                                </div>
                                <div>
                                  <p className="font-semibold text-sm">{e.user.name}</p>
                                  {e.studentMessage && (
                                    <p className="text-xs text-primary flex items-center gap-1 mt-0.5">
                                      <MessageSquare className="w-3 h-3" /> Has message
                                    </p>
                                  )}
                                </div>
                              </div>
                            </td>

                            {/* Email */}
                            <td className="py-4 px-6">
                              <p className="text-sm text-muted-foreground">{e.user.email}</p>
                            </td>

                            {/* Course */}
                            <td className="py-4 px-6">
                              <Badge variant="outline" className="font-medium">
                                {e.course.title}
                              </Badge>
                            </td>

                            {/* Request Date */}
                            <td className="py-4 px-6">
                              <p className="text-sm">
                                {new Date(e.createdAt).toLocaleDateString(undefined, {
                                  month: "short",
                                  day: "numeric",
                                  year: "numeric",
                                })}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(e.createdAt).toLocaleTimeString([], {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })}
                              </p>
                            </td>

                            {/* Status */}
                            <td className="py-4 px-6">
                              <div className="flex items-center gap-2">
                                <Clock className="h-4 w-4 text-yellow-500" />
                                <span className="text-sm font-medium text-yellow-600">Pending</span>
                              </div>
                            </td>

                            {/* Actions */}
                            <td className="py-4 px-6 text-right">
                              <div className="flex justify-end gap-2">
                                {/* Review Button */}
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="gap-1"
                                  onClick={() => setSelectedEnrollment(e)}
                                  title="Review enrollment request and student profile"
                                >
                                  <Eye className="w-4 h-4" />
                                  <span className="hidden sm:inline">Review</span>
                                </Button>

                                {/* Reject Button */}
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-destructive hover:bg-destructive/10 hover:text-destructive border-destructive/30 gap-1"
                                  onClick={() => {
                                    setConfirmState({
                                      isOpen: true,
                                      title: "Reject Enrollment",
                                      description: `Are you sure you want to reject the enrollment for ${e.user.name}?`,
                                      variant: "destructive",
                                      onConfirm: () => handleEnrollmentStatus(e.id, "REJECTED"),
                                    });
                                  }}
                                  title="Reject this enrollment request"
                                >
                                  <X className="w-4 h-4" />
                                  <span className="hidden sm:inline">Reject</span>
                                </Button>

                                {/* Approve Button */}
                                <Button
                                  size="sm"
                                  className="bg-green-600 hover:bg-green-700 text-white gap-1"
                                  onClick={() => {
                                    setConfirmState({
                                      isOpen: true,
                                      title: "Approve Enrollment",
                                      description: `Are you sure you want to approve the enrollment for ${e.user.name} in ${e.course.title}?`,
                                      onConfirm: () => handleEnrollmentStatus(e.id, "APPROVED"),
                                    });
                                  }}
                                  title="Approve this enrollment request"
                                >
                                  <Check className="w-4 h-4" />
                                  <span className="hidden sm:inline">Approve</span>
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Enrollment Detail Modal */}
            <Dialog
              open={!!selectedEnrollment}
              onOpenChange={(open) => !open && setSelectedEnrollment(null)}
            >
              <DialogContent className="sm:max-w-[700px]">
                {selectedEnrollment && (
                  <>
                    <DialogHeader>
                      <DialogTitle className="text-2xl font-display">
                        Enrollment Request Review
                      </DialogTitle>
                    </DialogHeader>

                    <div className="py-6 space-y-6">
                      {/* Student Profile Section */}
                      <div className="flex gap-6 items-start p-5 bg-gradient-to-r from-primary/5 to-primary/10 rounded-lg border border-primary/20">
                        <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-xl shrink-0 overflow-hidden border-2 border-primary/20">
                          {selectedEnrollment.user.profilePicture ? (
                            <img src={selectedEnrollment.user.profilePicture} alt={selectedEnrollment.user.name} className="w-full h-full object-cover" />
                          ) : (
                            <span className="text-4xl font-bold text-primary">
                              {selectedEnrollment.user.name.charAt(0).toUpperCase()}
                            </span>
                          )}
                        </div>
                        <div className="space-y-2 flex-1">
                          <h3 className="text-2xl font-bold">
                            {selectedEnrollment.user.name}
                          </h3>
                          <p className="text-muted-foreground flex items-center gap-2">
                            <Mail className="w-4 h-4" />{" "}
                            {selectedEnrollment.user.email}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Requested:{" "}
                            <span className="font-medium">
                              {new Date(
                                selectedEnrollment.createdAt,
                              ).toLocaleDateString()}
                            </span>
                          </p>
                          <Badge className="mt-2">Pending Approval</Badge>
                        </div>
                      </div>

                      {/* About Student */}
                      <div className="space-y-2">
                        <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">
                          About the Student
                        </h4>
                        <div className="p-4 bg-card border border-border rounded-md min-h-[80px] text-sm leading-relaxed">
                          {selectedEnrollment.user.bio ||
                            "No biography provided by the student."}
                        </div>
                      </div>

                      {/* Student Message */}
                      {selectedEnrollment.studentMessage && (
                        <div className="space-y-2">
                          <h4 className="text-sm font-bold uppercase tracking-wider text-primary">
                            Student's Message
                          </h4>
                          <div className="p-4 bg-primary/5 border border-primary/20 rounded-md min-h-[100px] text-sm italic leading-relaxed">
                            "{selectedEnrollment.studentMessage}"
                          </div>
                        </div>
                      )}

                      {/* Course & Details */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 border border-border rounded-lg">
                          <p className="text-xs text-muted-foreground uppercase font-bold mb-1">
                            Course
                          </p>
                          <p className="font-semibold">
                            {selectedEnrollment.course.title}
                          </p>
                        </div>
                        <div className="p-4 border border-border rounded-lg">
                          <p className="text-xs text-muted-foreground uppercase font-bold mb-1">
                            Status
                          </p>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-yellow-500" />
                            <span className="font-medium text-yellow-600">
                              Pending
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <DialogFooter className="gap-2">
                      <Button
                        variant="outline"
                        onClick={() => setSelectedEnrollment(null)}
                      >
                        Close
                      </Button>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          className="text-destructive hover:bg-destructive/10 border-destructive/30"
                          onClick={() => {
                            handleEnrollmentStatus(
                              selectedEnrollment.id,
                              "REJECTED",
                            );
                            setSelectedEnrollment(null);
                          }}
                        >
                          <X className="w-4 h-4 mr-2" />
                          Reject
                        </Button>
                        <Button
                          className="bg-green-600 hover:bg-green-700 text-white"
                          onClick={() => {
                            handleEnrollmentStatus(
                              selectedEnrollment.id,
                              "APPROVED",
                            );
                            setSelectedEnrollment(null);
                          }}
                        >
                          <Check className="w-4 h-4 mr-2" />
                          Approve Enrollment
                        </Button>
                      </div>
                    </DialogFooter>
                  </>
                )}
              </DialogContent>
            </Dialog>
          </div>
        )}

        {/* Blog Management Tab */}
        {activeTab === "blog" && (
          <section className="my-8">
            <AdminBlogManager />
          </section>
        )}
      </div>
      <Footer />
      <ConfirmDialog
        isOpen={confirmState.isOpen}
        onOpenChange={(open) => setConfirmState(prev => ({ ...prev, isOpen: open }))}
        title={confirmState.title}
        description={confirmState.description}
        onConfirm={confirmState.onConfirm}
        variant={confirmState.variant}
      />
    </div>
  );
}

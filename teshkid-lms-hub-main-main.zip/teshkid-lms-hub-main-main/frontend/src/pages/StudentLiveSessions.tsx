import { useState, useEffect, useRef } from "react";
import api from "@/lib/api";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { format, formatDistanceToNow, isPast, isFuture } from "date-fns";
import { getImageUrl } from "@/lib/imageUtils";
import {
  Video, Calendar, Clock, Users, Radio, CheckCircle2,
  PlayCircle, Bell, BellOff, ExternalLink, Youtube,
  Maximize2, ChevronDown, ChevronUp, UserRound,
  CheckCheck, Lock, Loader2, RefreshCw,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────
interface LiveSession {
  id: string;
  title: string;
  description: string;
  hostName: string;
  meetingLink: string;
  streamUrl: string;
  recordingUrl: string;
  scheduledAt: string;
  durationMinutes: number;
  status: "UPCOMING" | "LIVE" | "ENDED";
  bannerUrl?: string;
  courseName?: string;
  rsvpCount: number;
  hasRsvp: number; // 1 | 0
  maxAttendees?: number;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function extractYouTubeId(url: string): string | null {
  if (!url) return null;
  const m = url.match(
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/live\/)([A-Za-z0-9_-]{11})/
  );
  return m ? m[1] : null;
}

/** Returns { days, hours, minutes, seconds } until a future date */
function useCountdown(target: string) {
  const calc = () => {
    const diff = new Date(target).getTime() - Date.now();
    if (diff <= 0) return { days: 0, hours: 0, minutes: 0, seconds: 0, done: true };
    return {
      days:    Math.floor(diff / 86_400_000),
      hours:   Math.floor((diff % 86_400_000) / 3_600_000),
      minutes: Math.floor((diff % 3_600_000)  / 60_000),
      seconds: Math.floor((diff % 60_000)      / 1_000),
      done: false,
    };
  };
  const [tick, setTick] = useState(calc);
  useEffect(() => {
    const id = setInterval(() => setTick(calc()), 1_000);
    return () => clearInterval(id);
  }, [target]);
  return tick;
}

// ─── Status badge meta ────────────────────────────────────────────────────────
const STATUS_META = {
  LIVE:     { label: "Live Now",  badge: "bg-red-500/15 text-red-400 border-red-500/30",    dot: "bg-red-500 animate-pulse" },
  UPCOMING: { label: "Upcoming",  badge: "bg-blue-500/15 text-blue-400 border-blue-500/30", dot: "bg-blue-400" },
  ENDED:    { label: "Ended",     badge: "bg-muted text-muted-foreground border-border/60", dot: "bg-muted-foreground" },
};


// ─── Countdown block (shown on UPCOMING cards) ────────────────────────────────
function CountdownBlock({ scheduledAt }: { scheduledAt: string }) {
  const { days, hours, minutes, seconds, done } = useCountdown(scheduledAt);
  if (done) return <p className="text-xs text-primary font-bold">Starting soon…</p>;
  const units = [
    { v: days,    l: "d" },
    { v: hours,   l: "h" },
    { v: minutes, l: "m" },
    { v: seconds, l: "s" },
  ];
  return (
    <div className="flex items-center gap-1.5">
      <Clock className="w-3 h-3 text-muted-foreground shrink-0" />
      <div className="flex items-center gap-1">
        {units.map(({ v, l }) => (
          <span key={l} className="flex items-baseline gap-0.5">
            <span className="text-sm font-black text-foreground tabular-nums w-5 text-center">{String(v).padStart(2, "0")}</span>
            <span className="text-[10px] text-muted-foreground font-bold">{l}</span>
          </span>
        ))}
      </div>
    </div>
  );
}

// ─── Full-width embedded player (YouTube) ─────────────────────────────────────
function EmbeddedPlayer({ url, title, autoplay = false }: { url: string; title: string; autoplay?: boolean }) {
  const ytId = extractYouTubeId(url);
  const [full, setFull] = useState(false);

  if (!ytId) {
    // Fallback: plain link if not YouTube
    return (
      <a href={url} target="_blank" rel="noopener noreferrer"
        className="flex items-center justify-center gap-2 w-full aspect-video bg-muted rounded-xl text-sm text-primary font-bold hover:underline">
        <ExternalLink className="w-4 h-4" /> Open stream in new tab
      </a>
    );
  }

  return (
    <div className={cn("relative bg-black group", full ? "fixed inset-0 z-50" : "rounded-xl overflow-hidden")}>
      <iframe
        className="w-full aspect-video"
        src={`https://www.youtube.com/embed/${ytId}?${autoplay ? "autoplay=1&" : ""}rel=0&modestbranding=1&color=red`}
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
        allowFullScreen
        title={title}
        style={full ? { height: "100vh" } : undefined}
      />
      <button
        onClick={() => setFull(f => !f)}
        className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/60 text-white opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/80"
        title={full ? "Exit fullscreen" : "Fullscreen"}
      >
        <Maximize2 className="w-4 h-4" />
      </button>
      {full && (
        <button onClick={() => setFull(false)}
          className="absolute top-4 left-4 px-3 py-1.5 rounded-lg bg-black/60 text-white text-sm font-bold hover:bg-black/80 transition-colors">
          ✕ Close
        </button>
      )}
    </div>
  );
}


// ─── Session card ─────────────────────────────────────────────────────────────
function SessionCard({ session, onRsvp }: { session: LiveSession; onRsvp: (s: LiveSession) => void }) {
  const meta     = STATUS_META[session.status];
  const isLive   = session.status === "LIVE";
  const isEnded  = session.status === "ENDED";
  const rsvped   = session.hasRsvp === 1;
  const [expanded, setExpanded] = useState(isLive); // live sessions start expanded

  const hasStream    = !!session.streamUrl;
  const hasRecording = !!session.recordingUrl;
  const hasMeeting   = !!session.meetingLink;

  return (
    <div className={cn(
      "rounded-2xl border bg-card/60 backdrop-blur-sm overflow-hidden shadow-md transition-all",
      isLive ? "border-red-500/40 shadow-red-500/10" : "border-border/60 hover:border-border"
    )}>

      {/* ── LIVE: full-width video at top ──────────────────────────────────── */}
      {isLive && hasStream && (
        <div className="border-b border-red-500/20">
          <EmbeddedPlayer url={session.streamUrl} title={session.title} autoplay />
        </div>
      )}

      {/* ── Banner (non-live with no stream open) ─────────────────────────── */}
      {!isLive && session.bannerUrl && !expanded && (
        <div className="w-full h-40 overflow-hidden border-b border-border/40">
          <img src={session.bannerUrl} alt={session.title} className="w-full h-full object-cover" />
        </div>
      )}

      {/* ── LIVE status bar ───────────────────────────────────────────────── */}
      {isLive && (
        <div className="flex items-center justify-between px-5 py-2 bg-red-500/10 border-b border-red-500/20">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-xs font-black text-red-400 uppercase tracking-widest">Live Now</span>
          </div>
          <span className="text-[10px] text-red-400 font-bold flex items-center gap-1">
            <Users className="w-3 h-3" /> {session.rsvpCount} registered
          </span>
        </div>
      )}

      {/* ── Card body ─────────────────────────────────────────────────────── */}
      <div className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            {/* Badges row */}
            <div className="flex flex-wrap items-center gap-2 mb-2">
              {!isLive && (
                <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold border", meta.badge)}>
                  <span className={cn("w-1.5 h-1.5 rounded-full", meta.dot)} />
                  {meta.label}
                </span>
              )}
              {session.courseName && (
                <span className="text-[10px] bg-muted text-muted-foreground px-2 py-0.5 rounded-full border border-border/40">
                  {session.courseName}
                </span>
              )}
              {rsvped && !isEnded && (
                <span className="text-[10px] bg-primary/10 text-primary border border-primary/20 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                  <CheckCheck className="w-2.5 h-2.5" /> Registered
                </span>
              )}
            </div>

            <h3 className="text-base font-black text-foreground font-['Space_Grotesk'] mb-1 leading-snug">{session.title}</h3>

            {/* Meta row */}
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground mb-2">
              <span className="flex items-center gap-1.5">
                <UserRound className="w-3.5 h-3.5" />
                {session.hostName || "Teshkid Instructor"}
              </span>
              <span className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" />
                {format(new Date(session.scheduledAt), "EEE, MMM d, yyyy")}
              </span>
              <span className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                {format(new Date(session.scheduledAt), "h:mm a")} · {session.durationMinutes} min
              </span>
              {session.rsvpCount > 0 && (
                <span className="flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5" />
                  {session.rsvpCount} registered
                  {session.maxAttendees ? ` / ${session.maxAttendees}` : ""}
                </span>
              )}
            </div>

            {/* Countdown (upcoming only) */}
            {session.status === "UPCOMING" && isFuture(new Date(session.scheduledAt)) && (
              <div className="mt-2 mb-3">
                <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mb-1">Starts in</p>
                <CountdownBlock scheduledAt={session.scheduledAt} />
              </div>
            )}
          </div>

          {/* Expand / collapse toggle for description + player */}
          {(session.description || hasStream || hasRecording) && !isLive && (
            <button onClick={() => setExpanded(e => !e)}
              className="p-1.5 rounded-lg text-muted-foreground hover:bg-muted/60 hover:text-foreground transition-all shrink-0">
              {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          )}
        </div>

        {/* ── Expanded content ──────────────────────────────────────────────── */}
        {(expanded || isLive) && (
          <div className="mt-3 space-y-3">
            {session.description && (
              <p className="text-sm text-muted-foreground leading-relaxed">{session.description}</p>
            )}

            {/* Ended: recording embed */}
            {isEnded && hasRecording && (
              <div>
                <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mb-2 flex items-center gap-1.5">
                  <PlayCircle className="w-3.5 h-3.5 text-green-400" /> Session Recording
                </p>
                <EmbeddedPlayer url={session.recordingUrl} title={session.title} />
              </div>
            )}

            {/* Upcoming: stream preview (no autoplay) */}
            {session.status === "UPCOMING" && hasStream && (
              <div>
                <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mb-2 flex items-center gap-1.5">
                  <Youtube className="w-3.5 h-3.5 text-red-400" /> Stream Preview
                </p>
                <EmbeddedPlayer url={session.streamUrl} title={session.title} />
              </div>
            )}
          </div>
        )}

        {/* ── Action bar ────────────────────────────────────────────────────── */}
        <div className="flex flex-wrap items-center gap-2 mt-4 pt-4 border-t border-border/30">

          {/* LIVE: Join via meeting link */}
          {isLive && hasMeeting && (
            <a href={session.meetingLink} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-red-500 text-white text-sm font-bold hover:bg-red-600 transition-all shadow-lg shadow-red-500/20">
              <span className="w-2 h-2 bg-white rounded-full animate-pulse" /> Join on Zoom/Meet
            </a>
          )}

          {/* UPCOMING: RSVP button */}
          {session.status === "UPCOMING" && (
            <button onClick={() => onRsvp(session)}
              className={cn(
                "flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold transition-all",
                rsvped
                  ? "bg-primary/10 text-primary border border-primary/30 hover:bg-destructive/10 hover:text-destructive hover:border-destructive/30"
                  : "bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/20"
              )}>
              {rsvped
                ? <><BellOff className="w-4 h-4" /> Cancel RSVP</>
                : <><Bell className="w-4 h-4" /> RSVP — Save My Spot</>}
            </button>
          )}

          {/* ENDED: no recording notice */}
          {isEnded && !hasRecording && (
            <span className="flex items-center gap-2 px-4 py-2 rounded-xl bg-muted/50 text-muted-foreground text-sm font-medium border border-border/40">
              <Lock className="w-3.5 h-3.5" /> Recording not available
            </span>
          )}

          {/* External meeting link (non-live upcoming) */}
          {session.status === "UPCOMING" && hasMeeting && (
            <a href={session.meetingLink} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-border/50 text-muted-foreground text-xs font-bold hover:text-primary hover:border-primary/40 transition-all">
              <ExternalLink className="w-3.5 h-3.5" /> Open meeting link
            </a>
          )}

          {/* Spacer then time badge */}
          <span className="ml-auto text-[10px] text-muted-foreground/60">
            {isEnded
              ? `Ended ${formatDistanceToNow(new Date(session.scheduledAt), { addSuffix: true })}`
              : isLive
              ? "Started " + formatDistanceToNow(new Date(session.scheduledAt), { addSuffix: true })
              : format(new Date(session.scheduledAt), "MMM d · h:mm a")}
          </span>
        </div>
      </div>
    </div>
  );
}


// ─── Main page ────────────────────────────────────────────────────────────────
export default function StudentLiveSessions() {
  const [sessions, setSessions]       = useState<LiveSession[]>([]);
  const [gamification, setGamification] = useState<any>(null);
  const [loading, setLoading]         = useState(true);
  const [filter, setFilter]           = useState<"all" | "UPCOMING" | "LIVE" | "ENDED">("all");
  const [rsvpLoading, setRsvpLoading] = useState<string | null>(null);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [dashRes, sessRes] = await Promise.all([
        api.get("/dashboard"),
        api.get("/live-sessions").catch(() => ({ data: [] })),
      ]);
      setGamification(dashRes.data.gamification);
      setSessions(sessRes.data || []);
    } catch { toast.error("Failed to load sessions"); }
    finally { setLoading(false); }
  };

  const handleRsvp = async (session: LiveSession) => {
    setRsvpLoading(session.id);
    try {
      const res = await api.post(`/live-sessions/${session.id}/rsvp`);
      const rsvped = res.data.rsvped as boolean;
      setSessions(prev =>
        prev.map(s => s.id === session.id
          ? { ...s, hasRsvp: rsvped ? 1 : 0, rsvpCount: s.rsvpCount + (rsvped ? 1 : -1) }
          : s
        )
      );
      toast.success(rsvped ? "✅ RSVP confirmed — you're registered!" : "RSVP cancelled");
    } catch { toast.error("Failed to update RSVP"); }
    finally { setRsvpLoading(null); }
  };

  const xpProgress = gamification
    ? Math.round(((gamification.xp - gamification.xpForCurrentLevel) /
        (gamification.xpForNextLevel - gamification.xpForCurrentLevel)) * 100)
    : 0;

  const live     = sessions.filter(s => s.status === "LIVE");
  const upcoming = sessions.filter(s => s.status === "UPCOMING");
  const ended    = sessions.filter(s => s.status === "ENDED");

  const filtered = filter === "all" ? sessions : sessions.filter(s => s.status === filter);

  return (
    <DashboardLayout xp={gamification?.xp} level={gamification?.level} xpProgress={xpProgress}>
      <div className="max-w-4xl mx-auto px-4 md:px-8 py-8 space-y-6">

        {/* ── Header ──────────────────────────────────────────────────────── */}
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-black font-['Space_Grotesk'] text-foreground flex items-center gap-2">
              <Radio className="w-6 h-6 text-primary" /> Live Sessions
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              Watch instructor-led live classes embedded right here
            </p>
          </div>
          <button onClick={loadData} className="p-2 rounded-xl border border-border/50 bg-card text-muted-foreground hover:text-foreground hover:bg-muted transition-all">
            <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
          </button>
        </div>

        {/* ── Live now hero (if any session is live) ───────────────────────── */}
        {!loading && live.length > 0 && (
          <div className="rounded-2xl border border-red-500/40 bg-red-500/5 p-1 shadow-xl shadow-red-500/10 space-y-1">
            <div className="flex items-center gap-2 px-4 pt-3 pb-1">
              <span className="w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse" />
              <span className="text-xs font-black text-red-400 uppercase tracking-widest">
                {live.length === 1 ? "1 session is live right now" : `${live.length} sessions live`}
              </span>
            </div>
            {live.map(s => (
              <SessionCard key={s.id} session={s} onRsvp={handleRsvp} />
            ))}
          </div>
        )}

        {/* ── Stats row ────────────────────────────────────────────────────── */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { key: "LIVE"     as const, label: "Live Now",   value: live.length,     color: "text-red-400",  bg: "bg-red-500/10 border-red-500/20",   icon: Radio        },
            { key: "UPCOMING" as const, label: "Upcoming",   value: upcoming.length, color: "text-blue-400", bg: "bg-blue-500/10 border-blue-500/20", icon: Calendar     },
            { key: "ENDED"    as const, label: "Recordings", value: ended.filter(s => !!s.recordingUrl).length, color: "text-green-400", bg: "bg-green-500/10 border-green-500/20", icon: PlayCircle },
          ].map(({ key, label, value, color, bg, icon: Icon }) => (
            <button key={key} onClick={() => setFilter(f => f === key ? "all" : key)}
              className={cn(
                "rounded-xl border p-3.5 text-left transition-all hover:shadow-md",
                bg,
                filter === key && "ring-2 ring-primary/40"
              )}>
              <div className="flex items-center gap-1.5 mb-1">
                <Icon className={cn("w-3.5 h-3.5", color)} />
                <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wide">{label}</span>
              </div>
              <p className="text-2xl font-black text-foreground">{value}</p>
            </button>
          ))}
        </div>

        {/* ── Filter tabs ──────────────────────────────────────────────────── */}
        <div className="flex gap-1.5 flex-wrap">
          {([
            { key: "all"      as const, label: "All Sessions"   },
            { key: "LIVE"     as const, label: "Live Now"       },
            { key: "UPCOMING" as const, label: "Upcoming"       },
            { key: "ENDED"    as const, label: "Past / Replays" },
          ]).map(({ key, label }) => (
            <button key={key} onClick={() => setFilter(key)}
              className={cn(
                "px-4 py-1.5 rounded-full text-sm font-semibold border transition-all",
                filter === key
                  ? "bg-primary text-primary-foreground border-primary shadow-md shadow-primary/20"
                  : "bg-card border-border/50 text-muted-foreground hover:border-primary/40 hover:text-foreground"
              )}>
              {label}
              {key === "LIVE" && live.length > 0 && (
                <span className="ml-1.5 w-2 h-2 bg-red-500 rounded-full inline-block animate-pulse" />
              )}
            </button>
          ))}
        </div>

        {/* ── Session list ─────────────────────────────────────────────────── */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 gap-3">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
            <p className="text-sm text-muted-foreground animate-pulse">Loading sessions…</p>
          </div>
        ) : filtered.filter(s => filter === "all" ? s.status !== "LIVE" : true).length === 0 && live.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border/60 p-16 text-center">
            <Video className="w-12 h-12 text-muted-foreground/20 mx-auto mb-4" />
            <p className="text-muted-foreground font-medium">
              {filter === "LIVE" ? "No sessions are live right now."
               : filter === "UPCOMING" ? "No upcoming sessions yet."
               : filter === "ENDED" ? "No past sessions yet."
               : "No sessions available yet."}
            </p>
            <p className="text-xs text-muted-foreground/60 mt-2">
              Check back later — your instructor will schedule live classes here.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Upcoming */}
            {(filter === "all" || filter === "UPCOMING") && upcoming.length > 0 && (
              <div className="space-y-3">
                {filter === "all" && (
                  <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest px-1">
                    Upcoming Sessions
                  </p>
                )}
                {upcoming.map(s => (
                  <div key={s.id} className={cn(rsvpLoading === s.id && "opacity-70 pointer-events-none")}>
                    <SessionCard session={s} onRsvp={handleRsvp} />
                  </div>
                ))}
              </div>
            )}

            {/* Past / recordings */}
            {(filter === "all" || filter === "ENDED") && ended.length > 0 && (
              <div className="space-y-3">
                {filter === "all" && (
                  <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest px-1 mt-6">
                    Past Sessions &amp; Recordings
                  </p>
                )}
                {ended.map(s => (
                  <SessionCard key={s.id} session={s} onRsvp={handleRsvp} />
                ))}
              </div>
            )}
          </div>
        )}

      </div>
    </DashboardLayout>
  );
}

import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import api from "@/lib/api";
import { toast } from "sonner";
import {
  UploadCloud,
  FileImage,
  FileVideo,
  Loader2,
  Plus,
  Trash2,
  DollarSign,
  Type,
  AlignLeft,
  ChevronRight,
  PlayCircle,
  Link as LinkIcon
} from "lucide-react";

interface CoursePart {
  id: string; // temporary for UI
  title: string;
  videoUrl: string;
  duration: string;
  isUploading?: boolean;
  videoType?: 'upload' | 'link';
}

export default function AdminCourseForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [isEdit, setIsEdit] = useState(false);
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    title: "",
    description: "",
    instructor: "Teshkid is Crypto",
    thumbnail: "",
    level: "All Levels",
    duration: "", // total duration, calculated
    price: 0,
    bannerUrl: "",
    previewVideoUrl: "",
  });

  const [parts, setParts] = useState<CoursePart[]>([]);
  const [uploadingBanner, setUploadingBanner] = useState(false);

  useEffect(() => {
    if (id) {
      setIsEdit(true);
      setLoading(true);
      api
        .get(`/admin/courses/${id}`)
        .then((res) => {
          const c = res.data;
          setForm({
            title: c.title,
            description: c.description,
            instructor: c.instructor,
            thumbnail: c.thumbnail,
            level: c.level || "All Levels",
            duration: c.duration,
            price: c.price,
            bannerUrl: c.bannerUrl || "",
            previewVideoUrl: c.previewVideoUrl || "",
          });

          // Flatten lessons from modules to "Parts"
          if (c.modules && c.modules.length > 0) {
            const allLessons: CoursePart[] = [];
            c.modules.forEach((mod: any) => {
              if (mod.lessons) {
                mod.lessons.forEach((less: any) => {
                  allLessons.push({
                    id: less.id,
                    title: less.title,
                    videoUrl: less.videoUrl,
                    duration: less.duration,
                    videoType: less.videoUrl?.startsWith('http') && !less.videoUrl.includes('/uploads/') ? 'link' : 'upload'
                  });
                });
              }
            });
            setParts(allLessons);
          }
        })
        .catch((err) => {
          console.error(err);
          toast.error("Could not load course.");
        })
        .finally(() => setLoading(false));
    } else {
      // Add one empty part by default for new courses
      setParts([{ id: Math.random().toString(36).substr(2, 9), title: "Part 1: Introduction", videoUrl: "", duration: "", videoType: 'upload' }]);
    }
  }, [id]);

  const addPart = () => {
    setParts([...parts, {
      id: Math.random().toString(36).substr(2, 9),
      title: `Part ${parts.length + 1}: `,
      videoUrl: "",
      duration: "",
      videoType: 'upload'
    }]);
  };

  const removePart = (partId: string) => {
    setParts(parts.filter(p => p.id !== partId));
  };

  const updatePart = (partId: string, updates: Partial<CoursePart>) => {
    setParts(parts.map(p => p.id === partId ? { ...p, ...updates } : p));
  };

  const handleFileUpload = async (file: File, type: 'banner' | 'part-video', partId?: string) => {
    const formData = new FormData();
    formData.append("file", file);

    if (type === 'banner') {
      setUploadingBanner(true);
    } else if (partId) {
      updatePart(partId, { isUploading: true });
    }

    try {
      const res = await api.post("/admin/content/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      const url = res.data.fileUrl;

      if (type === 'banner') {
        setForm(prev => ({ ...prev, bannerUrl: url, thumbnail: url }));
        toast.success("Banner uploaded");
      } else if (partId) {
        updatePart(partId, { videoUrl: url, isUploading: false });
        toast.success("Video uploaded");
      }
    } catch (err) {
      console.error(err);
      toast.error(`Could not upload ${type}.`);
      if (partId) updatePart(partId, { isUploading: false });
    } finally {
      if (type === 'banner') setUploadingBanner(false);
    }
  };

  const handleSubmit = async () => {
    if (!form.title) return toast.error("Course title is required");
    if (!form.bannerUrl) return toast.error("Course banner is required");

    setLoading(true);
    try {
      // Map Parts to a single Module structure for the backend
      const payload = {
        ...form,
        duration: parts.length > 0 ? `${parts.length} Parts` : "0 Parts", // auto calculate duration text
        modules: [
          {
            title: "Course Content",
            description: "All videos for this course",
            lessons: parts.map((p, idx) => ({
              title: p.title || `Part ${idx + 1}`,
              duration: p.duration || "0:00",
              type: "video",
              videoUrl: p.videoUrl,
              description: "",
              order: idx + 1
            }))
          }
        ]
      };

      if (isEdit && id) {
        await api.put(`/admin/courses/${id}`, payload);
        // Backend put might not handle modules yet, so we handle it separately if needed
        // But the user didn't request full lesson editing sync here yet, 
        // usually detail page handles lesson management in this current architecture.
        // However, I will try to update it as much as possible.
        toast.success("Course updated successfully");
        navigate(`/admin/courses/${id}`);
      } else {
        const res = await api.post("/admin/courses", payload);
        toast.success("Course created successfully with " + parts.length + " parts!");
        navigate(`/admin/courses/${res.data.id}`);
      }
    } catch (err) {
      console.error(err);
      toast.error("Could not save course.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="pt-32 sm:pt-40 pb-20 container mx-auto max-w-4xl px-4">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-black gradient-text">
              {isEdit ? "Refine Course" : "Launch New Course"}
            </h1>
            <p className="text-muted-foreground mt-1 font-medium">Simplify your teaching experience.</p>
          </div>
          <Button variant="outline" onClick={() => navigate("/admin/courses")} className="rounded-xl">
            Cancel
          </Button>
        </div>

        <div className="space-y-8">
          {/* Section 1: Core Content */}
          <Card className="border-none shadow-2xl bg-card/50 backdrop-blur-sm overflow-hidden rounded-2xl">
            <div className="h-2 bg-primary w-full" />
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Type className="w-5 h-5 text-primary" /> General Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Course Title</label>
                <Input
                  className="h-12 bg-muted/30 border-border text-lg font-bold focus:ring-primary/20"
                  placeholder="e.g., Master Crypto Trading: Zero to Hero"
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Price (In US Dollars)</label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-primary" />
                  <Input
                    type="number"
                    className="h-12 bg-muted/30 border-border pl-10 text-lg font-bold focus:ring-primary/20"
                    placeholder="99.99"
                    value={String(form.price)}
                    onChange={(e) => setForm({ ...form, price: Number(e.target.value) })}
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-black text-muted-foreground uppercase">USD</span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Course Banner (Featured Image)</label>
                <div className="relative aspect-video rounded-2xl bg-muted/20 border-2 border-dashed border-border flex flex-col items-center justify-center overflow-hidden group">
                  {form.bannerUrl ? (
                    <>
                      <img src={form.bannerUrl} className="w-full h-full object-cover" alt="Banner" />
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                        <label className="cursor-pointer bg-primary text-primary-foreground px-6 py-2 rounded-xl font-bold hover:scale-105 transition-transform">
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'banner')}
                          />
                          Change Image
                        </label>
                      </div>
                    </>
                  ) : (
                    <label className="cursor-pointer flex flex-col items-center gap-4 text-muted-foreground hover:text-primary transition-colors">
                      <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
                        {uploadingBanner ? <Loader2 className="w-8 h-8 animate-spin" /> : <Plus className="w-8 h-8" />}
                      </div>
                      <div className="text-center">
                        <p className="font-bold text-base">Click to upload banner</p>
                        <p className="text-xs">Recommended: 1920x1080 (16:9)</p>
                      </div>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'banner')}
                      />
                    </label>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Description</label>
                <Textarea
                  className="bg-muted/30 border-border min-h-[160px] text-base leading-relaxed resize-none focus:ring-primary/20"
                  placeholder="Tell your students what they will learn in this course..."
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                />
              </div>
            </CardContent>
          </Card>

          {/* Section 2: Course Parts (Videos) */}
          <Card className="border-none shadow-2xl bg-card/50 backdrop-blur-sm overflow-hidden rounded-2xl">
            <div className="h-2 bg-emerald-500 w-full" />
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <PlayCircle className="w-5 h-5 text-emerald-500" /> Course Content (Parts)
              </CardTitle>
              <Button onClick={addPart} variant="outline" size="sm" className="gap-2 border-emerald-500/30 text-emerald-500 hover:bg-emerald-500/10 h-8 rounded-lg">
                <Plus className="w-4 h-4" /> Add Part
              </Button>
            </CardHeader>
            <CardContent className="space-y-6">
              {parts.map((part, index) => (
                <div key={part.id} className="p-5 bg-muted/20 border border-border rounded-2xl group relative animate-in fade-in slide-in-from-top-2">
                  <div className="absolute -left-3 top-6 w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center text-xs font-black shadow-lg">
                    {index + 1}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Part Title</label>
                        <Input
                          className="bg-muted/40 border-border h-10 font-bold"
                          placeholder={`Part ${index + 1}: Getting Started`}
                          value={part.title}
                          onChange={(e) => updatePart(part.id, { title: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Duration (e.g. 10:45)</label>
                        <Input
                          className="bg-muted/40 border-border h-10"
                          placeholder="0:00"
                          value={part.duration}
                          onChange={(e) => updatePart(part.id, { duration: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="flex flex-col justify-end">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Video Lesson</label>
                          <div className="flex bg-muted/30 p-1 rounded-lg gap-1">
                            <button
                              onClick={() => updatePart(part.id, { videoType: 'upload' })}
                              className={`px-3 py-1 rounded-md text-[9px] font-black uppercase tracking-widest transition-all ${part.videoType !== 'link' ? 'bg-primary text-primary-foreground shadow-lg' : 'text-muted-foreground hover:bg-muted/50'}`}
                            >
                              Upload
                            </button>
                            <button
                              onClick={() => updatePart(part.id, { videoType: 'link' })}
                              className={`px-3 py-1 rounded-md text-[9px] font-black uppercase tracking-widest transition-all ${part.videoType === 'link' ? 'bg-primary text-primary-foreground shadow-lg' : 'text-muted-foreground hover:bg-muted/50'}`}
                            >
                              Link
                            </button>
                          </div>
                        </div>

                        {part.videoType === 'link' ? (
                          <div className="relative group/link">
                            <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-primary" />
                            <Input
                              className="bg-muted/40 border-border h-10 pl-10 text-xs font-medium focus:ring-primary/20"
                              placeholder="Direct Video URL (mp4, etc.)"
                              value={part.videoUrl}
                              onChange={(e) => updatePart(part.id, { videoUrl: e.target.value })}
                            />
                          </div>
                        ) : part.videoUrl ? (
                          <div className="relative h-24 rounded-xl bg-black border border-border/50 overflow-hidden group/vid">
                            <video src={part.videoUrl} className="w-full h-full object-cover" />
                            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                              <label className="cursor-pointer text-xs font-bold text-white bg-emerald-500/80 px-3 py-1 rounded-full hover:bg-emerald-500 transition-colors">
                                <input
                                  type="file"
                                  accept="video/*"
                                  className="hidden"
                                  onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'part-video', part.id)}
                                />
                                Replace Video
                              </label>
                            </div>
                          </div>
                        ) : (
                          <label className="flex flex-col items-center justify-center h-24 rounded-xl bg-muted/40 border-2 border-dashed border-border hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all cursor-pointer">
                            {part.isUploading ? (
                              <Loader2 className="w-6 h-6 animate-spin text-emerald-500" />
                            ) : (
                              <>
                                <FileVideo className="w-6 h-6 text-muted-foreground" />
                                <span className="text-[10px] font-bold uppercase text-muted-foreground mt-2">Upload Video</span>
                              </>
                            )}
                            <input
                              type="file"
                              accept="video/*"
                              className="hidden"
                              onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'part-video', part.id)}
                            />
                          </label>
                        )}
                      </div>
                    </div>
                  </div>

                  {parts.length > 1 && (
                    <button
                      onClick={() => removePart(part.id)}
                      className="absolute -right-2 -top-2 w-7 h-7 bg-destructive text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}

              <Button
                onClick={addPart}
                variant="ghost"
                className="w-full border-2 border-dashed border-border py-8 h-auto rounded-2xl hover:bg-emerald-500/5 hover:border-emerald-500/30 transition-all gap-2"
              >
                <Plus className="w-5 h-5 text-emerald-500" />
                <span className="font-bold text-muted-foreground group-hover:text-emerald-500">Append Another Part</span>
              </Button>
            </CardContent>
          </Card>

          {/* Submit */}
          <div className="flex flex-col gap-4">
            <Button
              size="lg"
              onClick={handleSubmit}
              disabled={loading}
              className="h-14 rounded-2xl bg-primary hover:bg-primary/90 text-primary-foreground font-black text-xl shadow-2xl shadow-primary/30 transition-all hover:scale-[1.01] active:scale-[0.98]"
            >
              {loading ? (
                <Loader2 className="w-6 h-6 animate-spin" />
              ) : isEdit ? (
                "Update Course Structure"
              ) : (
                "Publish This Course"
              )}
            </Button>
            <p className="text-center text-xs text-muted-foreground font-medium">
              By publishing, this course will be visible to all students.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

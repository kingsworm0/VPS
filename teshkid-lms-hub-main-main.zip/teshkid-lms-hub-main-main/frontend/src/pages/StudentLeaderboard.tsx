import { useState, useEffect } from "react";
import api from "@/lib/api";
import { getImageUrl } from "@/lib/imageUtils";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { toast } from "sonner";
import { Trophy, Medal, Star, Flame, Crown, TrendingUp, UserRound } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";

interface LeaderboardEntry {
  rank: number;
  userId: string;
  name: string;
  profilePicture?: string;
  xp: number;
  streak: number;
  level: number;
  lessonsCompleted: number;
}

const RANK_STYLES: Record<number, { icon: any; color: string; bg: string; border: string }> = {
  1: { icon: Crown, color: "text-amber-400", bg: "bg-amber-500/10", border: "border-amber-500/30" },
  2: { icon: Medal, color: "text-slate-300", bg: "bg-slate-500/10", border: "border-slate-400/30" },
  3: { icon: Medal, color: "text-amber-600", bg: "bg-amber-700/10", border: "border-amber-700/30" },
};

export default function StudentLeaderboard() {
  const { user } = useAuth();
  const [leaders, setLeaders] = useState<LeaderboardEntry[]>([]);
  const [gamification, setGamification] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [dashRes, lbRes] = await Promise.all([
        api.get("/dashboard"),
        api.get("/leaderboard").catch(() => ({ data: [] })),
      ]);
      setGamification(dashRes.data.gamification);
      setLeaders(lbRes.data || []);
    } catch {
      toast.error("Failed to load leaderboard");
    } finally {
      setLoading(false);
    }
  };

  const xpProgress = gamification
    ? Math.round(((gamification.xp - gamification.xpForCurrentLevel) / (gamification.xpForNextLevel - gamification.xpForCurrentLevel)) * 100)
    : 0;

  const myRank = leaders.findIndex((l) => l.userId === (user as any)?.id) + 1;

  return (
    <DashboardLayout xp={gamification?.xp} level={gamification?.level} xpProgress={xpProgress}>
      <div className="max-w-4xl mx-auto px-4 md:px-8 py-8 space-y-6">
        <div>
          <h1 className="text-2xl font-black font-['Space_Grotesk'] text-foreground">Leaderboard</h1>
          <p className="text-sm text-muted-foreground mt-1">Top learners ranked by XP this month</p>
        </div>

        {/* Top 3 podium */}
        {!loading && leaders.length >= 3 && (
          <div className="flex items-end justify-center gap-3 py-8">
            {/* 2nd place */}
            <div className="flex flex-col items-center gap-2 w-24">
              <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-slate-400/50 bg-muted flex items-center justify-center">
                {leaders[1].profilePicture ? (
                  <img 
                    src={getImageUrl(leaders[1].profilePicture) || ''} 
                    alt={leaders[1].name} 
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      e.currentTarget.nextElementSibling?.classList.remove('hidden');
                    }}
                  />
                ) : null}
                <div className={cn(
                  "w-full h-full bg-slate-500/20 flex items-center justify-center text-slate-300",
                  leaders[1].profilePicture ? "hidden" : ""
                )}>
                  <UserRound className="w-7 h-7" />
                </div>
              </div>
              <p className="text-xs font-bold text-foreground text-center truncate w-full">{leaders[1].name}</p>
              <p className="text-[11px] text-slate-300 font-semibold">{leaders[1].xp} XP</p>
              <div className="w-full h-16 bg-slate-500/20 border border-slate-400/30 rounded-t-xl flex items-center justify-center">
                <Medal className="w-5 h-5 text-slate-300" />
                <span className="text-slate-300 font-black ml-1">2</span>
              </div>
            </div>
            {/* 1st place */}
            <div className="flex flex-col items-center gap-2 w-28">
              <Crown className="w-5 h-5 text-amber-400" />
              <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-amber-400/60 bg-muted shadow-lg shadow-amber-500/20 flex items-center justify-center">
                {leaders[0].profilePicture ? (
                  <img 
                    src={getImageUrl(leaders[0].profilePicture) || ''} 
                    alt={leaders[0].name} 
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      e.currentTarget.nextElementSibling?.classList.remove('hidden');
                    }}
                  />
                ) : null}
                <div className={cn(
                  "w-full h-full bg-amber-500/20 flex items-center justify-center text-amber-400",
                  leaders[0].profilePicture ? "hidden" : ""
                )}>
                  <UserRound className="w-8 h-8" />
                </div>
              </div>
              <p className="text-xs font-bold text-foreground text-center truncate w-full">{leaders[0].name}</p>
              <p className="text-[11px] text-amber-400 font-semibold">{leaders[0].xp} XP</p>
              <div className="w-full h-24 bg-amber-500/20 border border-amber-400/40 rounded-t-xl flex items-center justify-center">
                <Crown className="w-5 h-5 text-amber-400" />
                <span className="text-amber-400 font-black ml-1">1</span>
              </div>
            </div>
            {/* 3rd place */}
            <div className="flex flex-col items-center gap-2 w-24">
              <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-amber-700/50 bg-muted flex items-center justify-center">
                {leaders[2].profilePicture ? (
                  <img 
                    src={getImageUrl(leaders[2].profilePicture) || ''} 
                    alt={leaders[2].name} 
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      e.currentTarget.nextElementSibling?.classList.remove('hidden');
                    }}
                  />
                ) : null}
                <div className={cn(
                  "w-full h-full bg-amber-700/20 flex items-center justify-center text-amber-600",
                  leaders[2].profilePicture ? "hidden" : ""
                )}>
                  <UserRound className="w-7 h-7" />
                </div>
              </div>
              <p className="text-xs font-bold text-foreground text-center truncate w-full">{leaders[2].name}</p>
              <p className="text-[11px] text-amber-600 font-semibold">{leaders[2].xp} XP</p>
              <div className="w-full h-10 bg-amber-700/20 border border-amber-700/30 rounded-t-xl flex items-center justify-center">
                <Medal className="w-5 h-5 text-amber-600" />
                <span className="text-amber-600 font-black ml-1">3</span>
              </div>
            </div>
          </div>
        )}

        {/* Full list */}
        <div className="rounded-2xl border border-border/60 bg-card/60 overflow-hidden shadow-md">
          {loading ? (
            <div className="flex justify-center py-20">
              <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
            </div>
          ) : leaders.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground text-sm">
              <Trophy className="w-10 h-10 mx-auto mb-3 text-muted-foreground/30" />
              No learners ranked yet. Start completing lessons to appear here!
            </div>
          ) : (
            <div className="divide-y divide-border/40">
              {leaders.map((entry, i) => {
                const isMe = entry.userId === (user as any)?.id;
                const rankStyle = RANK_STYLES[entry.rank];
                return (
                  <div
                    key={entry.userId}
                    className={cn(
                      "flex items-center gap-4 px-5 py-4 transition-colors",
                      isMe ? "bg-primary/5 border-l-2 border-primary" : "hover:bg-muted/20"
                    )}
                  >
                    {/* Rank */}
                    <div className={cn(
                      "w-9 h-9 rounded-full flex items-center justify-center border font-black text-sm shrink-0",
                      rankStyle ? `${rankStyle.bg} ${rankStyle.border} ${rankStyle.color}` : "bg-muted border-border text-muted-foreground"
                    )}>
                      {rankStyle ? <rankStyle.icon className="w-4 h-4" /> : entry.rank}
                    </div>

                    {/* Avatar */}
                    <div className="w-10 h-10 rounded-full overflow-hidden bg-muted shrink-0 border border-border/50 flex items-center justify-center">
                      {entry.profilePicture ? (
                        <img 
                          src={getImageUrl(entry.profilePicture) || ''} 
                          alt={entry.name} 
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            e.currentTarget.style.display = 'none';
                            e.currentTarget.nextElementSibling?.classList.remove('hidden');
                          }}
                        />
                      ) : null}
                      <div className={cn(
                        "w-full h-full bg-primary/10 flex items-center justify-center text-primary",
                        entry.profilePicture ? "hidden" : ""
                      )}>
                        <UserRound className="w-5 h-5" />
                      </div>
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-bold text-foreground truncate">{entry.name}</p>
                        {isMe && <span className="text-[10px] bg-primary/10 text-primary border border-primary/20 px-1.5 py-0.5 rounded-full font-bold">You</span>}
                      </div>
                      <div className="flex items-center gap-3 mt-0.5 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1"><Star className="w-3 h-3 text-violet-400" /> Lv.{entry.level}</span>
                        <span>{entry.lessonsCompleted} lessons</span>
                      </div>
                    </div>

                    {/* XP */}
                    <div className="text-right shrink-0">
                      <p className="text-base font-black text-primary">{entry.xp.toLocaleString()}</p>
                      <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-wider">XP</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {myRank > 0 && myRank > 10 && (
          <p className="text-center text-sm text-muted-foreground">
            Your current rank: <span className="text-primary font-bold">#{myRank}</span> — keep learning to climb!
          </p>
        )}
      </div>
    </DashboardLayout>
  );
}

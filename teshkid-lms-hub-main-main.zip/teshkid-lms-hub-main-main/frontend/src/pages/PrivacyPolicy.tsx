import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { cn } from "@/lib/utils";
import {
  Shield, Lock, Eye, Database, Globe, Mail, ChevronRight,
  FileText, Users, AlertTriangle, Scroll, Server, Trash2,
  RefreshCw, UserCheck, Cookie, Phone,
} from "lucide-react";

// ─── Section registry ────────────────────────────────────────────────────────
const SECTIONS = [
  { id: "overview",       num: "01", title: "Overview",                           icon: Shield },
  { id: "data-collect",   num: "02", title: "Information We Collect",             icon: Database },
  { id: "how-collect",    num: "03", title: "How We Collect Information",         icon: Eye },
  { id: "how-use",        num: "04", title: "How We Use Your Information",        icon: FileText },
  { id: "sharing",        num: "05", title: "Sharing Your Information",           icon: Users },
  { id: "crypto",         num: "06", title: "Cryptocurrency & Blockchain Data",   icon: Globe },
  { id: "cookies",        num: "07", title: "Cookies & Tracking",                 icon: Cookie },
  { id: "storage",        num: "08", title: "Data Storage & Security",            icon: Server },
  { id: "retention",      num: "09", title: "Data Retention",                     icon: Trash2 },
  { id: "rights",         num: "10", title: "Your Rights",                        icon: UserCheck },
  { id: "children",       num: "11", title: "Children's Privacy",                 icon: Shield },
  { id: "third-party",    num: "12", title: "Third-Party Services",               icon: Globe },
  { id: "transfers",      num: "13", title: "International Transfers",            icon: Globe },
  { id: "changes",        num: "14", title: "Changes to This Policy",             icon: RefreshCw },
  { id: "contact",        num: "15", title: "Contact Us",                         icon: Mail },
];

// ─── Shared building blocks ───────────────────────────────────────────────────
function SectionTitle({ num, title, icon: Icon }: { num: string; title: string; icon: React.ElementType }) {
  return (
    <div className="flex items-center gap-3 mb-5">
      <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
        <Icon className="w-4 h-4 text-primary" />
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-[11px] font-black text-primary/60 tracking-widest uppercase">{num}</span>
        <h2 className="text-lg font-black text-foreground font-['Space_Grotesk']">{title}</h2>
      </div>
    </div>
  );
}

function BulletList({ items }: { items: string[] }) {
  return (
    <ul className="space-y-1.5 mt-3">
      {items.map((item, i) => (
        <li key={i} className="flex items-start gap-2.5 text-sm text-muted-foreground leading-relaxed">
          <ChevronRight className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  );
}

function Para({ children }: { children: React.ReactNode }) {
  return <p className="text-sm text-muted-foreground leading-relaxed mt-2">{children}</p>;
}

function InfoBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="mt-4 rounded-xl border border-primary/20 bg-primary/5 px-4 py-3.5 flex gap-3">
      <Shield className="w-4 h-4 text-primary mt-0.5 shrink-0" />
      <p className="text-sm text-primary/80 leading-relaxed">{children}</p>
    </div>
  );
}

function NoteBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="mt-4 rounded-xl border border-border/60 bg-muted/30 px-4 py-3.5 flex gap-3">
      <FileText className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
      <p className="text-sm text-muted-foreground leading-relaxed">{children}</p>
    </div>
  );
}

function WarningBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="mt-4 rounded-xl border border-destructive/20 bg-destructive/5 px-4 py-3.5 flex gap-3">
      <AlertTriangle className="w-4 h-4 text-destructive mt-0.5 shrink-0" />
      <p className="text-sm text-destructive/80 leading-relaxed">{children}</p>
    </div>
  );
}

function Divider() {
  return <div className="h-px bg-border/40 my-8" />;
}

function SubHeading({ children }: { children: React.ReactNode }) {
  return <h3 className="text-sm font-black text-foreground mt-5 mb-2">{children}</h3>;
}

// ─── Main page ───────────────────────────────────────────────────────────────
export default function PrivacyPolicy() {
  const [activeSection, setActiveSection] = useState("");

  useEffect(() => {
    const observer = new IntersectionObserver(
      entries => entries.forEach(e => { if (e.isIntersecting) setActiveSection(e.target.id); }),
      { rootMargin: "-30% 0px -60% 0px" }
    );
    SECTIONS.forEach(s => {
      const el = document.getElementById(s.id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  const scrollTo = (id: string) =>
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      {/* Hero */}
      <div className="relative overflow-hidden border-b border-border/50 bg-card/30">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent pointer-events-none" />
        <div className="container mx-auto px-4 pt-32 pb-12 relative">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
            <Link to="/" className="hover:text-primary transition-colors">Home</Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-foreground font-medium">Privacy Policy</span>
          </div>
          <div className="flex items-start gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0 mt-1">
              <Lock className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-black text-foreground font-['Space_Grotesk']">
                Privacy Policy
              </h1>
              <p className="text-muted-foreground mt-1 text-sm">
                Teshkid Is Crypto ·{" "}
                <span className="text-primary font-semibold">Effective Date: August 7, 2026</span>
              </p>
            </div>
          </div>
          <div className="max-w-3xl">
            <Para>
              Teshkid Crypto School ("Teshkid", "we", "our", or "us") is committed to protecting your privacy.
              Teshkid Is Crypto ("Teshkid", "we", "our", or "us") is committed to protecting your privacy.
              This Privacy Policy explains what personal information we collect, how we use it, how we protect it,
              and what rights you have over your data when you use our platform, services, website, mobile applications,
              LMS, community features, and any related educational content.
            </Para>
            <InfoBox>
              By using the Teshkid platform you agree to the collection and use of your information as described in this
              Privacy Policy. Please read it carefully. If you do not agree, please discontinue use of the platform.
            </InfoBox>
          </div>
        </div>
      </div>


      {/* Two-column layout */}
      <div className="container mx-auto px-4 py-12 flex gap-8 items-start">

        {/* Sticky sidebar TOC */}
        <aside className="hidden lg:flex flex-col w-64 shrink-0 sticky top-24 max-h-[calc(100vh-7rem)] overflow-y-auto">
          <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mb-3 px-1">
            Table of Contents
          </p>
          <nav className="space-y-0.5">
            {SECTIONS.map(s => (
              <button
                key={s.id}
                onClick={() => scrollTo(s.id)}
                className={cn(
                  "w-full text-left flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-[12px] font-medium transition-all",
                  activeSection === s.id
                    ? "bg-primary/10 text-primary font-bold"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                )}
              >
                <span className="text-[10px] font-black text-muted-foreground/50 w-5 shrink-0">{s.num}</span>
                <span className="truncate">{s.title}</span>
              </button>
            ))}
          </nav>
        </aside>

        {/* Main content */}
        <main className="flex-1 min-w-0 max-w-3xl">

          {/* 01 – Overview */}
          <section id="overview" className="scroll-mt-28">
            <SectionTitle num="01" title="Overview" icon={Shield} />
            <Para>
              This Privacy Policy applies to all users of the Teshkid platform, including students, visitors, and
              anyone who interacts with our website or services. It covers all data we process — from the moment you
              visit our site to after you complete your courses.
            </Para>
            <Para>
              We are committed to transparency. We only collect data that is necessary, store it securely, and never
              sell your personal information to third parties.
            </Para>
            <NoteBox>
              This policy applies to teshkid.com and all associated subdomains, mobile applications, APIs, and services.
            </NoteBox>
          </section>
          <Divider />

          {/* 02 – What we collect */}
          <section id="data-collect" className="scroll-mt-28">
            <SectionTitle num="02" title="Information We Collect" icon={Database} />

            <SubHeading>Account & Registration Data</SubHeading>
            <BulletList items={[
              "Full name and display name",
              "Email address",
              "Username and password (stored in encrypted form)",
              "Profile picture (optional)",
              "Date of account creation",
              "Account role (student / admin)",
            ]} />

            <SubHeading>Course & Learning Data</SubHeading>
            <BulletList items={[
              "Courses enrolled in and enrollment status",
              "Lesson progress and completion percentages",
              "Quiz and assignment scores",
              "Certificates earned",
              "Watch time and lesson timestamps",
              "Notes created within courses",
              "Live session attendance",
            ]} />

            <SubHeading>Payment & Transaction Data</SubHeading>
            <BulletList items={[
              "Payment method type (card, crypto, Mpesa)",
              "Transaction reference numbers",
              "Amount paid and currency",
              "Billing address (if provided)",
              "Cryptocurrency wallet address used for payment",
              "Mpesa phone number (if used)",
            ]} />

            <SubHeading>Communication Data</SubHeading>
            <BulletList items={[
              "Messages sent to support via the Student Inbox",
              "Admin replies to your messages",
              "Internal ticket metadata (status, priority, timestamps)",
            ]} />

            <SubHeading>Technical & Usage Data</SubHeading>
            <BulletList items={[
              "IP address and approximate location",
              "Browser type and version",
              "Device type and operating system",
              "Pages visited and time spent",
              "Referring website",
              "Error logs and crash reports",
            ]} />

            <SubHeading>Profile & Preference Data</SubHeading>
            <BulletList items={[
              "Bio and personal description",
              "Timezone and language preferences",
              "Notification preferences",
              "Privacy settings (visibility, activity status)",
              "Phone number and address (optional)",
            ]} />
          </section>
          <Divider />


          {/* 03 – How we collect */}
          <section id="how-collect" className="scroll-mt-28">
            <SectionTitle num="03" title="How We Collect Information" icon={Eye} />
            <Para>We collect information through the following means:</Para>

            <SubHeading>Directly from You</SubHeading>
            <BulletList items={[
              "When you register for an account",
              "When you enroll in a course or make a payment",
              "When you update your profile settings",
              "When you send a message to support",
              "When you participate in live sessions or discussions",
            ]} />

            <SubHeading>Automatically</SubHeading>
            <BulletList items={[
              "Through cookies and similar tracking technologies",
              "Through server logs when you access our platform",
              "Through analytics tools that measure usage patterns",
              "Through error monitoring when issues occur",
            ]} />

            <SubHeading>From Third Parties</SubHeading>
            <BulletList items={[
              "Payment processors confirming transaction status",
              "Blockchain networks confirming cryptocurrency payments",
              "Authentication providers (if social login is used)",
            ]} />
          </section>
          <Divider />

          {/* 04 – How we use */}
          <section id="how-use" className="scroll-mt-28">
            <SectionTitle num="04" title="How We Use Your Information" icon={FileText} />
            <Para>We use your information to:</Para>

            <SubHeading>Provide the Service</SubHeading>
            <BulletList items={[
              "Create and manage your student account",
              "Process course enrollments and payments",
              "Track and display your learning progress",
              "Issue certificates upon course completion",
              "Provide access to purchased course content",
              "Deliver live session access and recordings",
            ]} />

            <SubHeading>Support & Communication</SubHeading>
            <BulletList items={[
              "Respond to your support messages and tickets",
              "Send important account and course notifications",
              "Deliver announcements about platform updates",
              "Send payment confirmations and receipts",
            ]} />

            <SubHeading>Security & Integrity</SubHeading>
            <BulletList items={[
              "Detect and prevent fraudulent activity",
              "Enforce our Terms and Conditions",
              "Monitor for unauthorized account access",
              "Protect the security of the platform and its users",
            ]} />

            <SubHeading>Improvement & Analytics</SubHeading>
            <BulletList items={[
              "Analyse how students interact with courses",
              "Improve our platform, content, and user experience",
              "Generate anonymised platform performance reports",
              "Identify and resolve technical issues",
            ]} />

            <InfoBox>
              We do not use your personal data to build advertising profiles or sell your information
              to marketers or data brokers.
            </InfoBox>
          </section>
          <Divider />

          {/* 05 – Sharing */}
          <section id="sharing" className="scroll-mt-28">
            <SectionTitle num="05" title="Sharing Your Information" icon={Users} />
            <Para>
              We do not sell, rent, or trade your personal information. We may share your information only in
              the following limited circumstances:
            </Para>

            <SubHeading>Service Providers</SubHeading>
            <Para>
              We share data with trusted third-party providers who help us operate the platform, including
              payment processors, cloud hosting providers, email delivery services, and video hosting platforms.
              These providers are contractually obligated to protect your data and use it only for the specified purpose.
            </Para>

            <SubHeading>Legal Requirements</SubHeading>
            <Para>
              We may disclose your information if required by law, court order, or government authority, or if
              we believe disclosure is necessary to protect the rights, property, or safety of Teshkid, its users,
              or the public.
            </Para>

            <SubHeading>Business Transfers</SubHeading>
            <Para>
              In the event of a merger, acquisition, or sale of assets, your information may be transferred as
              part of that transaction. We will notify you before your data becomes subject to a different privacy policy.
            </Para>

            <SubHeading>With Your Consent</SubHeading>
            <Para>
              In any other situation, we will only share your data with your explicit consent.
            </Para>
          </section>
          <Divider />


          {/* 06 – Crypto & Blockchain */}
          <section id="crypto" className="scroll-mt-28">
            <SectionTitle num="06" title="Cryptocurrency & Blockchain Data" icon={Globe} />
            <Para>
              When you pay using cryptocurrency, certain data is permanently recorded on a public blockchain network.
              This is an inherent property of blockchain technology and is outside Teshkid's control.
            </Para>
            <BulletList items={[
              "Cryptocurrency wallet addresses used in transactions are recorded on the public blockchain.",
              "Transaction amounts and timestamps are publicly visible on the blockchain.",
              "We store your wallet address internally to verify your payment.",
              "We do not publicly display your wallet address on the platform.",
              "Blockchain transaction records cannot be deleted or altered by Teshkid.",
            ]} />
            <WarningBox>
              Blockchain transactions are irreversible and permanently public. Never share your private keys or
              seed phrases with anyone, including Teshkid staff.
            </WarningBox>
          </section>
          <Divider />

          {/* 07 – Cookies */}
          <section id="cookies" className="scroll-mt-28">
            <SectionTitle num="07" title="Cookies & Tracking" icon={Cookie} />
            <Para>
              Teshkid uses cookies and similar technologies to enhance your experience, maintain your session,
              and understand how you use the platform.
            </Para>

            <SubHeading>Types of Cookies We Use</SubHeading>
            <BulletList items={[
              "Essential cookies — required for the platform to function (authentication, session management).",
              "Preference cookies — remember your settings such as language and timezone.",
              "Analytics cookies — help us understand platform usage patterns (anonymised data).",
              "Security cookies — detect and prevent fraudulent or malicious activity.",
            ]} />

            <Para>
              You can control cookie settings through your browser. Disabling essential cookies may affect your
              ability to use the platform.
            </Para>
            <NoteBox>
              We do not use advertising or third-party tracking cookies. We do not share cookie data with
              advertisers.
            </NoteBox>
          </section>
          <Divider />

          {/* 08 – Storage & Security */}
          <section id="storage" className="scroll-mt-28">
            <SectionTitle num="08" title="Data Storage & Security" icon={Server} />
            <Para>
              Your data is stored on secure servers with industry-standard protections. We implement multiple
              layers of security including:
            </Para>
            <BulletList items={[
              "Passwords are hashed using bcrypt — we never store plain-text passwords.",
              "All data is transmitted over HTTPS/TLS encrypted connections.",
              "Database access is restricted to authorised systems and personnel only.",
              "Authentication tokens are short-lived and securely managed.",
              "Regular security audits and vulnerability assessments are conducted.",
              "Failed login attempts trigger automatic security lockouts.",
              "Admin actions are logged for audit purposes.",
            ]} />
            <InfoBox>
              Despite our best efforts, no method of transmission or storage is 100% secure. We encourage you
              to use a strong, unique password and enable any available security features on your account.
            </InfoBox>
          </section>
          <Divider />

          {/* 09 – Retention */}
          <section id="retention" className="scroll-mt-28">
            <SectionTitle num="09" title="Data Retention" icon={Trash2} />
            <Para>We retain your personal data for as long as necessary to:</Para>
            <BulletList items={[
              "Maintain your active account and provide the service.",
              "Comply with our legal, tax, and financial obligations.",
              "Resolve disputes and enforce our agreements.",
              "Preserve certificates and academic records as required.",
            ]} />
            <Para>
              When you delete your account, we will remove or anonymise your personal data within a reasonable
              period, except where retention is required by law or legitimate business need. Course completion
              records and certificates may be retained for longer periods to verify credentials.
            </Para>
            <Para>
              Payment transaction records are retained for a minimum of 7 years in accordance with financial
              regulations.
            </Para>
          </section>
          <Divider />


          {/* 10 – Your Rights */}
          <section id="rights" className="scroll-mt-28">
            <SectionTitle num="10" title="Your Rights" icon={UserCheck} />
            <Para>
              Depending on your location, you may have the following rights regarding your personal data:
            </Para>

            <SubHeading>Access</SubHeading>
            <Para>You have the right to request a copy of the personal data we hold about you.</Para>

            <SubHeading>Correction</SubHeading>
            <Para>
              You can update most of your personal information directly in your profile settings. For other
              corrections, contact us and we will update inaccurate data promptly.
            </Para>

            <SubHeading>Deletion</SubHeading>
            <Para>
              You may request deletion of your account and associated personal data. Some data may be retained
              where legally required (e.g. payment records, certificate records).
            </Para>

            <SubHeading>Restriction & Objection</SubHeading>
            <Para>
              You may request that we limit or stop certain processing of your data in specific circumstances.
            </Para>

            <SubHeading>Data Portability</SubHeading>
            <Para>
              You may request your data in a structured, machine-readable format where technically feasible.
            </Para>

            <SubHeading>Withdraw Consent</SubHeading>
            <Para>
              Where processing is based on your consent, you may withdraw it at any time without affecting the
              lawfulness of processing before withdrawal.
            </Para>

            <NoteBox>
              To exercise any of these rights, contact us through the Student Inbox or the official contact
              information on the platform. We will respond within a reasonable timeframe and in accordance with
              applicable law.
            </NoteBox>
          </section>
          <Divider />

          {/* 11 – Children */}
          <section id="children" className="scroll-mt-28">
            <SectionTitle num="11" title="Children's Privacy" icon={Shield} />
            <Para>
              Teshkid is not directed at children under the age of 18. We do not knowingly collect personal
              data from anyone under 18 without verified parental or guardian consent.
            </Para>
            <Para>
              If you are a parent or guardian and believe your child has provided us with personal information
              without your consent, please contact us immediately. We will take prompt action to delete such data.
            </Para>
          </section>
          <Divider />

          {/* 12 – Third-Party */}
          <section id="third-party" className="scroll-mt-28">
            <SectionTitle num="12" title="Third-Party Services" icon={Globe} />
            <Para>
              Our platform integrates with third-party services to deliver certain features. These include:
            </Para>
            <BulletList items={[
              "Payment processors (card payments, Mpesa)",
              "Cryptocurrency payment networks (Bitcoin, Ethereum, stablecoins)",
              "Cloud hosting and content delivery networks",
              "Video hosting platforms for course content",
              "Email delivery services for notifications",
              "Analytics services for platform improvement",
            ]} />
            <Para>
              Each third-party service operates under its own privacy policy. We encourage you to review the
              privacy policies of any third-party services you interact with through our platform. Teshkid is not
              responsible for the privacy practices of third-party services.
            </Para>
          </section>
          <Divider />

          {/* 13 – International Transfers */}
          <section id="transfers" className="scroll-mt-28">
            <SectionTitle num="13" title="International Transfers" icon={Globe} />
            <Para>
              Teshkid serves students globally. Your information may be stored or processed in countries other
              than your country of residence. These countries may have different data protection laws.
            </Para>
            <Para>
              When transferring data internationally, we take appropriate steps to ensure your information
              receives an adequate level of protection, including using standard contractual clauses and working
              only with reputable service providers.
            </Para>
          </section>
          <Divider />

          {/* 14 – Changes */}
          <section id="changes" className="scroll-mt-28">
            <SectionTitle num="14" title="Changes to This Policy" icon={RefreshCw} />
            <Para>
              We may update this Privacy Policy from time to time to reflect changes in our practices, technology,
              legal requirements, or for other operational reasons. The updated version will always be available
              at <span className="text-primary font-semibold">teshkid.com/privacy</span>.
            </Para>
            <Para>
              We will notify you of material changes through a prominent notice on the platform or by email.
              Continued use of the platform after changes are published constitutes your acceptance of the
              updated policy.
            </Para>
          </section>
          <Divider />

          {/* 15 – Contact */}
          <section id="contact" className="scroll-mt-28">
            <SectionTitle num="15" title="Contact Us" icon={Mail} />
            <Para>
              If you have any questions, concerns, or requests regarding this Privacy Policy or the way we handle
              your personal data, please contact us through:
            </Para>
            <BulletList items={[
              "The Student Inbox on your dashboard",
              "The official contact information listed on the Teshkid platform",
            ]} />
            <NoteBox>
              We take all privacy inquiries seriously and aim to respond within 7 business days.
            </NoteBox>
          </section>
          <Divider />


          {/* Commitment block */}
          <section className="rounded-2xl border border-primary/20 bg-primary/5 p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center">
                <Lock className="w-5 h-5 text-primary" />
              </div>
              <h2 className="text-lg font-black text-foreground font-['Space_Grotesk']">
                Our Commitment to Your Privacy
              </h2>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              At Teshkid Crypto School, we believe that privacy is a fundamental right. We are committed to
              At Teshkid Is Crypto, we believe that privacy is a fundamental right. We are committed to
              being transparent about the data we collect, responsible in how we use it, and accountable if
              anything goes wrong. Your trust is the foundation of everything we do. By using Teshkid, you
              agree to this Privacy Policy and trust us to handle your information with care and integrity.
            </p>
          </section>

          {/* Bottom nav */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 pb-2">
            <p className="text-xs text-muted-foreground">
              Last updated:{" "}
              <span className="font-semibold text-foreground">August 7, 2026</span>
            </p>
            <div className="flex gap-4">
              <Link to="/terms" className="text-xs font-bold text-primary hover:underline">
                Terms &amp; Conditions
              </Link>
              <Link to="/courses" className="text-xs font-bold text-primary hover:underline">
                Browse Courses
              </Link>
            </div>
          </div>

        </main>
      </div>{/* end two-column */}

      <Footer />
    </div>
  );
}

import { useEffect, useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import api from "@/lib/api";
import { getImageUrl } from "@/lib/imageUtils";
import { toast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { Switch } from "@/components/ui/switch";
import { ConfirmDialog } from "@/components/ui/ConfirmDialog";
import {
  User,
  Mail,
  Shield,
  Zap,
  Trash2,
  Eye,
  Lock,
  Check,
  X,
  Calendar,
  Users,
  TrendingUp,
} from "lucide-react";

export default function AdminUsers() {
  const [users, setUsers] = useState<any[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [confirmState, setConfirmState] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    onConfirm: () => void;
    variant?: "default" | "destructive";
  }>({
    isOpen: false,
    title: "",
    description: "",
    onConfirm: () => { },
  });
  const navigate = useNavigate();

  useEffect(() => {
    fetchUsers();
  }, []);

  useEffect(() => {
    filterUsers();
  }, [users, searchQuery, roleFilter]);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const res = await api.get("/admin/users");
      setUsers(res.data);
    } catch (err) {
      console.error(err);
      toast({ title: "Error", description: "Could not load users." });
    } finally {
      setLoading(false);
    }
  };

  const filterUsers = () => {
    let filtered = users;

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(
        (u) =>
          u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          u.email.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filter by role
    if (roleFilter !== "all") {
      filtered = filtered.filter((u) => u.role === roleFilter);
    }

    setFilteredUsers(filtered);
  };

  const handleRoleChange = async (id: string, role: string) => {
    try {
      await api.put(`/admin/users/${id}`, { role });
      toast({ title: "Updated", description: "User role updated." });
      fetchUsers();
    } catch (err) {
      console.error(err);
      toast({ title: "Error", description: "Could not update user." });
    }
  };

  const handlePremiumChange = async (id: string, isPremium: boolean) => {
    try {
      await api.put(`/admin/users/${id}`, { isPremium });
      toast({ title: "Updated", description: "User premium status updated." });
      fetchUsers();
    } catch (err) {
      console.error(err);
      toast({ title: "Error", description: "Could not update user." });
    }
  };

  const handleDelete = async (id: string) => {
    setConfirmState({
      isOpen: true,
      title: "Delete User",
      description: "Are you sure you want to delete this user? This action cannot be undone and will remove all their progress and enrollments.",
      variant: "destructive",
      onConfirm: async () => {
        try {
          await api.delete(`/admin/users/${id}`);
          toast({ title: "Deleted", description: "User deleted." });
          fetchUsers();
        } catch (err) {
          console.error(err);
          toast({ title: "Error", description: "Could not delete user." });
        }
      },
    });
  };

  const handleOpenPasswordDialog = (user: any) => {
    setSelectedUser(user);
    setNewPassword("");
    setConfirmPassword("");
    setShowPasswordDialog(true);
  };

  const handleChangePassword = async () => {
    if (!newPassword || !confirmPassword) {
      toast({ title: "Error", description: "Please fill in all fields." });
      return;
    }

    if (newPassword !== confirmPassword) {
      toast({ title: "Error", description: "Passwords do not match." });
      return;
    }

    if (newPassword.length < 6) {
      toast({
        title: "Error",
        description: "Password must be at least 6 characters.",
      });
      return;
    }

    setPasswordLoading(true);
    try {
      await api.put(`/admin/users/${selectedUser.id}/change-password`, {
        password: newPassword,
      });
      toast({
        title: "Success",
        description: "Password changed successfully.",
      });
      setShowPasswordDialog(false);
      fetchUsers();
    } catch (err) {
      console.error(err);
      toast({ title: "Error", description: "Could not change password." });
    } finally {
      setPasswordLoading(false);
    }
  };

  const handleBlockUser = async (id: string, isBlocked: boolean) => {
    const action = isBlocked ? "enable" : "disable";
    setConfirmState({
      isOpen: true,
      title: `${action.charAt(0).toUpperCase() + action.slice(1)} User Account`,
      description: `Are you sure you want to ${action} this user's account? ${isBlocked ? "They will be able to log in again." : "They will be prevented from logging in."}`,
      variant: isBlocked ? "default" : "destructive",
      onConfirm: async () => {
        try {
          await api.put(`/admin/users/${id}/block`, {
            blocked: !isBlocked,
          });
          toast({
            title: "Updated",
            description: `User account ${isBlocked ? "enabled" : "disabled"}.`,
          });
          fetchUsers();
        } catch (err) {
          console.error(err);
          toast({ title: "Error", description: "Could not update user." });
        }
      },
    });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <main className="flex-1 pt-32 sm:pt-40 pb-12">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="mb-8 flex items-center justify-between">
            <div>
              <h1 className="font-display text-4xl font-bold mb-2">
                Manage Users
              </h1>
              <p className="text-muted-foreground">
                View, manage, and monitor user accounts
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={() => navigate("/admin")}>
                Back to Admin
              </Button>
              <Button onClick={fetchUsers} variant="default">
                Refresh
              </Button>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Users</p>
                    <p className="text-2xl font-bold">{users.length}</p>
                  </div>
                  <Users className="h-8 w-8 text-primary/50" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Students</p>
                    <p className="text-2xl font-bold">
                      {users.filter((u) => u.role === "STUDENT").length}
                    </p>
                  </div>
                  <User className="h-8 w-8 text-blue-500/50" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Admins</p>
                    <p className="text-2xl font-bold">
                      {users.filter((u) => u.role === "ADMIN").length}
                    </p>
                  </div>
                  <Shield className="h-8 w-8 text-orange-500/50" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Premium</p>
                    <p className="text-2xl font-bold">
                      {users.filter((u) => u.isPremium).length}
                    </p>
                  </div>
                  <Zap className="h-8 w-8 text-yellow-500/50" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Search and Filter */}
          <div className="mb-8 space-y-4">
            <Input
              placeholder="Search by name or email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-10"
            />

            <div className="flex gap-2">
              {["all", "STUDENT", "ADMIN"].map((role) => (
                <Button
                  key={role}
                  variant={roleFilter === role ? "default" : "outline"}
                  onClick={() => setRoleFilter(role)}
                  className="capitalize"
                >
                  {role === "all" ? "All Roles" : role}
                </Button>
              ))}
            </div>
          </div>

          {/* Users Grid */}
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <div className="text-lg text-muted-foreground">
                Loading users...
              </div>
            </div>
          ) : filteredUsers.length === 0 ? (
            <div className="flex items-center justify-center py-20">
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-2">No users found</h3>
                <p className="text-muted-foreground">
                  Try adjusting your search or filter criteria.
                </p>
              </div>
            </div>
          ) : (
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-muted/50 border-b border-border">
                      <tr>
                        <th className="text-left py-4 px-6 font-semibold text-muted-foreground">
                          User
                        </th>
                        <th className="text-left py-4 px-6 font-semibold text-muted-foreground">
                          Email
                        </th>
                        <th className="text-left py-4 px-6 font-semibold text-muted-foreground">
                          Role
                        </th>
                        <th className="text-left py-4 px-6 font-semibold text-muted-foreground">
                          Enrollments
                        </th>
                        <th className="text-left py-4 px-6 font-semibold text-muted-foreground">
                          Progress
                        </th>
                        <th className="text-left py-4 px-6 font-semibold text-muted-foreground">
                          Premium
                        </th>
                        <th className="text-left py-4 px-6 font-semibold text-muted-foreground">
                          Status
                        </th>
                        <th className="text-left py-4 px-6 font-semibold text-muted-foreground">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredUsers.map((user) => (
                        <tr
                          key={user.id}
                          className="border-b border-border hover:bg-muted/30 transition-colors"
                        >
                          {/* User Profile */}
                          <td className="py-4 px-6">
                            <div className="flex items-center gap-3">
                              <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center flex-shrink-0 overflow-hidden">
                                {user.profilePicture ? (
                                  <img
                                    src={getImageUrl(user.profilePicture) || ''}
                                    alt={user.name}
                                    className="h-full w-full object-cover"
                                  />
                                ) : (
                                  <User className="h-5 w-5 text-muted-foreground" />
                                )}
                              </div>
                              <div>
                                <p className="font-medium">{user.name}</p>
                                <p className="text-xs text-muted-foreground">
                                  {new Date(user.createdAt).toLocaleDateString()}
                                </p>
                              </div>
                            </div>
                          </td>

                          {/* Email */}
                          <td className="py-4 px-6">
                            <p className="text-sm">{user.email}</p>
                          </td>

                          {/* Role */}
                          <td className="py-4 px-6">
                            <select
                              value={user.role}
                              onChange={(e) =>
                                handleRoleChange(user.id, e.target.value)
                              }
                              className="text-xs bg-secondary border border-border rounded px-2 py-1"
                            >
                              <option value="STUDENT">Student</option>
                              <option value="ADMIN">Admin</option>
                            </select>
                          </td>

                          {/* Enrollments */}
                          <td className="py-4 px-6">
                            <div className="flex items-center gap-1 text-sm">
                              <Users className="h-4 w-4 text-muted-foreground" />
                              {user.enrollmentsCount || 0}
                            </div>
                          </td>

                          {/* Progress */}
                          <td className="py-4 px-6">
                            <div className="flex items-center gap-2">
                              <div className="w-16 bg-secondary rounded-full h-1.5">
                                <div
                                  className="bg-primary h-1.5 rounded-full transition-all"
                                  style={{
                                    width: `${user.averageProgress || 0}%`,
                                  }}
                                />
                              </div>
                              <span className="text-xs font-semibold min-w-[30px]">
                                {user.averageProgress || 0}%
                              </span>
                            </div>
                          </td>

                          {/* Premium */}
                          <td className="py-4 px-6">
                            <Switch
                              checked={!!user.isPremium}
                              onCheckedChange={(checked) =>
                                handlePremiumChange(user.id, checked)
                              }
                            />
                          </td>

                          {/* Status */}
                          <td className="py-4 px-6">
                            <div className="flex items-center gap-2">
                              {user.isBlocked ? (
                                <>
                                  <div className="h-2 w-2 rounded-full bg-red-500" />
                                  <span className="text-xs font-medium text-red-600">
                                    Blocked
                                  </span>
                                </>
                              ) : (
                                <>
                                  <div className="h-2 w-2 rounded-full bg-green-500" />
                                  <span className="text-xs font-medium text-green-600">
                                    Active
                                  </span>
                                </>
                              )}
                            </div>
                          </td>

                          {/* Actions */}
                          <td className="py-4 px-6">
                            <div className="flex items-center gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => navigate(`/admin/users/${user.id}`)}
                                title="View Details"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>

                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleOpenPasswordDialog(user)}
                                title="Change Password"
                              >
                                <Lock className="h-4 w-4" />
                              </Button>

                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() =>
                                  handleBlockUser(user.id, user.isBlocked)
                                }
                                title={user.isBlocked ? "Enable Account" : "Disable Account"}
                              >
                                {user.isBlocked ? (
                                  <Check className="h-4 w-4" />
                                ) : (
                                  <X className="h-4 w-4" />
                                )}
                              </Button>

                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDelete(user.id)}
                                className="text-destructive hover:text-destructive"
                                title="Delete User"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Results Count */}
          {!loading && (
            <div className="text-center text-sm text-muted-foreground">
              Showing {filteredUsers.length} of {users.length} users
            </div>
          )}
        </div>
      </main>

      {/* Password Change Dialog */}
      <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change Password for {selectedUser?.name}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">
                New Password
              </label>
              <Input
                type="password"
                placeholder="Enter new password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">
                Confirm Password
              </label>
              <Input
                type="password"
                placeholder="Confirm new password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />
            </div>

            {newPassword && confirmPassword && newPassword !== confirmPassword && (
              <p className="text-sm text-red-500">Passwords do not match</p>
            )}

            {newPassword && newPassword.length < 6 && (
              <p className="text-sm text-yellow-600">
                Password must be at least 6 characters
              </p>
            )}
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowPasswordDialog(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleChangePassword}
              disabled={
                passwordLoading ||
                !newPassword ||
                !confirmPassword ||
                newPassword !== confirmPassword ||
                newPassword.length < 6
              }
            >
              {passwordLoading ? "Changing..." : "Change Password"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Footer />
      <ConfirmDialog
        isOpen={confirmState.isOpen}
        onOpenChange={(open) => setConfirmState(prev => ({ ...prev, isOpen: open }))}
        title={confirmState.title}
        description={confirmState.description}
        onConfirm={confirmState.onConfirm}
        variant={confirmState.variant}
      />
    </div>
  );
}

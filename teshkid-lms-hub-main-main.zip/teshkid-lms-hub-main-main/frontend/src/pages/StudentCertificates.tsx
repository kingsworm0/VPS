import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import api from "@/lib/api";
import { Award, ChevronRight, Medal, Trophy } from "lucide-react";

export default function StudentCertificates() {
  const [certs, setCerts] = useState<any[]>([]);
  const [gamification, setGamification] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [certRes, dashRes] = await Promise.all([
        api.get("/certificates"),
        api.get("/dashboard").catch(() => ({ data: {} })),
      ]);
      setCerts(certRes.data);
      setGamification(dashRes.data.gamification);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const xpProgress = gamification
    ? Math.round(
        ((gamification.xp - gamification.xpForCurrentLevel) /
          (gamification.xpForNextLevel - gamification.xpForCurrentLevel)) *
          100
      )
    : 0;

  return (
    <DashboardLayout xp={gamification?.xp} level={gamification?.level} xpProgress={xpProgress}>
      <div className="max-w-5xl mx-auto px-4 md:px-8 py-8 space-y-6">
        <div>
          <h1 className="text-2xl font-black font-sans text-foreground">Achievements</h1>
          <p className="text-sm text-muted-foreground mt-1">Your earned certificates and badges</p>
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[
            { label: "Certificates Earned", value: certs.length, icon: Award, color: "text-amber-400", bg: "bg-amber-500/10 border-amber-500/20" },
            { label: "Courses Mastered", value: certs.length, icon: Trophy, color: "text-violet-400", bg: "bg-violet-500/10 border-violet-500/20" },
            { label: "Current Level", value: `Lv. ${gamification?.level ?? 1}`, icon: Medal, color: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/20" },
          ].map((s) => (
            <div key={s.label} className={`rounded-2xl border bg-card/60 p-4 shadow-md ${s.bg}`}>
              <div className="flex items-center gap-2 mb-2">
                <s.icon className={`w-4 h-4 ${s.color}`} />
                <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">{s.label}</span>
              </div>
              <div className="text-3xl font-black text-foreground">{s.value}</div>
            </div>
          ))}
        </div>

        {/* Certificates grid */}
        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : certs.length > 0 ? (
          <div className="grid md:grid-cols-2 gap-5">
            {certs.map((cert) => (
              <div
                key={cert.id}
                className="group rounded-2xl border border-border/60 bg-card/60 overflow-hidden hover:border-primary/40 hover:shadow-xl transition-all"
              >
                <div className="h-40 relative overflow-hidden bg-muted">
                  <img
                    src={cert.thumbnail || "/placeholder.svg"}
                    alt={cert.courseTitle}
                    className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent flex items-end p-4">
                    <div className="w-10 h-10 rounded-full bg-amber-500 flex items-center justify-center shadow-xl border-2 border-white/20">
                      <Medal className="w-5 h-5 text-white" />
                    </div>
                  </div>
                </div>
                <div className="p-5">
                  <p className="text-[10px] font-black uppercase tracking-widest text-primary mb-1">Certified Master</p>
                  <h3 className="text-base font-bold text-foreground mb-3 truncate">{cert.courseTitle}</h3>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Issued On</p>
                      <p className="text-sm font-black text-foreground">{new Date(cert.issuedAt).toLocaleDateString()}</p>
                    </div>
                    <button
                      onClick={() => navigate(`/certificates/${cert.id}`)}
                      className="flex items-center gap-1 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-bold hover:bg-primary/90 transition-all shadow-md shadow-primary/20"
                    >
                      View <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-border/60 p-16 text-center">
            <Award className="w-14 h-14 mx-auto mb-4 text-muted-foreground/20" />
            <h3 className="text-xl font-black text-foreground mb-2">No Certificates Yet</h3>
            <p className="text-muted-foreground text-sm mb-6 max-w-sm mx-auto">
              Complete a course 100% to earn a verified certificate.
            </p>
            <button
              onClick={() => navigate("/courses")}
              className="px-6 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-bold hover:bg-primary/90 transition-all shadow-md shadow-primary/20"
            >
              Explore Courses
            </button>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}

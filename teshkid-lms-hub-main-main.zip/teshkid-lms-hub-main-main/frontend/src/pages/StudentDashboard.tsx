import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { toast } from "sonner";
import {
  BookOpen,
  CheckCircle,
  BarChart3,
  Award,
  Flame,
  Play,
  Lock,
  Clock,
  Trash2,
  ChevronRight,
  Target,
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { cn } from "@/lib/utils";

interface DashboardStats {
  enrolledCourses: number;
  completedLessons: number;
  totalLessons: number;
  completionPercentage: number;
}

interface Gamification {
  xp: number;
  streak: number;
  level: number;
  xpForCurrentLevel: number;
  xpForNextLevel: number;
  dailyGoalLessons: number;
  lessonsToday: number;
  memberSince: string;
}

interface Course {
  id: string;
  title: string;
  description: string;
  thumbnail?: string;
  lessonsCompleted: number;
  totalLessons: number;
  enrolledAt: string;
  status: string;
}

const COLORS = ["#7c3aed", "#f59e0b", "#10b981", "#ef4444", "#3b82f6", "#ec4899"];

export default function StudentDashboard() {
  const { user, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [gamification, setGamification] = useState<Gamification | null>(null);
  const [recentCourses, setRecentCourses] = useState<Course[]>([]);
  const [certs, setCerts] = useState<any[]>([]);
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && user?.role === "ADMIN") {
      navigate("/admin", { replace: true });
      return;
    }
    loadDashboard();
  }, [user, authLoading, navigate]);

  const loadDashboard = async () => {
    try {
      const [dashRes, certRes, annRes] = await Promise.all([
        api.get("/dashboard"),
        api.get("/certificates").catch(() => ({ data: [] })),
        api.get("/announcements").catch(() => ({ data: [] })),
      ]);
      setStats(dashRes.data.stats);
      setRecentCourses(dashRes.data.recentCourses);
      setGamification(dashRes.data.gamification);
      setCerts(certRes.data);
      if (annRes.data && Array.isArray(annRes.data)) {
        setAnnouncements(annRes.data);
      }
    } catch (error) {
      console.error("Failed to load dashboard:", error);
      toast.error("Failed to load dashboard");
    } finally {
      setLoading(false);
    }
  };

  const xpProgress = gamification
    ? Math.round(
        ((gamification.xp - gamification.xpForCurrentLevel) /
          (gamification.xpForNextLevel - gamification.xpForCurrentLevel)) *
          100
      )
    : 0;

  const memberSinceFormatted = gamification?.memberSince
    ? new Date(gamification.memberSince).toLocaleDateString("en-US", {
        month: "long",
        year: "numeric",
      })
    : "";

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-muted-foreground text-sm font-medium">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <DashboardLayout xp={gamification?.xp} level={gamification?.level} xpProgress={xpProgress}>
      <div className="max-w-5xl mx-auto px-4 md:px-8 py-8 space-y-6">

        {/* Announcements Banner */}
        {announcements.length > 0 && (
          <div className="space-y-3 mb-6">
            {announcements.map((ann, idx) => (
              <div key={ann.id || idx} className="bg-background rounded-lg border border-primary/20 p-4 flex gap-4 shadow-sm animate-in fade-in slide-in-from-top-4 duration-500">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <BookOpen className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-bold text-foreground">{ann.title}</h4>
                  <p className="text-sm text-muted-foreground mt-1">{ann.content}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── Welcome Card ── */}
        <div className="relative rounded-2xl overflow-hidden border border-border/60 bg-card/60 backdrop-blur-sm p-6 md:p-8 shadow-xl">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-violet-900/10 pointer-events-none" />
          <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <p className="text-sm text-muted-foreground font-medium mb-1">Welcome back 👋</p>
              <h1 className="text-3xl md:text-4xl font-black font-sans text-foreground leading-tight">
                {user?.name}
              </h1>
              <p className="text-sm text-muted-foreground mt-2">
                Member since {memberSinceFormatted} · {stats?.completedLessons ?? 0} lessons completed
              </p>
            </div>
            <div className="flex items-center gap-4 shrink-0">
              <div className="flex flex-col items-center justify-center w-20 h-20 rounded-2xl bg-primary/10 border border-primary/30 shadow-lg">
                <span className="text-xl font-black text-primary">{gamification?.xp ?? 0}</span>
                <span className="text-[10px] font-bold text-primary/70 uppercase tracking-wider">XP Points</span>
              </div>
            </div>
          </div>
        </div>

        {/* ── XP Progress Card ── */}
        <div className="rounded-2xl border border-border/60 bg-card/60 backdrop-blur-sm p-5 shadow-md">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">XP Progress</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center text-white font-black text-sm shadow-lg shadow-primary/30 shrink-0">
              {gamification?.level ?? 1}
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
                <span>Level {gamification?.level ?? 1}</span>
                <span>
                  {gamification?.xp ?? 0} / {gamification?.xpForNextLevel ?? 500} XP · Lv.
                  {(gamification?.level ?? 1) + 1}
                </span>
              </div>
              <div className="h-3 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-violet-500 to-primary transition-all duration-700"
                  style={{ width: `${xpProgress}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* ── Stats Grid ── */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              label: "Enrolled Courses",
              value: stats?.enrolledCourses ?? 0,
              sub: "Active learner",
              icon: BookOpen,
              color: "text-violet-400",
              bg: "bg-violet-500/10",
              border: "border-violet-500/20",
              to: "/student/my-courses",
            },
            {
              label: "Lessons Completed",
              value: stats?.completedLessons ?? 0,
              sub: `Out of ${stats?.totalLessons ?? 0} total`,
              icon: CheckCircle,
              color: "text-emerald-400",
              bg: "bg-emerald-500/10",
              border: "border-emerald-500/20",
              to: "/student/activity",
            },
            {
              label: "Completion Rate",
              value: `${stats?.completionPercentage ?? 0}%`,
              sub: "Overall progress",
              icon: BarChart3,
              color: "text-amber-400",
              bg: "bg-amber-500/10",
              border: "border-amber-500/20",
              to: "/student/my-courses",
            },
            {
              label: "Certificates",
              value: certs.length,
              sub: "View achievements",
              icon: Award,
              color: "text-rose-400",
              bg: "bg-rose-500/10",
              border: "border-rose-500/20",
              to: "/student/achievements",
            },
          ].map((card) => (
            <Link
              key={card.label}
              to={card.to}
              className="rounded-2xl border border-border/60 bg-card/60 backdrop-blur-sm p-4 md:p-5 shadow-md hover:shadow-lg hover:border-primary/30 transition-all group block"
            >
              <div className="flex items-start justify-between mb-3">
                <p className="text-[11px] font-bold text-muted-foreground uppercase tracking-widest leading-tight">
                  {card.label}
                </p>
                <div className={cn("w-7 h-7 rounded-lg flex items-center justify-center shrink-0", card.bg, "border", card.border)}>
                  <card.icon className={cn("w-3.5 h-3.5", card.color)} />
                </div>
              </div>
              <div className="text-3xl font-black text-foreground mb-1">{card.value}</div>
              <p className="text-xs text-muted-foreground">{card.sub}</p>
            </Link>
          ))}
        </div>

        {/* ── Overall Learning Progress ── */}
        {recentCourses.length > 0 && (
          <div className="rounded-2xl border border-border/60 bg-card/60 backdrop-blur-sm p-6 shadow-md">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-base font-bold text-foreground font-sans">Overall Learning Progress</h2>
              <span className="text-xs text-muted-foreground">
                {stats?.completedLessons ?? 0} of {stats?.totalLessons ?? 0} lessons
              </span>
            </div>

            {/* Unified segmented bar */}
            <div className="flex rounded-full overflow-hidden h-3 mb-5 gap-px bg-muted">
              {recentCourses.map((course, i) => {
                const pct =
                  course.totalLessons > 0
                    ? Math.round((course.lessonsCompleted / course.totalLessons) * 100)
                    : 0;
                return (
                  <div
                    key={course.id}
                    className="h-full transition-all"
                    style={{
                      flex: course.totalLessons || 1,
                      background: COLORS[i % COLORS.length],
                      opacity: 0.3 + (pct / 100) * 0.7,
                    }}
                    title={`${course.title}: ${pct}%`}
                  />
                );
              })}
            </div>

            {/* Per-course progress bars */}
            <div className="grid sm:grid-cols-2 gap-3">
              {recentCourses.map((course, i) => {
                const pct =
                  course.totalLessons > 0
                    ? Math.round((course.lessonsCompleted / course.totalLessons) * 100)
                    : 0;
                return (
                  <div key={course.id} className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <p
                        className="text-xs font-medium text-muted-foreground truncate max-w-[75%]"
                        title={course.title}
                      >
                        {course.title.length > 28 ? course.title.slice(0, 26) + "…" : course.title}
                      </p>
                      <span className="text-xs font-bold" style={{ color: COLORS[i % COLORS.length] }}>
                        {pct}%
                      </span>
                    </div>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{ width: `${pct}%`, background: COLORS[i % COLORS.length] }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── Daily Goal ── */}
        <div className="rounded-2xl border border-border/60 bg-card/60 backdrop-blur-sm p-6 shadow-md">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-primary" />
              <h2 className="text-base font-bold text-foreground font-sans">Daily Goal</h2>
            </div>
            <span className="text-xs font-semibold text-primary">
              {gamification?.lessonsToday ?? 0} / {gamification?.dailyGoalLessons ?? 3} lessons today
            </span>
          </div>
          <div className="flex gap-1.5 mb-3">
            {Array.from({ length: gamification?.dailyGoalLessons ?? 3 }).map((_, i) => (
              <div
                key={i}
                className={cn(
                  "flex-1 h-3 rounded-full transition-all",
                  i < (gamification?.lessonsToday ?? 0)
                    ? "bg-gradient-to-r from-emerald-400 to-primary shadow-sm shadow-primary/30"
                    : "bg-muted"
                )}
              />
            ))}
          </div>
          <p className="text-xs text-muted-foreground">
            {(gamification?.lessonsToday ?? 0) >= (gamification?.dailyGoalLessons ?? 3) ? (
              <span className="text-emerald-400 font-semibold">🎉 Daily goal achieved! Great work!</span>
            ) : (
              <>
                Complete{" "}
                <span className="text-primary font-bold">
                  {(gamification?.dailyGoalLessons ?? 3) - (gamification?.lessonsToday ?? 0)} more lesson
                  {(gamification?.dailyGoalLessons ?? 3) - (gamification?.lessonsToday ?? 0) !== 1 ? "s" : ""}
                </span>{" "}
                to hit your daily goal!
              </>
            )}
          </p>
        </div>

        {/* ── My Courses ── */}
        <div id="recent-courses">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-foreground font-sans">My Courses</h2>
            <Link
              to="/student/my-courses"
              className="text-xs text-primary hover:underline font-medium flex items-center gap-1"
            >
              View all <ChevronRight className="w-3 h-3" />
            </Link>
          </div>

          {recentCourses.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-border/60 p-10 text-center">
              <BookOpen className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground mb-3">You haven't enrolled in any courses yet.</p>
              <Link to="/courses" className="text-sm text-primary hover:underline font-semibold">
                Browse courses →
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {recentCourses.map((course, i) => {
                const pct =
                  course.totalLessons > 0
                    ? Math.round((course.lessonsCompleted / course.totalLessons) * 100)
                    : 0;
                const isApproved = course.status === "APPROVED";
                const cert = certs.find((c: any) => c.courseId === course.id);

                return (
                  <div
                    key={course.id}
                    className="group rounded-2xl border border-border/60 bg-card/50 backdrop-blur-sm overflow-hidden hover:border-primary/40 hover:shadow-xl transition-all"
                  >
                    <div className="grid md:grid-cols-3">
                      <div className="relative aspect-video md:aspect-auto bg-muted min-h-[120px]">
                        <img
                          src={course.thumbnail || "/placeholder.svg"}
                          alt={course.title}
                          className={cn("w-full h-full object-cover", !isApproved && "grayscale blur-[2px]")}
                        />
                        {!isApproved && (
                          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                            <Lock className="w-7 h-7 text-white/60" />
                          </div>
                        )}
                        <div className="absolute top-2 left-2">
                          <span
                            className={cn(
                              "text-[10px] font-black uppercase px-2 py-1 rounded-full",
                              isApproved
                                ? "bg-emerald-500 text-white"
                                : "bg-yellow-500 text-white animate-pulse"
                            )}
                          >
                            {isApproved ? "Active" : "Pending"}
                          </span>
                        </div>
                      </div>

                      <div className="md:col-span-2 p-5 flex flex-col justify-between">
                        <div>
                          <div className="flex items-start justify-between gap-2 mb-2">
                            <h3 className="font-bold text-foreground text-base group-hover:text-primary transition-colors leading-tight">
                              {course.title}
                            </h3>
                            <span className="text-2xl font-black text-primary shrink-0">{pct}%</span>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
                            {isApproved ? (
                              <span className="flex items-center gap-1 text-emerald-500">
                                <CheckCircle className="w-3 h-3" /> Access Granted
                              </span>
                            ) : (
                              <span className="flex items-center gap-1 text-yellow-500">
                                <Clock className="w-3 h-3" /> Awaiting Verification
                              </span>
                            )}
                            <span>·</span>
                            <span>{new Date(course.enrolledAt).toLocaleDateString()}</span>
                          </div>
                          <div className="space-y-1.5 mb-5">
                            <div className="flex justify-between text-xs text-muted-foreground">
                              <span>
                                {course.lessonsCompleted}/{course.totalLessons} Lessons
                              </span>
                            </div>
                            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                              <div
                                className="h-full rounded-full transition-all"
                                style={{ width: `${pct}%`, background: COLORS[i % COLORS.length] }}
                              />
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          {cert ? (
                            <Link to={`/certificates/${cert.id}`} className="flex-1">
                              <button className="w-full h-10 rounded-xl bg-gradient-to-r from-emerald-600 to-primary text-white text-sm font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-all shadow-md shadow-emerald-500/20">
                                <Award className="w-4 h-4 text-yellow-300" />
                                View Certificate
                              </button>
                            </Link>
                          ) : pct === 100 ? (
                            <Link to={`/courses/${course.id}/learn`} className="flex-1">
                              <button className="w-full h-10 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-black text-sm font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-all shadow-md shadow-yellow-500/20 animate-pulse">
                                <Award className="w-4 h-4" />
                                Claim Certificate
                              </button>
                            </Link>
                          ) : (
                            <Link to={`/courses/${course.id}/learn`} className="flex-1">
                              <button className="w-full h-10 rounded-xl bg-primary text-primary-foreground text-sm font-bold flex items-center justify-center gap-2 hover:bg-primary/90 transition-all shadow-md shadow-primary/20">
                                <Play className="w-3.5 h-3.5 fill-current" />
                                {isApproved ? "Continue Learning" : "View Curriculum"}
                              </button>
                            </Link>
                          )}
                          <button
                            onClick={() => {
                              if (confirm("Forfeit this course? You will lose all progress.")) {
                                api
                                  .post(`/enrollments/forfeit/${course.id}`)
                                  .then(() => {
                                    toast.success("Course forfeited");
                                    loadDashboard();
                                  })
                                  .catch(() => toast.error("Failed to forfeit course"));
                              }
                            }}
                            className="w-10 h-10 rounded-xl bg-muted/50 text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-all flex items-center justify-center"
                            title="Forfeit Course"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}

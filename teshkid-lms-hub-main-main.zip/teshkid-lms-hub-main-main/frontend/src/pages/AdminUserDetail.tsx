import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import api from "@/lib/api";
import { toast } from "@/hooks/use-toast";
import {
  Calendar,
  Mail,
  Shield,
  Book,
  CheckCircle2,
  Clock,
  TrendingUp,
} from "lucide-react";

export default function AdminUserDetail() {
  const { id } = useParams();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showProfilePhoto, setShowProfilePhoto] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    api
      .get(`/admin/users/${id}`)
      .then((res) => setUser(res.data))
      .catch((err) => {
        console.error(err);
        toast({ title: "Error", description: "Could not load user." });
      })
      .finally(() => setLoading(false));
  }, [id]);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <main className="flex-1 pt-24 pb-12">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="font-display text-4xl font-bold mb-2">User Details</h1>
              <p className="text-muted-foreground">View user profile and enrollment history</p>
            </div>
            <Button
              variant="outline"
              onClick={() => navigate("/admin/users")}
            >
              Back to Users
            </Button>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-20">
              <div className="text-lg text-muted-foreground">Loading user...</div>
            </div>
          ) : !user ? (
            <div className="flex items-center justify-center py-20">
              <div className="text-lg text-muted-foreground">User not found</div>
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-6">
              {/* Profile Card */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle>Profile Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="h-20 w-20 rounded-full bg-secondary flex items-center justify-center">
                    {user.profilePicture ? (
                      <button
                        type="button"
                        onClick={() => setShowProfilePhoto(true)}
                        className="block h-full w-full cursor-zoom-in rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-inset"
                        aria-label={`View ${user.name}'s profile photo`}
                        title="View profile photo"
                      >
                        <img
                          src={user.profilePicture}
                          alt={user.name}
                          className="h-full w-full rounded-full object-cover"
                        />
                      </button>
                    ) : (
                      <div className="text-2xl font-bold text-muted-foreground">
                        {user.name?.charAt(0)?.toUpperCase()}
                      </div>
                    )}
                  </div>

                  <Dialog open={showProfilePhoto} onOpenChange={setShowProfilePhoto}>
                    <DialogContent className="max-w-3xl border-0 bg-transparent p-2 shadow-none">
                      <DialogTitle className="sr-only">
                        {user.name}'s profile photo
                      </DialogTitle>
                      <img
                        src={user.profilePicture}
                        alt={user.name}
                        className="max-h-[80vh] w-full rounded-lg object-contain"
                      />
                    </DialogContent>
                  </Dialog>

                  <div className="space-y-3">
                    <div>
                      <p className="text-xs text-muted-foreground font-medium">Name</p>
                      <p className="font-semibold">{user.name}</p>
                    </div>

                    <div className="flex items-start gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-xs text-muted-foreground font-medium">Email</p>
                        <p className="text-sm">{user.email}</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2">
                      <Shield className="h-4 w-4 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-xs text-muted-foreground font-medium">Role</p>
                        <p className="text-sm font-medium">{user.role}</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-xs text-muted-foreground font-medium">Joined</p>
                        <p className="text-sm">
                          {new Date(user.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>

                    {user.bio && (
                      <div>
                        <p className="text-xs text-muted-foreground font-medium">Bio</p>
                        <p className="text-sm">{user.bio}</p>
                      </div>
                    )}
                  </div>

                  {/* Status Badge */}
                  <div className="pt-4 border-t border-border">
                    <p className="text-xs text-muted-foreground font-medium mb-2">Account Status</p>
                    <div className="text-sm font-medium mb-3">
                      {user.isBlocked ? (
                        <span className="text-red-500">🔒 Blocked</span>
                      ) : (
                        <span className="text-green-500">✓ Active</span>
                      )}
                    </div>
                    <Button
                      className="w-full"
                      variant={user.isBlocked ? "secondary" : "destructive"}
                      size="sm"
                      onClick={async () => {
                        try {
                          await api.put(`/admin/users/${user.id}/block`, {
                            blocked: !user.isBlocked,
                          });
                          toast({
                            title: "Updated",
                            description: user.isBlocked
                              ? "User unblocked"
                              : "User blocked",
                          });
                          const res = await api.get(`/admin/users/${id}`);
                          setUser(res.data);
                        } catch (err) {
                          console.error(err);
                          toast({
                            title: "Error",
                            description: "Could not update user.",
                          });
                        }
                      }}
                    >
                      {user.isBlocked ? "Unblock User" : "Block User"}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Enrollments Table */}
              <Card className="md:col-span-2">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle>Enrollment History</CardTitle>
                    <span className="text-sm text-muted-foreground">
                      {user.enrollments?.length || 0} courses
                    </span>
                  </div>
                </CardHeader>
                <CardContent>
                  {!user.enrollments || user.enrollments.length === 0 ? (
                    <div className="text-center py-12">
                      <Book className="h-12 w-12 text-muted-foreground/30 mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">
                        No enrollments yet
                      </p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b border-border">
                            <th className="text-left py-3 px-2 font-semibold text-muted-foreground">
                              Course
                            </th>
                            <th className="text-left py-3 px-2 font-semibold text-muted-foreground">
                              Status
                            </th>
                            <th className="text-left py-3 px-2 font-semibold text-muted-foreground">
                              Progress
                            </th>
                            <th className="text-left py-3 px-2 font-semibold text-muted-foreground">
                              Enrolled
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {user.enrollments.map((enrollment: any) => (
                            <tr
                              key={enrollment.id}
                              className="border-b border-border hover:bg-muted/50 transition-colors"
                            >
                              <td className="py-3 px-2">
                                <div>
                                  <p className="font-medium">
                                    {enrollment.courseTitle || "Unknown Course"}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    ID: {enrollment.courseId}
                                  </p>
                                </div>
                              </td>
                              <td className="py-3 px-2">
                                <div className="flex items-center gap-2">
                                  {enrollment.status === "APPROVED" ? (
                                    <>
                                      <CheckCircle2 className="h-4 w-4 text-green-500" />
                                      <span className="text-green-600 font-medium">
                                        Approved
                                      </span>
                                    </>
                                  ) : enrollment.status === "PENDING" ? (
                                    <>
                                      <Clock className="h-4 w-4 text-yellow-500" />
                                      <span className="text-yellow-600 font-medium">
                                        Pending
                                      </span>
                                    </>
                                  ) : (
                                    <span className="text-red-600 font-medium">
                                      {enrollment.status}
                                    </span>
                                  )}
                                </div>
                              </td>
                              <td className="py-3 px-2">
                                <div className="flex items-center gap-2">
                                  <div className="w-20 bg-secondary rounded-full h-2">
                                    <div
                                      className="bg-primary h-2 rounded-full transition-all"
                                      style={{
                                        width: `${enrollment.progress || 0}%`,
                                      }}
                                    />
                                  </div>
                                  <span className="text-xs font-semibold min-w-fit">
                                    {enrollment.progress || 0}%
                                  </span>
                                </div>
                              </td>
                              <td className="py-3 px-2">
                                <p className="text-xs">
                                  {enrollment.createdAt
                                    ? new Date(
                                        enrollment.createdAt
                                      ).toLocaleDateString()
                                    : "N/A"}
                                </p>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}

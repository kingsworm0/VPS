import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { cn } from "@/lib/utils";
import {
  Shield, CreditCard, AlertTriangle, BookOpen, FileText,
  Users, Globe, Lock, Scroll, Scale, Mail, ChevronRight,
  GraduationCap, Wallet, BarChart2, Award,
} from "lucide-react";

// ─── Section data ──────────────────────────────────────────────────────────
const SECTIONS = [
  { id: "about",            num: "01", title: "About Teshkid",                 icon: BookOpen },
  { id: "eligibility",      num: "02", title: "Eligibility",                    icon: Users },
  { id: "accounts",         num: "03", title: "Student Accounts",               icon: Lock },
  { id: "enrollment",       num: "04", title: "Course Enrollment",              icon: GraduationCap },
  { id: "payments",         num: "05", title: "Payments",                       icon: Wallet },
  { id: "crypto-payment",   num: "06", title: "Cryptocurrency Payment Policy",  icon: CreditCard },
  { id: "refund",           num: "07", title: "Refund Policy",                  icon: Scroll },
  { id: "disclaimer",       num: "08", title: "Educational Disclaimer",         icon: FileText },
  { id: "risk",             num: "09", title: "Cryptocurrency Risk Warning",    icon: AlertTriangle },
  { id: "certificates",     num: "10", title: "Certificates",                   icon: Award },
  { id: "community",        num: "11", title: "Community Guidelines",           icon: Users },
  { id: "blog",             num: "12", title: "Blog and Educational Content",   icon: BarChart2 },
  { id: "ip",               num: "13", title: "Intellectual Property",          icon: Shield },
  { id: "availability",     num: "14", title: "Platform Availability",          icon: Globe },
  { id: "third-party",      num: "15", title: "Third-Party Services",           icon: Globe },
  { id: "conduct",          num: "16", title: "User Conduct",                   icon: Scale },
  { id: "liability",        num: "17", title: "Limitation of Liability",        icon: Shield },
  { id: "privacy",          num: "18", title: "Privacy",                        icon: Lock },
  { id: "termination",      num: "19", title: "Suspension and Termination",     icon: Lock },
  { id: "changes-services", num: "20", title: "Changes to Courses & Services",  icon: Scroll },
  { id: "changes-terms",    num: "21", title: "Changes to These Terms",         icon: FileText },
  { id: "governing",        num: "22", title: "Governing Law",                  icon: Scale },
  { id: "contact",          num: "23", title: "Contact Us",                     icon: Mail },
];


// ─── Reusable building blocks ───────────────────────────────────────────────
function SectionTitle({ num, title, icon: Icon }: { num: string; title: string; icon: React.ElementType }) {
  return (
    <div className="flex items-center gap-3 mb-5">
      <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
        <Icon className="w-4 h-4 text-primary" />
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-[11px] font-black text-primary/60 tracking-widest uppercase">{num}</span>
        <h2 className="text-lg font-black text-foreground font-['Space_Grotesk']">{title}</h2>
      </div>
    </div>
  );
}

function BulletList({ items }: { items: string[] }) {
  return (
    <ul className="space-y-1.5 mt-3">
      {items.map((item, i) => (
        <li key={i} className="flex items-start gap-2.5 text-sm text-muted-foreground leading-relaxed">
          <ChevronRight className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  );
}

function Para({ children }: { children: React.ReactNode }) {
  return <p className="text-sm text-muted-foreground leading-relaxed mt-2">{children}</p>;
}

function WarningBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="mt-4 rounded-xl border border-destructive/20 bg-destructive/5 px-4 py-3.5 flex gap-3">
      <AlertTriangle className="w-4 h-4 text-destructive mt-0.5 shrink-0" />
      <p className="text-sm text-destructive/80 leading-relaxed">{children}</p>
    </div>
  );
}

function InfoBox({ children }: { children: React.ReactNode }) {
  return (
    <div className="mt-4 rounded-xl border border-primary/20 bg-primary/5 px-4 py-3.5 flex gap-3">
      <Shield className="w-4 h-4 text-primary mt-0.5 shrink-0" />
      <p className="text-sm text-primary/80 leading-relaxed">{children}</p>
    </div>
  );
}

function Divider() {
  return <div className="h-px bg-border/40 my-8" />;
}


// ─── Main page ───────────────────────────────────────────────────────────────
export default function TermsAndConditions() {
  const [activeSection, setActiveSection] = useState("");

  // Scroll-spy: track which section is in view
  useEffect(() => {
    const observer = new IntersectionObserver(
      entries => {
        entries.forEach(e => { if (e.isIntersecting) setActiveSection(e.target.id); });
      },
      { rootMargin: "-30% 0px -60% 0px" }
    );
    SECTIONS.forEach(s => {
      const el = document.getElementById(s.id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      {/* Hero */}
      <div className="relative overflow-hidden border-b border-border/50 bg-card/30">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent pointer-events-none" />
        <div className="container mx-auto px-4 pt-32 pb-12 relative">
          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
            <Link to="/" className="hover:text-primary transition-colors">Home</Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-foreground font-medium">Terms & Conditions</span>
          </div>
          <div className="flex items-start gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0 mt-1">
              <Scroll className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-black text-foreground font-['Space_Grotesk']">
                Terms &amp; Conditions
              </h1>
              <p className="text-muted-foreground mt-1 text-sm">
                Teshkid Is Crypto · <span className="text-primary font-semibold">Effective Date: August 7, 2026</span>
              </p>
            </div>
          </div>
          <div className="max-w-3xl">
            <p className="text-sm text-muted-foreground leading-relaxed">
              Welcome to <strong className="text-foreground">Teshkid Crypto School</strong> ("Teshkid", "we", "our", or "us").
              Welcome to <strong className="text-foreground">Teshkid Is Crypto</strong> ("Teshkid", "we", "our", or "us").
              These Terms and Conditions govern your access to and use of our website, Learning Management System (LMS),
              mobile services, educational content, blog, community, messaging platform, certificates, and all related services.
            </p>
            <InfoBox>
              By accessing or using the Teshkid platform, creating an account, enrolling in a course, or making a payment,
              you agree to be legally bound by these Terms. If you do not agree, you should not use our platform.
            </InfoBox>
          </div>
        </div>
      </div>


      {/* Two-column layout */}
      <div className="container mx-auto px-4 py-12 flex gap-8 items-start">

        {/* Sticky sidebar TOC */}
        <aside className="hidden lg:flex flex-col w-64 shrink-0 sticky top-24 max-h-[calc(100vh-7rem)] overflow-y-auto">
          <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mb-3 px-1">
            Table of Contents
          </p>
          <nav className="space-y-0.5">
            {SECTIONS.map(s => (
              <button
                key={s.id}
                onClick={() => scrollTo(s.id)}
                className={cn(
                  "w-full text-left flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-[12px] font-medium transition-all",
                  activeSection === s.id
                    ? "bg-primary/10 text-primary font-bold"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                )}
              >
                <span className="text-[10px] font-black text-muted-foreground/50 w-5 shrink-0">{s.num}</span>
                <span className="truncate">{s.title}</span>
              </button>
            ))}
          </nav>
        </aside>

        {/* Main content */}
        <main className="flex-1 min-w-0 max-w-3xl space-y-0">


          {/* 01 – About */}
          <section id="about" className="scroll-mt-28">
            <SectionTitle num="01" title="About Teshkid" icon={BookOpen} />
            <Para>
              Teshkid Crypto School is an online educational platform providing professional training in:
              Teshkid Is Crypto is an online educational platform providing professional training in:
            </Para>
            <BulletList items={[
              "Cryptocurrency Fundamentals", "Blockchain Technology", "Bitcoin & Ethereum",
              "Smart Contracts", "Web3 Development", "Decentralized Finance (DeFi)", "NFTs",
              "Technical Analysis", "Crypto Trading Strategies", "Blockchain Security",
              "Smart Contract Auditing", "DAO Governance", "Crypto Investing", "Digital Asset Security",
            ]} />
            <Para>
              Our mission is to provide practical, high-quality blockchain education through expert-led courses and hands-on learning experiences.
            </Para>
          </section>
          <Divider />

          {/* 02 – Eligibility */}
          <section id="eligibility" className="scroll-mt-28">
            <SectionTitle num="02" title="Eligibility" icon={Users} />
            <Para>To use Teshkid you must:</Para>
            <BulletList items={[
              "Be at least 18 years old, or have parental or guardian consent.",
              "Provide accurate registration information.",
              "Maintain the security of your account credentials.",
              "Comply with all applicable laws in your jurisdiction.",
            ]} />
            <Para>You are responsible for all activities that occur under your account.</Para>
          </section>
          <Divider />

          {/* 03 – Student Accounts */}
          <section id="accounts" className="scroll-mt-28">
            <SectionTitle num="03" title="Student Accounts" icon={Lock} />
            <Para>Students are responsible for:</Para>
            <BulletList items={[
              "Keeping passwords confidential.",
              "Updating personal information when necessary.",
              "Protecting their account from unauthorized access.",
            ]} />
            <Para>
              Teshkid reserves the right to suspend accounts that are suspected of fraud, abuse, or unauthorized sharing.
            </Para>
          </section>
          <Divider />

          {/* 04 – Course Enrollment */}
          <section id="enrollment" className="scroll-mt-28">
            <SectionTitle num="04" title="Course Enrollment" icon={GraduationCap} />
            <Para>Upon successful payment, students receive access to the purchased course according to its access terms.</Para>
            <Para>Course access may include:</Para>
            <BulletList items={[
              "Video lessons", "Reading materials", "Quizzes", "Assignments",
              "Downloadable resources", "Practical projects", "Certificates (where applicable)",
            ]} />
            <InfoBox>Course access is licensed to the purchaser only and may not be shared.</InfoBox>
          </section>
          <Divider />


          {/* 05 – Payments */}
          <section id="payments" className="scroll-mt-28">
            <SectionTitle num="05" title="Payments" icon={Wallet} />
            <Para>Teshkid accepts payments through approved payment gateways, including:</Para>
            <BulletList items={[
              "Credit and Debit Cards", "Bitcoin (BTC)", "Ethereum (ETH)",
              "Supported Stablecoins", "Other approved cryptocurrency payment methods", "Mpesa",
            ]} />
            <Para>Prices are displayed in USD unless otherwise stated.</Para>
            <Para>Blockchain transaction fees ("gas fees") are the responsibility of the purchaser.</Para>
            <WarningBox>
              Completed blockchain transactions cannot be reversed once confirmed on the blockchain.
              Any payment issues — the Instructor will advise.
            </WarningBox>
          </section>
          <Divider />

          {/* 06 – Crypto Payment Policy */}
          <section id="crypto-payment" className="scroll-mt-28">
            <SectionTitle num="06" title="Cryptocurrency Payment Policy" icon={CreditCard} />
            <Para>When paying with cryptocurrency:</Para>
            <BulletList items={[
              "Wallet addresses must be entered correctly.",
              "Payments sent to incorrect addresses cannot be recovered.",
              "Network congestion may delay confirmation.",
              "Exchange rate fluctuations after payment do not affect completed purchases.",
              "Additional blockchain network fees are not included in course prices.",
            ]} />
          </section>
          <Divider />

          {/* 07 – Refund Policy */}
          <section id="refund" className="scroll-mt-28">
            <SectionTitle num="07" title="Refund Policy" icon={Scroll} />
            <Para>Refund requests are considered in accordance with our Refund Policy.</Para>
            <Para>Refunds may be denied if:</Para>
            <BulletList items={[
              "More than 30% of a course has been completed.",
              "Course materials have been extensively downloaded.",
              "Certificates have already been issued.",
              "Fraudulent activity is detected.",
              "The student violates these Terms.",
            ]} />
            <Para>
              Cryptocurrency refunds, if approved, may be issued in USD equivalent or another method determined by Teshkid.
            </Para>
          </section>
          <Divider />

          {/* 08 – Educational Disclaimer */}
          <section id="disclaimer" className="scroll-mt-28">
            <SectionTitle num="08" title="Educational Disclaimer" icon={FileText} />
            <Para>All courses are intended solely for educational purposes. Nothing on the Teshkid platform constitutes:</Para>
            <BulletList items={[
              "Financial advice", "Investment advice", "Legal advice",
              "Tax advice", "Professional trading advice",
            ]} />
            <WarningBox>
              Students remain solely responsible for any investment or trading decisions made using information learned through our courses.
            </WarningBox>
          </section>
          <Divider />


          {/* 09 – Risk Warning */}
          <section id="risk" className="scroll-mt-28">
            <SectionTitle num="09" title="Cryptocurrency Risk Warning" icon={AlertTriangle} />
            <Para>Digital assets are highly volatile. Trading or investing in cryptocurrencies involves substantial financial risk.</Para>
            <Para>Students acknowledge that:</Para>
            <BulletList items={[
              "Prices may fluctuate dramatically.",
              "Losses may exceed expectations.",
              "Past market performance does not predict future results.",
              "Teshkid does not guarantee profits or successful trades.",
            ]} />
            <WarningBox>
              All investment decisions remain the sole responsibility of the student.
            </WarningBox>
          </section>
          <Divider />

          {/* 10 – Certificates */}
          <section id="certificates" className="scroll-mt-28">
            <SectionTitle num="10" title="Certificates" icon={Award} />
            <Para>Students who successfully complete eligible courses may receive a digital certificate of completion.</Para>
            <Para>Certificates:</Para>
            <BulletList items={[
              "Verify successful completion of a course.",
              "Do not constitute professional licensing.",
              "Do not guarantee employment.",
              "May be revoked if obtained through academic misconduct or fraud.",
            ]} />
          </section>
          <Divider />

          {/* 11 – Community Guidelines */}
          <section id="community" className="scroll-mt-28">
            <SectionTitle num="11" title="Community Guidelines" icon={Users} />
            <Para>Teshkid provides communication features such as:</Para>
            <BulletList items={[
              "Student Inbox", "Discussion Forums", "Community Groups", "Live Classes", "Course Discussions",
            ]} />
            <Para>Users must:</Para>
            <BulletList items={[
              "Treat others respectfully.",
              "Avoid harassment or discrimination.",
              "Avoid spam and unsolicited promotions.",
              "Refrain from sharing illegal, harmful, or offensive content.",
              "Respect instructors and moderators.",
            ]} />
            <Para>Violation of these guidelines may result in suspension or termination of access.</Para>
          </section>
          <Divider />

          {/* 12 – Blog */}
          <section id="blog" className="scroll-mt-28">
            <SectionTitle num="12" title="Blog and Educational Content" icon={BarChart2} />
            <Para>
              Articles published on the Teshkid Blog represent educational opinions and market analysis.
              Blog content should not be interpreted as:
            </Para>
            <BulletList items={[
              "Trading signals", "Investment recommendations", "Guaranteed forecasts",
            ]} />
            <Para>Readers should conduct their own research before making financial decisions.</Para>
          </section>
          <Divider />


          {/* 13 – Intellectual Property */}
          <section id="ip" className="scroll-mt-28">
            <SectionTitle num="13" title="Intellectual Property" icon={Shield} />
            <Para>All platform content remains the exclusive property of Teshkid Crypto School. This includes:</Para>
            <Para>All platform content remains the exclusive property of Teshkid Is Crypto. This includes:</Para>
            <BulletList items={[
              "Videos", "Lessons", "PDFs", "Source Code", "Smart Contract Examples",
              "Trading Examples", "Blog Articles", "Images", "Graphics", "Logos",
              "Branding", "Course Structure", "Certificates",
            ]} />
            <Para>Students may not:</Para>
            <BulletList items={[
              "Record or redistribute videos.",
              "Share premium content publicly.",
              "Sell course materials.",
              "Upload materials to other websites.",
              "Copy substantial portions of content without written permission.",
            ]} />
            <WarningBox>Unauthorized use may result in legal action.</WarningBox>
          </section>
          <Divider />

          {/* 14 – Platform Availability */}
          <section id="availability" className="scroll-mt-28">
            <SectionTitle num="14" title="Platform Availability" icon={Globe} />
            <Para>
              While we strive to maintain uninterrupted service, Teshkid does not guarantee continuous availability.
              Scheduled maintenance, software updates, or unforeseen technical issues may temporarily affect access.
              We are not liable for losses arising from service interruptions.
            </Para>
          </section>
          <Divider />

          {/* 15 – Third-Party Services */}
          <section id="third-party" className="scroll-mt-28">
            <SectionTitle num="15" title="Third-Party Services" icon={Globe} />
            <Para>Our platform may integrate with third-party services including:</Para>
            <BulletList items={[
              "Cryptocurrency wallets", "Payment processors", "Blockchain explorers",
              "Video hosting platforms", "Authentication providers", "Cloud hosting services",
            ]} />
            <Para>Teshkid is not responsible for the security, privacy, or functionality of third-party services.</Para>
          </section>
          <Divider />

          {/* 16 – User Conduct */}
          <section id="conduct" className="scroll-mt-28">
            <SectionTitle num="16" title="User Conduct" icon={Scale} />
            <Para>Users agree not to:</Para>
            <BulletList items={[
              "Attempt unauthorized access to the platform.",
              "Circumvent platform security.",
              "Upload malware or malicious software.",
              "Reverse engineer platform software.",
              "Share copyrighted course content.",
              "Impersonate instructors or other users.",
              "Disrupt platform operations.",
            ]} />
            <WarningBox>Violations may result in immediate account termination.</WarningBox>
          </section>
          <Divider />


          {/* 17 – Limitation of Liability */}
          <section id="liability" className="scroll-mt-28">
            <SectionTitle num="17" title="Limitation of Liability" icon={Shield} />
            <Para>To the maximum extent permitted by law, Teshkid Crypto School shall not be liable for:</Para>
            <Para>To the maximum extent permitted by law, Teshkid Is Crypto shall not be liable for:</Para>
            <BulletList items={[
              "Cryptocurrency trading losses.", "Investment losses.", "Business losses.",
              "Lost profits.", "Loss of digital assets.", "Data loss.",
              "Service interruptions.", "Indirect or consequential damages.",
            ]} />
            <WarningBox>Your use of the platform is entirely at your own risk.</WarningBox>
          </section>
          <Divider />

          {/* 18 – Privacy */}
          <section id="privacy" className="scroll-mt-28">
            <SectionTitle num="18" title="Privacy" icon={Lock} />
            <Para>
              Your personal information is processed in accordance with the Teshkid Privacy Policy.
              By using our platform, you consent to the collection, storage, and processing of your information
              for educational, administrative, security, and operational purposes.
            </Para>
          </section>
          <Divider />

          {/* 19 – Termination */}
          <section id="termination" className="scroll-mt-28">
            <SectionTitle num="19" title="Suspension and Termination" icon={Lock} />
            <Para>Teshkid reserves the right to suspend or permanently terminate accounts that:</Para>
            <BulletList items={[
              "Violate these Terms.", "Engage in fraud.", "Abuse staff or students.",
              "Share course materials without authorization.", "Attempt to compromise platform security.",
            ]} />
            <Para>Access may be removed without prior notice where necessary to protect the platform or its users.</Para>
          </section>
          <Divider />

          {/* 20 – Changes to Services */}
          <section id="changes-services" className="scroll-mt-28">
            <SectionTitle num="20" title="Changes to Courses & Services" icon={Scroll} />
            <Para>
              We may update, modify, improve, or discontinue courses, features, pricing, instructors, or services at any time.
              Such changes are intended to enhance the quality and security of the platform.
            </Para>
          </section>
          <Divider />

          {/* 21 – Changes to Terms */}
          <section id="changes-terms" className="scroll-mt-28">
            <SectionTitle num="21" title="Changes to These Terms" icon={FileText} />
            <Para>
              These Terms may be updated periodically. The latest version will always be available on the Teshkid website.
              Continued use of the platform after changes take effect constitutes acceptance of the revised Terms.
            </Para>
          </section>
          <Divider />

          {/* 22 – Governing Law */}
          <section id="governing" className="scroll-mt-28">
            <SectionTitle num="22" title="Governing Law" icon={Scale} />
            <Para>
              These Terms shall be governed by and interpreted in accordance with the laws applicable in the jurisdiction
              where Teshkid Crypto operates. Any disputes arising from these Terms shall be resolved through the competent
              courts or other legally recognized dispute resolution mechanisms.
            </Para>
          </section>
          <Divider />

          {/* 23 – Contact */}
          <section id="contact" className="scroll-mt-28">
            <SectionTitle num="23" title="Contact Us" icon={Mail} />
            <Para>
              For questions regarding these Terms and Conditions, support requests, or legal inquiries,
              please contact Teshkid through the official contact information provided on the platform.
            </Para>
          </section>
          <Divider />


          {/* Acceptance block */}
          <section className="rounded-2xl border border-primary/20 bg-primary/5 p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center">
                <Scroll className="w-5 h-5 text-primary" />
              </div>
              <h2 className="text-lg font-black text-foreground font-['Space_Grotesk']">Acceptance of Terms</h2>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              By creating an account, enrolling in a course, purchasing educational content, using the Student Dashboard,
              Inbox, Blog, Community, or any other Teshkid services, you acknowledge that you have read, understood, and
              agreed to these Terms and Conditions. You further acknowledge that cryptocurrency and blockchain-related
              activities involve significant risk, and you accept full responsibility for your own financial and educational decisions.
            </p>
          </section>

          {/* Bottom nav */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 pb-2">
            <p className="text-xs text-muted-foreground">
              Last updated: <span className="font-semibold text-foreground">August 7, 2026</span>
            </p>
            <div className="flex gap-3">
              <Link to="/courses" className="text-xs font-bold text-primary hover:underline">Browse Courses</Link>
              <Link to="/student/login" className="text-xs font-bold text-primary hover:underline">Create Account</Link>
            </div>
          </div>

        </main>
      </div>{/* end two-column */}

      <Footer />
    </div>
  );
}

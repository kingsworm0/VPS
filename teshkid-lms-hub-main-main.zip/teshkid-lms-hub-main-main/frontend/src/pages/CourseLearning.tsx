import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import api from "@/lib/api";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";
import {
  Play,
  CheckCircle2,
  Lock,
  ChevronLeft,
  ChevronRight,
  FileText,
  Code,
  HelpCircle,
  BookOpen,
  StickyNote,
  Trash2,
  Award,
  Loader2,
  Eye,
} from "lucide-react";
import { Linkify } from "@/components/ui/Linkify";

export default function CourseLearning() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [course, setCourse] = useState<any>(null);
  const [currentLesson, setCurrentLesson] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [notes, setNotes] = useState<any[]>([]);
  const [newNote, setNewNote] = useState("");
  const [showNotes, setShowNotes] = useState(false);
  const [isClaiming, setIsClaiming] = useState(false);

  const isAdmin = user?.role === "ADMIN";

  useEffect(() => {
    fetchCourse();
  }, [id]);

  useEffect(() => {
    if (currentLesson) {
      fetchNotes();
    }
  }, [currentLesson]);

  const fetchCourse = async () => {
    try {
      const res = await api.get(`/courses/${id}/learn`);
      setCourse(res.data);
      // Set first lesson as current
      if (res.data?.modules?.[0]?.lessons?.[0]) {
        setCurrentLesson(res.data.modules[0].lessons[0]);
      }
    } catch (error) {
      console.error(error);
      toast({ title: "Error", description: "Could not load course" });
    } finally {
      setLoading(false);
    }
  };

  const fetchNotes = async () => {
    if (!currentLesson) return;
    try {
      const res = await api.get(`/lessons/${currentLesson.id}/notes`);
      setNotes(res.data);
    } catch (error) {
      console.error(error);
    }
  };

  const markComplete = async () => {
    if (!currentLesson || !course) return;
    try {
      await api.post(`/lessons/${currentLesson.id}/complete`, {
        timeSpent: 0,
        lastPosition: 0,
      });
      
      const allLessons = course.modules.flatMap((m: any) => m.lessons);
      const remainingUncompleted = allLessons.filter(
        (l: any) => l.id !== currentLesson.id && (!l.progress || !l.progress[0]?.completed)
      );

      if (remainingUncompleted.length === 0) {
        toast({
          title: "🎉 Course Completed!",
          description: "Congratulations! Claiming your verified signed certificate...",
        });
        await fetchCourse();
        await claimCertificate();
      } else {
        toast({ title: "Success", description: "Lesson marked as complete!" });
        fetchCourse();
      }
    } catch (error) {
      console.error(error);
      toast({ title: "Error", description: "Could not mark lesson complete" });
    }
  };

  const saveNote = async () => {
    if (!newNote.trim() || !currentLesson) return;
    try {
      await api.post("/notes", {
        lessonId: currentLesson.id,
        content: newNote,
      });
      setNewNote("");
      fetchNotes();
      toast({ title: "Success", description: "Note saved!" });
    } catch (error) {
      console.error(error);
      toast({ title: "Error", description: "Could not save note" });
    }
  };

  const claimCertificate = async () => {
    setIsClaiming(true);
    try {
      const res = await api.post(`/certificates/claim/${id}`);
      toast({ title: "Congratulations!", description: "Your certificate has been issued." });
      navigate(`/certificates/${res.data.id}`);
    } catch (error: any) {
      console.error(error);
      const msg = error.response?.data?.error || "Could not claim certificate";
      toast({ title: "Error", description: msg, variant: "destructive" });
    } finally {
      setIsClaiming(false);
    }
  };

  const goToNextLesson = () => {
    if (!course || !currentLesson) return;
    const allLessons = course.modules.flatMap((m: any) => m.lessons);
    const currentIndex = allLessons.findIndex(
      (l: any) => l.id === currentLesson.id,
    );
    if (currentIndex < allLessons.length - 1) {
      setCurrentLesson(allLessons[currentIndex + 1]);
    }
  };

  const goToPrevLesson = () => {
    if (!course || !currentLesson) return;
    const allLessons = course.modules.flatMap((m: any) => m.lessons);
    const currentIndex = allLessons.findIndex(
      (l: any) => l.id === currentLesson.id,
    );
    if (currentIndex > 0) {
      setCurrentLesson(allLessons[currentIndex - 1]);
    }
  };

  const getLessonIcon = (type: string) => {
    switch (type) {
      case "video":
        return Play;
      case "quiz":
        return HelpCircle;
      case "exercise":
        return Code;
      default:
        return FileText;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        Loading...
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        Course not found
      </div>
    );
  }

  const totalLessons = course.modules.reduce(
    (acc: number, mod: any) => acc + mod.lessons.length,
    0,
  );
  const completedLessons = course.modules.reduce(
    (acc: number, mod: any) =>
      acc + mod.lessons.filter((l: any) => l.progress && l.progress[0]?.completed).length,
    0,
  );
  const progress =
    totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-32 sm:pt-40">
        <div className="container mx-auto px-4 py-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <Button
                variant="ghost"
                onClick={() => navigate(`/courses/${id}`)}
                className="mb-2"
              >
                <ChevronLeft className="w-4 h-4 mr-2" />
                Back to Course
              </Button>
              <h1 className="font-display text-2xl font-bold">
                {course.title}
              </h1>
              <div className="flex items-center gap-4 mt-2">
                <Progress value={progress} className="w-48" />
                <span className="text-sm text-muted-foreground">
                  {completedLessons}/{totalLessons} lessons completed
                </span>
                {progress === 100 && (
                  <Button
                    size="sm"
                    className="ml-4 bg-yellow-500 hover:bg-yellow-600 text-black font-bold animate-bounce"
                    onClick={claimCertificate}
                    disabled={isClaiming}
                  >
                    {isClaiming ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Award className="w-4 h-4 mr-2" />}
                    Claim Certificate
                  </Button>
                )}
              </div>
            </div>
            {!isAdmin && (
              <Button
                variant="outline"
                size="sm"
                className="text-destructive hover:bg-destructive/10 border-destructive/20"
                onClick={() => {
                  if (confirm("Are you sure you want to forfeit this course? You will lose all access and progress immediately.")) {
                    api.post(`/enrollments/forfeit/${id}`)
                      .then(() => {
                        toast({ title: "Course Forfeited", description: "You have successfully left the course." });
                        navigate("/dashboard");
                      })
                      .catch(() => toast({ title: "Error", description: "Could not forfeit course.", variant: "destructive" }));
                  }
                }}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Forfeit Course
              </Button>
            )}
            {isAdmin && (
              <div className="flex items-center gap-2 px-3 py-2 bg-primary/10 rounded-lg border border-primary/20">
                <Eye className="w-4 h-4 text-primary" />
                <span className="text-sm font-bold text-primary">Admin View</span>
              </div>
            )}
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Lesson Content */}
              <Card>
                <CardContent className="p-0 overflow-hidden">
                  {/* Banner for Pending or Approved */}
                  {course.isApproved === false ? (
                    <div className="flex flex-col">
                      <div className="aspect-video relative overflow-hidden group">
                        <img
                          src={course.bannerUrl || course.thumbnail || "/placeholder.svg"}
                          alt={course.title}
                          className="w-full h-full object-cover grayscale-[50%] blur-[2px] transition-all group-hover:blur-0 group-hover:grayscale-0"
                        />
                        <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center p-6 text-center">
                          <div className="w-20 h-20 rounded-full bg-yellow-500/20 flex items-center justify-center mb-6 border border-yellow-500/50 animate-pulse">
                            <Lock className="w-10 h-10 text-yellow-500" />
                          </div>
                          <h2 className="text-3xl font-black text-white mb-2">Enrollment Pending Approval</h2>
                          <p className="max-w-md text-white/80 font-medium">
                            Your enrollment for <span className="text-yellow-500 font-bold">"{course.title}"</span> is currently being reviewed by our team.
                            You will get full access to all video lessons once approved.
                          </p>
                          <div className="mt-8 px-6 py-2 bg-white/10 backdrop-blur-md rounded-full border border-white/20 text-white text-xs font-black uppercase tracking-widest">
                            Status: {course.enrollmentStatus || "Under Review"}
                          </div>
                        </div>
                      </div>
                      <div className="p-8 bg-muted/30 border-t border-border/50 text-center">
                        <p className="text-muted-foreground italic">"Patience is the key to mastery."</p>
                      </div>
                    </div>
                  ) : currentLesson ? (
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h2 className="font-display text-xl font-bold">
                          {currentLesson.title}
                        </h2>
                        {currentLesson.progress?.[0]?.completed && (
                          <CheckCircle2 className="w-6 h-6 text-success" />
                        )}
                      </div>

                      {/* Video Player or Content */}
                      {currentLesson.type === "video" &&
                        (currentLesson.content || currentLesson.videoUrl) && (
                          <div className="aspect-video bg-black rounded-lg mb-4">
                            <video
                              controls
                              className="w-full h-full rounded-lg"
                              src={
                                currentLesson.content || currentLesson.videoUrl
                              }
                            >
                              Your browser does not support the video tag.
                            </video>
                          </div>
                        )}

                      {currentLesson.type === "pdf" &&
                        currentLesson.content && (
                          <div className="aspect-video bg-secondary rounded-lg mb-4 flex items-center justify-center">
                            <div className="text-center">
                              <FileText className="w-12 h-12 mx-auto mb-2 text-primary" />
                              <p className="text-sm text-muted-foreground mb-4">
                                PDF Document
                              </p>
                              <Button asChild>
                                <a
                                  href={currentLesson.content}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                >
                                  Open PDF
                                </a>
                              </Button>
                            </div>
                          </div>
                        )}

                      {currentLesson.type === "quiz" && (
                        <div className="aspect-video bg-secondary rounded-lg mb-4 flex items-center justify-center">
                          <div className="text-center">
                            <HelpCircle className="w-12 h-12 mx-auto mb-2 text-primary" />
                            <p className="text-sm text-muted-foreground mb-4">
                              Quiz Available
                            </p>
                            <Button>Start Quiz</Button>
                          </div>
                        </div>
                      )}

                      {/* Mark Complete Button */}
                      {!isAdmin && !currentLesson.progress?.[0]?.completed && (
                        <Button onClick={markComplete} className="w-full">
                          <CheckCircle2 className="w-4 h-4 mr-2" />
                          Mark as Complete
                        </Button>
                      )}
                      
                      {isAdmin && (
                        <div className="w-full p-3 bg-primary/10 rounded-lg border border-primary/20 text-center">
                          <p className="text-sm text-primary font-medium">
                            <Eye className="w-4 h-4 inline mr-2" />
                            Admin Preview Mode - Progress tracking disabled
                          </p>
                        </div>
                      )}

                      {/* Navigation */}
                      <div className="flex items-center justify-between mt-6 pt-6 border-t">
                        <Button
                          variant="outline"
                          onClick={goToPrevLesson}
                          disabled={
                            course.modules?.[0]?.lessons?.[0]?.id === currentLesson.id
                          }
                        >
                          <ChevronLeft className="w-4 h-4 mr-2" />
                          Previous
                        </Button>
                        <Button
                          onClick={goToNextLesson}
                          disabled={
                            course.modules?.[course.modules.length - 1]?.lessons?.[
                              course.modules[course.modules.length - 1].lessons.length - 1
                            ]?.id === currentLesson.id
                          }
                        >
                          Next
                          <ChevronRight className="w-4 h-4 ml-2" />
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-12 text-center text-muted-foreground">
                      <BookOpen className="w-12 h-12 mx-auto mb-4 opacity-20" />
                      <p className="font-bold">Select a lesson to begin</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Course Completed Celebration Card */}
              {progress === 100 && (
                <div className="p-6 bg-gradient-to-r from-emerald-500/15 via-primary/10 to-amber-500/15 border-2 border-emerald-500/30 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl shadow-emerald-500/5">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center shadow-lg shadow-yellow-500/20 shrink-0">
                      <Award className="w-6 h-6 text-black" />
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-foreground">Course Completed! 🎉</h3>
                      <p className="text-sm text-muted-foreground">
                        You have mastered all lessons. Claim and view your official verified certificate signed by Teshkid is Crypto.
                      </p>
                    </div>
                  </div>
                  <Button
                    onClick={claimCertificate}
                    disabled={isClaiming}
                    className="rounded-xl bg-gradient-to-r from-emerald-600 to-primary hover:opacity-90 font-bold px-6 py-5 shadow-lg shadow-emerald-500/20 shrink-0 w-full sm:w-auto"
                  >
                    {isClaiming ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Award className="w-4 h-4 mr-2" />}
                    Claim & View Certificate
                  </Button>
                </div>
              )}

              {/* Notes Section */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold flex items-center gap-2">
                      <StickyNote className="w-5 h-5" />
                      Notes
                    </h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowNotes(!showNotes)}
                    >
                      {showNotes ? "Hide" : "Show"}
                    </Button>
                  </div>
                  {showNotes && (
                    <>
                      <Textarea
                        placeholder="Add a note..."
                        value={newNote}
                        onChange={(e) => setNewNote(e.target.value)}
                        rows={3}
                        className="mb-2"
                      />
                      <Button onClick={saveNote} size="sm" className="mb-4">
                        Save Note
                      </Button>
                      <div className="space-y-2">
                        {notes.map((note) => (
                          <div
                            key={note.id}
                            className="p-3 bg-secondary rounded-lg text-sm"
                          >
                            <p className="whitespace-pre-wrap">
                              <Linkify text={note.content} />
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {new Date(note.createdAt).toLocaleString()}
                            </p>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Sidebar - Course Outline */}
            <div>
              <Card className="sticky top-24 md:top-28">
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <BookOpen className="w-5 h-5" />
                    Course Content
                  </h3>
                  <div className="space-y-2 max-h-[600px] overflow-y-auto">
                    {course.modules.map((module: any) => (
                      <div key={module.id} className="space-y-1">
                        <p className="text-sm font-medium text-muted-foreground px-2 py-1">
                          {module.title}
                        </p>
                        {module.lessons.map((lesson: any) => {
                          const Icon = getLessonIcon(lesson.type);
                          const isCompleted = lesson.progress[0]?.completed;
                          const isCurrent = currentLesson?.id === lesson.id;

                          return (
                            <button
                              key={lesson.id}
                              onClick={() => setCurrentLesson(lesson)}
                              className={`w-full text-left p-2 rounded-lg text-sm flex items-center gap-2 transition-colors ${isCurrent
                                ? "bg-primary text-primary-foreground"
                                : "hover:bg-secondary"
                                }`}
                            >
                              <Icon className="w-4 h-4 flex-shrink-0" />
                              <span className="flex-1 truncate">
                                {lesson.title}
                              </span>
                              {isCompleted && (
                                <CheckCircle2 className="w-4 h-4 text-success flex-shrink-0" />
                              )}
                            </button>
                          );
                        })}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

import { useState } from "react";
import { useSearchParams, Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Mail, Lock, User, ArrowRight, Eye, EyeOff, GraduationCap } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import api from "@/lib/api";
import { useAuth } from "@/context/AuthContext";

export default function StudentAuth() {
    const [searchParams] = useSearchParams();
    const navigate = useNavigate();
    const [isSignUp, setIsSignUp] = useState(
        searchParams.get("mode") === "signup",
    );
    const [showPassword, setShowPassword] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    const [formData, setFormData] = useState({
        firstName: "",
        lastName: "",
        email: "",
        password: "",
        confirmPassword: "",
        agreeToTerms: false,
    });

    const { login } = useAuth();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);

        try {
            if (isSignUp) {
                // basic validation
                if (formData.password !== formData.confirmPassword) {
                    toast({
                        title: "Passwords do not match",
                        description: "Please confirm your password.",
                    });
                    setIsLoading(false);
                    return;
                }
                if (!formData.agreeToTerms) {
                    toast({
                        title: "Agree to terms",
                        description:
                            "You must agree to the Terms of Service to create an account.",
                    });
                    setIsLoading(false);
                    return;
                }

                const res = await api.post("/auth/signup", {
                    firstName: formData.firstName,
                    lastName: formData.lastName,
                    email: formData.email,
                    password: formData.password,
                });
                const { token, user } = res.data;

                // Check if user is actually a student
                if (user.role === "ADMIN") {
                    toast({
                        title: "Invalid account type",
                        description: "Admin accounts should use the admin login page.",
                        variant: "destructive",
                    });
                    setIsLoading(false);
                    return;
                }

                // auto-login after signup
                login(token, user);
                toast({
                    title: `Welcome, ${user.name}!`,
                    description:
                        "Your account has been created and you are now logged in.",
                });
                navigate("/dashboard");
            } else {
                const res = await api.post("/auth/login", {
                    email: formData.email,
                    password: formData.password,
                });
                const { token, user } = res.data;

                // Check if user is actually a student
                if (user.role === "ADMIN") {
                    toast({
                        title: "Invalid account type",
                        description: "Admin accounts should use the admin login page.",
                        variant: "destructive",
                    });
                    setIsLoading(false);
                    return;
                }

                login(token, user);
                toast({
                    title: `Welcome back, ${user.name}!`,
                    description: "You have successfully signed in.",
                });
                navigate("/dashboard");
            }
        } catch (error: any) {
            toast({
                title: "Authentication failed",
                description:
                    error.response?.data?.error ||
                    error.response?.data?.message ||
                    "Please check your credentials and try again.",
            });
        } finally {
            setIsLoading(false);
        }
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    return (
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
            {/* Background Pattern */}
            <div className="absolute inset-0 bg-hero-pattern opacity-50" />
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />

            <div className="relative w-full max-w-md">
                {/* Logo */}
                <Link to="/" className="flex items-center justify-center gap-2 mb-8">
                    <img
                        src="/logo.png"
                        alt="Teshkid Logo"
                        className="h-[155px] w-auto"
                    />
                </Link>

                <Card variant="glass" className="backdrop-blur-xl">
                    <CardHeader className="text-center pb-2">
                        <div className="flex items-center justify-center gap-2 mb-2">
                            <GraduationCap className="w-8 h-8 text-primary" />
                        </div>
                        <CardTitle className="font-display text-2xl">
                            {isSignUp ? "Student Registration" : "Student Login"}
                        </CardTitle>
                        <CardDescription>
                            {isSignUp
                                ? "Start your crypto education journey today"
                                : "Sign in to continue your learning"}
                        </CardDescription>
                    </CardHeader>

                    <CardContent className="pt-6">
                        <form onSubmit={handleSubmit} className="space-y-4">
                            {isSignUp && (
                                <>
                                    <div className="space-y-2">
                                        <Label htmlFor="firstName">First Name</Label>
                                        <div className="relative">
                                            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                                            <Input
                                                id="firstName"
                                                name="firstName"
                                                placeholder="John"
                                                value={formData.firstName}
                                                onChange={handleInputChange}
                                                className="pl-10 bg-secondary border-border"
                                                required
                                            />
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="lastName">Last Name</Label>
                                        <div className="relative">
                                            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                                            <Input
                                                id="lastName"
                                                name="lastName"
                                                placeholder="Doe"
                                                value={formData.lastName}
                                                onChange={handleInputChange}
                                                className="pl-10 bg-secondary border-border"
                                            />
                                        </div>
                                    </div>
                                </>
                            )}

                            <div className="space-y-2">
                                <Label htmlFor="email">Email</Label>
                                <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                                    <Input
                                        id="email"
                                        name="email"
                                        type="email"
                                        placeholder="you@example.com"
                                        value={formData.email}
                                        onChange={handleInputChange}
                                        className="pl-10 bg-secondary border-border"
                                        required
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="password">Password</Label>
                                <p className="text-xs text-muted-foreground mb-2">
                                    Enter your password (min. 6 characters)
                                </p>
                                <div className="relative">
                                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                                    <Input
                                        id="password"
                                        name="password"
                                        type={showPassword ? "text" : "password"}
                                        placeholder="Enter your password"
                                        value={formData.password}
                                        onChange={handleInputChange}
                                        className="pl-10 pr-10 bg-secondary border-border"
                                        required
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShowPassword(!showPassword)}
                                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                                    >
                                        {showPassword ? (
                                            <EyeOff className="w-4 h-4" />
                                        ) : (
                                            <Eye className="w-4 h-4" />
                                        )}
                                    </button>
                                </div>
                            </div>

                            {isSignUp && (
                                <div className="space-y-2">
                                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                                    <p className="text-xs text-muted-foreground mb-2">
                                        Re-enter your password to confirm
                                    </p>
                                    <div className="relative">
                                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                                        <Input
                                            id="confirmPassword"
                                            name="confirmPassword"
                                            type={showPassword ? "text" : "password"}
                                            placeholder="Re-enter your password"
                                            value={formData.confirmPassword}
                                            onChange={handleInputChange}
                                            className="pl-10 bg-secondary border-border"
                                            required
                                        />
                                    </div>
                                </div>
                            )}

                            {!isSignUp && (
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center space-x-2">
                                        <Checkbox id="remember" />
                                        <label
                                            htmlFor="remember"
                                            className="text-sm text-muted-foreground cursor-pointer"
                                        >
                                            Remember me
                                        </label>
                                    </div>
                                    <Link
                                        to="/forgot-password"
                                        className="text-sm text-primary hover:underline"
                                    >
                                        Forgot password?
                                    </Link>
                                </div>
                            )}

                            {isSignUp && (
                                <div className="flex items-start space-x-2">
                                    <Checkbox
                                        id="terms"
                                        checked={formData.agreeToTerms}
                                        onCheckedChange={(checked) =>
                                            setFormData({
                                                ...formData,
                                                agreeToTerms: checked as boolean,
                                            })
                                        }
                                    />
                                    <label
                                        htmlFor="terms"
                                        className="text-sm text-muted-foreground cursor-pointer leading-tight"
                                    >
                                        I agree to the{" "}
                                        <Link to="/terms" className="text-primary hover:underline">
                                            Terms of Service
                                        </Link>{" "}
                                        and{" "}
                                        <Link
                                            to="/privacy"
                                            className="text-primary hover:underline"
                                        >
                                            Privacy Policy
                                        </Link>
                                    </label>
                                </div>
                            )}

                            <Button
                                type="submit"
                                variant="hero"
                                size="lg"
                                className="w-full"
                                disabled={isLoading}
                            >
                                {isLoading ? (
                                    <div className="w-5 h-5 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                                ) : (
                                    <>
                                        {isSignUp ? "Create Account" : "Sign In"}
                                        <ArrowRight className="w-4 h-4 ml-2" />
                                    </>
                                )}
                            </Button>
                        </form>

                        <p className="text-center text-sm text-muted-foreground mt-6">
                            {isSignUp ? "Already have an account?" : "Don't have an account?"}{" "}
                            <button
                                type="button"
                                onClick={() => setIsSignUp(!isSignUp)}
                                className="text-primary hover:underline font-medium"
                            >
                                {isSignUp ? "Sign in" : "Sign up"}
                            </button>
                        </p>
                    </CardContent>
                </Card>

                <p className="text-center text-xs text-muted-foreground mt-6">
                    By continuing, you agree to Teshkid's Terms of Service
                    <br />
                    and acknowledge our Privacy Policy.
                </p>
            </div>
        </div>
    );
}

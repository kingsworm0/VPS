import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import api from "@/lib/api";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { BookOpen, Play, Lock, Clock, CheckCircle, Trash2, ChevronRight, Award } from "lucide-react";
import { cn } from "@/lib/utils";

const COLORS = ["#7c3aed", "#f59e0b", "#10b981", "#ef4444", "#3b82f6", "#ec4899"];

export default function StudentMyCourses() {
  const [courses, setCourses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [gamification, setGamification] = useState<any>(null);

  const [certs, setCerts] = useState<any[]>([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [dashRes, certRes] = await Promise.all([
        api.get("/dashboard"),
        api.get("/certificates").catch(() => ({ data: [] })),
      ]);
      setCourses(dashRes.data.recentCourses || []);
      setGamification(dashRes.data.gamification);
      setCerts(certRes.data || []);
    } catch {
      toast.error("Failed to load courses");
    } finally {
      setLoading(false);
    }
  };

  const xpProgress = gamification
    ? Math.round(((gamification.xp - gamification.xpForCurrentLevel) / (gamification.xpForNextLevel - gamification.xpForCurrentLevel)) * 100)
    : 0;

  return (
    <DashboardLayout xp={gamification?.xp} level={gamification?.level} xpProgress={xpProgress}>
      <div className="max-w-5xl mx-auto px-4 md:px-8 py-8 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-black font-sans text-foreground">My Courses</h1>
            <p className="text-sm text-muted-foreground mt-1">{courses.length} enrolled course{courses.length !== 1 ? "s" : ""}</p>
          </div>
          <Link to="/courses" className="flex items-center gap-1 text-sm text-primary font-semibold hover:underline">
            Browse more <ChevronRight className="w-4 h-4" />
          </Link>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-24">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : courses.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border/60 p-16 text-center">
            <BookOpen className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-muted-foreground mb-4">You haven't enrolled in any courses yet.</p>
            <Link to="/courses" className="text-primary hover:underline font-semibold text-sm">
              Browse Courses →
            </Link>
          </div>
        ) : (
          <div className="grid gap-4">
            {courses.map((course: any, i: number) => {
              const pct = course.totalLessons > 0
                ? Math.round((course.lessonsCompleted / course.totalLessons) * 100)
                : 0;
              const isApproved = course.status === "APPROVED";
              const cert = certs.find((c: any) => c.courseId === course.id);

              return (
                <div
                  key={course.id}
                  className="group rounded-2xl border border-border/60 bg-card/50 backdrop-blur-sm overflow-hidden hover:border-primary/40 hover:shadow-xl transition-all"
                >
                  <div className="grid md:grid-cols-3">
                    <div className="relative aspect-video md:aspect-auto bg-muted min-h-[120px]">
                      <img
                        src={course.thumbnail || "/placeholder.svg"}
                        alt={course.title}
                        className={cn("w-full h-full object-cover", !isApproved && "grayscale blur-[2px]")}
                      />
                      {!isApproved && (
                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                          <Lock className="w-7 h-7 text-white/60" />
                        </div>
                      )}
                      <div className="absolute top-2 left-2">
                        <span className={cn(
                          "text-[10px] font-black uppercase px-2 py-1 rounded-full",
                          isApproved ? "bg-emerald-500 text-white" : "bg-yellow-500 text-white animate-pulse"
                        )}>
                          {isApproved ? "Active" : "Pending"}
                        </span>
                      </div>
                    </div>

                    <div className="md:col-span-2 p-5 flex flex-col justify-between">
                      <div>
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <h3 className="font-bold text-foreground text-base group-hover:text-primary transition-colors">
                            {course.title}
                          </h3>
                          <span className="text-2xl font-black text-primary shrink-0">{pct}%</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
                          {isApproved ? (
                            <span className="flex items-center gap-1 text-emerald-500">
                              <CheckCircle className="w-3 h-3" /> Access Granted
                            </span>
                          ) : (
                            <span className="flex items-center gap-1 text-yellow-500">
                              <Clock className="w-3 h-3" /> Awaiting Verification
                            </span>
                          )}
                          <span>·</span>
                          <span>Enrolled {new Date(course.enrolledAt).toLocaleDateString()}</span>
                        </div>
                        <div className="space-y-1.5 mb-5">
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>{course.lessonsCompleted} / {course.totalLessons} lessons completed</span>
                          </div>
                          <div className="h-2 bg-muted rounded-full overflow-hidden">
                            <div
                              className="h-full rounded-full transition-all"
                              style={{ width: `${pct}%`, background: COLORS[i % COLORS.length] }}
                            />
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {cert ? (
                          <Link to={`/certificates/${cert.id}`} className="flex-1">
                            <button className="w-full h-10 rounded-xl bg-gradient-to-r from-emerald-600 to-primary text-white text-sm font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-all shadow-md shadow-emerald-500/20">
                              <Award className="w-4 h-4 text-yellow-300" />
                              View Certificate
                            </button>
                          </Link>
                        ) : pct === 100 ? (
                          <Link to={`/courses/${course.id}/learn`} className="flex-1">
                            <button className="w-full h-10 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-black text-sm font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-all shadow-md shadow-yellow-500/20 animate-pulse">
                              <Award className="w-4 h-4" />
                              Claim Certificate
                            </button>
                          </Link>
                        ) : (
                          <Link to={`/courses/${course.id}/learn`} className="flex-1">
                            <button className="w-full h-10 rounded-xl bg-primary text-primary-foreground text-sm font-bold flex items-center justify-center gap-2 hover:bg-primary/90 transition-all shadow-md shadow-primary/20">
                              <Play className="w-3.5 h-3.5 fill-current" />
                              {isApproved ? "Continue Learning" : "View Curriculum"}
                            </button>
                          </Link>
                        )}
                        <button
                          onClick={() => {
                            if (confirm("Forfeit this course? You will lose all progress.")) {
                              api.post(`/enrollments/forfeit/${course.id}`)
                                .then(() => { toast.success("Course forfeited"); loadData(); })
                                .catch(() => toast.error("Failed to forfeit"));
                            }
                          }}
                          className="w-10 h-10 rounded-xl bg-muted/50 text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-all flex items-center justify-center"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}

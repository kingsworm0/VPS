import { useEffect, useState, useRef } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import api from "@/lib/api";
import { getImageUrl } from "@/lib/imageUtils";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { format, formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";
import { ConfirmDialog } from "@/components/ui/ConfirmDialog";
import { Linkify } from "@/components/ui/Linkify";
import {
  Search, RefreshCw, Loader2, Mail, Star, Archive,
  Trash2, CheckCircle2, UserRound, BookOpen, ChevronRight,
  XCircle, Send, Lock, Unlock, AlertTriangle, Tag,
  MessageSquare, Clock, CheckCheck, Circle, SlidersHorizontal,
  MoreVertical, UserCheck, Inbox as InboxIcon, Paperclip
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// ─── Types ─────────────────────────────────────────────────────────────────
interface Message {
  id: string;
  subject: string;
  message: string;
  content?: string;
  reply?: string;
  attachmentUrl?: string;
  replyAttachmentUrl?: string;
  userName: string;
  userEmail: string;
  userProfilePicture?: string;
  isRead?: boolean;
  createdAt: string;
  resolvedAt?: string;
}

interface Enrollment {
  id: string;
  createdAt: string;
  user: { name: string; email: string; profilePicture?: string };
  course: { title: string };
}

// ─── Helpers ────────────────────────────────────────────────────────────────

function Avatar({ src, name, size = "md" }: { src?: string | null; name: string; size?: "sm" | "md" | "lg" }) {
  const [err, setErr] = useState(false);
  const sz = size === "sm" ? "w-7 h-7" : size === "lg" ? "w-12 h-12" : "w-9 h-9";
  const iconSz = size === "sm" ? "w-3.5 h-3.5" : size === "lg" ? "w-6 h-6" : "w-4 h-4";
  const url = getImageUrl(src);
  return (
    <div className={cn("rounded-full overflow-hidden bg-muted flex items-center justify-center shrink-0 border border-border/50", sz)}>
      {url && !err
        ? <img src={url} alt={name} className="w-full h-full object-cover" onError={() => setErr(true)} />
        : <UserRound className={cn("text-muted-foreground", iconSz)} />}
    </div>
  );
}

// ─── Main Component ──────────────────────────────────────────────────────────
export default function AdminMessages() {
  const { user } = useAuth();

  // list state
  const [messages, setMessages]         = useState<Message[]>([]);
  const [enrollments, setEnrollments]   = useState<Enrollment[]>([]);
  const [loading, setLoading]           = useState(true);
  const [searchQuery, setSearchQuery]   = useState("");
  const [tab, setTab]                   = useState<"open" | "enrollments">("open");

  // detail panel state
  const [selected, setSelected]         = useState<Message | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [replyText, setReplyText]       = useState("");
  const [attachment, setAttachment]     = useState<File | null>(null);
  const [sendingReply, setSendingReply] = useState(false);
  const threadRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // confirm dialog
  const [confirm, setConfirm] = useState<{
    isOpen: boolean; title: string; description: string;
    onConfirm: () => void; variant?: "default" | "destructive";
  }>({ isOpen: false, title: "", description: "", onConfirm: () => {} });

  // ─── Data fetching ───────────────────────────────────────────────────────
  useEffect(() => { fetchAll(); }, []);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [tRes, eRes] = await Promise.all([
        api.get("/messages"),
        api.get("/admin/enrollments/pending").catch(() => ({ data: [] })),
      ]);
      setMessages(tRes.data || []);
      setEnrollments(eRes.data || []);
    } catch { toast.error("Failed to load inbox"); }
    finally { setLoading(false); }
  };

  const openMessage = async (t: Message) => {
    setSelected(t);
    setReplyText("");
    setAttachment(null);
    setLoadingDetail(true);
    try {
      const tRes = await api.get(`/messages/${t.id}`);
      setSelected(tRes.data);
      if (!t.isRead) {
        await api.put(`/messages/${t.id}/read`, { isRead: true });
        setMessages(prev => prev.map(x => x.id === t.id ? { ...x, isRead: true } : x));
      }
    } catch { toast.error("Failed to load message"); }
    finally { setLoadingDetail(false); }
    setTimeout(() => threadRef.current?.scrollTo({ top: threadRef.current.scrollHeight, behavior: "smooth" }), 200);
  };

  // ─── Actions ──────────────────────────────────────────────────────────────
  const sendReply = async () => {
    if ((!replyText.trim() && !attachment) || !selected) return;
    setSendingReply(true);
    try {
      let replyAttachmentUrl = undefined;
      if (attachment) {
        const formData = new FormData();
        formData.append("file", attachment);
        const uploadRes = await api.post("/upload/file", formData, {
          headers: { "Content-Type": "multipart/form-data" },
        });
        replyAttachmentUrl = uploadRes.data.url;
      }

      await api.put(`/messages/${selected.id}/reply`, { reply: replyText, replyAttachmentUrl });
      toast.success("Reply sent");
      setReplyText("");
      setAttachment(null);
      await openMessage(selected);
      fetchAll();
    } catch { toast.error("Failed to send reply"); }
    finally { setSendingReply(false); }
  };



  const deleteMessage = async (t: Message) => {
    setConfirm({
      isOpen: true, title: "Delete Message", variant: "destructive",
      description: `Permanently delete "${t.subject}"? This cannot be undone.`,
      onConfirm: async () => {
        try {
          await api.delete(`/messages/${t.id}`);
          toast.success("Message deleted");
          if (selected?.id === t.id) setSelected(null);
          fetchAll();
        } catch { toast.error("Failed to delete message"); }
      },
    });
  };

  const handleEnrollmentAction = async (id: string, status: "APPROVED" | "REJECTED") => {
    try {
      await api.put(`/admin/enrollments/${id}/status`, { status });
      toast.success(`Enrollment ${status === "APPROVED" ? "approved" : "rejected"}`);
      fetchAll();
    } catch { toast.error("Failed to update enrollment"); }
  };

  // ─── Filtering ────────────────────────────────────────────────────────────
  const unread = messages.filter(t => !t.isRead).length;
  const pendingEnrollments = enrollments.length;

  const visibleMessages = messages
    .filter(t => {
      const q = searchQuery.toLowerCase();
      if (q && !t.subject.toLowerCase().includes(q) && !t.userName.toLowerCase().includes(q) && !(t.message || "").toLowerCase().includes(q)) return false;
      return true;
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      <main className="flex-1 pt-20 pb-8 flex flex-col">
        {/* Page header */}
        <div className="px-6 py-4 border-b border-border/50 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
              <InboxIcon className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-black font-sans text-foreground leading-none">Support Inbox</h1>
              <p className="text-xs text-muted-foreground mt-0.5">
                {unread > 0 ? <><span className="text-primary font-bold">{unread} unread</span> · </> : ""}
                {messages.length} total messages
              </p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={fetchAll} className="h-9 w-9 rounded-lg text-muted-foreground hover:text-foreground">
            <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
          </Button>
        </div>

        {/* Two-panel body */}
        <div className="flex flex-1 overflow-hidden">

          {/* ── LEFT: ticket list ──────────────────────────────────────────── */}
          <aside className="w-[320px] shrink-0 border-r border-border/50 flex flex-col bg-card/30 overflow-hidden">

            {/* Search */}
            <div className="p-3 border-b border-border/40 shrink-0">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                <Input
                  placeholder="Filter messages..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pl-9 h-8 bg-muted/50 border-border/40 text-sm focus-visible:ring-1 focus-visible:ring-primary"
                />
              </div>
            </div>

            {/* Nav tabs */}
            <div className="p-2 border-b border-border/40 space-y-0.5 shrink-0">
              {([
                { key: "open",        label: "All Messages", icon: InboxIcon,    badge: unread },
                { key: "enrollments", label: "Requests",     icon: BookOpen,     badge: pendingEnrollments },
              ] as const).map(({ key, label, icon: Icon, badge }) => (
                <button
                  key={key}
                  onClick={() => { setTab(key); setSelected(null); }}
                  className={cn(
                    "w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-sm font-medium transition-all text-left",
                    tab === key ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted/60 hover:text-foreground"
                  )}
                >
                  <Icon className="w-3.5 h-3.5 shrink-0" />
                  <span className="flex-1">{label}</span>
                  {badge > 0 && (
                    <span className={cn("text-[10px] font-black px-1.5 py-0.5 rounded-full", tab === key ? "bg-primary-foreground/20 text-primary-foreground" : "bg-primary/10 text-primary")}>
                      {badge}
                    </span>
                  )}
                </button>
              ))}
            </div>



            {/* Ticket list */}
            <div className="flex-1 overflow-y-auto">
              {loading ? (
                <div className="flex items-center justify-center h-40"><Loader2 className="w-5 h-5 animate-spin text-primary" /></div>
              ) : tab === "enrollments" ? (
                enrollments.length === 0 ? (
                  <div className="p-8 text-center text-muted-foreground text-sm">No pending requests</div>
                ) : (
                  enrollments.map(enr => (
                    <div key={enr.id} className="p-3 border-b border-border/30 hover:bg-muted/30 transition-colors">
                      <div className="flex items-center gap-2 mb-2">
                        <Avatar src={enr.user.profilePicture} name={enr.user.name} size="sm" />
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-foreground truncate">{enr.user.name}</p>
                          <p className="text-[10px] text-muted-foreground truncate">{enr.user.email}</p>
                        </div>
                      </div>
                      <p className="text-xs text-primary font-medium truncate mb-2">{enr.course.title}</p>
                      <div className="flex gap-1.5">
                        <Button size="sm" onClick={() => handleEnrollmentAction(enr.id, "APPROVED")} className="h-6 text-[11px] px-2 bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground flex-1 font-bold">Approve</Button>
                        <Button size="sm" variant="ghost" onClick={() => handleEnrollmentAction(enr.id, "REJECTED")} className="h-6 text-[11px] px-2 text-destructive hover:bg-destructive/10">Reject</Button>
                      </div>
                    </div>
                  ))
                )
              ) : visibleMessages.length === 0 ? (
                <div className="p-8 text-center text-muted-foreground text-sm">No messages found</div>
              ) : (
                visibleMessages.map(t => {
                  const isActive = selected?.id === t.id;
                  return (
                    <div
                      key={t.id}
                      onClick={() => openMessage(t)}
                      className={cn(
                        "p-3 border-b border-border/30 cursor-pointer transition-all group relative",
                        isActive ? "bg-primary/10 border-l-2 border-l-primary" : "hover:bg-muted/30",
                        !t.isRead && !isActive && "bg-primary/[0.03]"
                      )}
                    >
                      <div className="flex items-start gap-2">
                        <Avatar src={t.userProfilePicture} name={t.userName} size="sm" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-1 mb-0.5">
                            <span className={cn("text-xs font-bold truncate", !t.isRead ? "text-foreground" : "text-muted-foreground")}>{t.userName}</span>
                            <span className="text-[10px] text-muted-foreground shrink-0">{formatDistanceToNow(new Date(t.createdAt), { addSuffix: true })}</span>
                          </div>
                          <p className={cn("text-xs truncate mb-1", !t.isRead ? "font-semibold text-foreground" : "text-muted-foreground")}>{t.subject}</p>
                          <p className="text-[10px] text-muted-foreground/70 truncate">{(t.message || t.content || "").slice(0, 60)}</p>
                          <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                            {!t.isRead && <span className="w-1.5 h-1.5 rounded-full bg-primary ml-auto shrink-0" />}
                            {t.attachmentUrl && <Paperclip className="w-3 h-3 text-muted-foreground" />}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </aside>

          {/* ── RIGHT: thread / detail panel ───────────────────────────────── */}
          <section className="flex-1 flex flex-col overflow-hidden bg-background">
            {!selected ? (
              <div className="flex-1 flex flex-col items-center justify-center gap-4 text-center px-8">
                <div className="w-16 h-16 rounded-2xl bg-muted/50 flex items-center justify-center">
                  <MessageSquare className="w-8 h-8 text-muted-foreground/30" />
                </div>
                <p className="text-base font-bold text-muted-foreground">Select a message to view the thread</p>
                <p className="text-sm text-muted-foreground/60">Choose from the list on the left</p>
              </div>
            ) : (
              <>
                {/* Message header */}
                <div className="px-5 py-3.5 border-b border-border/50 shrink-0 bg-card/30">
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="min-w-0">
                      <h2 className="text-base font-black text-foreground font-sans leading-tight truncate">{selected.subject}</h2>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {selected.userName} · {selected.userEmail}
                        {selected.resolvedAt && <> · Resolved {format(new Date(selected.resolvedAt), "MMM d, h:mm a")}</>}
                      </p>
                    </div>

                  </div>

                  {/* Action bar */}
                  <div className="flex items-center gap-2 flex-wrap">
                    <Button variant="ghost" size="sm" onClick={() => deleteMessage(selected)} className="text-destructive hover:text-destructive hover:bg-destructive/10">
                      <Trash2 className="w-4 h-4 mr-1.5" /> Delete
                    </Button>
                  </div>
                </div>

                {/* Thread area */}
                {loadingDetail ? (
                  <div className="flex-1 flex items-center justify-center"><Loader2 className="w-5 h-5 animate-spin text-primary" /></div>
                ) : (
                  <div ref={threadRef} className="flex-1 overflow-y-auto px-5 py-4 space-y-4">

                    {/* Student's original message */}
                    <div className="flex gap-3 items-start">
                      <Avatar src={selected.userProfilePicture} name={selected.userName} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline gap-2 mb-1">
                          <span className="text-sm font-black text-foreground">{selected.userName}</span>
                          <span className="text-[10px] text-muted-foreground">{format(new Date(selected.createdAt), "EEE, MMM d · h:mm a")}</span>
                        </div>
                        <div className="bg-card border border-border/50 rounded-xl rounded-tl-none p-3.5 text-sm leading-relaxed text-foreground/90 whitespace-pre-wrap">
                          <Linkify text={selected.message || selected.content || ""} />
                          {selected.attachmentUrl && (
                            <div className="mt-3">
                              <a href={selected.attachmentUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-3 py-1.5 bg-muted rounded-lg text-xs font-bold text-muted-foreground hover:text-foreground transition-colors border border-border">
                                <Paperclip className="w-3.5 h-3.5" />
                                View Attachment
                              </a>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>



                    {/* Admin reply */}
                    {selected.reply && (
                      <div className="flex gap-3 items-start translate-x-6">
                        <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center shrink-0">
                          <span className="text-xs font-black text-primary-foreground">A</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-baseline gap-2 mb-1">
                            <span className="text-sm font-black text-foreground">Support Team</span>
                            <span className="text-[10px] text-primary font-bold uppercase tracking-wide">Reply</span>
                          </div>
                          <div className="bg-primary/10 border border-primary/20 rounded-xl rounded-tl-none p-3.5 text-sm leading-relaxed text-foreground/90 whitespace-pre-wrap">
                            <Linkify text={selected.reply} />
                            {selected.replyAttachmentUrl && (
                              <div className="mt-3">
                                <a href={selected.replyAttachmentUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary/10 rounded-lg text-xs font-bold text-primary hover:bg-primary/20 transition-colors border border-primary/20">
                                  <Paperclip className="w-3.5 h-3.5" />
                                  View Attachment
                                </a>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    )}

                  </div>
                )}

                {/* Compose area */}
                <div className="border-t border-border/50 p-4 space-y-3 shrink-0 bg-card/20">



                  {/* Public reply */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black uppercase tracking-widest text-primary flex items-center gap-1.5">
                      <Send className="w-3 h-3" /> Reply to Student
                    </label>
                    <div className="flex gap-2">
                      <Input type="file" ref={fileInputRef} className="hidden" onChange={e => setAttachment(e.target.files?.[0] || null)} />
                      <Button variant="outline" size="icon" onClick={() => fileInputRef.current?.click()} className={cn("shrink-0 h-9 w-9 rounded-lg border-border/50 transition-colors", attachment && "bg-primary/10 border-primary/30 text-primary")}>
                        <Paperclip className="w-4 h-4" />
                      </Button>
                      <Textarea
                        placeholder={`Reply to ${selected.userName}...`}
                        value={replyText}
                        onChange={e => setReplyText(e.target.value)}
                        rows={3}
                        className="resize-none bg-muted/40 border-border/50 text-sm focus-visible:ring-primary/30 placeholder:text-muted-foreground/50"
                        onKeyDown={e => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) sendReply(); }}
                      />
                      <Button
                        onClick={sendReply}
                        disabled={sendingReply || (!replyText.trim() && !attachment)}
                        className="self-end h-9 px-3 font-black rounded-lg text-xs shadow-lg shadow-primary/20"
                      >
                        {sendingReply ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                      </Button>
                    </div>
                    {attachment && (
                      <div className="flex items-center gap-2 text-[10px] font-bold text-primary bg-primary/10 px-2.5 py-1 rounded-md w-fit mt-2 border border-primary/20">
                        <Paperclip className="w-3 h-3" />
                        <span className="truncate max-w-[150px]">{attachment.name}</span>
                        <button onClick={() => setAttachment(null)} className="hover:bg-primary/20 rounded-full p-0.5"><XCircle className="w-3 h-3" /></button>
                      </div>
                    )}
                    <p className="text-[10px] text-muted-foreground/50 mt-1">Ctrl+Enter to send</p>
                  </div>

                </div>
              </>
            )}
          </section>

        </div>{/* end two-panel */}
      </main>

      <Footer />

      <ConfirmDialog
        isOpen={confirm.isOpen}
        onOpenChange={open => setConfirm(p => ({ ...p, isOpen: open }))}
        title={confirm.title}
        description={confirm.description}
        onConfirm={confirm.onConfirm}
        variant={confirm.variant}
      />
    </div>
  );
}

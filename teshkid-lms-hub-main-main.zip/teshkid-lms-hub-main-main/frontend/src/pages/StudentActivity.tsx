import { useState, useEffect } from "react";
import api from "@/lib/api";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { toast } from "sonner";
import { Activity, BookOpen, CheckCircle, Clock, TrendingUp, Calendar } from "lucide-react";

interface ActivityItem {
  id: string;
  type: "lesson_complete" | "course_enroll" | "certificate";
  title: string;
  courseName?: string;
  createdAt: string;
}

export default function StudentActivity() {
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [gamification, setGamification] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [dashRes, certRes] = await Promise.all([
        api.get("/dashboard"),
        api.get("/certificates").catch(() => ({ data: [] })),
      ]);
      setStats(dashRes.data.stats);
      setGamification(dashRes.data.gamification);

      // Build activity feed from available data
      const feed: ActivityItem[] = [];
      (dashRes.data.recentCourses || []).forEach((c: any) => {
        feed.push({
          id: `enroll-${c.id}`,
          type: "course_enroll",
          title: `Enrolled in "${c.title}"`,
          courseName: c.title,
          createdAt: c.enrolledAt,
        });
        if (c.lessonsCompleted > 0) {
          feed.push({
            id: `lesson-${c.id}`,
            type: "lesson_complete",
            title: `Completed ${c.lessonsCompleted} lesson${c.lessonsCompleted !== 1 ? "s" : ""} in "${c.title}"`,
            courseName: c.title,
            createdAt: c.enrolledAt,
          });
        }
      });
      (certRes.data || []).forEach((cert: any) => {
        feed.push({
          id: `cert-${cert.id}`,
          type: "certificate",
          title: `Earned certificate for "${cert.courseName || "a course"}"`,
          createdAt: cert.issuedAt || cert.createdAt,
        });
      });
      feed.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setActivities(feed);
    } catch {
      toast.error("Failed to load activity");
    } finally {
      setLoading(false);
    }
  };

  const xpProgress = gamification
    ? Math.round(((gamification.xp - gamification.xpForCurrentLevel) / (gamification.xpForNextLevel - gamification.xpForCurrentLevel)) * 100)
    : 0;

  const ICON_MAP: Record<string, any> = {
    lesson_complete: { icon: CheckCircle, color: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/20" },
    course_enroll: { icon: BookOpen, color: "text-violet-400", bg: "bg-violet-500/10 border-violet-500/20" },
    certificate: { icon: TrendingUp, color: "text-amber-400", bg: "bg-amber-500/10 border-amber-500/20" },
  };

  return (
    <DashboardLayout xp={gamification?.xp} level={gamification?.level} xpProgress={xpProgress}>
      <div className="max-w-5xl mx-auto px-4 md:px-8 py-8 space-y-6">
        <div>
          <h1 className="text-2xl font-black font-sans text-foreground">Activity</h1>
          <p className="text-sm text-muted-foreground mt-1">Your learning journey at a glance</p>
        </div>

        {/* Quick stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "XP Earned", value: gamification?.xp ?? 0, icon: TrendingUp, color: "text-violet-400" },
            { label: "Lessons Done", value: stats?.completedLessons ?? 0, icon: CheckCircle, color: "text-emerald-400" },
            { label: "Today's Lessons", value: gamification?.lessonsToday ?? 0, icon: Clock, color: "text-blue-400" },
          ].map((s) => (
            <div key={s.label} className="rounded-2xl border border-border/60 bg-card/60 p-4 shadow-md">
              <div className="flex items-center gap-2 mb-2">
                <s.icon className={`w-4 h-4 ${s.color}`} />
                <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">{s.label}</span>
              </div>
              <div className="text-3xl font-black text-foreground">{s.value}</div>
            </div>
          ))}
        </div>

        {/* Activity feed */}
        <div className="rounded-2xl border border-border/60 bg-card/60 p-6 shadow-md">
          <h2 className="text-base font-bold text-foreground mb-5 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-primary" /> Recent Activity
          </h2>
          {loading ? (
            <div className="flex justify-center py-10">
              <div className="w-7 h-7 border-4 border-primary border-t-transparent rounded-full animate-spin" />
            </div>
          ) : activities.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground text-sm">
              No activity yet — start learning to see your progress here!
            </div>
          ) : (
            <div className="space-y-3">
              {activities.map((item) => {
                const cfg = ICON_MAP[item.type];
                const Icon = cfg.icon;
                return (
                  <div key={item.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-muted/30 transition-colors">
                    <div className={`w-9 h-9 rounded-full flex items-center justify-center border shrink-0 ${cfg.bg}`}>
                      <Icon className={`w-4 h-4 ${cfg.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{item.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(item.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}

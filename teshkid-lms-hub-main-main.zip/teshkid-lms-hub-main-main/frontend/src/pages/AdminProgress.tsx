import { useEffect, useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import api from "@/lib/api";
import { toast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { TrendingUp, Users, BookOpen, Edit } from "lucide-react";

export default function AdminProgress() {
  const [enrollments, setEnrollments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editProgress, setEditProgress] = useState("");
  const navigate = useNavigate();

  const fetchProgress = async () => {
    setLoading(true);
    try {
      const res = await api.get("/admin/progress");
      setEnrollments(res.data);
    } catch (err) {
      console.error(err);
      toast({ title: "Error", description: "Could not load progress data." });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProgress();
  }, []);

  const handleUpdateProgress = async (id: string) => {
    const progress = Number(editProgress);
    if (isNaN(progress) || progress < 0 || progress > 100) {
      toast({
        title: "Error",
        description: "Progress must be between 0 and 100.",
      });
      return;
    }
    try {
      await api.put(`/admin/enrollments/${id}`, { progress });
      toast({ title: "Success", description: "Progress updated." });
      setEditingId(null);
      setEditProgress("");
      fetchProgress();
    } catch (err) {
      console.error(err);
      toast({ title: "Error", description: "Could not update progress." });
    }
  };

  const filteredEnrollments = enrollments.filter(
    (e) =>
      e.user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.course.title.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const avgProgress =
    enrollments.length > 0
      ? Math.round(
        enrollments.reduce((acc, e) => acc + e.progress, 0) /
        enrollments.length,
      )
      : 0;

  const completedCount = enrollments.filter((e) => e.progress === 100).length;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-32 sm:pt-40 pb-20 container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <h1 className="font-display text-3xl font-bold">Student Progress</h1>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => navigate("/admin")}>
              Back
            </Button>
            <Button onClick={fetchProgress} variant="ghost">
              Refresh
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card variant="glass">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Enrollments
              </CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{enrollments.length}</div>
            </CardContent>
          </Card>
          <Card variant="glass">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Average Progress
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{avgProgress}%</div>
            </CardContent>
          </Card>
          <Card variant="glass">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Completed Courses
              </CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{completedCount}</div>
            </CardContent>
          </Card>
        </div>

        {/* Progress Table */}
        <Card>
          <CardHeader>
            <CardTitle>Enrollment Progress</CardTitle>
            <Input
              placeholder="Search by student name, email, or course..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="mt-4"
            />
          </CardHeader>
          <CardContent>
            {loading ? (
              <div>Loading...</div>
            ) : filteredEnrollments.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">
                No enrollments found
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="text-xs text-muted-foreground border-b">
                      <th className="pb-2">Student</th>
                      <th className="pb-2">Email</th>
                      <th className="pb-2">Course</th>
                      <th className="pb-2">Progress</th>
                      <th className="pb-2">Last Updated</th>
                      <th className="pb-2">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredEnrollments.map((enrollment) => (
                      <tr key={enrollment.id} className="border-b">
                        <td className="py-3">{enrollment.user.name}</td>
                        <td className="py-3 text-sm text-muted-foreground">
                          {enrollment.user.email}
                        </td>
                        <td className="py-3">{enrollment.course.title}</td>
                        <td className="py-3">
                          {editingId === enrollment.id ? (
                            <div className="flex items-center gap-2">
                              <Input
                                type="number"
                                min="0"
                                max="100"
                                value={editProgress}
                                onChange={(e) =>
                                  setEditProgress(e.target.value)
                                }
                                className="w-20"
                              />
                              <Button
                                size="sm"
                                onClick={() =>
                                  handleUpdateProgress(enrollment.id)
                                }
                              >
                                Save
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setEditingId(null);
                                  setEditProgress("");
                                }}
                              >
                                Cancel
                              </Button>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2">
                              <Progress
                                value={enrollment.progress}
                                className="w-24"
                              />
                              <span className="text-sm font-medium">
                                {enrollment.progress}%
                              </span>
                            </div>
                          )}
                        </td>
                        <td className="py-3 text-sm text-muted-foreground">
                          {new Date(enrollment.updatedAt).toLocaleDateString()}
                        </td>
                        <td className="py-3">
                          {editingId !== enrollment.id && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setEditingId(enrollment.id);
                                setEditProgress(enrollment.progress.toString());
                              }}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
      <Footer />
    </div>
  );
}

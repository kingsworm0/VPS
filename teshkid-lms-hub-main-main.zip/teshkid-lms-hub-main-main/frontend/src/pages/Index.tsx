import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CourseCard } from "@/components/courses/CourseCard";
import api from "@/lib/api";
import heroBg from "@/assets/hero-bg.png";
import {
  GraduationCap,
  Shield,
  Wallet,
  TrendingUp,
  Play,
  Users,
  Award,
  BookOpen,
  ArrowRight,
  CheckCircle2,
  Star,
  Zap,
} from "lucide-react";

import SocialIcons from "@/components/layout/SocialIcons";
import BlogSection from "@/components/dashboard/BlogSection";

const features = [
  {
    icon: Shield,
    title: "Industry-Leading Security",
    description:
      "Learn secure practices from crypto security experts with hands-on exercises.",
  },
  {
    icon: Wallet,
    title: "Pay with Crypto",
    description:
      "Enroll using BTC, ETH, or stablecoins. We practice what we teach.",
  },
  {
    icon: TrendingUp,
    title: "Real-World Projects",
    description:
      "Build actual dApps, deploy smart contracts, and trade in sandbox environments.",
  },
  {
    icon: Award,
    title: "Verified Certificates",
    description:
      "Earn blockchain-verified credentials that prove your expertise.",
  },
];

const stats = [
  { value: "50K+", label: "Students Enrolled" },
  { value: "120+", label: "Expert Courses" },
  { value: "95%", label: "Completion Rate" },
  { value: "4.9", label: "Average Rating" },
];

const testimonials = [
  {
    name: "Marcus Chen",
    role: "Blockchain Developer",
    avatar:
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&q=80",
    content:
      "Teshkid transformed my understanding of blockchain. The hands-on projects gave me the confidence to land my first Web3 job.",
    rating: 5,
  },
  {
    name: "Sarah Williams",
    role: "DeFi Analyst",
    avatar:
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&q=80",
    content:
      "The DeFi Mastery course is exceptional. I went from zero knowledge to managing liquidity pools professionally.",
    rating: 5,
  },
  {
    name: "David Park",
    role: "Crypto Trader",
    avatar:
      "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&q=80",
    content:
      "Best investment I've made. The trading strategies course paid for itself within the first month.",
    rating: 5,
  },
];

export default function Index() {
  const [featuredCourses, setFeaturedCourses] = useState<any[]>([]);
  const [loadingCourses, setLoadingCourses] = useState(true);

  useEffect(() => {
    const loadFeaturedCourses = async () => {
      try {
        const res = await api.get("/courses");
        const courses = Array.isArray(res.data) ? res.data : [];
        setFeaturedCourses(courses.slice(0, 3));
      } catch (error) {
        console.error("Failed to load featured courses", error);
        setFeaturedCourses([]);
      } finally {
        setLoadingCourses(false);
      }
    };

    loadFeaturedCourses();
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative pt-32 sm:pt-40 overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-30"
          style={{ backgroundImage: `url(${heroBg})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/80 to-background" />

        <div className="relative container mx-auto px-4 py-24 lg:py-32">
          <div className="max-w-4xl mx-auto text-center animate-slide-up">
            <Badge variant="gradient" className="mb-6 px-4 py-1.5 text-sm">
              <Zap className="w-3.5 h-3.5 mr-1" />
              #1 Crypto Education Platform
            </Badge>

            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Master <span className="gradient-text">Crypto & Blockchain</span>{" "}
              with Expert-Led Courses
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              From Bitcoin basics to advanced DeFi strategies. Join 50,000+
              students learning the future of finance with hands-on projects and
              real-world skills.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Link to="/courses">
                <Button
                  variant="hero"
                  size="xl"
                  className="gap-2 w-full sm:w-auto"
                >
                  Explore Courses
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </Link>
              <Button variant="hero-outline" size="xl" className="gap-2">
                <Play className="w-5 h-5" />
                Watch Demo
              </Button>
            </div>

            <div className="mt-4 flex justify-center">
              <SocialIcons />
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-3xl md:text-4xl font-display font-bold gradient-text">
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-card/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
              Why Choose <span className="gradient-text">Teshkid</span>?
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Built by crypto experts for crypto enthusiasts. Our platform
              combines cutting-edge curriculum with practical experience.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature) => (
              <Card
                key={feature.title}
                variant="glass"
                className="group hover:border-primary/30 transition-all duration-300"
              >
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-display font-semibold text-lg mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Courses */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="flex items-end justify-between mb-12">
            <div>
              <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
                Featured <span className="gradient-text">Courses</span>
              </h2>
              <p className="text-muted-foreground">
                Start your crypto journey with our most popular courses.
              </p>
            </div>
            <Link to="/courses" className="hidden md:block">
              <Button variant="outline" className="gap-2">
                View All Courses
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>

          {loadingCourses ? (
            <div className="text-center text-muted-foreground">Loading featured courses...</div>
          ) : featuredCourses.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredCourses.map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          ) : (
            <div className="text-center text-muted-foreground">
              No featured courses available yet.
            </div>
          )}

          <div className="mt-8 text-center md:hidden">
            <Link to="/courses">
              <Button variant="outline" className="gap-2">
                View All Courses
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Learning Path Section */}
      <section className="py-20 bg-card/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
              Your Path to <span className="gradient-text">Crypto Mastery</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Follow our structured learning paths designed to take you from
              beginner to expert.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="grid gap-4">
              {[
                {
                  step: 1,
                  title: "Foundation",
                  desc: "Bitcoin basics, blockchain fundamentals, wallet setup",
                  courses: 4,
                },
                {
                  step: 2,
                  title: "Intermediate",
                  desc: "Altcoins, trading strategies, DeFi introduction",
                  courses: 6,
                },
                {
                  step: 3,
                  title: "Advanced",
                  desc: "Smart contracts, yield farming, security auditing",
                  courses: 5,
                },
                {
                  step: 4,
                  title: "Expert",
                  desc: "Protocol development, MEV strategies, DAO governance",
                  courses: 3,
                },
              ].map((path, index) => (
                <Card
                  key={path.step}
                  variant="glass"
                  className="group hover:border-primary/30 transition-all duration-300"
                >
                  <CardContent className="p-6 flex items-center gap-6">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-emerald-600 flex items-center justify-center text-2xl font-display font-bold text-primary-foreground flex-shrink-0">
                      {path.step}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-display font-semibold text-lg mb-1">
                        {path.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {path.desc}
                      </p>
                    </div>
                    <div className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground">
                      <BookOpen className="w-4 h-4" />
                      {path.courses} courses
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
              Loved by <span className="gradient-text">50,000+ Students</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              See what our graduates have to say about their learning
              experience.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial) => (
              <Card key={testimonial.name} variant="glass">
                <CardContent className="p-6">
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star
                        key={i}
                        className="w-4 h-4 fill-warning text-warning"
                      />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-6">
                    {testimonial.content}
                  </p>
                  <div className="flex items-center gap-3">
                    <img
                      src={testimonial.avatar}
                      alt={testimonial.name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div>
                      <div className="font-semibold text-sm">
                        {testimonial.name}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {testimonial.role}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <Card variant="gradient" className="relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-transparent to-emerald-700/20" />
            <CardContent className="relative p-8 md:p-12 text-center">
              <GraduationCap className="w-16 h-16 mx-auto mb-6 text-primary" />
              <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
                Ready to Start Your Crypto Journey?
              </h2>
              <p className="text-muted-foreground max-w-xl mx-auto mb-8">
                Join thousands of students already building their future in
                Web3. Get started with our free introductory course today.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/student/login?mode=signup">
                  <Button
                    variant="hero"
                    size="lg"
                    className="gap-2 w-full sm:w-auto"
                  >
                    Get Started Free
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                </Link>
                <Link to="/courses">
                  <Button
                    variant="hero-outline"
                    size="lg"
                    className="w-full sm:w-auto"
                  >
                    Browse Courses
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
}

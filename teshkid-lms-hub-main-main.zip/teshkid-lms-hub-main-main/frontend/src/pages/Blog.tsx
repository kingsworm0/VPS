import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import api from "@/lib/api";
import { getImageUrl } from "@/lib/imageUtils";
import { updateMetaTags } from "@/lib/seo";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Search, ChevronLeft, ChevronRight, Eye, Heart,
  TrendingUp, Flame, Clock, Loader2, ArrowUpRight,
  Calendar,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────
interface Blog {
  id: string;
  title: string;
  content: string;
  slug: string;
  category: string;
  description?: string;
  featuredImage?: string;
  coverImage?: string;
  tags: string[];
  viewCount: number;
  likeCount?: number;
  createdAt: string;
  authorName?: string;
  authorProfilePicture?: string;
  gallery?: string[] | string;
}

// ─── Constants ────────────────────────────────────────────────────────────────
const CATEGORY_LABELS: Record<string, string> = {
  "admin-thoughts":  "Admin Thoughts",
  "mcrypto-analysis":"MCrypto Analysis",
  "previous-day":    "Daily Digest",
  "trading-ideas":   "Trading Strategies",
};

const CATEGORY_COLORS: Record<string, string> = {
  "admin-thoughts":  "bg-blue-500",
  "mcrypto-analysis":"bg-indigo-600",
  "previous-day":    "bg-emerald-500",
  "trading-ideas":   "bg-amber-500",
};

const HERO_FALLBACK =
  "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=2000";
const CARD_FALLBACK =
  "https://images.unsplash.com/photo-1642104704074-907c0698cbd9?auto=format&fit=crop&q=80&w=800";

const BLOGS_PER_PAGE = 9;

// ─── Helpers ──────────────────────────────────────────────────────────────────
const readingTime = (content: string) =>
  Math.max(1, Math.ceil(content.replace(/<[^>]*>/g, " ").trim().split(/\s+/).filter(Boolean).length / 220));

const galleryCount = (gallery: Blog["gallery"]) => {
  if (Array.isArray(gallery)) return gallery.length;
  if (typeof gallery === "string") { try { return JSON.parse(gallery).length; } catch { return 0; } }
  return 0;
};

// ─── Component ────────────────────────────────────────────────────────────────
export default function Blog() {
  const [blogs, setBlogs]               = useState<Blog[]>([]);
  const [loading, setLoading]           = useState(true);
  const [searchTerm, setSearchTerm]     = useState("");
  const [selectedCat, setSelectedCat]   = useState<string | null>(null);
  const [currentPage, setCurrentPage]   = useState(1);
  const [sortBy, setSortBy]             = useState<"latest" | "popular">("latest");

  useEffect(() => {
    updateMetaTags(
      "Crypto Blog & Market Insights | Teshkid Is Crypto",
      "Expert crypto analysis, trading strategies, and blockchain education from Teshkid Is Crypto.",
      `${window.location.origin}/blog`,
    );
    (async () => {
      try {
        const res = await api.get("/blogs");
        setBlogs(Array.isArray(res.data) ? res.data : []);
      } catch { setBlogs([]); }
      finally { setLoading(false); }
    })();
  }, []);

  // ── Derived data ────────────────────────────────────────────────────────────
  const categories = Array.from(new Set(blogs.map(b => b.category).filter(Boolean)));

  const sorted = [...blogs]
    .filter(b => {
      const q = searchTerm.toLowerCase();
      const matchSearch = !q || b.title.toLowerCase().includes(q) || (b.description || "").toLowerCase().includes(q);
      const matchCat    = !selectedCat || b.category === selectedCat;
      return matchSearch && matchCat;
    })
    .sort((a, b) =>
      sortBy === "popular"
        ? (b.likeCount || 0) + b.viewCount - ((a.likeCount || 0) + a.viewCount)
        : new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );

  const isFiltered   = !!(searchTerm || selectedCat);
  const featured     = !isFiltered ? sorted[0]    : null;
  const grid         = !isFiltered ? sorted.slice(1) : sorted;
  const totalPages   = Math.ceil(grid.length / BLOGS_PER_PAGE);
  const paginated    = grid.slice((currentPage - 1) * BLOGS_PER_PAGE, currentPage * BLOGS_PER_PAGE);
  const hot          = [...blogs].sort((a, b) => b.viewCount - a.viewCount).slice(0, 4);

  const resetPage = () => setCurrentPage(1);

  // ── Render ──────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />

      {/* ── HERO BANNER ──────────────────────────────────────────────────────── */}
      <div className="relative w-full h-[40vh] md:h-[52vh] overflow-hidden">
        {/* Background image — uses featured post image or fallback */}
        <img
          src={featured ? (getImageUrl(featured.featuredImage || featured.coverImage) || HERO_FALLBACK) : HERO_FALLBACK}
          alt="Blog hero"
          loading="eager"
          className="absolute inset-0 w-full h-full object-cover object-center"
        />
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-black/65" />
        {/* Grain texture overlay */}
        <div className="absolute inset-0 opacity-[0.03]"
          style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E\")" }} />
        {/* BLOG title */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-4">
          <p className="text-xs font-black uppercase tracking-[0.35em] text-primary mb-3 opacity-90">
            Teshkid Is Crypto · Newsroom
          </p>
          <h1 className="text-[clamp(4rem,14vw,9rem)] font-black text-white leading-none tracking-tighter uppercase"
            style={{ textShadow: "0 4px 40px rgba(0,0,0,0.7)" }}>
            BLOG
          </h1>
          <p className="mt-3 text-white/60 text-sm md:text-base font-medium max-w-lg">
            Market alpha, technical breakdowns, and deep-dive crypto research.
          </p>
        </div>
        {/* Bottom fade */}
        <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-background to-transparent" />
      </div>

      {/* ── FILTER BAR ───────────────────────────────────────────────────────── */}
      <div className="sticky top-16 z-40 border-b border-border/50 bg-background/95 backdrop-blur-xl">
        <div className="container mx-auto px-4 py-3 flex flex-col md:flex-row items-center gap-3">
          {/* Category pills */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar flex-1 min-w-0">
            <button
              onClick={() => { setSelectedCat(null); resetPage(); }}
              className={`shrink-0 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-wider transition-all ${
                !selectedCat ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" : "bg-muted text-muted-foreground hover:text-foreground"
              }`}>
              All
            </button>
            {categories.map(cat => (
              <button key={cat}
                onClick={() => { setSelectedCat(cat); resetPage(); }}
                className={`shrink-0 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-wider transition-all ${
                  selectedCat === cat ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" : "bg-muted text-muted-foreground hover:text-foreground"
                }`}>
                {CATEGORY_LABELS[cat] || cat}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="relative shrink-0 w-full md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search articles..."
              value={searchTerm}
              onChange={e => { setSearchTerm(e.target.value); resetPage(); }}
              className="pl-9 h-9 bg-muted/50 border-border/50 text-sm"
            />
          </div>

          {/* Sort */}
          <div className="flex items-center gap-1 shrink-0">
            {(["latest", "popular"] as const).map(s => (
              <button key={s} onClick={() => { setSortBy(s); resetPage(); }}
                className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all ${
                  sortBy === s ? "bg-card text-foreground border border-border shadow-sm" : "text-muted-foreground hover:text-foreground"
                }`}>
                {s === "latest" ? "Latest" : "Most Read"}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── MAIN CONTENT ─────────────────────────────────────────────────────── */}
      <main className="container mx-auto px-4 py-12 md:py-16">

        {loading ? (
          <div className="flex flex-col items-center justify-center py-32 gap-4">
            <Loader2 className="w-10 h-10 animate-spin text-primary" />
            <p className="text-muted-foreground text-sm font-bold uppercase tracking-widest animate-pulse">Loading…</p>
          </div>
        ) : sorted.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border/60 py-32 text-center">
            <Search className="w-12 h-12 text-muted-foreground/20 mx-auto mb-4" />
            <p className="text-muted-foreground font-bold">No articles found.</p>
            <button onClick={() => { setSearchTerm(""); setSelectedCat(null); }} className="mt-3 text-primary text-sm font-black hover:underline">
              Clear filters
            </button>
          </div>
        ) : (
          <>
            {/* ── FEATURED HERO CARD ─────────────────────────────────────────── */}
            {featured && !isFiltered && currentPage === 1 && (
              <Link to={`/blog/${featured.slug}`}
                className="group block rounded-3xl overflow-hidden border border-border/40 shadow-2xl mb-16 hover:border-primary/40 transition-all">
                <div className="relative aspect-[21/8] overflow-hidden">
                  <img
                    src={getImageUrl(featured.featuredImage || featured.coverImage) || HERO_FALLBACK}
                    alt={featured.title}
                    loading="eager"
                    className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10 md:max-w-[70%]">
                    <span className={`inline-block mb-3 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest text-white ${CATEGORY_COLORS[featured.category] || "bg-primary"}`}>
                      {CATEGORY_LABELS[featured.category] || "Featured"}
                    </span>
                    <h2 className="text-2xl md:text-5xl font-black text-white leading-tight mb-3 group-hover:text-primary transition-colors">
                      {featured.title}
                    </h2>
                    <p className="text-white/60 text-sm leading-relaxed line-clamp-2 mb-4 hidden md:block">
                      {featured.description || featured.content.replace(/<[^>]*>/g, "").slice(0, 200)}…
                    </p>
                    <div className="flex items-center gap-4 text-[10px] font-black uppercase tracking-wider text-white/50">
                      <span>{featured.authorName || "Teshkid Is Crypto"}</span>
                      <span>·</span>
                      <span>{new Date(featured.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
                      <span>·</span>
                      <span>{readingTime(featured.content)} min read</span>
                    </div>
                  </div>
                </div>
              </Link>
            )}

            {/* ── GRID + SIDEBAR ──────────────────────────────────────────────── */}
            <div className="grid lg:grid-cols-[1fr_280px] gap-12">

              {/* Card grid */}
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-lg font-black text-foreground flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-primary" />
                    {sortBy === "popular" ? "Reader Favorites" : "Latest Articles"}
                  </h2>
                  <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
                    {sorted.length} article{sorted.length !== 1 ? "s" : ""}
                  </span>
                </div>

                {/* ── 3-COLUMN CARD GRID matching the screenshot ──────────────── */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {paginated.map(blog => (
                    <Link
                      key={blog.id}
                      to={`/blog/${blog.slug}`}
                      className="group flex flex-col bg-card border border-border/50 rounded-2xl overflow-hidden hover:border-primary/40 hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
                    >
                      {/* Thumbnail */}
                      <div className="relative aspect-[16/10] overflow-hidden bg-muted">
                        <img
                          src={getImageUrl(blog.featuredImage || blog.coverImage) || CARD_FALLBACK}
                          alt={blog.title}
                          loading="lazy"
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                        {/* Category pill */}
                        <span className={`absolute top-3 left-3 px-2.5 py-1 rounded-full text-[8px] font-black uppercase tracking-widest text-white ${CATEGORY_COLORS[blog.category] || "bg-primary"}`}>
                          {CATEGORY_LABELS[blog.category] || blog.category}
                        </span>
                        {/* Gallery count */}
                        {galleryCount(blog.gallery) > 0 && (
                          <span className="absolute bottom-2.5 right-2.5 bg-black/70 text-white text-[9px] font-bold px-2 py-0.5 rounded-lg backdrop-blur-sm">
                            +{galleryCount(blog.gallery)}
                          </span>
                        )}
                      </div>

                      {/* Card body */}
                      <div className="flex flex-col flex-1 p-4">
                        {/* Meta */}
                        <div className="flex items-center gap-2 text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-2">
                          <Calendar className="w-3 h-3" />
                          <span>{new Date(blog.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
                          <span>·</span>
                          <Clock className="w-3 h-3" />
                          <span>{readingTime(blog.content)}m</span>
                        </div>

                        {/* Title */}
                        <h3 className="font-black text-foreground text-sm leading-snug mb-2 line-clamp-2 group-hover:text-primary transition-colors">
                          {blog.title}
                        </h3>

                        {/* Excerpt */}
                        <p className="text-muted-foreground text-xs leading-relaxed line-clamp-2 flex-1 mb-3">
                          {blog.description || blog.content.replace(/<[^>]*>/g, "").slice(0, 100)}…
                        </p>

                        {/* Footer */}
                        <div className="flex items-center justify-between pt-3 border-t border-border/40">
                          <div className="flex items-center gap-1.5">
                            {blog.authorProfilePicture ? (
                              <img src={blog.authorProfilePicture} alt="" className="w-5 h-5 rounded-full object-cover" />
                            ) : (
                              <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center">
                                <span className="text-[8px] font-black text-primary">T</span>
                              </div>
                            )}
                            <span className="text-[10px] font-bold text-muted-foreground truncate max-w-[80px]">
                              {blog.authorName || "Teshkid"}
                            </span>
                          </div>
                          <div className="flex items-center gap-3 text-[10px] font-bold text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Heart className="w-3 h-3 text-rose-400/70" />{blog.likeCount || 0}
                            </span>
                            <span className="flex items-center gap-1">
                              <Eye className="w-3 h-3 text-primary/60" />{blog.viewCount || 0}
                            </span>
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-center gap-2 mt-10">
                    <button
                      onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                      className="w-10 h-10 rounded-xl border border-border/50 bg-card flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted transition-all disabled:opacity-30">
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
                      <button key={p} onClick={() => setCurrentPage(p)}
                        className={`w-10 h-10 rounded-xl text-sm font-black transition-all ${
                          currentPage === p
                            ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20"
                            : "border border-border/50 bg-card text-muted-foreground hover:text-foreground hover:bg-muted"
                        }`}>
                        {p}
                      </button>
                    ))}
                    <button
                      onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                      className="w-10 h-10 rounded-xl border border-border/50 bg-card flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted transition-all disabled:opacity-30">
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              {/* ── SIDEBAR ──────────────────────────────────────────────────── */}
              <aside className="hidden lg:block">
                <div className="sticky top-32 space-y-8">

                  {/* Hot streams */}
                  <div>
                    <h3 className="flex items-center gap-2 text-sm font-black uppercase tracking-widest text-foreground mb-4">
                      <Flame className="w-4 h-4 text-orange-400" /> Most Read
                    </h3>
                    <div className="space-y-3">
                      {hot.map((b, i) => (
                        <Link key={b.id} to={`/blog/${b.slug}`}
                          className="group flex items-start gap-3 p-3 rounded-xl bg-card border border-border/40 hover:border-primary/40 hover:shadow-md transition-all">
                          <span className="text-2xl font-black text-border group-hover:text-primary transition-colors tabular-nums shrink-0 leading-none mt-0.5">
                            {String(i + 1).padStart(2, "0")}
                          </span>
                          <div className="min-w-0">
                            <span className={`inline-block mb-1 px-2 py-0.5 rounded-full text-[7px] font-black uppercase tracking-widest text-white ${CATEGORY_COLORS[b.category] || "bg-primary"}`}>
                              {CATEGORY_LABELS[b.category] || b.category}
                            </span>
                            <p className="text-xs font-bold text-foreground/80 group-hover:text-primary transition-colors line-clamp-2 leading-snug">
                              {b.title}
                            </p>
                            <div className="flex items-center gap-2 mt-1.5 text-[10px] text-muted-foreground font-bold">
                              <Eye className="w-3 h-3" />{b.viewCount}
                            </div>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>

                  {/* Categories */}
                  <div>
                    <h3 className="text-sm font-black uppercase tracking-widest text-foreground mb-4">Categories</h3>
                    <div className="flex flex-col gap-2">
                      {categories.map(cat => (
                        <button key={cat} onClick={() => { setSelectedCat(selectedCat === cat ? null : cat); resetPage(); }}
                          className={`flex items-center justify-between px-4 py-2.5 rounded-xl border text-sm font-bold transition-all ${
                            selectedCat === cat
                              ? "bg-primary/10 text-primary border-primary/30"
                              : "bg-card border-border/40 text-muted-foreground hover:text-foreground hover:border-primary/20"
                          }`}>
                          <span>{CATEGORY_LABELS[cat] || cat}</span>
                          <span className="text-[10px] font-black tabular-nums">
                            {blogs.filter(b => b.category === cat).length}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                </div>
              </aside>
            </div>
          </>
        )}
      </main>

      <Footer />
    </div>
  );
}

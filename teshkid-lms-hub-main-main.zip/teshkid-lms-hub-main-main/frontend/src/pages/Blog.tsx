import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import api from "@/lib/api";
import { updateMetaTags } from "@/lib/seo";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Search,
  ChevronLeft,
  ChevronRight,
  Eye,
  Heart,
  TrendingUp,
  Flame,
  Clock,
  Calendar,
  Loader2,
} from "lucide-react";

interface Blog {
  id: string;
  title: string;
  content: string;
  slug: string;
  category: string;
  description?: string;
  featuredImage?: string;
  coverImage?: string;
  tags: string[];
  viewCount: number;
  likeCount?: number;
  dislikeCount?: number;
  userLiked?: boolean;
  userDisliked?: boolean;
  createdAt: string;
  status: string;
  authorName?: string;
  authorProfilePicture?: string;
}

const categoryLabels: Record<string, string> = {
  "admin-thoughts": "Admin Thoughts",
  "mcrypto-analysis": "MCrypto Analysis",
  "previous-day": "Daily Digest",
  "trading-ideas": "Trading Strategies",
};

const categoryColors: Record<string, string> = {
  "admin-thoughts": "bg-blue-500",
  "mcrypto-analysis": "bg-indigo-600",
  "previous-day": "bg-emerald-500",
  "trading-ideas": "bg-amber-500",
};

const BLOGS_PER_PAGE = 9;

export default function Blog() {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [filteredBlogs, setFilteredBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);

  const categories = Array.from(
    new Set(blogs.map((blog) => blog.category).filter(Boolean)),
  );

  useEffect(() => {
    updateMetaTags(
      "Crypto Insights & Alpha | Teshkid",
      "Unlock professional-grade crypto analysis and trading strategies from the Teshkid team.",
      `${window.location.origin}/`,
    );

    const fetchBlogs = async () => {
      try {
        const res = await api.get("/blogs");
        const data = res.data;
        const blogsArray = Array.isArray(data) ? data : [];
        setBlogs(blogsArray);
        setFilteredBlogs(blogsArray);
      } catch (err) {
        console.error("Failed to fetch blogs", err);
        setBlogs([]);
      } finally {
        setLoading(false);
      }
    };
    fetchBlogs();
  }, []);

  useEffect(() => {
    let filtered = blogs;
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      filtered = filtered.filter(
        (blog) =>
          blog.title.toLowerCase().includes(searchLower) ||
          blog.content.toLowerCase().includes(searchLower),
      );
    }
    if (selectedCategory) {
      filtered = filtered.filter((blog) => blog.category === selectedCategory);
    }
    setFilteredBlogs(filtered);
    setCurrentPage(1);
  }, [searchTerm, selectedCategory, blogs]);

  const sortedBlogs = [...filteredBlogs].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );

  const featuredBlog = sortedBlogs[0];
  const popularBlogs = [...blogs]
    .sort((a, b) => (b.viewCount || 0) - (a.viewCount || 0))
    .slice(0, 4);

  const gridBlogs = sortedBlogs;
  const totalPages = Math.ceil(gridBlogs.length / BLOGS_PER_PAGE);
  const startIdx = (currentPage - 1) * BLOGS_PER_PAGE;
  const paginatedGridBlogs = gridBlogs.slice(
    startIdx,
    startIdx + BLOGS_PER_PAGE,
  );

  return (
    <div className="min-h-screen bg-[#05070a] text-white selection:bg-primary/30">
      <Navbar />

      {/* Hero Background Glows */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none opacity-20">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-primary/20 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-blue-500/10 rounded-full blur-[120px]" />
      </div>

      <main className="relative container mx-auto px-4 pt-32 sm:pt-40 pb-20">
        {/* Modern Header Section */}
        <div className="relative z-10 flex flex-col items-center text-center mb-16">
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20 py-1 px-4 text-[10px] font-black uppercase tracking-[0.2em] animate-in fade-in slide-in-from-bottom-4 duration-1000">
            Professional Analysis
          </Badge>
          <h1 className="text-5xl md:text-7xl font-black tracking-tight mb-4 animate-in fade-in slide-in-from-bottom-6 duration-1000 delay-200">
            Market <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-400">Insights</span>
          </h1>
          <p className="max-w-2xl text-white/60 text-lg font-medium leading-relaxed animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-300">
            Stay ahead of the curve with our curated stream of market alpha, technical breakdowns, and deep-dive crypto research.
          </p>
        </div>

        {/* Search & Categories Bar - Advanced Sticky Implementation */}
        <div className="sticky top-24 z-40 mb-12 animate-in fade-in duration-1000 delay-500">
          <div className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-2xl p-2 flex flex-col lg:flex-row items-center gap-4 shadow-2xl shadow-black/50">
            <div className="flex-1 w-full overflow-x-auto no-scrollbar scroll-smooth">
              <div className="flex items-center gap-2 p-1 min-w-max">
                <Button
                  variant={selectedCategory === null ? "default" : "ghost"}
                  onClick={() => setSelectedCategory(null)}
                  className={`rounded-xl text-xs font-black uppercase tracking-wider h-10 px-6 ${selectedCategory === null ? 'shadow-lg shadow-primary/20' : 'text-white/60'}`}
                >
                  All Streams
                </Button>
                {categories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? "default" : "ghost"}
                    onClick={() => setSelectedCategory(category)}
                    className={`rounded-xl text-xs font-black uppercase tracking-wider h-10 px-6 ${selectedCategory === category ? 'shadow-lg shadow-primary/20' : 'text-white/60 hover:text-white'}`}
                  >
                    {categoryLabels[category] || category}
                  </Button>
                ))}
              </div>
            </div>
            <div className="w-full lg:w-80 relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40 group-focus-within:text-primary transition-colors" />
              <Input
                type="text"
                placeholder="Scan articles..."
                className="bg-white/5 border-white/20 rounded-xl pl-12 h-10 text-sm focus:ring-primary focus:border-primary transition-all placeholder:text-white/20"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-32 space-y-6">
            <Loader2 className="w-12 h-12 text-primary animate-spin" />
            <p className="text-white/40 font-bold uppercase tracking-widest text-xs">Accessing Mainframe...</p>
          </div>
        ) : filteredBlogs.length === 0 ? (
          <div className="bg-white/5 border border-white/20 rounded-[2rem] py-32 text-center group">
            <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
              <Search className="w-8 h-8 text-white/20" />
            </div>
            <h3 className="text-2xl font-black mb-2">No Signals Found</h3>
            <p className="text-white/40 font-medium">Try adjusting your filters to find existing insights.</p>
          </div>
        ) : (
          <>
            {/* Featured Hero Article */}
            {!searchTerm && !selectedCategory && currentPage === 1 && featuredBlog && (
              <div className="relative group mb-20 animate-in zoom-in-95 duration-1000">
                <Link to={`/blog/${featuredBlog.slug}`}>
                  <div className="relative aspect-[21/9] rounded-[2.5rem] overflow-hidden border border-white/20 shadow-2xl">
                    <img
                      src={featuredBlog.featuredImage || featuredBlog.coverImage || "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=2000"}
                      alt={featuredBlog.title}
                      className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#05070a] via-[#05070a]/40 to-transparent" />

                    <div className="absolute bottom-0 left-0 right-0 p-8 md:p-16 flex flex-col items-start md:max-w-[70%]">
                      <Badge className={`${categoryColors[featuredBlog.category] || "bg-primary"} text-white border-none py-1.5 px-4 rounded-full text-[10px] font-black uppercase tracking-widest shadow-2xl mb-6`}>
                        {categoryLabels[featuredBlog.category] || "Featured Alpha"}
                      </Badge>
                      <h2 className="text-4xl md:text-6xl font-black mb-6 leading-[1.1] group-hover:text-primary transition-colors">
                        {featuredBlog.title}
                      </h2>
                      <div className="flex flex-wrap items-center gap-6 text-white/60 text-xs font-bold uppercase tracking-widest mb-8">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full border-2 border-primary/50 overflow-hidden bg-white/10 p-0.5">
                            <img
                              src={featuredBlog.authorProfilePicture || "/placeholder.svg"}
                              alt={featuredBlog.authorName}
                              className="w-full h-full object-cover rounded-full"
                            />
                          </div>
                          <span>{featuredBlog.authorName || "Teshkid is Crypto"}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-primary" />
                          {new Date(featuredBlog.createdAt).toLocaleDateString()}
                        </div>
                        <div className="flex items-center gap-2">
                          <Eye className="w-4 h-4 text-primary" />
                          {featuredBlog.viewCount} Signals
                        </div>
                      </div>
                      <p className="text-white/60 text-lg leading-relaxed line-clamp-2 md:line-clamp-3 mb-8 hidden md:block">
                        {featuredBlog.description || featuredBlog.content.replace(/<[^>]*>/g, "").slice(0, 250)}...
                      </p>
                      <Button className="rounded-2xl px-10 h-14 font-black uppercase tracking-widest shadow-xl shadow-primary/20 group-hover:bg-white group-hover:text-black transition-all">
                        Read Operation
                      </Button>
                    </div>
                  </div>
                </Link>
              </div>
            )}

            {/* Trending & Newsletter Bar */}
            <div className="grid lg:grid-cols-4 gap-8 mb-20 animate-in slide-in-from-bottom-10 duration-1000">
              <div className="lg:col-span-3">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-2xl font-black uppercase tracking-tighter flex items-center gap-3">
                    <TrendingUp className="w-6 h-6 text-primary" />
                    Live Analysis Feed
                  </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {paginatedGridBlogs.map((blog) => (
                    <div key={blog.id} className="group relative flex flex-col h-full bg-white/[0.03] hover:bg-white/[0.07] border border-white/20 rounded-[2rem] p-6 transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-primary/10">
                      <Link to={`/blog/${blog.slug}`} className="absolute inset-0 z-10" />

                      <div className="relative aspect-[16/10] rounded-2xl overflow-hidden mb-6 border border-white/5">
                        <img
                          src={blog.featuredImage || blog.coverImage || "https://images.unsplash.com/photo-1642104704074-907c0698cbd9?auto=format&fit=crop&q=80&w=800"}
                          alt={blog.title}
                          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                        />
                        <Badge className={`absolute top-4 left-4 ${categoryColors[blog.category] || "bg-white/20"} text-white border-none py-1 px-3 text-[8px] font-black uppercase tracking-widest`}>
                          {categoryLabels[blog.category] || blog.category}
                        </Badge>
                      </div>

                      <div className="flex-1 flex flex-col">
                        <div className="flex items-center gap-2 mb-3 text-[10px] font-black text-white/40 uppercase tracking-widest">
                          <span>{new Date(blog.createdAt).toLocaleDateString()}</span>
                          <span>•</span>
                          <span className="flex items-center gap-1 group-hover:text-primary transition-colors">
                            <Clock className="w-3 h-3" /> 5m Read
                          </span>
                        </div>

                        <h4 className="text-xl font-black leading-tight mb-4 group-hover:text-primary transition-colors line-clamp-2">
                          {blog.title}
                        </h4>

                        <p className="text-white/50 text-sm leading-relaxed line-clamp-3 mb-6 flex-1">
                          {blog.description || blog.content.replace(/<[^>]*>/g, "").slice(0, 120)}...
                        </p>

                        <div className="flex items-center justify-between pt-6 border-t border-white/10">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-full bg-white/10 border border-white/20 overflow-hidden">
                              <img src={blog.authorProfilePicture || "/placeholder.svg"} className="w-full h-full object-cover" />
                            </div>
                            <span className="text-[10px] font-bold text-white/60">{blog.authorName || "Teshkid is Crypto"}</span>
                          </div>
                          <div className="flex items-center gap-4 text-[10px] font-bold text-white/40">
                            <span className="flex items-center gap-1">
                              <Heart className="w-3 h-3 text-red-500/60" /> {blog.likeCount || 0}
                            </span>
                            <span className="flex items-center gap-1">
                              <Eye className="w-3 h-3 text-primary/60" /> {blog.viewCount || 0}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Modern Sidebar */}
              <div className="space-y-10">
                <div>
                  <h3 className="text-xl font-black uppercase tracking-tighter mb-6 flex items-center gap-2">
                    <Flame className="w-5 h-5 text-orange-500" />
                    Hot Streams
                  </h3>
                  <div className="space-y-4">
                    {popularBlogs.map((blog, idx) => (
                      <Link key={blog.id} to={`/blog/${blog.slug}`} className="group flex items-center gap-4 p-4 rounded-2xl bg-white/[0.02] hover:bg-white/[0.05] border border-white/20 transition-all">
                        <div className="text-3xl font-black text-white/10 group-hover:text-primary transition-colors italic tabular-nums">
                          0{idx + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <Badge variant="outline" className="text-[7px] h-4 mb-2 text-white/40 border-white/10 py-0">
                            {categoryLabels[blog.category]}
                          </Badge>
                          <h4 className="font-bold text-sm leading-tight text-white/80 group-hover:text-white truncate">
                            {blog.title}
                          </h4>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Pagination Implementation */}
            {totalPages > 1 && !searchTerm && !selectedCategory && (
              <div className="flex items-center justify-center gap-3 py-10">
                <Button
                  variant="outline"
                  size="icon"
                  className="w-12 h-12 rounded-2xl bg-white/5 border-white/20 hover:bg-white/10 disabled:opacity-20"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>

                <div className="flex gap-2">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                    <Button
                      key={p}
                      variant={currentPage === p ? "default" : "outline"}
                      onClick={() => setCurrentPage(p)}
                      className={`w-12 h-12 rounded-2xl text-xs font-black transition-all ${currentPage === p ? 'shadow-xl shadow-primary/20 scale-110' : 'bg-white/5 border-white/10 hover:bg-white/10 text-white/60'}`}
                    >
                      {p}
                    </Button>
                  ))}
                </div>

                <Button
                  variant="outline"
                  size="icon"
                  className="w-12 h-12 rounded-2xl bg-white/5 border-white/20 hover:bg-white/10 disabled:opacity-20"
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </div>
            )}
          </>
        )}
      </main>
      <Footer />
    </div>
  );
}

import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Mail, Lock, ArrowRight, Eye, EyeOff, Shield } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import api from "@/lib/api";
import { useAuth } from "@/context/AuthContext";

export default function AdminAuth() {
    const navigate = useNavigate();
    const [showPassword, setShowPassword] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    const [formData, setFormData] = useState({
        email: "",
        password: "",
    });

    const { login } = useAuth();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);

        try {
            const res = await api.post("/auth/login", {
                email: formData.email,
                password: formData.password,
            });
            const { token, user } = res.data;

            // Check if user is actually an admin
            if (user.role !== "ADMIN") {
                toast({
                    title: "Access Denied",
                    description: "This login page is for administrators only. Please use the student login page.",
                    variant: "destructive",
                });
                setIsLoading(false);
                return;
            }

            login(token, user);
            toast({
                title: `Welcome back, ${user.name}!`,
                description: "You have successfully signed in to the admin dashboard.",
            });
            navigate("/admin");
        } catch (error: any) {
            toast({
                title: "Authentication failed",
                description:
                    error.response?.data?.error ||
                    error.response?.data?.message ||
                    "Please check your credentials and try again.",
                variant: "destructive",
            });
        } finally {
            setIsLoading(false);
        }
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    return (
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
            {/* Background Pattern */}
            <div className="absolute inset-0 bg-hero-pattern opacity-50" />
            <div className="absolute inset-0 bg-gradient-to-br from-destructive/5 via-transparent to-primary/5" />

            <div className="relative w-full max-w-md">
                {/* Logo */}
                <Link to="/" className="flex items-center justify-center gap-2 mb-8">
                    <img
                        src="/logo.png"
                        alt="Teshkid Logo"
                        className="h-[155px] w-auto"
                    />
                </Link>

                <Card variant="glass" className="backdrop-blur-xl border-primary/20">
                    <CardHeader className="text-center pb-2">
                        <div className="flex items-center justify-center gap-2 mb-2">
                            <Shield className="w-8 h-8 text-primary" />
                        </div>
                        <CardTitle className="font-display text-2xl">
                            Admin Login
                        </CardTitle>
                        <CardDescription>
                            Access the administrative dashboard
                        </CardDescription>
                    </CardHeader>

                    <CardContent className="pt-6">
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="email">Admin Email</Label>
                                <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                                    <Input
                                        id="email"
                                        name="email"
                                        type="email"
                                        placeholder="admin@example.com"
                                        value={formData.email}
                                        onChange={handleInputChange}
                                        className="pl-10 bg-secondary border-border"
                                        required
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="password">Password</Label>
                                <p className="text-xs text-muted-foreground mb-2">
                                    Enter your admin password
                                </p>
                                <div className="relative">
                                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                                    <Input
                                        id="password"
                                        name="password"
                                        type={showPassword ? "text" : "password"}
                                        placeholder="Enter your password"
                                        value={formData.password}
                                        onChange={handleInputChange}
                                        className="pl-10 pr-10 bg-secondary border-border"
                                        required
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShowPassword(!showPassword)}
                                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                                    >
                                        {showPassword ? (
                                            <EyeOff className="w-4 h-4" />
                                        ) : (
                                            <Eye className="w-4 h-4" />
                                        )}
                                    </button>
                                </div>
                            </div>

                            <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-2">
                                    <Checkbox id="remember" />
                                    <label
                                        htmlFor="remember"
                                        className="text-sm text-muted-foreground cursor-pointer"
                                    >
                                        Remember me
                                    </label>
                                </div>
                                <Link
                                    to="/admin/forgot-password"
                                    className="text-sm text-primary hover:underline"
                                >
                                    Forgot password?
                                </Link>
                            </div>

                            <Button
                                type="submit"
                                variant="hero"
                                size="lg"
                                className="w-full"
                                disabled={isLoading}
                            >
                                {isLoading ? (
                                    <div className="w-5 h-5 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                                ) : (
                                    <>
                                        Sign In to Admin Dashboard
                                        <ArrowRight className="w-4 h-4 ml-2" />
                                    </>
                                )}
                            </Button>
                        </form>

                        <div className="mt-6 pt-4 border-t border-border">
                            <p className="text-center text-sm text-muted-foreground">
                                Not an administrator?{" "}
                                <Link
                                    to="/student/login"
                                    className="text-primary hover:underline font-medium"
                                >
                                    Student Login
                                </Link>
                            </p>
                        </div>

                        <div className="mt-4 p-3 bg-primary/5 border border-primary/20 rounded-lg">
                            <p className="text-xs text-muted-foreground text-center">
                                <Shield className="w-3 h-3 inline mr-1" />
                                This is a secure admin area. All login attempts are monitored.
                            </p>
                        </div>
                    </CardContent>
                </Card>

                <p className="text-center text-xs text-muted-foreground mt-6">
                    By continuing, you agree to Teshkid's Terms of Service
                    <br />
                    and acknowledge our Privacy Policy.
                </p>
            </div>
        </div>
    );
}

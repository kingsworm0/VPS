import { useEffect, useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import api from "@/lib/api";
import { toast } from "@/components/ui/use-toast";
import { useNavigate } from "react-router-dom";
import { Upload, FileText, Trash2, Plus } from "lucide-react";
import { ConfirmDialog } from "@/components/ui/ConfirmDialog";

export default function AdminContent() {
  const [content, setContent] = useState<any[]>([]);
  const [courses, setCourses] = useState<any[]>([]);
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [showAnnouncementForm, setShowAnnouncementForm] = useState(false);
  const [confirmState, setConfirmState] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    onConfirm: () => void;
    variant?: "default" | "destructive";
  }>({
    isOpen: false,
    title: "",
    description: "",
    onConfirm: () => { },
  });
  const navigate = useNavigate();

  const [uploadForm, setUploadForm] = useState({
    courseId: "",
    title: "",
    description: "",
    fileUrl: "",
    fileType: "document",
    isPremiumOnly: false,
  });

  const [announcementForm, setAnnouncementForm] = useState({
    title: "",
    content: "",
    type: "info",
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const [contentRes, coursesRes, announcementsRes] = await Promise.all([
        api.get("/admin/content"),
        api.get("/admin/courses"),
        api.get("/announcements"),
      ]);
      setContent(contentRes.data);
      setCourses(coursesRes.data);
      setAnnouncements(announcementsRes.data);
    } catch (err) {
      console.error(err);
      toast({ title: "Error", description: "Could not load data." });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleUpload = async () => {
    if (!uploadForm.title || !uploadForm.fileUrl) {
      toast({
        title: "Error",
        description: "Title and file URL are required.",
      });
      return;
    }
    try {
      await api.post("/admin/content", uploadForm);
      toast({
        title: "Success",
        description: "Content uploaded successfully.",
      });
      setUploadForm({
        courseId: "",
        title: "",
        description: "",
        fileUrl: "",
        fileType: "document",
        isPremiumOnly: false,
      });
      setShowUploadForm(false);
      fetchData();
    } catch (err) {
      console.error(err);
      toast({ title: "Error", description: "Could not upload content." });
    }
  };

  const handleDeleteContent = async (id: string) => {
    setConfirmState({
      isOpen: true,
      title: "Delete Content",
      description: "Are you sure you want to delete this content? This action cannot be undone.",
      variant: "destructive",
      onConfirm: async () => {
        try {
          await api.delete(`/admin/content/${id}`);
          toast({ title: "Success", description: "Content deleted." });
          fetchData();
        } catch (err) {
          console.error(err);
          toast({ title: "Error", description: "Could not delete content." });
        }
      },
    });
  };

  const handleCreateAnnouncement = async () => {
    if (!announcementForm.title || !announcementForm.content) {
      toast({ title: "Error", description: "Title and content are required." });
      return;
    }
    try {
      await api.post("/admin/announcements", announcementForm);
      toast({
        title: "Success",
        description: "Announcement created successfully.",
      });
      setAnnouncementForm({ title: "", content: "", type: "info" });
      setShowAnnouncementForm(false);
      fetchData();
    } catch (err) {
      console.error(err);
      toast({ title: "Error", description: "Could not create announcement." });
    }
  };

  const handleDeleteAnnouncement = async (id: string) => {
    setConfirmState({
      isOpen: true,
      title: "Delete Announcement",
      description: "Are you sure you want to delete this announcement? It will be removed from the homepage.",
      variant: "destructive",
      onConfirm: async () => {
        try {
          await api.delete(`/admin/announcements/${id}`);
          toast({ title: "Success", description: "Announcement deleted." });
          fetchData();
        } catch (err) {
          console.error(err);
          toast({ title: "Error", description: "Could not delete announcement." });
        }
      },
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-32 sm:pt-40 pb-20 container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <h1 className="font-display text-3xl font-bold">
            Content Management
          </h1>
          <Button variant="outline" onClick={() => navigate("/admin")}>
            Back
          </Button>
        </div>

        {/* Announcements Section */}
        <Card className="mb-6">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Homepage Announcements</CardTitle>
            <Button
              onClick={() => setShowAnnouncementForm(!showAnnouncementForm)}
              size="sm"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Announcement
            </Button>
          </CardHeader>
          <CardContent>
            {showAnnouncementForm && (
              <div className="mb-4 p-4 border rounded-lg space-y-3">
                <Input
                  placeholder="Announcement Title"
                  value={announcementForm.title}
                  onChange={(e) =>
                    setAnnouncementForm({
                      ...announcementForm,
                      title: e.target.value,
                    })
                  }
                />
                <Textarea
                  placeholder="Announcement Content"
                  value={announcementForm.content}
                  onChange={(e) =>
                    setAnnouncementForm({
                      ...announcementForm,
                      content: e.target.value,
                    })
                  }
                  rows={3}
                />
                <Select
                  value={announcementForm.type}
                  onValueChange={(value) =>
                    setAnnouncementForm({ ...announcementForm, type: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="info">Info</SelectItem>
                    <SelectItem value="warning">Warning</SelectItem>
                    <SelectItem value="success">Success</SelectItem>
                  </SelectContent>
                </Select>
                <div className="flex gap-2">
                  <Button onClick={handleCreateAnnouncement} className="flex-1">
                    Create
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setShowAnnouncementForm(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
            <div className="space-y-2">
              {announcements.map((ann) => (
                <div
                  key={ann.id}
                  className="flex items-start justify-between p-3 border rounded-lg"
                >
                  <div className="flex-1">
                    <p className="font-medium">{ann.title}</p>
                    <p className="text-sm text-muted-foreground">
                      {ann.content}
                    </p>
                    <span
                      className={`text-xs px-2 py-1 rounded mt-2 inline-block ${ann.type === "info"
                        ? "bg-blue-100 text-blue-800"
                        : ann.type === "warning"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-green-100 text-green-800"
                        }`}
                    >
                      {ann.type}
                    </span>
                  </div>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDeleteAnnouncement(ann.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Course Content Section */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Course Content Library
            </CardTitle>
            <Button
              onClick={() => setShowUploadForm(!showUploadForm)}
              size="sm"
            >
              <Upload className="w-4 h-4 mr-2" />
              Upload Content
            </Button>
          </CardHeader>
          <CardContent>
            {showUploadForm && (
              <div className="mb-4 p-4 border rounded-lg space-y-3">
                <Input
                  placeholder="Content Title"
                  value={uploadForm.title}
                  onChange={(e) =>
                    setUploadForm({ ...uploadForm, title: e.target.value })
                  }
                />
                <Textarea
                  placeholder="Description (optional)"
                  value={uploadForm.description}
                  onChange={(e) =>
                    setUploadForm({
                      ...uploadForm,
                      description: e.target.value,
                    })
                  }
                  rows={2}
                />
                <div className="flex gap-2">
                  <Input
                    placeholder="File URL"
                    value={uploadForm.fileUrl}
                    onChange={(e) =>
                      setUploadForm({ ...uploadForm, fileUrl: e.target.value })
                    }
                  />
                  <input
                    type="file"
                    id="file"
                    className="hidden"
                    onChange={async (e) => {
                      const f = (e.target as HTMLInputElement).files?.[0];
                      if (!f) return;
                      const fd = new FormData();
                      fd.append("file", f);
                      try {
                        const res = await api.post(
                          "/admin/content/upload",
                          fd,
                          {
                            headers: { "Content-Type": "multipart/form-data" },
                          },
                        );
                        setUploadForm({
                          ...uploadForm,
                          fileUrl: res.data.fileUrl,
                        });
                        toast({
                          title: "Uploaded",
                          description: "File uploaded and URL populated.",
                        });
                      } catch (err) {
                        console.error(err);
                        toast({
                          title: "Error",
                          description: "File upload failed.",
                        });
                      }
                    }}
                  />
                  <Button
                    onClick={() => document.getElementById("file")?.click()}
                    variant="outline"
                  >
                    Choose File
                  </Button>
                </div>
                <Select
                  value={uploadForm.courseId}
                  onValueChange={(value) =>
                    setUploadForm({ ...uploadForm, courseId: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Course (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">None (General Content)</SelectItem>
                    {courses.map((course) => (
                      <SelectItem key={course.id} value={course.id}>
                        {course.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select
                  value={uploadForm.fileType}
                  onValueChange={(value) =>
                    setUploadForm({ ...uploadForm, fileType: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="document">Document</SelectItem>
                    <SelectItem value="pdf">PDF</SelectItem>
                    <SelectItem value="video">Video</SelectItem>
                    <SelectItem value="image">Image</SelectItem>
                  </SelectContent>
                </Select>
                <div className="flex items-center space-x-2 py-2">
                  <Checkbox
                    id="premium"
                    checked={uploadForm.isPremiumOnly}
                    onCheckedChange={(checked) =>
                      setUploadForm({
                        ...uploadForm,
                        isPremiumOnly: checked as boolean,
                      })
                    }
                  />
                  <Label htmlFor="premium">
                    Premium Only (Visible to Premium Users)
                  </Label>
                </div>
                <div className="flex gap-2">
                  <Button onClick={handleUpload} className="flex-1">
                    Upload
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setShowUploadForm(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
            {loading ? (
              <div>Loading...</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="text-xs text-muted-foreground border-b">
                      <th className="pb-2">Title</th>
                      <th className="pb-2">Course</th>
                      <th className="pb-2">Type</th>
                      <th className="pb-2">Premium</th>
                      <th className="pb-2">URL</th>
                      <th className="pb-2">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {content.map((item) => (
                      <tr key={item.id} className="border-b">
                        <td className="py-3">{item.title}</td>
                        <td className="py-3 text-sm text-muted-foreground">
                          {item.course?.title || "General"}
                        </td>
                        <td className="py-3 text-sm">{item.fileType}</td>
                        <td className="py-3 text-sm">
                          {item.isPremiumOnly ? (
                            <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded">
                              Premium
                            </span>
                          ) : (
                            <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">
                              Free
                            </span>
                          )}
                        </td>
                        <td className="py-3 text-sm">
                          <a
                            href={item.fileUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-primary hover:underline"
                          >
                            View
                          </a>
                        </td>
                        <td className="py-3">
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDeleteContent(item.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
      <Footer />
      <ConfirmDialog
        isOpen={confirmState.isOpen}
        onOpenChange={(open) => setConfirmState(prev => ({ ...prev, isOpen: open }))}
        title={confirmState.title}
        description={confirmState.description}
        onConfirm={confirmState.onConfirm}
        variant={confirmState.variant}
      />
    </div>
  );
}

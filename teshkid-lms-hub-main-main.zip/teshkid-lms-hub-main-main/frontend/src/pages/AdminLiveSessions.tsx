import { useState, useEffect, useRef } from "react";
import api from "@/lib/api";
import { toast } from "sonner";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { cn } from "@/lib/utils";
import { ConfirmDialog } from "@/components/ui/ConfirmDialog";
import { format } from "date-fns";
import {
  Video, Plus, Trash2, Edit2, Radio, Clock, Calendar,
  Users, CheckCircle, X, Link2, Image as ImageIcon,
  Loader2, RefreshCw, MonitorPlay, PlayCircle,
  Mic, MicOff, Eye, Youtube, ExternalLink,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────
interface LiveSession {
  id: string;
  title: string;
  description: string;
  hostName: string;
  meetingLink: string;
  streamUrl: string;
  recordingUrl: string;
  scheduledAt: string;
  durationMinutes: number;
  status: "UPCOMING" | "LIVE" | "ENDED";
  bannerUrl?: string;
  courseName?: string;
  rsvpCount: number;
  maxAttendees?: number;
}

const BLANK: Omit<LiveSession, "id" | "rsvpCount"> = {
  title: "", description: "", hostName: "", meetingLink: "",
  streamUrl: "", recordingUrl: "", scheduledAt: "",
  durationMinutes: 60, status: "UPCOMING", bannerUrl: "",
  maxAttendees: undefined,
};

// ─── Status meta ──────────────────────────────────────────────────────────────
const STATUS_META = {
  LIVE:     { label: "Live Now",     badge: "bg-red-500/15 text-red-400 border-red-500/30",         dot: "bg-red-500 animate-pulse" },
  UPCOMING: { label: "Upcoming",     badge: "bg-blue-500/15 text-blue-400 border-blue-500/30",      dot: "bg-blue-400" },
  ENDED:    { label: "Ended",        badge: "bg-muted text-muted-foreground border-border/60",      dot: "bg-muted-foreground" },
};

// ─── Helper: extract YouTube embed ID from any YT URL ─────────────────────────
function extractYouTubeId(url: string): string | null {
  if (!url) return null;
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/live\/)([A-Za-z0-9_-]{11})/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return null;
}

export default function AdminLiveSessions() {
  const [sessions, setSessions]     = useState<LiveSession[]>([]);
  const [loading, setLoading]       = useState(true);
  const [showForm, setShowForm]     = useState(false);
  const [editId, setEditId]         = useState<string | null>(null);
  const [form, setForm]             = useState<typeof BLANK>({ ...BLANK });
  const [saving, setSaving]         = useState(false);
  const [uploading, setUploading]   = useState(false);
  const [activeTab, setActiveTab]   = useState<"UPCOMING" | "LIVE" | "ENDED">("LIVE");
  const [confirm, setConfirm]       = useState<{
    isOpen: boolean; title: string; description: string;
    onConfirm: () => void; variant?: "default" | "destructive";
  }>({ isOpen: false, title: "", description: "", onConfirm: () => {} });
  const bannerRef = useRef<HTMLInputElement>(null);

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    try {
      const res = await api.get("/admin/live-sessions");
      setSessions(res.data || []);
      // Auto-switch to LIVE tab if any session is live
      if ((res.data || []).some((s: LiveSession) => s.status === "LIVE")) {
        setActiveTab("LIVE");
      }
    } catch { toast.error("Failed to load sessions"); }
    finally { setLoading(false); }
  };

  const openCreate = (status: "UPCOMING" | "LIVE" = "UPCOMING") => {
    setEditId(null);
    setForm({ ...BLANK, status });
    setShowForm(true);
  };

  const openEdit = (s: LiveSession) => {
    setEditId(s.id);
    setForm({
      title: s.title, description: s.description || "",
      hostName: s.hostName || "", meetingLink: s.meetingLink || "",
      streamUrl: s.streamUrl || "", recordingUrl: s.recordingUrl || "",
      scheduledAt: s.scheduledAt?.slice(0, 16) || "",
      durationMinutes: s.durationMinutes || 60,
      status: s.status, bannerUrl: s.bannerUrl || "",
      maxAttendees: s.maxAttendees,
    });
    setShowForm(true);
  };

  const handleBannerUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fd = new FormData();
    fd.append("file", file);
    setUploading(true);
    try {
      const res = await api.post("/admin/content/upload", fd);
      setForm(f => ({ ...f, bannerUrl: res.data.fileUrl }));
      toast.success("Banner uploaded");
    } catch { toast.error("Upload failed"); }
    finally { setUploading(false); }
  };

  const handleSave = async () => {
    if (!form.title.trim() || !form.scheduledAt) {
      toast.error("Title and scheduled date/time are required");
      return;
    }
    setSaving(true);
    try {
      if (editId) {
        await api.put(`/admin/live-sessions/${editId}`, form);
        toast.success("Session updated");
      } else {
        await api.post("/admin/live-sessions", form);
        toast.success("Session created");
      }
      setShowForm(false);
      load();
    } catch { toast.error("Failed to save session"); }
    finally { setSaving(false); }
  };

  const confirmDelete = (id: string, title: string) => {
    setConfirm({
      isOpen: true, title: "Delete Session", variant: "destructive",
      description: `Permanently delete "${title}"? This cannot be undone.`,
      onConfirm: async () => {
        try {
          await api.delete(`/admin/live-sessions/${id}`);
          toast.success("Session deleted");
          load();
        } catch { toast.error("Failed to delete"); }
      },
    });
  };

  const setStatus = async (id: string, status: string) => {
    try {
      await api.put(`/admin/live-sessions/${id}`, { status });
      const msg = status === "LIVE" ? "🔴 Session is now LIVE!" : status === "ENDED" ? "Session ended" : "Status updated";
      toast.success(msg);
      load();
      if (status === "LIVE") setActiveTab("LIVE");
    } catch { toast.error("Failed to update status"); }
  };

  const upcoming = sessions.filter(s => s.status === "UPCOMING");
  const live     = sessions.filter(s => s.status === "LIVE");
  const ended    = sessions.filter(s => s.status === "ENDED");
  const displayed = { UPCOMING: upcoming, LIVE: live, ENDED: ended }[activeTab];


  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      <main className="pt-24 pb-16 flex-1 max-w-6xl mx-auto px-4 w-full space-y-6">

        {/* ── Page header ───────────────────────────────────────────────────── */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-black font-sans text-foreground flex items-center gap-2">
              <Radio className="w-6 h-6 text-primary" /> Live Sessions
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              Schedule, stream, and manage live classes for enrolled students
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={load} className="w-9 h-9 rounded-xl border border-border/50 bg-card flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted transition-all">
              <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
            </button>
            <button
              onClick={() => openCreate("UPCOMING")}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-bold hover:bg-primary/90 transition-all shadow-lg shadow-primary/20"
            >
              <Plus className="w-4 h-4" /> Schedule Session
            </button>
            <button
              onClick={() => openCreate("LIVE")}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-500 text-white text-sm font-bold hover:bg-red-600 transition-all shadow-lg shadow-red-500/20"
            >
              <Radio className="w-4 h-4" /> Go Live Now
            </button>
          </div>
        </div>

        {/* ── Stat cards ────────────────────────────────────────────────────── */}
        <div className="grid grid-cols-3 gap-4">
          {[
            { key: "UPCOMING" as const, label: "Upcoming",     value: upcoming.length, icon: Clock,        color: "text-blue-400", bg: "bg-blue-500/10 border-blue-500/20" },
            { key: "LIVE"     as const, label: "Live Now",     value: live.length,     icon: Radio,        color: "text-red-400",  bg: "bg-red-500/10 border-red-500/20"  },
            { key: "ENDED"    as const, label: "Past",         value: ended.length,    icon: CheckCircle,  color: "text-muted-foreground", bg: "bg-muted border-border/60"   },
          ].map(s => (
            <button key={s.key} onClick={() => setActiveTab(s.key)}
              className={cn("rounded-2xl border p-4 text-left transition-all hover:shadow-md", s.bg, activeTab === s.key && "ring-2 ring-primary/40")}>
              <div className="flex items-center gap-2 mb-1">
                <s.icon className={cn("w-4 h-4", s.color)} />
                <span className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">{s.label}</span>
              </div>
              <p className="text-3xl font-black text-foreground">{s.value}</p>
              {s.key === "LIVE" && s.value > 0 && (
                <p className="text-[10px] text-red-400 font-bold mt-1 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse inline-block" /> Broadcasting now
                </p>
              )}
            </button>
          ))}
        </div>

        {/* ── Tabs ──────────────────────────────────────────────────────────── */}
        <div className="flex gap-1 p-1 bg-muted/50 rounded-xl border border-border/40 w-fit">
          {(["UPCOMING","LIVE","ENDED"] as const).map(t => (
            <button key={t} onClick={() => setActiveTab(t)}
              className={cn("px-5 py-2 rounded-lg text-sm font-semibold transition-all flex items-center gap-2",
                activeTab === t ? "bg-card text-foreground shadow-sm border border-border/60" : "text-muted-foreground hover:text-foreground"
              )}>
              {t === "LIVE" && <span className={cn("w-2 h-2 rounded-full", live.length > 0 ? "bg-red-500 animate-pulse" : "bg-muted-foreground")} />}
              {t === "UPCOMING" ? "Upcoming" : t === "LIVE" ? "Live Now" : "Past Sessions"}
              {(t === "UPCOMING" ? upcoming : t === "LIVE" ? live : ended).length > 0 && (
                <span className="text-[10px] font-black bg-background border border-border/40 rounded-full px-1.5 py-0.5">
                  {(t === "UPCOMING" ? upcoming : t === "LIVE" ? live : ended).length}
                </span>
              )}
            </button>
          ))}
        </div>


        {/* ── Session list ──────────────────────────────────────────────────── */}
        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : displayed.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border/60 p-16 text-center">
            <Video className="w-12 h-12 text-muted-foreground/20 mx-auto mb-4" />
            <p className="text-muted-foreground text-sm">
              {activeTab === "LIVE" ? "No session is live right now."
               : activeTab === "UPCOMING" ? "No sessions scheduled yet."
               : "No past sessions."}
            </p>
            {activeTab !== "ENDED" && (
              <button onClick={() => openCreate(activeTab)} className="mt-3 text-primary text-sm font-bold hover:underline">
                + {activeTab === "LIVE" ? "Start a live session" : "Schedule a session"}
              </button>
            )}
          </div>
        ) : (
          <div className="grid gap-4">
            {displayed.map(session => {
              const meta   = STATUS_META[session.status];
              const ytId   = extractYouTubeId(session.streamUrl || "");
              const isLive = session.status === "LIVE";
              const { date, time } = {
                date: format(new Date(session.scheduledAt), "EEE, MMM d, yyyy"),
                time: format(new Date(session.scheduledAt), "h:mm a"),
              };

              return (
                <div key={session.id} className={cn(
                  "rounded-2xl border bg-card/60 backdrop-blur-sm overflow-hidden shadow-md hover:shadow-lg transition-all",
                  isLive ? "border-red-500/40 shadow-red-500/10" : "border-border/60"
                )}>
                  {/* Live red stripe */}
                  {isLive && (
                    <div className="bg-red-500/10 border-b border-red-500/20 px-5 py-2 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                        <span className="text-xs font-black text-red-400 uppercase tracking-widest">Broadcasting Live</span>
                      </div>
                      <span className="text-[10px] text-red-400 font-bold">{session.rsvpCount} watching</span>
                    </div>
                  )}

                  {/* Embedded stream preview (admin sees it too) */}
                  {isLive && ytId && (
                    <div className="w-full aspect-video bg-black">
                      <iframe
                        className="w-full h-full"
                        src={`https://www.youtube.com/embed/${ytId}?autoplay=1&mute=1&rel=0&modestbranding=1`}
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        title={session.title}
                      />
                    </div>
                  )}

                  {/* Banner (non-live) */}
                  {!isLive && session.bannerUrl && (
                    <div className="w-full h-40 overflow-hidden border-b border-border/40">
                      <img src={session.bannerUrl} alt={session.title} className="w-full h-full object-cover" />
                    </div>
                  )}

                  <div className="p-5 md:p-6">
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-2">
                          <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold border", meta.badge)}>
                            <span className={cn("w-1.5 h-1.5 rounded-full", meta.dot)} />
                            {meta.label}
                          </span>
                          {session.courseName && (
                            <span className="text-[10px] bg-muted text-muted-foreground px-2 py-0.5 rounded-full border border-border/40">
                              {session.courseName}
                            </span>
                          )}
                          {session.rsvpCount > 0 && (
                            <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                              <Users className="w-3 h-3" /> {session.rsvpCount} RSVPs
                            </span>
                          )}
                        </div>

                        <h3 className="text-base font-bold text-foreground mb-1">{session.title}</h3>
                        {session.description && (
                          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{session.description}</p>
                        )}

                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-muted-foreground">
                          {session.hostName && (
                            <span className="flex items-center gap-1.5"><Mic className="w-3.5 h-3.5" />{session.hostName}</span>
                          )}
                          <span className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" />{date}</span>
                          <span className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" />{time} · {session.durationMinutes} min</span>
                          {session.streamUrl && (
                            <span className="flex items-center gap-1 text-primary font-medium">
                              <Youtube className="w-3.5 h-3.5" /> Stream linked
                            </span>
                          )}
                          {session.recordingUrl && (
                            <span className="flex items-center gap-1 text-green-400 font-medium">
                              <PlayCircle className="w-3.5 h-3.5" /> Recording saved
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2 shrink-0 flex-wrap">
                        {session.status === "UPCOMING" && (
                          <button onClick={() => setStatus(session.id, "LIVE")}
                            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-500 text-white text-sm font-bold hover:bg-red-600 transition-all shadow-md shadow-red-500/20">
                            <Radio className="w-3.5 h-3.5" /> Go Live
                          </button>
                        )}
                        {session.status === "LIVE" && (
                          <button onClick={() => setStatus(session.id, "ENDED")}
                            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-muted text-muted-foreground border border-border text-sm font-bold hover:bg-border transition-all">
                            <MicOff className="w-3.5 h-3.5" /> End Session
                          </button>
                        )}
                        {session.status === "ENDED" && (
                          <button onClick={() => setStatus(session.id, "UPCOMING")}
                            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/30 text-sm font-bold hover:bg-blue-500/20 transition-all">
                            <Clock className="w-3.5 h-3.5" /> Reschedule
                          </button>
                        )}
                        <button onClick={() => openEdit(session)}
                          className="w-9 h-9 rounded-xl bg-muted/50 border border-border/40 text-muted-foreground hover:bg-primary/10 hover:text-primary transition-all flex items-center justify-center">
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button onClick={() => confirmDelete(session.id, session.title)}
                          className="w-9 h-9 rounded-xl bg-muted/50 border border-border/40 text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-all flex items-center justify-center">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      <Footer />


      {/* ── Create / Edit Modal ───────────────────────────────────────────── */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-2xl rounded-2xl border border-border bg-card shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">

            {/* Modal header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-border/60 shrink-0">
              <div>
                <h2 className="text-lg font-black font-sans text-foreground">
                  {editId ? "Edit Session" : "New Live Session"}
                </h2>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {editId ? "Update the session details below" : "Schedule or start a live class for your students"}
                </p>
              </div>
              <button onClick={() => setShowForm(false)} className="p-2 rounded-lg hover:bg-muted transition-colors">
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>

            {/* Scrollable body */}
            <div className="overflow-y-auto flex-1 px-6 py-5 space-y-5">

              {/* Session type toggle (new only) */}
              {!editId && (
                <div className="grid grid-cols-2 gap-2">
                  {(["UPCOMING","LIVE"] as const).map(s => (
                    <button key={s} onClick={() => setForm(f => ({ ...f, status: s }))}
                      className={cn("flex items-center justify-center gap-2 py-2.5 rounded-xl border text-sm font-bold transition-all",
                        form.status === s
                          ? s === "LIVE" ? "bg-red-500 text-white border-red-500 shadow-lg shadow-red-500/20"
                                         : "bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/20"
                          : "bg-muted/40 text-muted-foreground border-border/50 hover:border-primary/40"
                      )}>
                      {s === "LIVE" ? <><Radio className="w-3.5 h-3.5" /> Start Live Now</>
                                   : <><Calendar className="w-3.5 h-3.5" /> Schedule for Later</>}
                    </button>
                  ))}
                </div>
              )}

              {/* Title */}
              <div>
                <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest block mb-1.5">Session Title *</label>
                <input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                  placeholder="e.g. Bitcoin Trading Fundamentals — Week 3"
                  className="w-full bg-muted/50 border border-border/50 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30" />
              </div>

              {/* Description */}
              <div>
                <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest block mb-1.5">Description</label>
                <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  rows={3} placeholder="What will students learn in this session?"
                  className="w-full bg-muted/50 border border-border/50 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none" />
              </div>

              {/* Host + Duration */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest block mb-1.5">Host / Instructor</label>
                  <input value={form.hostName} onChange={e => setForm(f => ({ ...f, hostName: e.target.value }))}
                    placeholder="Instructor name"
                    className="w-full bg-muted/50 border border-border/50 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30" />
                </div>
                <div>
                  <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest block mb-1.5">Duration (minutes)</label>
                  <input type="number" min={15} max={480} value={form.durationMinutes}
                    onChange={e => setForm(f => ({ ...f, durationMinutes: parseInt(e.target.value) || 60 }))}
                    className="w-full bg-muted/50 border border-border/50 rounded-xl px-4 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30" />
                </div>
              </div>

              {/* Date + Max attendees */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest block mb-1.5">Date & Time *</label>
                  <input type="datetime-local" value={form.scheduledAt}
                    onChange={e => setForm(f => ({ ...f, scheduledAt: e.target.value }))}
                    className="w-full bg-muted/50 border border-border/50 rounded-xl px-4 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30" />
                </div>
                <div>
                  <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest block mb-1.5">Max Attendees (optional)</label>
                  <input type="number" min={1} value={form.maxAttendees || ""}
                    onChange={e => setForm(f => ({ ...f, maxAttendees: e.target.value ? parseInt(e.target.value) : undefined }))}
                    placeholder="Unlimited"
                    className="w-full bg-muted/50 border border-border/50 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30" />
                </div>
              </div>

              {/* Stream URL */}
              <div>
                <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest block mb-1.5 flex items-center gap-1.5">
                  <Youtube className="w-3.5 h-3.5 text-red-400" /> YouTube Live / Stream URL
                </label>
                <input value={form.streamUrl} onChange={e => setForm(f => ({ ...f, streamUrl: e.target.value }))}
                  placeholder="https://youtube.com/live/xxxx  or  https://youtu.be/xxxx"
                  className="w-full bg-muted/50 border border-border/50 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30" />
                <p className="text-[10px] text-muted-foreground/60 mt-1.5">
                  Paste a YouTube Live URL. Students will watch it embedded inside the platform.
                </p>
                {/* Inline preview */}
                {extractYouTubeId(form.streamUrl) && (
                  <div className="mt-2 rounded-xl overflow-hidden border border-border/50 aspect-video">
                    <iframe className="w-full h-full"
                      src={`https://www.youtube.com/embed/${extractYouTubeId(form.streamUrl)}?rel=0&modestbranding=1`}
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen title="preview" />
                  </div>
                )}
              </div>

              {/* Recording URL */}
              <div>
                <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest block mb-1.5 flex items-center gap-1.5">
                  <PlayCircle className="w-3.5 h-3.5 text-green-400" /> Recording URL (after session ends)
                </label>
                <input value={form.recordingUrl} onChange={e => setForm(f => ({ ...f, recordingUrl: e.target.value }))}
                  placeholder="https://youtube.com/watch?v=xxxx  (paste after the session)"
                  className="w-full bg-muted/50 border border-border/50 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30" />
              </div>

              {/* Meeting link */}
              <div>
                <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest block mb-1.5 flex items-center gap-1.5">
                  <Link2 className="w-3.5 h-3.5" /> External Meeting Link (Zoom / Google Meet)
                </label>
                <input value={form.meetingLink} onChange={e => setForm(f => ({ ...f, meetingLink: e.target.value }))}
                  placeholder="https://zoom.us/j/... (optional backup)"
                  className="w-full bg-muted/50 border border-border/50 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30" />
              </div>

              {/* Banner upload */}
              <div>
                <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest block mb-1.5 flex items-center gap-1.5">
                  <ImageIcon className="w-3.5 h-3.5" /> Banner Image
                </label>
                <div className="flex gap-3 items-start">
                  {form.bannerUrl ? (
                    <div className="relative w-32 h-20 rounded-xl overflow-hidden border border-border/50 shrink-0">
                      <img src={form.bannerUrl} alt="banner" className="w-full h-full object-cover" />
                      <button onClick={() => setForm(f => ({ ...f, bannerUrl: "" }))}
                        className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-destructive transition-colors">
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ) : null}
                  <button onClick={() => bannerRef.current?.click()}
                    disabled={uploading}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl border border-dashed border-border/60 bg-muted/30 text-muted-foreground text-sm hover:border-primary/40 hover:text-primary transition-all">
                    {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4" />}
                    {uploading ? "Uploading..." : form.bannerUrl ? "Replace banner" : "Upload banner"}
                  </button>
                  <input ref={bannerRef} type="file" accept="image/*" className="hidden" onChange={handleBannerUpload} />
                </div>
              </div>

              {/* Status (edit only) */}
              {editId && (
                <div>
                  <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest block mb-1.5">Status</label>
                  <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value as any }))}
                    className="w-full bg-muted/50 border border-border/50 rounded-xl px-4 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30">
                    <option value="UPCOMING">Upcoming</option>
                    <option value="LIVE">Live Now</option>
                    <option value="ENDED">Ended</option>
                  </select>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t border-border/60 flex justify-end gap-3 shrink-0 bg-muted/20">
              <button onClick={() => setShowForm(false)}
                className="px-5 py-2.5 rounded-xl border border-border/50 text-sm font-bold text-muted-foreground hover:bg-muted transition-all">
                Cancel
              </button>
              <button onClick={handleSave} disabled={saving}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-bold hover:bg-primary/90 transition-all shadow-lg shadow-primary/20 disabled:opacity-60">
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                {saving ? "Saving..." : editId ? "Save Changes" : "Create Session"}
              </button>
            </div>
          </div>
        </div>
      )}

      <ConfirmDialog
        isOpen={confirm.isOpen}
        onOpenChange={open => setConfirm(p => ({ ...p, isOpen: open }))}
        title={confirm.title}
        description={confirm.description}
        onConfirm={confirm.onConfirm}
        variant={confirm.variant}
      />
    </div>
  );
}

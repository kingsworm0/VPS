import { useEffect, useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import api from "@/lib/api";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { ConfirmDialog } from "@/components/ui/ConfirmDialog";
import {
  Plus,
  Users,
  Video,
  Edit,
  Trash2,
  Eye,
  Search,
  BookOpen,
  DollarSign,
  ChevronRight,
  Loader2
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export default function AdminCourses() {
  const [courses, setCourses] = useState<any[]>([]);
  const [filteredCourses, setFilteredCourses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [confirmState, setConfirmState] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    onConfirm: () => void;
    variant?: "default" | "destructive";
  }>({
    isOpen: false,
    title: "",
    description: "",
    onConfirm: () => { },
  });
  const navigate = useNavigate();

  const fetch = async () => {
    setLoading(true);
    try {
      const res = await api.get("/admin/courses");
      setCourses(res.data);
      setFilteredCourses(res.data);
    } catch (err) {
      console.error(err);
      toast.error("Could not fetch courses.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetch();
  }, []);

  useEffect(() => {
    const query = searchQuery.toLowerCase();
    const filtered = courses.filter(c =>
      c.title.toLowerCase().includes(query) ||
      c.instructor.toLowerCase().includes(query)
    );
    setFilteredCourses(filtered);
  }, [searchQuery, courses]);

  const handleDelete = async (id: string) => {
    setConfirmState({
      isOpen: true,
      title: "Delete Course",
      description: "Are you sure you want to delete this course? This will remove all modules and lessons associated with it. This action cannot be undone.",
      variant: "destructive",
      onConfirm: async () => {
        try {
          await api.delete(`/admin/courses/${id}`);
          toast.success("Course deleted successfully.");
          fetch();
        } catch (err) {
          console.error(err);
          toast.error("Could not delete course.");
        }
      },
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-32 sm:pt-40 pb-20 container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-10">
          <div>
            <h1 className="text-4xl font-black gradient-text">Academy Laboratory</h1>
            <p className="text-muted-foreground mt-1 font-medium">Manage your educational curriculum and training assets.</p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              onClick={() => navigate("/admin/courses/new")}
              className="gap-2 shadow-lg shadow-primary/20 h-11 px-6 rounded-xl"
            >
              <Plus className="w-5 h-5" />
              Create New Course
            </Button>
            <Button variant="outline" onClick={() => navigate("/admin")} className="h-11 rounded-xl">
              Back
            </Button>
          </div>
        </div>

        <div className="flex items-center gap-3 max-w-md bg-card/50 backdrop-blur-sm border rounded-xl px-4 py-1 mb-8">
          <Search className="w-5 h-5 text-muted-foreground" />
          <Input
            className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 px-0 h-11 text-base"
            placeholder="Search courses or instructors..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <Loader2 className="w-10 h-10 animate-spin text-primary" />
            <p className="text-muted-foreground font-bold animate-pulse">Syncing Academy Data...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredCourses.length === 0 ? (
              <div className="col-span-full text-center py-20 border-2 border-dashed rounded-3xl bg-muted/10">
                <p className="text-muted-foreground text-lg">No courses found matching your criteria.</p>
              </div>
            ) : (
              filteredCourses.map((c) => (
                <Card key={c.id} className="group flex flex-col overflow-hidden bg-card/50 backdrop-blur-sm border-border/50 hover:border-primary/50 transition-all hover:shadow-2xl hover:shadow-primary/5 rounded-2xl">
                  <div className="aspect-video w-full bg-muted relative overflow-hidden">
                    {c.thumbnail ? (
                      <img
                        src={c.thumbnail}
                        alt={c.title}
                        className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500"
                      />
                    ) : (
                      <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
                        <BookOpen className="w-12 h-12 opacity-20" />
                      </div>
                    )}
                    <div className="absolute top-4 left-4">
                      <Badge className="bg-black/80 backdrop-blur-md text-white border-none px-3 py-1 font-black text-sm">
                        <DollarSign className="w-3.5 h-3.5 mr-0.5 text-primary" />
                        {c.price > 0 ? Number(c.price).toFixed(2) : "FREE"}
                      </Badge>
                    </div>
                  </div>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start gap-2">
                      <CardTitle className="line-clamp-2 text-xl font-bold leading-tight group-hover:text-primary transition-colors">
                        {c.title}
                      </CardTitle>
                    </div>
                    <div className="text-sm font-medium text-muted-foreground flex items-center gap-2 mt-1">
                      <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center text-[10px] text-primary">
                        {c.instructor.charAt(0)}
                      </div>
                      {c.instructor}
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1 flex flex-col justify-end">
                    <div className="flex items-center gap-6 py-4 border-y border-border/50 my-2">
                      <div className="flex flex-col">
                        <div className="flex items-center gap-1.5 text-muted-foreground mb-1">
                          <Video className="w-3.5 h-3.5 text-emerald-500" />
                          <span className="text-[10px] uppercase font-black tracking-tighter">Content</span>
                        </div>
                        <span className="font-black text-base">{c.modulesCount || 0} Parts</span>
                      </div>
                      <div className="flex flex-col border-l border-border/50 pl-6">
                        <div className="flex items-center gap-1.5 text-muted-foreground mb-1">
                          <Users className="w-3.5 h-3.5 text-blue-500" />
                          <span className="text-[10px] uppercase font-black tracking-tighter">Students</span>
                        </div>
                        <span className="font-black text-base">{c.students || 0} Members</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => navigate(`/admin/courses/${c.id}/edit`)}
                        className="gap-2 font-bold rounded-xl h-10 bg-primary/10 text-primary hover:bg-primary/20"
                      >
                        <Edit className="w-4 h-4" />
                        Configure
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => navigate(`/admin/courses/${c.id}`)}
                        className="gap-2 font-bold rounded-xl h-10"
                      >
                        <Eye className="w-4 h-4" />
                        Explore
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(c.id)}
                        className="col-span-2 text-destructive hover:bg-destructive/5 hover:text-destructive h-10 font-bold rounded-xl transition-colors"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Decommission Course
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        )}
      </main>
      <Footer />
      <ConfirmDialog
        isOpen={confirmState.isOpen}
        onOpenChange={(open) => setConfirmState(prev => ({ ...prev, isOpen: open }))}
        title={confirmState.title}
        description={confirmState.description}
        onConfirm={confirmState.onConfirm}
        variant={confirmState.variant}
      />
    </div>
  );
}

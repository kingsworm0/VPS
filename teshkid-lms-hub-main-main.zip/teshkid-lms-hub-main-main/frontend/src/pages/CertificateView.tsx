import { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import api from "@/lib/api";
import { Award, Download, Share2, ChevronLeft, Star, ShieldCheck, QrCode } from "lucide-react";
import { toast } from "sonner";

// ─── Helpers ──────────────────────────────────────────────────────────────────
function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-US", {
    month: "long", day: "numeric", year: "numeric",
  });
}

export default function CertificateView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [cert, setCert] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const certRef = useRef<HTMLDivElement>(null);

  useEffect(() => { fetchCertificate(); }, [id]);

  const fetchCertificate = async () => {
    try {
      const res = await api.get(`/certificates/${id}`);
      setCert(res.data);
    } catch {
      toast.error("Could not load certificate");
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => window.print();

  const handleShare = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Certificate — ${cert.courseTitle}`,
          text: `I earned a verified certificate for "${cert.courseTitle}" on Teshkid Is Crypto!`,
          url,
        });
        return;
      } catch {}
    }
    await navigator.clipboard.writeText(url);
    toast.success("Certificate link copied!");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-sm font-bold text-muted-foreground">Loading certificate…</p>
        </div>
      </div>
    );
  }

  if (!cert) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-3">
          <Award className="w-16 h-16 text-muted-foreground/20 mx-auto" />
          <p className="text-xl font-black text-foreground">Certificate Not Found</p>
          <p className="text-sm text-muted-foreground">This certificate may have been revoked or the link is invalid.</p>
          <Button onClick={() => navigate("/")} className="mt-2 rounded-xl">Go Home</Button>
        </div>
      </div>
    );
  }

  const studentName = cert.firstName
    ? `${cert.firstName} ${cert.lastName || ""}`.trim()
    : cert.name || "Valued Student";

  const issuedDate = cert.issuedAt ? formatDate(cert.issuedAt) : formatDate(new Date().toISOString());
  const certIdShort = (cert.id || "").substring(0, 20).toUpperCase();

  return (
    <div className="min-h-screen bg-background text-foreground print:bg-white">

      {/* Navbar — hidden on print */}
      <div className="print:hidden">
        <Navbar />
      </div>

      {/* Action bar — hidden on print */}
      <div className="print:hidden pt-28 pb-8 container mx-auto px-4 max-w-5xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <button onClick={() => navigate(-1)}
              className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-3">
              <ChevronLeft className="w-4 h-4" /> Back
            </button>
            <h1 className="text-3xl font-black text-foreground">Official Certificate</h1>
            <p className="text-sm text-muted-foreground mt-1 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-primary" />
              Verified · ID: <span className="font-mono text-foreground/70">{certIdShort}…</span>
            </p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={handlePrint}
              className="rounded-xl border-border/60 gap-2 font-bold hover:border-primary/40 hover:text-primary">
              <Download className="w-4 h-4" /> Save / Print
            </Button>
            <Button onClick={handleShare}
              className="rounded-xl gap-2 font-bold shadow-lg shadow-primary/20">
              <Share2 className="w-4 h-4" /> Share
            </Button>
          </div>
        </div>
      </div>

      {/* ── Certificate ─────────────────────────────────────────────────────── */}
      <div className="pb-16 container mx-auto px-4 max-w-5xl print:px-0 print:pb-0 print:max-w-none">
        <div ref={certRef} className="certificate-body">

          {/* Outer border frame */}
          <div className="relative w-full bg-white text-black overflow-hidden print:shadow-none"
            style={{
              aspectRatio: "11 / 8.5",
              boxShadow: "0 32px 80px rgba(0,0,0,0.35)",
              border: "2px solid #d1d5db",
            }}>

            {/* ── Thick decorative border inset ─────────────────────────────── */}
            <div className="absolute inset-4 border-2 pointer-events-none z-10"
              style={{ borderColor: "#c9a84c" }} />

            {/* ── Corner ornaments ──────────────────────────────────────────── */}
            {/* Top-left */}
            <svg className="absolute top-2 left-2 z-20" width="80" height="80" viewBox="0 0 80 80" fill="none">
              <path d="M4 4 L76 4 M4 4 L4 76" stroke="#10b981" strokeWidth="3" strokeLinecap="round"/>
              <path d="M12 12 L44 12 M12 12 L12 44" stroke="#c9a84c" strokeWidth="1.5" strokeLinecap="round"/>
              <circle cx="4" cy="4" r="3" fill="#10b981"/>
            </svg>
            {/* Top-right */}
            <svg className="absolute top-2 right-2 z-20" width="80" height="80" viewBox="0 0 80 80" fill="none">
              <path d="M76 4 L4 4 M76 4 L76 76" stroke="#10b981" strokeWidth="3" strokeLinecap="round"/>
              <path d="M68 12 L36 12 M68 12 L68 44" stroke="#c9a84c" strokeWidth="1.5" strokeLinecap="round"/>
              <circle cx="76" cy="4" r="3" fill="#10b981"/>
            </svg>
            {/* Bottom-left */}
            <svg className="absolute bottom-2 left-2 z-20" width="80" height="80" viewBox="0 0 80 80" fill="none">
              <path d="M4 76 L76 76 M4 76 L4 4" stroke="#dc2626" strokeWidth="3" strokeLinecap="round"/>
              <path d="M12 68 L44 68 M12 68 L12 36" stroke="#c9a84c" strokeWidth="1.5" strokeLinecap="round"/>
              <circle cx="4" cy="76" r="3" fill="#dc2626"/>
            </svg>
            {/* Bottom-right */}
            <svg className="absolute bottom-2 right-2 z-20" width="80" height="80" viewBox="0 0 80 80" fill="none">
              <path d="M76 76 L4 76 M76 76 L76 4" stroke="#dc2626" strokeWidth="3" strokeLinecap="round"/>
              <path d="M68 68 L36 68 M68 68 L68 36" stroke="#c9a84c" strokeWidth="1.5" strokeLinecap="round"/>
              <circle cx="76" cy="76" r="3" fill="#dc2626"/>
            </svg>

            {/* ── Watermark logo ────────────────────────────────────────────── */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0">
              <img src="/logo.png" alt="" aria-hidden="true"
                className="w-[45%] opacity-[0.04] object-contain select-none" />
            </div>

            {/* ── Main content ──────────────────────────────────────────────── */}
            <div className="relative z-10 h-full flex flex-col items-center justify-between px-[7%] py-[4%]">

              {/* Header row: logo + cert ID */}
              <div className="w-full flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <img src="/logo.png" alt="Teshkid Is Crypto"
                    className="h-14 w-auto object-contain" />
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] leading-none"
                      style={{ color: "#10b981" }}>Certified By</p>
                    <p className="text-lg font-black tracking-tight text-black leading-tight mt-0.5">
                      Teshkid Is Crypto
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-[9px] font-black uppercase tracking-[0.18em] text-gray-400">Certificate ID</p>
                  <p className="text-[10px] font-mono font-bold text-gray-600 mt-0.5">{certIdShort}…</p>
                </div>
              </div>

              {/* Body */}
              <div className="flex flex-col items-center text-center w-full">
                {/* Title */}
                <div className="flex items-center gap-3 mb-3">
                  <div className="h-px flex-1 bg-gradient-to-r from-transparent to-amber-400/40" style={{ width: "3rem" }} />
                  <h2 className="text-[11px] sm:text-xs font-black uppercase tracking-[0.35em] text-gray-500">
                    Certificate of Completion
                  </h2>
                  <div className="h-px flex-1 bg-gradient-to-l from-transparent to-amber-400/40" style={{ width: "3rem" }} />
                </div>

                <p className="text-sm italic text-gray-400 mb-2" style={{ fontFamily: "Georgia, serif" }}>
                  This is to proudly certify that
                </p>

                {/* Student name */}
                <div className="relative mb-3">
                  <h3 className="font-black text-black leading-none tracking-tight"
                    style={{
                      fontSize: "clamp(1.6rem, 5vw, 3.5rem)",
                      fontFamily: "'Proxima Nova', 'Nunito', sans-serif",
                      letterSpacing: "-0.01em",
                    }}>
                    {studentName}
                  </h3>
                  {/* Underline flourish */}
                  <svg className="w-full mt-1" height="6" viewBox="0 0 400 6" preserveAspectRatio="none">
                    <path d="M0 3 Q100 0 200 3 Q300 6 400 3" stroke="url(#nameGrad)" strokeWidth="2" fill="none"/>
                    <defs>
                      <linearGradient id="nameGrad" x1="0" y1="0" x2="1" y2="0">
                        <stop offset="0%" stopColor="#10b981"/>
                        <stop offset="50%" stopColor="#c9a84c"/>
                        <stop offset="100%" stopColor="#dc2626"/>
                      </linearGradient>
                    </defs>
                  </svg>
                </div>

                <p className="text-xs sm:text-sm text-gray-500 leading-relaxed max-w-lg"
                  style={{ fontFamily: "Georgia, serif" }}>
                  has successfully completed all requirements of the intensive digital
                  training program in
                </p>

                <p className="font-black text-black uppercase tracking-tight mt-2"
                  style={{
                    fontSize: "clamp(0.9rem, 2.5vw, 1.4rem)",
                    fontFamily: "'Proxima Nova', 'Nunito', sans-serif",
                    color: "#111",
                  }}>
                  {cert.courseTitle}
                </p>
              </div>

              {/* Footer row: signature | badge | date */}
              <div className="w-full flex items-end justify-between">

                {/* Left — Instructor signature */}
                <div className="flex flex-col items-center min-w-[160px]">
                  {/* Signature image — the Montero signature provided */}
                  <img
                    src="/signature.png"
                    alt="Instructor Signature"
                    className="object-contain select-none pointer-events-none"
                    style={{
                      width: "clamp(100px, 14vw, 180px)",
                      height: "clamp(40px, 6vw, 72px)",
                      mixBlendMode: "multiply",
                      filter: "contrast(1.3) brightness(0.85)",
                    }}
                  />
                  <div className="w-full border-b border-gray-300 mt-1 mb-1.5" />
                  <p className="text-[10px] font-black uppercase tracking-widest text-black text-center leading-tight">
                    Teshkid Is Crypto
                  </p>
                  <p className="text-[9px] text-gray-400 font-bold tracking-wide mt-0.5">Lead Instructor</p>
                </div>

                {/* Centre — Gold seal badge */}
                <div className="flex flex-col items-center gap-1">
                  <div className="relative">
                    {/* Outer glow ring */}
                    <div className="absolute inset-0 rounded-full blur-md opacity-30"
                      style={{ background: "radial-gradient(circle, #f59e0b, transparent)" }} />
                    {/* Star burst background (12-point) */}
                    <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100"
                      style={{ width: "clamp(80px, 10vw, 120px)", height: "clamp(80px, 10vw, 120px)" }}>
                      <polygon points="50,2 61,35 95,35 68,57 79,91 50,70 21,91 32,57 5,35 39,35"
                        fill="url(#sealGrad)" opacity="0.9"/>
                      <defs>
                        <linearGradient id="sealGrad" x1="0" y1="0" x2="1" y2="1">
                          <stop offset="0%" stopColor="#fbbf24"/>
                          <stop offset="50%" stopColor="#f59e0b"/>
                          <stop offset="100%" stopColor="#d97706"/>
                        </linearGradient>
                      </defs>
                    </svg>
                    {/* Inner circle */}
                    <div className="relative flex flex-col items-center justify-center rounded-full border-2 border-yellow-400 bg-gradient-to-br from-yellow-300 via-yellow-400 to-amber-600 shadow-lg"
                      style={{
                        width: "clamp(72px, 9vw, 110px)",
                        height: "clamp(72px, 9vw, 110px)",
                      }}>
                      <div className="flex gap-0.5 mb-0.5">
                        <Star className="text-white fill-white" style={{ width: "clamp(8px,1vw,12px)", height: "clamp(8px,1vw,12px)" }} />
                        <Star className="text-white fill-white" style={{ width: "clamp(8px,1vw,12px)", height: "clamp(8px,1vw,12px)" }} />
                        <Star className="text-white fill-white" style={{ width: "clamp(8px,1vw,12px)", height: "clamp(8px,1vw,12px)" }} />
                      </div>
                      <Award className="text-white" style={{ width: "clamp(22px,3vw,38px)", height: "clamp(22px,3vw,38px)" }} />
                      <p className="text-white font-black uppercase tracking-widest leading-none mt-0.5"
                        style={{ fontSize: "clamp(5px,0.7vw,8px)" }}>MASTERED</p>
                    </div>
                  </div>
                </div>

                {/* Right — Date */}
                <div className="flex flex-col items-center min-w-[160px]">
                  <div className="w-full border-b border-gray-300 mb-1.5" />
                  <p className="text-[10px] font-black uppercase tracking-widest text-black text-center leading-tight">
                    {issuedDate}
                  </p>
                  <p className="text-[9px] text-gray-400 font-bold tracking-wide mt-0.5">Date Issued</p>
                </div>

              </div>
            </div>{/* end main content */}
          </div>{/* end certificate-body inner */}
        </div>{/* end certificate-body */}

        {/* Verification note — hidden on print */}
        <div className="print:hidden mt-6 rounded-2xl border border-border/50 bg-card/40 p-4 flex items-center gap-3">
          <ShieldCheck className="w-5 h-5 text-primary shrink-0" />
          <div>
            <p className="text-sm font-bold text-foreground">Verified Certificate</p>
            <p className="text-xs text-muted-foreground">
              This certificate is tamper-evident and permanently recorded.
              Share the URL to let anyone verify its authenticity.
            </p>
          </div>
        </div>
      </div>

      <div className="print:hidden">
        <Footer />
      </div>

      {/* Print styles */}
      <style>{`
        @media print {
          body { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; background: white !important; }
          .print\\:hidden { display: none !important; }
          .print\\:px-0 { padding-left: 0 !important; padding-right: 0 !important; }
          .print\\:pb-0 { padding-bottom: 0 !important; }
          .print\\:max-w-none { max-width: none !important; }
          .print\\:shadow-none { box-shadow: none !important; }
          @page { size: landscape; margin: 0.3cm; }
        }
      `}</style>
    </div>
  );
}

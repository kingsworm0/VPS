import { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import api from "@/lib/api";
import { Award, Download, Share2, ChevronLeft, ShieldCheck, Star } from "lucide-react";
import { toast } from "sonner";

export default function CertificateView() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [cert, setCert] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const certRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        fetchCertificate();
    }, [id]);

    const fetchCertificate = async () => {
        try {
            const res = await api.get(`/certificates/${id}`);
            setCert(res.data);
        } catch (error) {
            console.error(error);
            toast.error("Could not load certificate");
        } finally {
            setLoading(false);
        }
    };

    const handlePrint = () => {
        window.print();
    };

    const handleShare = async () => {
        const url = window.location.href;
        if (navigator.share) {
            try {
                await navigator.share({
                    title: `Official Certificate - ${cert.courseTitle}`,
                    text: `Check out my verified certificate of completion for "${cert.courseTitle}" on Teshkid LMS!`,
                    url,
                });
                return;
            } catch (err) {
                // fallback to clipboard
            }
        }
        await navigator.clipboard.writeText(url);
        toast.success("Certificate link copied to clipboard!");
    };

    if (loading) return <div className="min-h-screen flex items-center justify-center font-bold text-lg">Loading Certificate...</div>;
    if (!cert) return <div className="min-h-screen flex items-center justify-center font-bold text-lg">Certificate Not Found</div>;

    const studentName = cert.firstName
        ? `${cert.firstName} ${cert.lastName || ''}`.trim()
        : (cert.name || 'Valued Student');

    return (
        <div className="min-h-screen bg-background text-foreground print:bg-white">
            <div className="print:hidden">
                <Navbar />
            </div>

            <main className="pt-32 pb-20 container mx-auto px-4 max-w-5xl">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12 print:hidden">
                    <div>
                        <Button variant="ghost" onClick={() => navigate(-1)} className="mb-4">
                            <ChevronLeft className="w-4 h-4 mr-2" /> Back
                        </Button>
                        <h1 className="text-4xl font-black gradient-text">Official Certificate</h1>
                        <p className="text-muted-foreground font-medium">Verified proof of your achievement.</p>
                    </div>
                    <div className="flex gap-3">
                        <Button variant="outline" className="rounded-xl border-primary text-primary hover:bg-primary/10" onClick={handlePrint}>
                            <Download className="w-4 h-4 mr-2" /> Save PDF / Print
                        </Button>
                        <Button className="rounded-xl bg-primary shadow-lg shadow-primary/20" onClick={handleShare}>
                            <Share2 className="w-4 h-4 mr-2" /> Share Achievement
                        </Button>
                    </div>
                </div>

                {/* Certificate Card */}
                <div className="flex justify-center">
                    <div
                        ref={certRef}
                        className="relative w-full aspect-[11/8.5] bg-white shadow-2xl overflow-hidden text-black font-serif flex flex-col items-center justify-between p-12 sm:p-20"
                        style={{ 
                            backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(0,0,0,0.02) 1px, transparent 0)', 
                            backgroundSize: '24px 24px',
                            border: '16px solid transparent',
                            borderImage: 'linear-gradient(135deg, #10b981, #059669, #dc2626, #b91c1c) 1',
                            borderImageSlice: '1'
                        }}
                    >
                        {/* Decorative Corners with Teshkid Brand Colors */}
                        <div className="absolute top-0 left-0 w-32 h-32 border-t-[8px] border-l-[8px] rounded-tl-sm pointer-events-none" style={{ borderColor: '#10b981' }} />
                        <div className="absolute top-0 right-0 w-32 h-32 border-t-[8px] border-r-[8px] rounded-tr-sm pointer-events-none" style={{ borderColor: '#10b981' }} />
                        <div className="absolute bottom-0 left-0 w-32 h-32 border-b-[8px] border-l-[8px] rounded-bl-sm pointer-events-none" style={{ borderColor: '#dc2626' }} />
                        <div className="absolute bottom-0 right-0 w-32 h-32 border-b-[8px] border-r-[8px] rounded-br-sm pointer-events-none" style={{ borderColor: '#dc2626' }} />

                        {/* Background Logo Watermark - Teshkid Logo */}
                        <div className="absolute inset-0 flex items-center justify-center opacity-[0.06] pointer-events-none">
                            <img 
                                src="/logo.png" 
                                alt="Teshkid Logo" 
                                className="w-[550px] h-auto object-contain"
                            />
                        </div>

                        <div className="w-full flex justify-between items-start z-10">
                            <div className="flex items-center gap-3">
                                {/* Actual Teshkid Logo */}
                                <img 
                                    src="/logo.png" 
                                    alt="Teshkid Logo" 
                                    className="w-20 h-20 object-contain"
                                />
                                <div>
                                    <p className="text-xs font-black uppercase tracking-widest leading-none" style={{ color: '#10b981' }}>Certified By</p>
                                    <p className="text-xl font-black tracking-tight text-black leading-none mt-1">Teshkid Is Crypto</p>
                                </div>
                            </div>
                            <div className="text-right">
                                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground mr-1">Certificate ID</p>
                                <p className="text-xs font-mono font-bold text-black uppercase">{cert.id?.substring(0, 18)}...</p>
                            </div>
                        </div>

                        <div className="flex flex-col items-center text-center z-10 w-full mt-8">
                            <h2 className="text-2xl font-black uppercase tracking-[0.3em] mb-8" style={{ color: '#10b981' }}>Certificate of Completion</h2>
                            <p className="text-xl italic font-serif text-muted-foreground mb-4">This is to certify that</p>
                            <h3 className="text-5xl sm:text-7xl font-black tracking-tight text-black px-12 py-4 mb-8 relative">
                                <span className="relative z-10">
                                    {studentName}
                                </span>
                                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 via-emerald-600 to-red-500" />
                            </h3>
                            <p className="text-lg sm:text-xl text-balance max-w-2xl leading-relaxed text-muted-foreground">
                                has successfully completed the intensive digital training program for
                                <br />
                                <span className="text-black font-black text-2xl sm:text-3xl uppercase not-italic block mt-4 tracking-tight">
                                    {cert.courseTitle}
                                </span>
                            </p>
                        </div>

                        <div className="w-full flex justify-between items-end z-10 mt-12">
                            <div className="flex flex-col items-center">
                                {/* Signature Image */}
                                <img 
                                    src="/signature.png" 
                                    alt="Instructor Signature" 
                                    className="w-48 h-20 object-contain mb-1 mix-blend-multiply contrast-125 select-none"
                                />
                                <div className="w-48 border-b-2 border-black/20 mb-2" />
                                <p className="text-sm font-bold uppercase tracking-widest text-black">
                                    Teshkid is Crypto
                                </p>
                                <p className="text-xs font-bold text-muted-foreground">Lead Instructor</p>
                            </div>

                            {/* Golden Badge */}
                            <div className="relative group">
                                <div className="absolute inset-0 bg-yellow-400 blur-2xl opacity-20 group-hover:opacity-40 transition-opacity" />
                                <div className="relative w-32 h-32 rounded-full border-4 border-yellow-500 bg-gradient-to-br from-yellow-400 via-yellow-500 to-yellow-600 flex flex-col items-center justify-center shadow-xl transform hover:scale-110 transition-transform">
                                    <div className="flex gap-1 mb-1">
                                        <Star className="w-3 h-3 text-white fill-white" />
                                        <Star className="w-3 h-3 text-white fill-white" />
                                        <Star className="w-3 h-3 text-white fill-white" />
                                    </div>
                                    <Award className="w-10 h-10 text-white" />
                                    <p className="text-[8px] font-black text-white uppercase mt-1 tracking-widest">MASTERED</p>
                                </div>
                            </div>

                            <div className="flex flex-col items-center">
                                <div className="w-48 border-b-2 border-black/20 mb-2" />
                                <p className="text-sm font-bold uppercase tracking-widest text-black">
                                    {cert.issuedAt ? new Date(cert.issuedAt).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) : new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                                </p>
                                <p className="text-xs font-bold text-muted-foreground">Date Issued</p>
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            <div className="print:hidden">
                <Footer />
            </div>

            <style>{`
        @media print {
          body {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
            background: white !important;
          }
          .print\\:hidden {
            display: none !important;
          }
          @page {
            size: landscape;
            margin: 0.5cm;
          }
        }
      `}</style>
        </div>
    );
}

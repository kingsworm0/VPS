import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { getImageUrl } from "@/lib/imageUtils";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { User, Mail, Calendar, ArrowLeft, Trophy, BookOpen, Clock } from "lucide-react";
import { Linkify } from "@/components/ui/Linkify";

interface StudentDetails {
  student: {
    id: string;
    name: string;
    email: string;
    profilePicture?: string;
    bio?: string;
    createdAt: string;
  };
  stats: {
    totalEnrolledCourses: number;
    completedCourses: number;
    totalLessonsCompleted: number;
    averageProgress: number;
  };
  courses: Array<{
    id: string;
    title: string;
    description: string;
    enrolledAt: string;
    totalLessons: number;
    completedLessons: number;
    progressPercentage: number;
  }>;
  recentActivities: Array<{
    id: string;
    lessonTitle: string;
    moduleTitle: string;
    courseTitle: string;
    completedAt: string;
  }>;
}

export default function AdminStudentDetail() {
  const { studentId } = useParams<{ studentId: string }>();
  const navigate = useNavigate();
  const [student, setStudent] = useState<StudentDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [showProfilePhoto, setShowProfilePhoto] = useState(false);

  useEffect(() => {
    if (!studentId) return;
    loadStudentDetails();
  }, [studentId]);

  const loadStudentDetails = async () => {
    try {
      const response = await api.get(
        `/admin/progress/students/${studentId}/progress`,
      );
      setStudent(response.data);
    } catch (error) {
      console.error("Failed to load student details:", error);
      toast.error("Failed to load student details");
      navigate("/admin");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">Loading...</div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!student) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">Student not found</div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-1 container mx-auto px-4 pt-32 sm:pt-40 pb-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row items-center md:items-start justify-between gap-6 mb-8 p-6 rounded-2xl bg-gradient-to-br from-primary/5 via-transparent to-accent/5 border border-primary/10 shadow-sm">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
            <div className="relative">
              <div className="w-28 h-28 rounded-full overflow-hidden bg-muted flex items-center justify-center border-4 border-background shadow-xl ring-2 ring-primary/20">
                {student.student.profilePicture ? (
                  <button
                    type="button"
                    onClick={() => setShowProfilePhoto(true)}
                    className="block w-full h-full cursor-zoom-in focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-inset"
                    aria-label={`View ${student.student.name}'s profile photo`}
                    title="View profile photo"
                  >
                    <img
                      src={getImageUrl(student.student.profilePicture) || ''}
                      alt={student.student.name}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ) : (
                  <div className="bg-primary/10 w-full h-full flex items-center justify-center text-primary">
                    <User className="w-12 h-12" />
                  </div>
                )}
              </div>
              <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-success border-4 border-background flex items-center justify-center shadow-lg" title="Active Student">
                <Trophy className="w-3.5 h-3.5 text-success-foreground" />
              </div>
            </div>

            <div className="text-center md:text-left space-y-2">
              <h1 className="text-3xl font-display font-bold tracking-tight">{student.student.name}</h1>
              <div className="flex flex-wrap justify-center md:justify-start gap-4">
                <div className="flex items-center gap-1.5 text-sm font-medium text-muted-foreground">
                  <Mail className="w-4 h-4 text-primary" />
                  {student.student.email}
                </div>
                <div className="flex items-center gap-1.5 text-sm font-medium text-muted-foreground">
                  <Calendar className="w-4 h-4 text-primary" />
                  Joined {new Date(student.student.createdAt).toLocaleDateString(undefined, { dateStyle: 'long' })}
                </div>
              </div>
              {student.student.bio && (
                <div className="mt-3 p-3 rounded-lg bg-background/50 border border-border text-sm text-balance max-w-md italic text-muted-foreground whitespace-pre-wrap">
                  "<Linkify text={student.student.bio} />"
                </div>
              )}
            </div>
          </div>
          <Button variant="outline" onClick={() => navigate("/admin")} className="gap-2 shrink-0 shadow-sm">
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 border-b">
          <button
            onClick={() => setActiveTab("overview")}
            className={`pb-2 px-4 ${activeTab === "overview"
              ? "border-b-2 border-blue-600 text-blue-600 font-bold"
              : "text-gray-600"
              }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab("courses")}
            className={`pb-2 px-4 ${activeTab === "courses"
              ? "border-b-2 border-blue-600 text-blue-600 font-bold"
              : "text-gray-600"
              }`}
          >
            Courses
          </button>
          <button
            onClick={() => setActiveTab("activity")}
            className={`pb-2 px-4 ${activeTab === "activity"
              ? "border-b-2 border-blue-600 text-blue-600 font-bold"
              : "text-gray-600"
              }`}
          >
            Recent Activity
          </button>
        </div>

        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div>
            {/* Statistics Cards */}

        <Dialog open={showProfilePhoto} onOpenChange={setShowProfilePhoto}>
          <DialogContent className="max-w-3xl border-0 bg-transparent p-2 shadow-none">
            <DialogTitle className="sr-only">
              {student.student.name}'s profile photo
            </DialogTitle>
            <img
              src={getImageUrl(student.student.profilePicture) || ''}
              alt={student.student.name}
              className="max-h-[80vh] w-full rounded-lg object-contain"
            />
          </DialogContent>
        </Dialog>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">
                    Enrolled Courses
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {student.stats.totalEnrolledCourses}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">
                    Completed Courses
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {student.stats.completedCourses}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">
                    Lessons Done
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {student.stats.totalLessonsCompleted}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">
                    Avg Progress
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {(Number(student.stats.averageProgress) || 0).toFixed(1)}%
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Overall Progress */}
            <Card>
              <CardHeader>
                <CardTitle>Overall Progress</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Progress value={Number(student.stats.averageProgress) || 0} />
                  <p className="text-sm text-gray-600">
                    Average progress across all enrolled courses
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Courses Tab */}
        {activeTab === "courses" && (
          <Card>
            <CardHeader>
              <CardTitle>Course Progress</CardTitle>
            </CardHeader>
            <CardContent>
              {student.courses.length === 0 ? (
                <p className="text-gray-500">No courses enrolled</p>
              ) : (
                <div className="space-y-6">
                  {student.courses.map((course) => (
                    <div key={course.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h3 className="font-bold text-lg">{course.title}</h3>
                          <p className="text-sm text-gray-600 line-clamp-2">
                            <Linkify text={course.description} />
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            Enrolled:{" "}
                            {new Date(course.enrolledAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-blue-600">
                            {(Number(course.progressPercentage) || 0).toFixed(0)}%
                          </div>
                          <p className="text-xs text-gray-600 font-bold uppercase tracking-tighter">Complete</p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600 font-medium">
                            {course.completedLessons}/{course.totalLessons}{" "}
                            lessons
                          </span>
                        </div>
                        <Progress value={Number(course.progressPercentage) || 0} />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Activity Tab */}
        {activeTab === "activity" && (
          <Card>
            <CardHeader>
              <CardTitle>Recent Learning Activities</CardTitle>
            </CardHeader>
            <CardContent>
              {student.recentActivities.length === 0 ? (
                <p className="text-gray-500">No activities yet</p>
              ) : (
                <div className="space-y-3">
                  {student.recentActivities.map((activity) => (
                    <div
                      key={activity.id}
                      className="flex items-start gap-3 border-l-4 border-blue-500 pl-4 py-2"
                    >
                      <div className="flex-1">
                        <p className="font-medium">{activity.lessonTitle}</p>
                        <p className="text-sm text-gray-600">
                          {activity.moduleTitle} • {activity.courseTitle}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">
                          {new Date(activity.completedAt).toLocaleDateString()}{" "}
                          at{" "}
                          {new Date(activity.completedAt).toLocaleTimeString()}
                        </p>
                      </div>
                      <div className="text-green-600 font-bold">✓</div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
      <Footer />
    </div>
  );
}

import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import api from "@/lib/api";

export default function ForgotPassword() {
  const location = useLocation();
  const isAdmin = location.pathname.startsWith("/admin/");
  const loginPath = isAdmin ? "/admin/login" : "/student/login";
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setIsLoading(true);
    try {
      await api.post("/auth/forgot-password", { email });
      setSubmitted(true);
    } catch (error: any) {
      toast({
        title: "Unable to send reset link",
        description: error.response?.data?.error || "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-hero-pattern opacity-50" />
      <Card variant="glass" className="relative w-full max-w-md backdrop-blur-xl border-primary/20">
        <CardHeader className="text-center">
          <div className="mx-auto mb-2 rounded-full bg-primary/10 p-3 w-fit">
            <Mail className="h-7 w-7 text-primary" />
          </div>
          <CardTitle className="font-display text-2xl">Forgot password?</CardTitle>
          <CardDescription>
            {submitted
              ? "If an account exists for that email, a reset link has been sent."
              : "Enter your email and we will send you a secure reset link."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {submitted ? (
            <Button asChild className="w-full"><Link to={loginPath}>Back to login</Link></Button>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email">Email address</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Sending..." : "Send reset link"}
              </Button>
              <Link to={loginPath} className="block text-center text-sm text-primary hover:underline">Back to login</Link>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

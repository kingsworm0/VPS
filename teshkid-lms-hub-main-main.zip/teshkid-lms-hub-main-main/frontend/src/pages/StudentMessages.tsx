import { useEffect, useState, useRef } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader,
  DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu, DropdownMenuContent,
  DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import api from "@/lib/api";
import {
  Send, Loader2, Mail, RefreshCw, Plus,
  Archive as ArchiveIcon, Trash2,
  Star as StarIcon, CheckCircle2,
  Inbox as InboxIcon, Search, MoreVertical,
  Clock, ArrowRight, UserRound, Eye,
  MessageSquare, CheckCheck, Circle, Paperclip, XCircle
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { ConfirmDialog } from "@/components/ui/ConfirmDialog";
import { Linkify } from "@/components/ui/Linkify";
import { cn } from "@/lib/utils";

interface StudentMessage {
  id: string;
  subject: string;
  message: string;
  content?: string;
  createdAt: string;
  reply?: string;
  attachmentUrl?: string;
  replyAttachmentUrl?: string;
  /** studentIsRead — backend returns this as isRead for students */
  isRead?: boolean;
}

export default function StudentMessages() {
  const { user } = useAuth();
  const [messages, setMessages]       = useState<StudentMessage[]>([]);
  const [loading, setLoading]         = useState(true);
  const [showCompose, setShowCompose] = useState(false);
  const [newMsg, setNewMsg]           = useState({ subject: "", message: "" });
  const [attachment, setAttachment]     = useState<File | null>(null);
  const [sendingMsg, setSendingMsg]   = useState(false);
  const [selectedMsg, setSelectedMsg] = useState<StudentMessage | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);


  const [confirmState, setConfirmState] = useState<{
    isOpen: boolean; title: string; description: string;
    onConfirm: () => void; variant?: "default" | "destructive";
  }>({ isOpen: false, title: "", description: "", onConfirm: () => {} });

  useEffect(() => { fetchMyMessages(); }, []);

  const fetchMyMessages = async () => {
    try {
      setLoading(true);
      const res = await api.get("/messages/my");
      setMessages(res.data || []);
    } catch { toast.error("Failed to fetch your messages"); }
    finally { setLoading(false); }
  };

  const handleSendMessage = async () => {
    if (!newMsg.subject.trim() || (!newMsg.message.trim() && !attachment)) {
      toast.error("Subject and message are required");
      return;
    }
    try {
      setSendingMsg(true);
      let attachmentUrl = undefined;
      if (attachment) {
        const formData = new FormData();
        formData.append("file", attachment);
        const uploadRes = await api.post("/upload/file", formData, {
          headers: { "Content-Type": "multipart/form-data" },
        });
        attachmentUrl = uploadRes.data.url;
      }

      await api.post("/messages", { subject: newMsg.subject, message: newMsg.message, attachmentUrl });
      toast.success("Message sent to support!");
      setNewMsg({ subject: "", message: "" });
      setAttachment(null);
      setShowCompose(false);
      fetchMyMessages();
    } catch { toast.error("Failed to send message"); }
    finally { setSendingMsg(false); }
  };

  const openMessage = async (msg: StudentMessage) => {
    setSelectedMsg(msg);
    // Mark student-side as read when they open it
    if (!msg.isRead) {
      try {
        await api.put(`/messages/${msg.id}/read`, { isRead: true });
        setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, isRead: true } : m));
      } catch {}
    }
  };

  const deleteMessage = async (msgId: string) => {
    setConfirmState({
      isOpen: true, title: "Delete Message", variant: "destructive",
      description: "Permanently remove this message from your history?",
      onConfirm: async () => {
        try {
          await api.delete(`/messages/${msgId}`);
          toast.success("Message deleted");
          if (selectedMsg?.id === msgId) setSelectedMsg(null);
          fetchMyMessages();
        } catch { toast.error("Failed to delete message"); }
      },
    });
  };



  // ─── Filtering ────────────────────────────────────────────────────────────
  // "unread" for students = a reply arrived that they haven't opened yet
  const unreadCount = messages.filter(m => !m.isRead && !!m.reply).length;
  const pendingCount = messages.filter(m => !m.reply).length;

  const filteredMessages = messages
    .filter(m => {
      const q = searchQuery.toLowerCase();
      if (q && !m.subject.toLowerCase().includes(q) && !(m.message || m.content || "").toLowerCase().includes(q)) return false;
      return true;
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-background flex flex-col font-sans">
      <Navbar />

      <main className="pt-20 pb-8 flex-1 flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-border/50 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
              <InboxIcon className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-black font-['Space_Grotesk'] text-foreground leading-none">My Messages</h1>
              <p className="text-xs text-muted-foreground mt-0.5">
                {unreadCount > 0 && <><span className="text-primary font-bold">{unreadCount} new {unreadCount === 1 ? "reply" : "replies"}</span> · </>}
                {pendingCount > 0 ? <>{pendingCount} awaiting reply</> : "All messages answered"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" onClick={() => setShowCompose(true)} className="h-8 px-3 text-xs font-black rounded-lg gap-1.5 shadow-lg shadow-primary/20">
              <Plus className="w-3.5 h-3.5" /> New Message
            </Button>
            <Button variant="ghost" size="icon" onClick={fetchMyMessages} className="h-8 w-8 rounded-lg text-muted-foreground hover:text-foreground">
              <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
            </Button>
          </div>
        </div>

        {/* Two-panel body */}
        <div className="flex flex-1 overflow-hidden">

          {/* ── LEFT: message list ─────────────────────────────────────── */}
          <aside className="w-[300px] shrink-0 border-r border-border/50 flex flex-col bg-card/30 overflow-hidden">

            {/* Search */}
            <div className="p-3 border-b border-border/40 shrink-0">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                <Input
                  placeholder="Search messages..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pl-9 h-8 bg-muted/50 border-border/40 text-sm focus-visible:ring-1 focus-visible:ring-primary"
                />
              </div>
            </div>



            {/* Message list */}
            <div className="flex-1 overflow-y-auto">
              {loading ? (
                <div className="flex items-center justify-center h-40"><Loader2 className="w-5 h-5 animate-spin text-primary" /></div>
              ) : filteredMessages.length === 0 ? (
                <div className="p-8 text-center text-muted-foreground text-sm">No messages found</div>
              ) : (
                filteredMessages.map(msg => {
                  const hasReply = !!msg.reply;
                  const isUnread = !msg.isRead && hasReply; // unread = new reply student hasn't seen
                  const isActive = selectedMsg?.id === msg.id;
                  return (
                    <div
                      key={msg.id}
                      onClick={() => openMessage(msg)}
                      className={cn(
                        "p-3 border-b border-border/30 cursor-pointer transition-all group",
                        isActive ? "bg-primary/10 border-l-2 border-l-primary" : "hover:bg-muted/30",
                        isUnread && !isActive && "bg-primary/[0.04]"
                      )}
                    >
                      <div className="flex items-start gap-2">
                        {/* Support avatar placeholder */}
                        <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center shrink-0 text-[10px] font-black text-primary border border-primary/20">
                          S
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-1 mb-0.5">
                            <span className={cn("text-xs font-bold truncate", isUnread ? "text-foreground" : "text-muted-foreground")}>
                              Support
                            </span>
                            <span className="text-[10px] text-muted-foreground shrink-0">{formatDistanceToNow(new Date(msg.createdAt), { addSuffix: true })}</span>
                          </div>
                          <p className={cn("text-xs truncate mb-0.5", isUnread ? "font-semibold text-foreground" : "text-muted-foreground")}>{msg.subject}</p>
                          <p className="text-[10px] text-muted-foreground/60 truncate">
                            {hasReply ? msg.reply?.slice(0, 55) : (msg.message || msg.content || "").slice(0, 55)}
                          </p>
                          <div className="flex items-center gap-1.5 mt-1.5">
                            {hasReply ? (
                              <span className="flex items-center gap-0.5 text-[9px] font-bold text-primary">
                                <CheckCheck className="w-2.5 h-2.5" /> Replied
                              </span>
                            ) : (
                              <span className="flex items-center gap-0.5 text-[9px] font-bold text-muted-foreground">
                                <Clock className="w-2.5 h-2.5" /> Pending
                              </span>
                            )}

                            {isUnread && <span className="w-1.5 h-1.5 rounded-full bg-primary ml-auto shrink-0" />}
                            {msg.attachmentUrl && <Paperclip className="w-3 h-3 text-muted-foreground ml-auto shrink-0" />}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </aside>

          {/* ── RIGHT: thread view ─────────────────────────────────────── */}
          <section className="flex-1 flex flex-col overflow-hidden bg-background">
            {!selectedMsg ? (
              <div className="flex-1 flex flex-col items-center justify-center gap-4 text-center px-8">
                <div className="w-16 h-16 rounded-2xl bg-muted/50 flex items-center justify-center">
                  <MessageSquare className="w-8 h-8 text-muted-foreground/30" />
                </div>
                <p className="text-base font-bold text-muted-foreground">Select a message to read</p>
                <p className="text-sm text-muted-foreground/60">Or compose a new one</p>
                <Button size="sm" onClick={() => setShowCompose(true)} className="mt-2 gap-2 font-black rounded-xl shadow-lg shadow-primary/20">
                  <Plus className="w-4 h-4" /> Compose Message
                </Button>
              </div>
            ) : (
              <>
                {/* Thread header */}
                <div className="px-5 py-3.5 border-b border-border/50 shrink-0 bg-card/30 flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h2 className="text-sm font-black text-foreground font-['Space_Grotesk'] truncate">{selectedMsg.subject}</h2>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      Submitted {format(new Date(selectedMsg.createdAt), "MMM d, yyyy 'at' h:mm a")}
                      {" · "}
                      {selectedMsg.reply
                        ? <span className="text-primary font-bold">Support replied</span>
                        : <span className="text-muted-foreground">Awaiting reply from support</span>
                      }
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <Button variant="ghost" size="sm" onClick={() => deleteMessage(selectedMsg.id)} className="text-destructive hover:text-destructive hover:bg-destructive/10">
                      <Trash2 className="w-4 h-4 mr-1.5" /> Delete
                    </Button>
                  </div>
                </div>

                {/* Thread body */}
                <div className="flex-1 overflow-y-auto px-5 py-5 space-y-5">

                  {/* Student's original message */}
                  <div className="flex gap-3 items-start">
                    <div className="w-9 h-9 rounded-full overflow-hidden bg-muted flex items-center justify-center border border-border/50 shrink-0">
                      {user?.profilePicture
                        ? <img src={user.profilePicture} alt={user.name} className="w-full h-full object-cover" />
                        : <UserRound className="w-4 h-4 text-muted-foreground" />
                      }
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-baseline gap-2 mb-1.5">
                        <span className="text-sm font-black text-foreground">{user?.name}</span>
                        <span className="text-[10px] text-muted-foreground">{format(new Date(selectedMsg.createdAt), "EEE, MMM d · h:mm a")}</span>
                      </div>
                      <div className="bg-card border border-border/50 rounded-xl rounded-tl-none p-4 text-sm leading-relaxed text-foreground/90 whitespace-pre-wrap">
                        <Linkify text={selectedMsg.message || selectedMsg.content || ""} />
                        {selectedMsg.attachmentUrl && (
                          <div className="mt-3">
                            <a href={selectedMsg.attachmentUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-3 py-1.5 bg-muted rounded-lg text-xs font-bold text-muted-foreground hover:text-foreground transition-colors border border-border">
                              <Paperclip className="w-3.5 h-3.5" />
                              View Attachment
                            </a>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Admin reply */}
                  {selectedMsg.reply ? (
                    <div className="flex gap-3 items-start translate-x-4">
                      <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center shrink-0">
                        <span className="text-xs font-black text-primary-foreground">S</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline gap-2 mb-1.5">
                          <span className="text-sm font-black text-foreground">Teshkid Support</span>
                          <span className="text-[10px] text-primary font-bold uppercase tracking-wide">Reply</span>
                        </div>
                        <div className="bg-primary/10 border border-primary/20 rounded-xl rounded-tl-none p-4 text-sm leading-relaxed text-foreground/90 whitespace-pre-wrap relative overflow-hidden">
                          <div className="absolute top-2 right-3 opacity-10">
                            <CheckCircle2 className="w-10 h-10 text-primary" />
                          </div>
                          <Linkify text={selectedMsg.reply} />
                          {selectedMsg.replyAttachmentUrl && (
                            <div className="mt-3 relative z-10">
                              <a href={selectedMsg.replyAttachmentUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary/10 rounded-lg text-xs font-bold text-primary hover:bg-primary/20 transition-colors border border-primary/20">
                                <Paperclip className="w-3.5 h-3.5" />
                                View Attachment
                              </a>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center py-8">
                      <div className="text-center space-y-2">
                        <div className="w-10 h-10 rounded-full bg-muted/50 flex items-center justify-center mx-auto">
                          <Clock className="w-5 h-5 text-muted-foreground/40" />
                        </div>
                        <p className="text-xs font-bold text-muted-foreground">Waiting for a reply from support</p>
                        <p className="text-[10px] text-muted-foreground/60">We typically respond within 24 hours</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Footer actions */}
                <div className="border-t border-border/50 px-5 py-3 shrink-0 bg-card/20 flex items-center justify-between gap-3">
                  <p className="text-[10px] text-muted-foreground">
                    Message ID: <span className="font-mono text-foreground/60">{selectedMsg.id.slice(0, 8).toUpperCase()}</span>
                  </p>
                  <Button size="sm" onClick={() => setShowCompose(true)} className="h-7 text-xs px-3 font-black rounded-lg gap-1.5">
                    <Plus className="w-3 h-3" /> New Message
                  </Button>
                </div>
              </>
            )}
          </section>

        </div>{/* end two-panel */}
      </main>

      <Footer />

      {/* Compose Dialog */}
      <Dialog open={showCompose} onOpenChange={setShowCompose}>
        <DialogContent className="max-w-lg bg-card border-border/50 shadow-2xl rounded-2xl overflow-hidden p-0">
          <div className="bg-primary px-6 py-5 relative overflow-hidden">
            <div className="absolute -right-4 -top-4 opacity-10">
              <Send className="w-24 h-24" />
            </div>
            <DialogTitle className="text-xl font-black text-primary-foreground">New Message</DialogTitle>
            <p className="text-primary-foreground/70 text-sm mt-1">Send a message to Teshkid support</p>
          </div>

          <div className="px-6 py-5 space-y-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Subject</label>
              <Input
                placeholder="Briefly describe your issue..."
                value={newMsg.subject}
                onChange={e => setNewMsg({ ...newMsg, subject: e.target.value })}
                className="bg-muted/40 border-border/50 focus-visible:ring-primary/30"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Message</label>
              <Textarea
                placeholder="Describe your question or issue in detail..."
                value={newMsg.message}
                onChange={e => setNewMsg({ ...newMsg, message: e.target.value })}
                rows={5}
                className="resize-none bg-muted/40 border-border/50 focus-visible:ring-primary/30"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground block">Attachment (Optional)</label>
              <div className="flex items-center gap-2">
                <Input type="file" ref={fileInputRef} className="hidden" onChange={e => setAttachment(e.target.files?.[0] || null)} />
                <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()} className={cn("h-8 rounded-lg border-border/50 transition-colors gap-2", attachment && "bg-primary/10 border-primary/30 text-primary")}>
                  <Paperclip className="w-4 h-4" />
                  {attachment ? "Change File" : "Attach File"}
                </Button>
                {attachment && (
                  <div className="flex items-center gap-2 text-[10px] font-bold text-primary bg-primary/10 px-2.5 py-1.5 rounded-md border border-primary/20">
                    <span className="truncate max-w-[150px]">{attachment.name}</span>
                    <button onClick={() => setAttachment(null)} className="hover:bg-primary/20 rounded-full p-0.5"><XCircle className="w-3 h-3" /></button>
                  </div>
                )}
              </div>
            </div>
          </div>

          <DialogFooter className="px-6 py-4 border-t border-border/40 bg-muted/10">
            <Button variant="ghost" onClick={() => setShowCompose(false)} className="font-bold rounded-xl">Cancel</Button>
            <Button
              onClick={handleSendMessage}
              disabled={sendingMsg || !newMsg.subject.trim() || (!newMsg.message.trim() && !attachment)}
              className="font-black rounded-xl shadow-lg shadow-primary/20 gap-2"
            >
              {sendingMsg ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              Send Message
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        isOpen={confirmState.isOpen}
        onOpenChange={open => setConfirmState(p => ({ ...p, isOpen: open }))}
        title={confirmState.title}
        description={confirmState.description}
        onConfirm={confirmState.onConfirm}
        variant={confirmState.variant}
      />
    </div>
  );
}

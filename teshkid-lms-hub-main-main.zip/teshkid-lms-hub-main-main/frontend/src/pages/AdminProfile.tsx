import { useEffect, useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import api from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import {
  X, Camera, Server, Database, Activity, ShieldAlert, Zap, RefreshCw, UserCheck, UserX, Megaphone, UserRound
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";

interface SystemStatus {
  status: string;
  uptimeSeconds: number;
  dbLatencyMs: number;
  nodeVersion: string;
  env: string;
  metrics: {
    users: number;
    courses: number;
    enrollments: number;
    lessonProgress: number;
    liveSessions: number;
    certificates: number;
    blockedUsers: number;
  };
  recentAttempts: Array<{
    id: string;
    name: string;
    email: string;
    role: string;
    isBlocked: boolean;
    lastLoginDate?: string;
    createdAt: string;
    profilePicture?: string;
  }>;
}

const SIDEBAR_SECTIONS = [
  {
    title: "ADMIN ACCOUNT",
    tabs: [
      { id: "account", label: "My Account" }
    ]
  },
  {
    title: "SYSTEM CONTROL",
    tabs: [
      { id: "overview", label: "Overview" },
      { id: "optimization", label: "Optimization" },
    ]
  },
  {
    title: "LOGS & ACTIVITY",
    tabs: [
      { id: "attempts", label: "User Attempts" },
    ]
  },
  {
    title: "COMMUNICATIONS",
    tabs: [
      { id: "announcement", label: "Announcements" },
    ]
  }
];

export default function AdminProfile() {
  const { user, isLoading: authLoading, refreshUser } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("overview");

  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null);
  const [loadingStatus, setLoadingStatus] = useState(true);
  const [optimizing, setOptimizing] = useState(false);

  // Admin profile & avatar state
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [adminProfileData, setAdminProfileData] = useState({
    name: user?.name || "",
    bio: (user as any)?.bio || "",
  });
  const [savingAdminProfile, setSavingAdminProfile] = useState(false);

  // Announcement state
  const [announcement, setAnnouncement] = useState({ title: "", content: "", type: "info" });
  const [postingAnnouncement, setPostingAnnouncement] = useState(false);

  // Password change state
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [updatingPassword, setUpdatingPassword] = useState(false);

  // UI state for revealing edits
  const [editingField, setEditingField] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && (!user || user.role !== "ADMIN")) {
      navigate("/");
      return;
    }
    if (user) {
      setAdminProfileData({
        name: user.name || "",
        bio: (user as any)?.bio || "",
      });
    }
    
    // Initial load
    loadSystemStatus();
    
    // Set up real-time polling every 5 seconds
    const interval = setInterval(() => {
      loadSystemStatus(true); // Silent update without loading spinners
    }, 5000);
    
    return () => clearInterval(interval);
  }, [user, authLoading, navigate]);

  const handleAvatarUpload = async (file: File) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Please select a valid image file");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image file size should be less than 5MB");
      return;
    }

    setUploadingAvatar(true);
    try {
      const formDataObj = new FormData();
      formDataObj.append("profilePicture", file);
      await api.post("/student/profile-picture", formDataObj, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      await refreshUser();
      toast.success("Admin avatar picture updated successfully!");
    } catch (err: any) {
      console.error("Failed to upload avatar:", err);
      toast.error(err.response?.data?.message || "Failed to upload profile picture");
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleUpdateAdminProfile = async () => {
    if (!adminProfileData.name.trim()) {
      toast.error("Admin name cannot be empty");
      return;
    }
    setSavingAdminProfile(true);
    try {
      await api.put("/student/profile", {
        name: adminProfileData.name,
        bio: adminProfileData.bio,
      });
      await refreshUser();
      toast.success("Admin account details updated successfully!");
      setEditingField(null);
    } catch (err: any) {
      toast.error(err.response?.data?.message || "Failed to update profile details");
    } finally {
      setSavingAdminProfile(false);
    }
  };

  const loadSystemStatus = async (silent = false) => {
    if (!silent) setLoadingStatus(true);
    try {
      const res = await api.get("/admin/system-status");
      setSystemStatus(res.data);
    } catch {
      if (!silent) toast.error("Failed to load system status");
    } finally {
      if (!silent) setLoadingStatus(false);
    }
  };

  const handleOptimizeSystem = async () => {
    setOptimizing(true);
    try {
      const res = await api.post("/admin/system-optimize");
      toast.success(`${res.data.message} (${res.data.timeTakenMs}ms)`);
      loadSystemStatus();
    } catch {
      toast.error("Failed to run system optimization");
    } finally {
      setOptimizing(false);
    }
  };

  const handleToggleBlock = async (userId: string, currentBlocked: boolean) => {
    try {
      await api.put(`/admin/users/${userId}/block`, { isBlocked: !currentBlocked });
      toast.success(currentBlocked ? "User account unblocked" : "User account blocked");
      loadSystemStatus();
    } catch {
      toast.error("Failed to update user status");
    }
  };

  const handlePostAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!announcement.title.trim() || !announcement.content.trim()) {
      toast.error("Title and content are required");
      return;
    }
    setPostingAnnouncement(true);
    try {
      await api.post("/announcements", announcement);
      toast.success("System announcement broadcasted to all users!");
      setAnnouncement({ title: "", content: "", type: "info" });
    } catch {
      toast.error("Failed to post announcement");
    } finally {
      setPostingAnnouncement(false);
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordData.currentPassword || !passwordData.newPassword) {
      toast.error("Please fill in all required fields");
      return;
    }
    if (passwordData.newPassword.length < 6) {
      toast.error("New password must be at least 6 characters");
      return;
    }
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }

    setUpdatingPassword(true);
    try {
      await api.post("/auth/change-password", {
        currentPassword: passwordData.currentPassword,
        newPassword: passwordData.newPassword,
      });
      toast.success("Admin password changed successfully!");
      setPasswordData({ currentPassword: "", newPassword: "", confirmPassword: "" });
    } catch (err: any) {
      toast.error(err.response?.data?.message || "Failed to update password");
    } finally {
      setUpdatingPassword(false);
    }
  };

  const formatUptime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs}h ${mins}m ${secs}s`;
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans">
      <Navbar />
      <div className="flex flex-1 mt-16 min-h-[calc(100vh-4rem)]">
      
      {/* Sidebar */}
      <aside className="w-60 md:w-72 bg-card/30 border-r border-border/60 flex-shrink-0 flex flex-col items-end pt-8 pb-6 overflow-y-auto hidden sm:flex">
        <div className="w-full max-w-[218px] px-2 pr-4 space-y-4">
          {SIDEBAR_SECTIONS.map((section, idx) => (
            <div key={idx} className="mb-4">
              <h3 className="px-2.5 text-[11px] font-bold text-muted-foreground mb-1.5 uppercase tracking-wide">
                {section.title}
              </h3>
              <div className="space-y-0.5">
                {section.tabs.map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={cn(
                      "w-full text-left px-2.5 py-1.5 rounded text-[15px] font-medium transition-colors",
                      activeTab === tab.id 
                        ? "bg-primary text-primary-foreground" 
                        : "text-muted-foreground hover:bg-secondary/50 hover:text-foreground"
                    )}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
              {idx < SIDEBAR_SECTIONS.length - 1 && (
                <div className="mx-2.5 h-[1px] bg-border mt-4" />
              )}
            </div>
          ))}
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative min-w-0 bg-background">
        {/* ESC Button (Close) */}
        <div className="absolute top-8 right-10 z-10 hidden md:flex flex-col items-center group cursor-pointer" onClick={() => navigate("/admin")}>
          <div className="w-9 h-9 rounded-full border-2 border-muted-foreground group-hover:bg-secondary flex items-center justify-center mb-1 transition-colors">
            <X className="w-4 h-4 text-muted-foreground group-hover:text-foreground" />
          </div>
          <span className="text-[12px] font-bold text-muted-foreground group-hover:text-foreground">ESC</span>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar">
          <div className="max-w-[740px] px-6 md:px-10 py-10 pb-20">
            
            {/* 1. Admin Account */}
            {activeTab === "account" && (
              <div className="animate-in fade-in duration-200">
                <h2 className="text-[20px] font-bold text-foreground mb-5">My Account</h2>
                
                <div className="bg-muted rounded-xl overflow-hidden mb-8">
                  <div className="h-24 bg-primary/20"></div>
                  <div className="px-4 pb-4 flex justify-between items-start relative">
                    <div className="relative -mt-12 mb-4">
                      <div className="w-20 h-20 rounded-full border-[6px] border-muted bg-background overflow-hidden flex items-center justify-center group">
                        {uploadingAvatar ? (
                          <div className="w-6 h-6 border-2 border-foreground border-t-transparent rounded-full animate-spin"></div>
                        ) : user?.profilePicture ? (
                          <img src={user.profilePicture} alt="Avatar" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-primary/10">
                            <UserRound className="w-10 h-10 text-primary" />
                          </div>
                        )}
                        <div 
                          className="absolute inset-0 bg-black/50 hidden group-hover:flex items-center justify-center cursor-pointer"
                          onClick={() => fileInputRef.current?.click()}
                        >
                          <Camera className="w-5 h-5 text-white" />
                        </div>
                        <input 
                          type="file" 
                          ref={fileInputRef}
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleAvatarUpload(file);
                          }}
                          className="hidden" 
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-card m-4 mt-0 rounded-lg p-4 space-y-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-[12px] font-bold text-muted-foreground uppercase">Display Name</p>
                        {editingField === "name" ? (
                          <Input 
                            value={adminProfileData.name} 
                            onChange={e => setAdminProfileData({...adminProfileData, name: e.target.value})}
                            className="bg-muted border-none h-8 mt-1 text-foreground text-sm"
                          />
                        ) : (
                          <p className="text-foreground text-[15px]">{user?.name}</p>
                        )}
                      </div>
                      {editingField === "name" ? (
                        <div className="flex gap-2">
                          <Button size="sm" variant="ghost" onClick={() => setEditingField(null)} className="h-8 text-sm text-muted-foreground hover:text-foreground">Cancel</Button>
                          <Button size="sm" onClick={handleUpdateAdminProfile} disabled={savingAdminProfile} className="h-8 text-sm">Save</Button>
                        </div>
                      ) : (
                        <Button size="sm" variant="secondary" className="h-8 text-sm font-medium" onClick={() => setEditingField("name")}>Edit</Button>
                      )}
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-[12px] font-bold text-muted-foreground uppercase">Email</p>
                        <p className="text-foreground text-[15px]">{user?.email}</p>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <div className="flex-1 mr-4">
                        <p className="text-[12px] font-bold text-muted-foreground uppercase">Bio</p>
                        {editingField === "bio" ? (
                          <textarea 
                            value={adminProfileData.bio} 
                            onChange={e => setAdminProfileData({...adminProfileData, bio: e.target.value})}
                            className="w-full bg-muted rounded-md p-2 text-sm text-foreground resize-none h-20 mt-1 focus:outline-none focus:ring-1 focus:ring-primary"
                          />
                        ) : (
                          <p className="text-foreground text-[15px] truncate">{adminProfileData.bio || "No bio set."}</p>
                        )}
                      </div>
                      {editingField === "bio" ? (
                        <div className="flex gap-2 self-start mt-4">
                          <Button size="sm" variant="ghost" onClick={() => setEditingField(null)} className="h-8 text-sm text-muted-foreground hover:text-foreground">Cancel</Button>
                          <Button size="sm" onClick={handleUpdateAdminProfile} disabled={savingAdminProfile} className="h-8 text-sm">Save</Button>
                        </div>
                      ) : (
                        <Button size="sm" variant="secondary" className="h-8 text-sm font-medium" onClick={() => setEditingField("bio")}>Edit</Button>
                      )}
                    </div>
                  </div>
                </div>

                <div className="h-[1px] bg-border my-8" />
                
                <h2 className="text-[20px] font-bold text-foreground mb-5">Password and Authentication</h2>
                <div className="space-y-4">
                  <form onSubmit={handlePasswordChange} className="space-y-4 bg-card p-5 rounded-lg border border-border">
                    <div>
                      <p className="text-[12px] font-bold text-muted-foreground uppercase mb-2">Current Password</p>
                      <Input 
                        type="password"
                        value={passwordData.currentPassword}
                        onChange={e => setPasswordData({...passwordData, currentPassword: e.target.value})}
                        className="bg-muted border-none text-foreground focus-visible:ring-1 focus-visible:ring-primary"
                      />
                    </div>
                    <div>
                      <p className="text-[12px] font-bold text-muted-foreground uppercase mb-2">New Password</p>
                      <Input 
                        type="password"
                        value={passwordData.newPassword}
                        onChange={e => setPasswordData({...passwordData, newPassword: e.target.value})}
                        className="bg-muted border-none text-foreground focus-visible:ring-1 focus-visible:ring-primary"
                      />
                    </div>
                    <div>
                      <p className="text-[12px] font-bold text-muted-foreground uppercase mb-2">Confirm New Password</p>
                      <Input 
                        type="password"
                        value={passwordData.confirmPassword}
                        onChange={e => setPasswordData({...passwordData, confirmPassword: e.target.value})}
                        className="bg-muted border-none text-foreground focus-visible:ring-1 focus-visible:ring-primary"
                      />
                    </div>
                    <Button 
                      type="submit" 
                      disabled={updatingPassword}
                      className="w-full md:w-auto mt-2"
                    >
                      {updatingPassword ? "Updating Password..." : "Update Password"}
                    </Button>
                  </form>
                </div>
              </div>
            )}

            {/* 2. System Overview */}
            {activeTab === "overview" && (
              <div className="animate-in fade-in duration-200">
                <div className="flex justify-between items-center mb-5">
                  <h2 className="text-[20px] font-bold text-foreground">System Overview</h2>
                  <Button 
                    onClick={() => loadSystemStatus(false)} 
                    disabled={loadingStatus}
                    variant="secondary"
                    className="h-8 px-3"
                  >
                    <RefreshCw className={cn("w-4 h-4 mr-2", loadingStatus && "animate-spin")} /> Refresh
                  </Button>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-card p-4 rounded-lg border border-border">
                    <div className="flex items-center gap-2 mb-2 text-green-500">
                      <Server className="w-4 h-4" />
                      <span className="text-[11px] font-bold uppercase tracking-wide">Server Status</span>
                    </div>
                    <div className="text-[24px] font-bold text-foreground flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse" />
                      {systemStatus?.status || "HEALTHY"}
                    </div>
                    <p className="text-[12px] text-muted-foreground mt-1">Uptime: {systemStatus ? formatUptime(systemStatus.uptimeSeconds) : "..."}</p>
                  </div>

                  <div className="bg-card p-4 rounded-lg border border-border">
                    <div className="flex items-center gap-2 mb-2 text-blue-500">
                      <Database className="w-4 h-4" />
                      <span className="text-[11px] font-bold uppercase tracking-wide">DB Latency</span>
                    </div>
                    <div className="text-[24px] font-bold text-foreground">
                      {systemStatus?.dbLatencyMs ?? 0} ms
                    </div>
                    <p className="text-[12px] text-muted-foreground mt-1">MySQL response time</p>
                  </div>

                  <div className="bg-card p-4 rounded-lg border border-border">
                    <div className="flex items-center gap-2 mb-2 text-primary">
                      <Activity className="w-4 h-4" />
                      <span className="text-[11px] font-bold uppercase tracking-wide">Environment</span>
                    </div>
                    <div className="text-[24px] font-bold text-foreground uppercase">
                      {systemStatus?.env || "DEV"}
                    </div>
                    <p className="text-[12px] text-muted-foreground mt-1">Node {systemStatus?.nodeVersion || "Unknown"}</p>
                  </div>

                  <div className="bg-card p-4 rounded-lg border border-border">
                    <div className="flex items-center gap-2 mb-2 text-red-500">
                      <ShieldAlert className="w-4 h-4" />
                      <span className="text-[11px] font-bold uppercase tracking-wide">Blocked</span>
                    </div>
                    <div className="text-[24px] font-bold text-foreground">
                      {systemStatus?.metrics.blockedUsers ?? 0}
                    </div>
                    <p className="text-[12px] text-muted-foreground mt-1">Security lockouts</p>
                  </div>
                </div>

                <h3 className="text-[12px] font-bold text-muted-foreground uppercase mb-4 mt-8">Database Records</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {[
                    { label: "Students", val: systemStatus?.metrics.users ?? 0 },
                    { label: "Courses", val: systemStatus?.metrics.courses ?? 0 },
                    { label: "Enrollments", val: systemStatus?.metrics.enrollments ?? 0 },
                    { label: "Lesson Logs", val: systemStatus?.metrics.lessonProgress ?? 0 },
                    { label: "Live Sessions", val: systemStatus?.metrics.liveSessions ?? 0 },
                    { label: "Certificates", val: systemStatus?.metrics.certificates ?? 0 },
                  ].map((m) => (
                    <div key={m.label} className="bg-card p-3 rounded-lg border border-border text-center">
                      <p className="text-[11px] font-bold text-muted-foreground uppercase">{m.label}</p>
                      <p className="text-[18px] font-bold text-foreground mt-1">{m.val.toLocaleString()}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 3. System Optimization */}
            {activeTab === "optimization" && (
              <div className="animate-in fade-in duration-200">
                <h2 className="text-[20px] font-bold text-foreground mb-5">System Optimization</h2>
                
                <div className="bg-card rounded-xl p-6 border border-border flex flex-col items-center text-center">
                  <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-4">
                    <Zap className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold text-foreground mb-2">MySQL Database Vacuum</h3>
                  <p className="text-[14px] text-muted-foreground mb-6 max-w-md">
                    Re-index all database tables (users, courses, enrollments) and reclaim unused storage safely without blocking.
                  </p>
                  <Button 
                    onClick={handleOptimizeSystem}
                    disabled={optimizing}
                  >
                    <Zap className={cn("w-4 h-4 mr-2", optimizing && "animate-spin")} />
                    {optimizing ? "Executing..." : "Run Optimization"}
                  </Button>
                </div>
              </div>
            )}

            {/* 4. Logs & Activity */}
            {activeTab === "attempts" && (
              <div className="animate-in fade-in duration-200">
                <h2 className="text-[20px] font-bold text-foreground mb-5">User Attempts</h2>
                
                <div className="bg-card rounded-xl border border-border overflow-hidden">
                  <div className="p-4 bg-muted border-b border-border flex justify-between items-center">
                    <span className="text-[12px] font-bold text-muted-foreground uppercase">Recent Logins</span>
                  </div>
                  
                  <div className="divide-y divide-border max-h-[500px] overflow-y-auto custom-scrollbar">
                    {(systemStatus?.recentAttempts || []).map((attempt) => (
                      <div key={attempt.id} className="flex items-center justify-between p-4 hover:bg-muted/50 transition-colors">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-muted overflow-hidden flex items-center justify-center text-foreground">
                            {attempt.profilePicture ? (
                              <img src={attempt.profilePicture} alt={attempt.name} className="w-full h-full object-cover" />
                            ) : (
                              <UserRound className="w-5 h-5 text-muted-foreground" />
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="text-[15px] font-bold text-foreground">{attempt.name}</p>
                              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-primary/20 text-primary-foreground">
                                {attempt.role}
                              </span>
                            </div>
                            <p className="text-[12px] text-muted-foreground">{attempt.email}</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-4">
                          <Button
                            size="sm"
                            onClick={() => handleToggleBlock(attempt.id, attempt.isBlocked)}
                            className={cn(
                              "h-8 px-3 text-[12px] font-bold hover:opacity-80 transition-opacity",
                              attempt.isBlocked
                                ? "bg-red-500/20 text-red-500 hover:bg-red-500/30"
                                : "bg-green-500/20 text-green-500 hover:bg-green-500/30"
                            )}
                            variant="ghost"
                          >
                            {attempt.isBlocked ? (
                              <><UserX className="w-3.5 h-3.5 mr-1" /> Blocked</>
                            ) : (
                              <><UserCheck className="w-3.5 h-3.5 mr-1" /> Active</>
                            )}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 5. Communications */}
            {activeTab === "announcement" && (
              <div className="animate-in fade-in duration-200">
                <h2 className="text-[20px] font-bold text-foreground mb-5">Broadcast Announcement</h2>
                
                <div className="bg-card rounded-xl p-6 border border-border">
                  <p className="text-[14px] text-muted-foreground mb-6">
                    Send a system-wide announcement banner to all registered users.
                  </p>

                  <form onSubmit={handlePostAnnouncement} className="space-y-4">
                    <div>
                      <p className="text-[12px] font-bold text-muted-foreground uppercase mb-2">Announcement Title *</p>
                      <Input
                        value={announcement.title}
                        onChange={(e) => setAnnouncement({ ...announcement, title: e.target.value })}
                        placeholder="e.g. Scheduled Maintenance"
                        className="bg-muted border-none text-foreground focus-visible:ring-1 focus-visible:ring-primary"
                        required
                      />
                    </div>

                    <div>
                      <p className="text-[12px] font-bold text-muted-foreground uppercase mb-2">Type / Severity</p>
                      <select
                        value={announcement.type}
                        onChange={(e) => setAnnouncement({ ...announcement, type: e.target.value })}
                        className="w-full h-10 px-3 bg-muted border-none text-foreground rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                      >
                        <option value="info">General Info</option>
                        <option value="warning">Warning / Maintenance</option>
                        <option value="success">Success / Release</option>
                      </select>
                    </div>

                    <div>
                      <p className="text-[12px] font-bold text-muted-foreground uppercase mb-2">Content *</p>
                      <textarea
                        value={announcement.content}
                        onChange={(e) => setAnnouncement({ ...announcement, content: e.target.value })}
                        placeholder="Write the full announcement message..."
                        rows={5}
                        className="w-full bg-muted rounded-md p-3 text-sm text-foreground resize-none focus:outline-none focus:ring-1 focus:ring-primary"
                        required
                      />
                    </div>

                    <Button
                      type="submit"
                      disabled={postingAnnouncement}
                      className="w-full"
                    >
                      <Megaphone className="w-4 h-4 mr-2" />
                      {postingAnnouncement ? "Broadcasting..." : "Broadcast Announcement"}
                    </Button>
                  </form>
                </div>
              </div>
            )}

          </div>
        </div>
      </main>
      </div>
      <Footer />
    </div>
  );
}

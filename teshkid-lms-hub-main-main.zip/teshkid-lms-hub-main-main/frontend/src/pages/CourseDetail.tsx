import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { CryptoPaymentModal } from "@/components/payment/CryptoPaymentModal";
import api from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import {
  Clock,
  Users,
  BookOpen,
  Play,
  CheckCircle2,
  FileText,
  HelpCircle,
  Code,
  Star,
  Award,
  Globe,
  Wallet,
  ArrowLeft,
  Loader2,
} from "lucide-react";
import { Linkify } from "@/components/ui/Linkify";

const lessonTypeIcons: any = {
  video: Play,
  quiz: HelpCircle,
  exercise: Code,
  pdf: FileText,
};

export default function CourseDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [course, setCourse] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isEnrolled, setIsEnrolled] = useState(false);
  const [enrollmentStatus, setEnrollmentStatus] = useState<string | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [enrollmentMessage, setEnrollmentMessage] = useState("");
  const [showEnrollModal, setShowEnrollModal] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    fetchCourseData();
  }, [id, user]);

  const fetchCourseData = async () => {
    try {
      setLoading(true);
      // Fetch course details from public endpoint
      const courseRes = await api.get(`/courses/${id}`);
      setCourse(courseRes.data);

      // Check enrollment if logged in
      if (user) {
        try {
          const statusRes = await api.get(`/student/course/${id}/status`);
          if (statusRes.data.isEnrolled) {
            setIsEnrolled(true);
            setEnrollmentStatus(statusRes.data.status);
          } else {
            setIsEnrolled(false);
            setEnrollmentStatus(null);
          }
        } catch (e) {
          console.error("Enrollment check failed", e);
        }
      }
    } catch (error) {
      console.error(error);
      toast.error("Could not load course details");
    } finally {
      setLoading(false);
    }
  };

  const handleEnroll = async () => {
    if (!user) {
      toast.error("Please login to enroll");
      navigate("/student/login");
      return;
    }

    if (user.role === "ADMIN") {
      toast.error("Admins cannot enroll in courses");
      return;
    }

    try {
      setActionLoading(true);
      await api.post(`/student/enroll/${id}`, {
        studentMessage: enrollmentMessage,
      });
      toast.success("Enrollment request sent! Waiting for admin approval.");
      setIsEnrolled(true);
      setEnrollmentStatus("PENDING");
      setShowEnrollModal(false);
    } catch (error: any) {
      if (
        error.response?.status === 400 &&
        error.response.data.message.includes("Already")
      ) {
        setIsEnrolled(true);
        setEnrollmentStatus("APPROVED");
        toast.info("You are already enrolled.");
      } else {
        console.error(error);
        toast.error("Enrollment failed. Please try again.");
      }
    } finally {
      setActionLoading(false);
    }
  };

  const levelColors: any = {
    Beginner: "success",
    Intermediate: "warning",
    Advanced: "destructive",
  };

  // Safe checks for potentially missing data
  const modules = course?.modules || [];
  const lessonsCount = modules.reduce(
    (acc: number, m: any) => acc + (m.lessons?.length || 0),
    0,
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-background pt-20 text-center">
        Course not found
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="pt-32 sm:pt-40 pb-20">
        {/* Hero Section */}
        <section className="relative bg-card/50 border-b border-border/50">
          <div className="container mx-auto px-4 py-12">
            <Link
              to="/courses"
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Courses
            </Link>

            {course.bannerUrl && (
              <div className="absolute inset-0 z-0 overflow-hidden opacity-20">
                <img
                  src={course.bannerUrl}
                  className="w-full h-full object-cover blur-sm"
                  alt="Banner"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
              </div>
            )}

            <div className="grid lg:grid-cols-3 gap-8 relative z-10">
              {/* Course Info */}
              <div className="lg:col-span-2">
                <div className="flex items-center gap-3 mb-4">
                  <Badge variant={levelColors[course.level] || "default"}>
                    {course.level}
                  </Badge>
                  <Badge variant="outline" className="gap-1">
                    <Star className="w-3 h-3 fill-warning text-warning" />
                    4.9 (2,340 reviews)
                  </Badge>
                </div>

                <h1 className="font-display text-3xl md:text-4xl font-bold mb-4">
                  {course.title}
                </h1>

                <p className="text-lg text-muted-foreground mb-6 whitespace-pre-wrap">
                  <Linkify text={course.description} />
                </p>

                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xl">
                    {course.instructor?.charAt(0) || "T"}
                  </div>
                  <div>
                    <p className="font-medium">{course.instructor}</p>
                    <p className="text-sm text-muted-foreground">
                      Lead Instructor
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-6 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    {course.duration || "Self-paced"}
                  </div>
                  <div className="flex items-center gap-2">
                    <BookOpen className="w-4 h-4" />
                    {modules.length} modules
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    {course.students || 0} students
                  </div>
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    English
                  </div>
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4" />
                    Certificate included
                  </div>
                </div>
              </div>

              {/* Enrollment Card */}
              <div className="lg:col-span-1">
                <Card variant="glass" className="sticky top-24">
                  <div className="aspect-video relative overflow-hidden rounded-t-xl bg-card">
                    {course.previewVideoUrl ? (
                      <video
                        src={course.previewVideoUrl}
                        poster={course.bannerUrl || course.thumbnail}
                        controls
                        className="w-full h-full object-cover"
                      />
                    ) : course.thumbnail ? (
                      <img
                        src={course.thumbnail}
                        alt={course.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full text-muted-foreground">
                        No Preview
                      </div>
                    )}
                  </div>
                  <CardContent className="p-6">
                    <div className="flex items-baseline gap-2 mb-4">
                      <span className="text-4xl font-display font-bold">
                        {course.price > 0 ? `$${course.price}` : "Free"}
                      </span>
                      {course.cryptoPrice && (
                        <span className="text-muted-foreground">
                          or {course.cryptoPrice}
                        </span>
                      )}
                    </div>

                    {isEnrolled ? (
                      enrollmentStatus === "PENDING" ? (
                        <Button
                          variant="secondary"
                          size="lg"
                          className="w-full mb-3 gap-2 cursor-default"
                          disabled
                        >
                          <Clock className="w-5 h-5" />
                          Pending Approval
                        </Button>
                      ) : (
                        <Button
                          variant="success"
                          size="lg"
                          className="w-full mb-3 gap-2"
                          onClick={() => navigate(`/courses/${id}/learn`)}
                        >
                          <Play className="w-5 h-5" />
                          Continue Learning
                        </Button>
                      )
                    ) : (
                      <>
                        {user ? (
                          user.role === "ADMIN" ? (
                            <Button
                              variant="hero"
                              size="lg"
                              className="w-full mb-3 gap-2"
                              onClick={() => navigate(`/courses/${id}/learn`)}
                            >
                              <Play className="w-5 h-5" />
                              View Course Content (Admin)
                            </Button>
                          ) : (
                            <>
                              <Dialog
                                open={showEnrollModal}
                                onOpenChange={setShowEnrollModal}
                              >
                                <DialogTrigger asChild>
                                  <Button
                                    variant="hero"
                                    size="lg"
                                    className="w-full mb-3"
                                    disabled={actionLoading}
                                  >
                                    {actionLoading ? (
                                      <Loader2 className="w-4 h-4 animate-spin" />
                                    ) : (
                                      "Enroll Now"
                                    )}
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="sm:max-w-[500px]">
                                  <DialogHeader>
                                    <DialogTitle className="text-2xl font-display">
                                      Confirm Enrollment
                                    </DialogTitle>
                                    <p className="text-sm text-muted-foreground mt-2">
                                      You're about to enroll in <span className="font-semibold text-foreground">"{course.title}"</span>
                                    </p>
                                  </DialogHeader>
                                  <div className="py-4 space-y-4">
                                    <div className="space-y-2">
                                      <label className="text-sm font-medium">
                                        Quick note for the instructor (Optional)
                                      </label>
                                      <Textarea
                                        placeholder="Any questions or special requirements? (optional)"
                                        value={enrollmentMessage}
                                        onChange={(e) =>
                                          setEnrollmentMessage(e.target.value)
                                        }
                                        className="min-h-[80px] resize-none"
                                      />
                                    </div>
                                    <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                                      <div className="flex items-start gap-3">
                                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                                          <CheckCircle2 className="w-5 h-5 text-primary" />
                                        </div>
                                        <div className="space-y-1">
                                          <p className="text-sm font-medium">What happens next?</p>
                                          <p className="text-xs text-muted-foreground">
                                            Your enrollment will be approved automatically or reviewed by the instructor. You'll get instant access to all course materials once approved.
                                          </p>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <DialogFooter>
                                    <Button
                                      variant="ghost"
                                      onClick={() => setShowEnrollModal(false)}
                                    >
                                      Cancel
                                    </Button>
                                    <Button
                                      variant="hero"
                                      onClick={handleEnroll}
                                      disabled={actionLoading}
                                    >
                                      {actionLoading ? (
                                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                                      ) : null}
                                      Confirm Enrollment
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                              {course.price > 0 && (
                                <Button
                                  variant="outline"
                                  size="lg"
                                  className="w-full gap-2"
                                  onClick={() => setShowPaymentModal(true)}
                                >
                                  <Wallet className="w-4 h-4" />
                                  Pay with Crypto
                                </Button>
                              )}
                            </>
                          )
                        ) : (
                          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-3">
                            <p className="text-blue-900 font-semibold mb-4">
                              Sign in to enroll in this course
                            </p>
                            <Button
                              variant="hero"
                              size="lg"
                              className="w-full mb-3"
                              onClick={() => navigate("/student/login")}
                            >
                              Sign In
                            </Button>
                            <p className="text-sm text-blue-800 text-center">
                              Don't have an account?{" "}
                              <button
                                onClick={() =>
                                  navigate("/student/login?mode=signup")
                                }
                                className="font-semibold hover:underline"
                              >
                                Sign up here
                              </button>
                            </p>
                          </div>
                        )}
                      </>
                    )}

                    <div className="mt-6 pt-6 border-t border-border/50 space-y-3 text-sm">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-success" />
                        Full lifetime access
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-success" />
                        Certificate of completion
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Course Content */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                {/* Course Curriculum */}
                <Card variant="glass">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>Course Curriculum</CardTitle>
                      <span className="text-sm text-muted-foreground">
                        {lessonsCount} lessons
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Accordion type="multiple" className="space-y-2">
                      {modules.map((module: any, index: number) => (
                        <AccordionItem
                          key={module.id}
                          value={module.id}
                          className="border border-border/50 rounded-lg px-4 data-[state=open]:bg-secondary/30"
                        >
                          <AccordionTrigger className="hover:no-underline py-4">
                            <div className="flex items-center gap-4 flex-1">
                              <div className="w-8 h-8 rounded-lg flex items-center justify-center text-sm font-semibold bg-secondary text-foreground">
                                {index + 1}
                              </div>
                              <div className="text-left flex-1">
                                <p className="font-medium">{module.title}</p>
                                <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                                  <Linkify text={module.description} />
                                </p>
                              </div>
                              <span className="text-sm text-muted-foreground">
                                {module.lessons?.length || 0} lessons
                              </span>
                            </div>
                          </AccordionTrigger>
                          <AccordionContent className="pb-4">
                            <div className="space-y-2 ml-12">
                              {module.lessons?.map((lesson: any) => {
                                const Icon =
                                  lessonTypeIcons[lesson.type] || Play;
                                return (
                                  <div
                                    key={lesson.id}
                                    className="flex items-center gap-3 p-3 rounded-lg transition-colors bg-secondary/50"
                                  >
                                    <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-secondary text-muted-foreground">
                                      <Icon className="w-4 h-4" />
                                    </div>
                                    <div className="flex-1">
                                      <p className="text-sm font-medium">
                                        {lesson.title}
                                      </p>
                                    </div>
                                    <span className="text-xs text-muted-foreground">
                                      {lesson.duration}
                                    </span>
                                  </div>
                                );
                              })}
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      ))}
                    </Accordion>
                  </CardContent>
                </Card>
              </div>

              {/* Requirements & Includes */}
              <div className="space-y-6">
                <Card variant="glass">
                  <CardHeader>
                    <CardTitle className="text-lg">Requirements</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {[
                      "No prior crypto knowledge required",
                      "Computer with internet access",
                      "Willingness to learn and experiment",
                    ].map((req, i) => (
                      <div key={i} className="flex items-start gap-2 text-sm">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2" />
                        {req}
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {user && course && (
          <CryptoPaymentModal
            isOpen={showPaymentModal}
            onClose={() => setShowPaymentModal(false)}
            onSuccess={handleEnroll}
            amount={course.price}
            courseTitle={course.title}
          />
        )}
      </main>

      <Footer />
    </div>
  );
}

import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import AdminBlogManager from "@/components/dashboard/AdminBlogManager";
import { Link } from "react-router-dom";
import { ArrowLeft, BookOpen } from "lucide-react";

export default function AdminBlog() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      <main className="flex-1 pt-24 pb-16">
        <div className="container mx-auto px-4 max-w-6xl">

          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-6">
            <Link to="/admin" className="hover:text-primary transition-colors flex items-center gap-1">
              <ArrowLeft className="w-3.5 h-3.5" /> Admin
            </Link>
            <span>/</span>
            <span className="text-foreground font-medium flex items-center gap-1">
              <BookOpen className="w-3.5 h-3.5" /> Blog Management
            </span>
          </div>

          <AdminBlogManager />
        </div>
      </main>

      <Footer />
    </div>
  );
}

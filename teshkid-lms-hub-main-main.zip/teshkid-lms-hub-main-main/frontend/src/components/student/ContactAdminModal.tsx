import { useState } from "react";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
    DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, MessageSquare, Send, X } from "lucide-react";
import { toast } from "sonner";
import api from "@/lib/api";
import { useAuth } from "@/context/AuthContext";

interface ContactAdminModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export function ContactAdminModal({ isOpen, onClose }: ContactAdminModalProps) {
    const { user } = useAuth();
    const [subject, setSubject] = useState("");
    const [message, setMessage] = useState("");
    const [loading, setLoading] = useState(false);

    const handleSend = async () => {
        if (!subject.trim() || !message.trim()) {
            toast.error("Please fill in all fields");
            return;
        }

        try {
            setLoading(true);
            await api.post("/messages", {
                subject,
                message
            });
            toast.success("Message delivered successfully!");
            setSubject("");
            setMessage("");
            onClose();
        } catch (error) {
            console.error(error);
            toast.error("Failed to send message. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={(val) => !loading && onClose()}>
            <DialogContent className="sm:max-w-xl p-0 overflow-hidden border-none rounded-[32px] shadow-2xl bg-card">
                <div className="bg-primary p-8 text-white relative">
                    <div className="absolute top-0 right-0 p-12 opacity-10 pointer-events-none">
                        <MessageSquare className="w-24 h-24" />
                    </div>
                    <DialogTitle className="text-3xl font-black">Get in Touch</DialogTitle>
                    <DialogDescription className="text-primary-foreground/80 mt-2 font-medium">
                        Our support team usually responds within a few hours.
                    </DialogDescription>
                </div>

                <div className="p-8 space-y-6">
                    <div className="space-y-2">
                        <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Inquiry Topic</Label>
                        <Input
                            placeholder="Briefly state your concern..."
                            value={subject}
                            onChange={(e) => setSubject(e.target.value)}
                            disabled={loading}
                            className="bg-muted/40 border-border/50 h-12 rounded-xl focus:bg-background transition-colors font-medium"
                        />
                    </div>

                    <div className="space-y-2">
                        <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Detailed Message</Label>
                        <Textarea
                            placeholder="Describe your issue or question in detail..."
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                            disabled={loading}
                            className="min-h-[160px] bg-muted/40 border-border/50 rounded-2xl p-4 focus:bg-background transition-colors font-medium resize-none shadow-inner"
                        />
                    </div>
                </div>

                <DialogFooter className="p-8 bg-muted/10 border-t border-border/30 gap-3">
                    <Button variant="ghost" onClick={onClose} disabled={loading} className="rounded-xl font-bold px-8 h-12">
                        Dismiss
                    </Button>
                    <Button
                        onClick={handleSend}
                        disabled={loading}
                        className="rounded-2xl bg-primary hover:bg-primary/90 text-white font-black px-10 h-12 shadow-lg shadow-primary/20 transition-all active:scale-95 group"
                    >
                        {loading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Send className="w-5 h-5 mr-3 group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />}
                        Send Inqury
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

import { useState } from "react";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
    DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Copy, Check, Wallet, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface CryptoPaymentModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSuccess: () => void;
    amount: number;
    courseTitle: string;
}

const WALLETS = {
    // BTC: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
    // ETH: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
    // USDT: "TX9K2qY4rC0mC8t9Z0p1x7Z5v3n8m2k5j4l",
};

export function CryptoPaymentModal({
    isOpen,
    onClose,
    onSuccess,
    amount,
    courseTitle,
}: CryptoPaymentModalProps) {
    const [currency, setCurrency] = useState<keyof typeof WALLETS>("BTC");
    const [loading, setLoading] = useState(false);
    const [transactionId, setTransactionId] = useState("");

    const handleCopy = (text: string) => {
        navigator.clipboard.writeText(text);
        toast.success("Address copied to clipboard");
    };

    const handlePayment = async () => {
        if (!transactionId) {
            toast.error("Please enter your transaction ID/Hash for verification");
            return;
        }

        setLoading(true);
        // Simulate verification delay
        setTimeout(() => {
            setLoading(false);
            onSuccess();
            onClose();
        }, 2000);
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-md">
                <DialogHeader>
                    <DialogTitle>Pay with Crypto</DialogTitle>
                    <DialogDescription>
                        Send {currency === "USDT" ? "$" : ""}
                        {amount} worth of {currency} to enroll in "{courseTitle}".
                    </DialogDescription>
                </DialogHeader>

                <div className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label>Select Cryptocurrency</Label>
                        <Select
                            value={currency}
                            onValueChange={(v) => setCurrency(v as keyof typeof WALLETS)}
                        >
                            <SelectTrigger>
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                                <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                                <SelectItem value="USDT">Tether (USDT - TRC20)</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="p-4 bg-secondary rounded-lg space-y-3">
                        <div className="flex justify-center mb-2">
                            {/* Placeholder for QR Code - using a generated URL API if needed or just styling */}
                            <div className="bg-white p-2 rounded">
                                <img
                                    src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${WALLETS[currency]}`}
                                    alt="QR Code"
                                    className="w-32 h-32"
                                />
                            </div>
                        </div>
                        <div className="space-y-1">
                            <Label className="text-xs text-muted-foreground">
                                Send to this {currency} Address
                            </Label>
                            <div className="flex items-center gap-2">
                                <code className="flex-1 p-2 bg-background rounded border text-xs break-all">
                                    {WALLETS[currency]}
                                </code>
                                <Button
                                    size="icon"
                                    variant="ghost"
                                    onClick={() => handleCopy(WALLETS[currency])}
                                    className="h-8 w-8"
                                >
                                    <Copy className="w-4 h-4" />
                                </Button>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label>Transaction Hash / ID (For Verification)</Label>
                        <Input
                            placeholder="Enter TxID (e.g. 0x...)"
                            value={transactionId}
                            onChange={(e) => setTransactionId(e.target.value)}
                        />
                        <p className="text-xs text-muted-foreground">
                            We verify transactions automatically within 10-15 minutes usually, but this instant verification mocks that process.
                        </p>
                    </div>
                </div>

                <DialogFooter>
                    <Button variant="outline" onClick={onClose} disabled={loading}>
                        Cancel
                    </Button>
                    <Button onClick={handlePayment} disabled={loading} className="gap-2">
                        {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                        I Have Sent Payment
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

import { Link } from "react-router-dom";
import SocialIcons from "./SocialIcons";

const LOGO_URL = "/logo.png";

const footerLinks = {
  platform: [
    { label: "Home",    href: "/",       external: false },
    { label: "Courses", href: "/courses", external: false },
    { label: "Blog",    href: "/blog",    external: false },
  ],
  resources: [
    { label: "Documentation", href: "https://docs.teshkidiscrypto.com", external: true },
    { label: "Community",     href: "https://t.me/teshkidiscrypto",     external: true },
  ],
  company: [
    { label: "About",   href: "/#about",   external: false },
    { label: "Contact", href: "/#contact", external: false },
  ],
  legal: [
    { label: "Privacy", href: "/privacy", external: false },
    { label: "Terms",   href: "/terms",   external: false },
  ],
};

export function Footer() {
  return (
    <footer className="border-t border-border/50 bg-card/50">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">

          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <img src={LOGO_URL} alt="Teshkid Is Crypto" className="h-[90px] w-auto" />
            </Link>
            <p className="text-sm text-muted-foreground mb-4">
              Master crypto and blockchain with world-class education.
            </p>
            <SocialIcons />
          </div>

          {/* Platform */}
          <div>
            <h4 className="font-bold mb-4 text-foreground text-sm uppercase tracking-wider">Platform</h4>
            <ul className="space-y-2">
              {footerLinks.platform.map((link) => (
                <li key={link.label}>
                  <Link to={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="font-bold mb-4 text-foreground text-sm uppercase tracking-wider">Resources</h4>
            <ul className="space-y-2">
              {footerLinks.resources.map((link) => (
                <li key={link.label}>
                  <a href={link.href} target="_blank" rel="noopener noreferrer"
                    className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-bold mb-4 text-foreground text-sm uppercase tracking-wider">Company</h4>
            <ul className="space-y-2">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <Link to={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-bold mb-4 text-foreground text-sm uppercase tracking-wider">Legal</h4>
            <ul className="space-y-2">
              {footerLinks.legal.map((link) => (
                <li key={link.label}>
                  <Link to={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border/50 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Teshkid Is Crypto. All rights reserved.
          </p>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
            All systems operational
          </div>
        </div>
      </div>
    </footer>
  );
}

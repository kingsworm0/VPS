import { ReactNode, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import {
  LayoutDashboard,
  BookOpen,
  Award,
  Activity,
  Video,
  Trophy,
  LogOut,
  Menu,
  X,
  UserRound,
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { cn } from "@/lib/utils";

const NAV_LINKS = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, to: "/dashboard" },
  { id: "my-courses", label: "My Courses", icon: BookOpen, to: "/student/my-courses" },
  { id: "achievements", label: "Achievements", icon: Award, to: "/student/achievements" },
  { id: "activity", label: "Activity", icon: Activity, to: "/student/activity" },
  { id: "live-sessions", label: "Live Sessions", icon: Video, to: "/student/live-sessions" },
  { id: "leaderboard", label: "Leaderboard", icon: Trophy, to: "/student/leaderboard" },
];

interface DashboardLayoutProps {
  children: ReactNode;
  xp?: number;
  level?: number;
  xpProgress?: number;
}

export function DashboardLayout({ children, xp = 0, level = 1, xpProgress = 0 }: DashboardLayoutProps) {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate("/student/login");
  };

  const SidebarContent = () => (
    <>
      {/* User mini card */}
      <div className="p-4 border-b border-border/40 shrink-0">
        <div className="flex items-center gap-3">
          <div className="relative shrink-0">
            <div className="w-10 h-10 rounded-full overflow-hidden bg-primary/10 flex items-center justify-center border-2 border-primary/30 shadow-lg">
              {user?.profilePicture ? (
                <img src={user.profilePicture} alt={user?.name} className="w-full h-full object-cover" />
              ) : (
                <UserRound className="w-5 h-5 text-primary" />
              )}
            </div>
            <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-primary flex items-center justify-center text-[9px] font-black text-white border-2 border-card">
              {level}
            </div>
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold text-foreground truncate">{user?.name}</p>
            <p className="text-[11px] text-muted-foreground">Level {level} · {xp} XP</p>
          </div>
        </div>
        <div className="mt-3">
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-primary rounded-full transition-all duration-500"
              style={{ width: `${Math.min(xpProgress, 100)}%` }}
            />
          </div>
          <div className="flex justify-between mt-1">
            <span className="text-[10px] text-muted-foreground">{xp} XP</span>
            <span className="text-[10px] text-muted-foreground">Lv.{level + 1}</span>
          </div>
        </div>
      </div>

      {/* Nav links */}
      <nav className="flex flex-col gap-0.5 p-2 flex-1 overflow-y-auto">
        {NAV_LINKS.map((link) => {
          const isActive = location.pathname === link.to;
          return (
            <Link
              key={link.id}
              to={link.to}
              onClick={() => setMobileOpen(false)}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all",
                isActive
                  ? "bg-primary text-primary-foreground shadow-md shadow-primary/30"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
              )}
            >
              <link.icon className="w-4 h-4 shrink-0" />
              {link.label}
            </Link>
          );
        })}
      </nav>

      <div className="p-2 border-t border-border/40 shrink-0">
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-all w-full"
        >
          <LogOut className="w-4 h-4 shrink-0" />
          Sign out
        </button>
      </div>
    </>
  );

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />

      <div className="flex flex-1 mt-16 flex-col md:flex-row min-h-[calc(100vh-4rem)]">
        {/* Mobile topbar below navbar */}
        <div className="md:hidden flex items-center justify-between px-4 py-2.5 border-b border-border/40 bg-card/80 backdrop-blur-sm sticky top-16 z-30 shrink-0 shadow-sm">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full overflow-hidden bg-primary/10 border border-primary/30 flex items-center justify-center shrink-0">
              {user?.profilePicture ? (
                <img src={user.profilePicture} alt={user?.name} className="w-full h-full object-cover" />
              ) : (
                <UserRound className="w-4 h-4 text-primary" />
              )}
            </div>
            <div>
              <p className="text-sm font-bold text-foreground leading-none">{user?.name}</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">Lv.{level} · {xp} XP</p>
            </div>
          </div>
          <button
            onClick={() => setMobileOpen(true)}
            className="p-2 -mr-2 rounded-lg hover:bg-muted transition-colors"
          >
            <Menu className="w-5 h-5 text-foreground" />
          </button>
        </div>

        {/* Mobile slide-in drawer */}
        {mobileOpen && (
          <div className="fixed inset-0 z-[60] flex md:hidden">
            {/* Backdrop */}
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setMobileOpen(false)}
            />
            {/* Drawer */}
            <div className="relative w-72 max-w-[85vw] h-full bg-card border-r border-border flex flex-col shadow-2xl animate-in slide-in-from-left duration-200">
              <div className="flex items-center justify-between px-4 pt-4 pb-2 border-b border-border/40">
                <p className="text-sm font-black text-foreground font-['Space_Grotesk']">Navigation</p>
                <button
                  onClick={() => setMobileOpen(false)}
                  className="p-1.5 rounded-lg hover:bg-muted transition-colors"
                >
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
              <SidebarContent />
            </div>
          </div>
        )}

        {/* Desktop Sidebar */}
        <aside className="hidden md:flex flex-col w-[260px] shrink-0 border-r border-border/60 bg-card/30 backdrop-blur-sm sticky top-16 h-[calc(100vh-4rem)] overflow-hidden shadow-sm">
          <SidebarContent />
        </aside>

        {/* Main */}
        <main className="flex-1 min-w-0 p-4 md:p-6 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

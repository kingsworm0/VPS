import React from "react";
import {
  ExternalLink,
  Send,
  Instagram,
  Twitter,
  Youtube,
  MessageCircle,
  TreePine,
  TrendingUp,
  Globe
} from "lucide-react";
// Import Si icons if we had them, but let's stick to Lucide or keep working ones.
// For Binance/Bybit/Deriv which are niche, we can use a generic icon or keep trying SimpleIcons with correct slugs.
// Actually, simpleicons.org/bybit should work.

type SocialLink = {
  name: string;
  href: string;
  icon: React.ElementType;
};

export const socialLinks: SocialLink[] = [
  {
    name: "Linktree",
    href: "https://linktr.ee/teshkidiscrypto",
    icon: TreePine,
  },
  {
    name: "Binance",
    href: "https://accounts.binance.com/en/register?ref=M7D0UMQ3",
    icon: TrendingUp,
  },
  {
    name: "Bybit",
    href: "https://partner.bybit.com/b/57182",
    icon: TrendingUp,
  },
  {
    name: "Deriv",
    href: "https://track.deriv.com/_Asi2xc83uh62vdm9PpHVCmNd7ZgqdRLk/1",
    icon: TrendingUp,
  },
  {
    name: "Telegram",
    href: "https://t.me/sAUHqlU5EQthYzI0",
    icon: Send,
  },
  {
    name: "Instagram",
    href: "https://instagram.com/teshkid_is_crypto",
    icon: Instagram,
  },
  {
    name: "WhatsApp",
    href: "https://chat.whatsapp.com/CLUmWSbXDNA0cEOFuL55wk",
    icon: MessageCircle,
  },
  {
    name: "Twitter",
    href: "https://t.co/qBOFcVzrWR",
    icon: Twitter,
  },
  {
    name: "YouTube",
    href: "https://www.youtube.com/@teshkidfx",
    icon: Youtube,
  },
];

export function SocialIcons({ className = "" }: { className?: string }) {
  return (
    <div className={`flex flex-wrap gap-3 ${className}`}>
      {socialLinks.map((s) => {
        const Icon = s.icon;
        return (
          <a
            key={s.name}
            href={s.href}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={s.name}
            className="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center hover:bg-primary/20 hover:text-primary transition-all hover:scale-110"
          >
            <Icon className="w-5 h-5" />
          </a>
        );
      })}
    </div>
  );
}

export default SocialIcons;

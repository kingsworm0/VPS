import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, X, BookOpen, LayoutDashboard, FileText, MessageSquare, User as UserIcon, LogOut, Settings, Home } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface NavLink {
  href: string;
  label: string;
  icon: any;
  protected?: boolean;
  adminOnly?: boolean;
}

const navLinks: NavLink[] = [
  { href: "/", label: "Home", icon: Home },
  { href: "/courses", label: "Courses", icon: BookOpen },
  { href: "/blog", label: "Blog", icon: FileText },
  {
    href: "/dashboard",
    label: "Dashboard",
    icon: LayoutDashboard,
    protected: true,
  },
  {
    href: "/student/messages",
    label: "Inbox",
    icon: MessageSquare,
    protected: true,
  },
  {
    href: "/admin/messages",
    label: "Admin Inbox",
    icon: MessageSquare,
    protected: true,
    adminOnly: true,
  },
];

const LOGO_URL = "/logo.png";

import { ContactAdminModal } from "@/components/student/ContactAdminModal";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const location = useLocation();
  const { user } = useAuth();

  const filteredLinks = navLinks.filter((link) => {
    if (user?.role === "ADMIN") {
      return link.href === "/" || link.href === "/courses" || link.href === "/blog" || link.href === "/admin" || link.href === "/admin/messages" || link.href === "/admin/blog";
    }
    return (!link.protected || user) && !link.adminOnly;
  });

  const handleLogout = () => {
    window.localStorage.removeItem("token");
    window.location.href = "/";
  };

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 h-16 border-b border-border/50 bg-background/95 backdrop-blur-xl">
        <div className="container mx-auto px-4 h-full">
          <div className="flex h-16 items-center justify-between">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 group">
              <img
                src={LOGO_URL}
                alt="Teshkid Logo"
                className="h-12 md:h-14 w-auto max-h-14 object-contain group-hover:scale-105 transition-transform"
              />
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1">
              {filteredLinks.map((link) => (
                <Link key={link.href} to={link.href}>
                  <Button
                    variant="ghost"
                    className={cn(
                      "gap-2",
                      location.pathname === link.href &&
                      "bg-secondary text-primary",
                    )}
                  >
                    <link.icon className="w-4 h-4" />
                    {link.label}
                  </Button>
                </Link>
              ))}

            </div>

            {/* Auth Buttons */}
            <div className="hidden md:flex items-center gap-3">
              {user ? (
                <div className="flex items-center gap-4">
                  {user.role === "ADMIN" && (
                    <Link to="/admin">
                      <Button variant="outline" size="sm">
                        Admin
                      </Button>
                    </Link>
                  )}

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button className="relative w-10 h-10 rounded-full border-2 border-primary/20 overflow-hidden hover:border-primary/50 transition-colors focus:outline-none ring-offset-background focus:ring-2 focus:ring-primary/20">
                        {user.profilePicture ? (
                          <img
                            src={user.profilePicture}
                            alt={user.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="bg-primary/10 w-full h-full flex items-center justify-center text-primary">
                            <UserIcon className="w-5 h-5" />
                          </div>
                        )}
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56">
                      <DropdownMenuLabel>
                        <div className="flex flex-col space-y-1">
                          <p className="text-sm font-medium leading-none">{user.name}</p>
                          <p className="text-xs leading-none text-muted-foreground">
                            {user.email}
                          </p>
                        </div>
                      </DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <Link to={user.role === "ADMIN" ? "/admin/profile" : "/student/profile"}>
                        <DropdownMenuItem className="cursor-pointer">
                          <UserIcon className="mr-2 h-4 w-4" />
                          <span>{user.role === "ADMIN" ? "My Account" : "My Profile"}</span>
                        </DropdownMenuItem>
                      </Link>
                      <Link to={user.role === "ADMIN" ? "/admin" : "/dashboard"}>
                        <DropdownMenuItem className="cursor-pointer">
                          <LayoutDashboard className="mr-2 h-4 w-4" />
                          <span>Dashboard</span>
                        </DropdownMenuItem>
                      </Link>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        className="cursor-pointer text-destructive focus:text-destructive"
                        onClick={handleLogout}
                      >
                        <LogOut className="mr-2 h-4 w-4" />
                        <span>Logout</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              ) : (
                <>
                  <Link to="/student/login">
                    <Button variant="ghost" size="sm">
                      Sign In
                    </Button>
                  </Link>
                  <Link to="/student/login?mode=signup">
                    <Button variant="gradient" size="sm">
                      Get Started
                    </Button>
                  </Link>
                </>
              )}
            </div>

            {/* Mobile Actions */}
            <div className="flex md:hidden items-center gap-3">
              {user && (
                <Link to="/student/profile" className="w-8 h-8 rounded-full border border-primary/20 overflow-hidden">
                  {user.profilePicture ? (
                    <img src={user.profilePicture} alt={user.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-primary/10 flex items-center justify-center text-primary">
                      <UserIcon className="w-4 h-4" />
                    </div>
                  )}
                </Link>
              )}
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="p-2 rounded-lg hover:bg-secondary transition-colors"
                aria-label="Toggle menu"
              >
                {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden border-t border-border/50 bg-background/95 backdrop-blur-xl animate-fade-in overflow-y-auto max-h-[calc(100vh-64px)]">
            <div className="container mx-auto px-4 py-4 space-y-2">
              {filteredLinks.map((link) => (
                <Link
                  key={link.href}
                  to={link.href}
                  onClick={() => setIsOpen(false)}
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors",
                    location.pathname === link.href
                      ? "bg-secondary text-primary"
                      : "hover:bg-secondary",
                  )}
                >
                  <link.icon className="w-5 h-5" />
                  {link.label}
                </Link>
              ))}


              <div className="pt-4 border-t border-border/50 space-y-2">
                {user ? (
                  <>
                    <div className="px-4 py-3 flex items-center gap-3 bg-muted/50 rounded-lg mb-2">
                      <div className="w-10 h-10 rounded-full border border-primary/20 overflow-hidden shrink-0">
                        {user.profilePicture ? (
                          <img src={user.profilePicture} alt={user.name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full bg-primary/10 flex items-center justify-center text-primary">
                            <UserIcon className="w-5 h-5" />
                          </div>
                        )}
                      </div>
                      <div className="flex flex-col min-w-0">
                        <span className="text-sm font-bold truncate">{user.name}</span>
                        <span className="text-[10px] text-muted-foreground truncate">{user.email}</span>
                      </div>
                    </div>

                    <Link to={user.role === "ADMIN" ? "/admin" : "/student/profile"} onClick={() => setIsOpen(false)}>
                      <Button variant="ghost" className="w-full justify-start gap-3 px-4">
                        <UserIcon className="w-5 h-5" />
                        My Profile
                      </Button>
                    </Link>

                    {user.role === "ADMIN" ? (
                      <Link to="/admin" onClick={() => setIsOpen(false)}>
                        <Button variant="outline" className="w-full justify-start gap-3 px-4">
                          <LayoutDashboard className="w-5 h-5" />
                          Admin Dashboard
                        </Button>
                      </Link>
                    ) : (
                      <Link to="/dashboard" onClick={() => setIsOpen(false)}>
                        <Button variant="outline" className="w-full justify-start gap-3 px-4">
                          <LayoutDashboard className="w-5 h-5" />
                          My Dashboard
                        </Button>
                      </Link>
                    )}
                    <Button
                      variant="ghost"
                      className="w-full text-destructive hover:bg-destructive/10"
                      onClick={handleLogout}
                    >
                      Logout
                    </Button>
                  </>
                ) : (
                  <>
                    <Link to="/student/login" onClick={() => setIsOpen(false)}>
                      <Button variant="outline" className="w-full">
                        Sign In
                      </Button>
                    </Link>
                    <Link to="/student/login?mode=signup" onClick={() => setIsOpen(false)}>
                      <Button variant="gradient" className="w-full">
                        Get Started
                      </Button>
                    </Link>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </nav>
      <ContactAdminModal
        isOpen={showContactModal}
        onClose={() => setShowContactModal(false)}
      />
    </>
  );
}

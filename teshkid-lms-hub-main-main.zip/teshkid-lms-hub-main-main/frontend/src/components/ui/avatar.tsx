import { useState } from "react";
import { UserRound } from "lucide-react";
import { getImageUrl } from "@/lib/imageUtils";
import { cn } from "@/lib/utils";

interface AvatarProps {
  src?: string | null;
  alt: string;
  fallback?: string;
  className?: string;
  fallbackClassName?: string;
}

export function Avatar({ src, alt, fallback, className, fallbackClassName }: AvatarProps) {
  const [imageError, setImageError] = useState(false);
  const [imageLoading, setImageLoading] = useState(true);
  
  const imageUrl = getImageUrl(src);
  const shouldShowImage = imageUrl && !imageError;

  const handleImageError = () => {
    setImageError(true);
    setImageLoading(false);
  };

  const handleImageLoad = () => {
    setImageLoading(false);
  };

  return (
    <div className={cn("relative overflow-hidden bg-muted flex items-center justify-center", className)}>
      {shouldShowImage ? (
        <>
          <img
            src={imageUrl}
            alt={alt}
            className={cn(
              "w-full h-full object-cover",
              imageLoading ? "opacity-0" : "opacity-100",
              "transition-opacity duration-200"
            )}
            onError={handleImageError}
            onLoad={handleImageLoad}
            loading="lazy"
          />
          {imageLoading && (
            <div className={cn(
              "absolute inset-0 bg-primary/10 flex items-center justify-center text-primary",
              fallbackClassName
            )}>
              <UserRound className="w-1/2 h-1/2" />
            </div>
          )}
        </>
      ) : (
        <div className={cn(
          "w-full h-full bg-primary/10 flex items-center justify-center text-primary",
          fallbackClassName
        )}>
          <UserRound className="w-1/2 h-1/2" />
        </div>
      )}
    </div>
  );
}

interface AvatarGroupProps {
  avatars: Array<{
    src?: string | null;
    alt: string;
    fallback?: string;
  }>;
  max?: number;
  className?: string;
  avatarClassName?: string;
}

export function AvatarGroup({ avatars, max = 3, className, avatarClassName }: AvatarGroupProps) {
  const displayAvatars = avatars.slice(0, max);
  const remaining = avatars.length - max;

  return (
    <div className={cn("flex -space-x-2", className)}>
      {displayAvatars.map((avatar, index) => (
        <Avatar
          key={index}
          src={avatar.src}
          alt={avatar.alt}
          fallback={avatar.fallback}
          className={cn("border-2 border-background", avatarClassName)}
        />
      ))}
      {remaining > 0 && (
        <div className={cn(
          "rounded-full border-2 border-background bg-muted flex items-center justify-center text-xs font-bold text-muted-foreground",
          avatarClassName
        )}>
          +{remaining}
        </div>
      )}
    </div>
  );
}

import React from "react";

interface ContentBlock {
  type: "text" | "heading" | "section" | "quote" | "table" | "tradingplan" | "chart";
  content: string;
  data?: Record<string, any>;
}

interface ContentRendererProps {
  blocks: ContentBlock[];
}

export const ContentRenderer: React.FC<ContentRendererProps> = ({ blocks }) => {
  const renderBlock = (block: ContentBlock, idx: number) => {
    switch (block.type) {
      case "heading":
        return (
          <h2
            key={idx}
            className="text-3xl font-bold mt-8 mb-4 text-foreground border-b-2 border-primary pb-2"
          >
            {block.content}
          </h2>
        );

      case "quote":
        return (
          <blockquote
            key={idx}
            className="border-l-4 border-primary bg-primary/5 italic p-4 my-4 rounded text-foreground"
          >
            {block.content}
          </blockquote>
        );

      case "tradingplan":
        const plans = block.content.split("\n").filter((line) => line.trim());
        return (
          <div key={idx} className="bg-amber-50 border border-amber-200 rounded-lg p-4 my-4">
            <h3 className="font-bold text-amber-900 mb-3">Trading Plan</h3>
            <div className="space-y-2">
              {plans.map((plan, i) => {
                const [label, value] = plan.split("|").map((s) => s.trim());
                return (
                  <div key={i} className="flex justify-between items-center text-sm">
                    <span className="font-semibold text-amber-900">{label}:</span>
                    <span className="text-amber-800 font-mono">{value || "—"}</span>
                  </div>
                );
              })}
            </div>
          </div>
        );

      case "table":
        // Parse simple markdown table format
        const rows = block.content
          .split("\n")
          .filter((line) => line.includes("|"));
        return (
          <div key={idx} className="overflow-x-auto my-4">
            <table className="w-full border-collapse border border-border">
              <tbody>
                {rows.map((row, i) => (
                  <tr key={i} className={i === 0 ? "bg-primary/10" : ""}>
                    {row
                      .split("|")
                      .filter((cell) => cell.trim())
                      .map((cell, j) => (
                        <td
                          key={j}
                          className="border border-border p-2 text-sm text-foreground"
                        >
                          {cell.trim()}
                        </td>
                      ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );

      case "text":
      default:
        // Parse text for inline formatting
        let content = block.content;
        // Simple markdown-like formatting
        content = content
          .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
          .replace(/\*(.*?)\*/g, "<em>$1</em>")
          .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" target="_blank" class="text-primary hover:underline">$1</a>')
          .replace(/(?<!["'])(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" class="text-primary hover:underline">$1</a>');

        return (
          <p
            key={idx}
            className="text-foreground leading-7 mb-4"
            dangerouslySetInnerHTML={{ __html: content }}
          />
        );
    }
  };

  return (
    <div className="prose prose-lg max-w-none">
      {blocks.map((block, idx) => renderBlock(block, idx))}
    </div>
  );
};

export default ContentRenderer;

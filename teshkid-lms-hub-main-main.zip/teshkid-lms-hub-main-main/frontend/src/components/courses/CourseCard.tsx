import { Link } from "react-router-dom";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Clock, Users, BarChart3, Play, BookOpen } from "lucide-react";

export interface Course {
  id: string;
  title: string;
  description: string;
  instructor: string;
  thumbnail: string;
  level: "Beginner" | "Intermediate" | "Advanced";
  duration: string;
  modules: number;
  students: number;
  price: number;
  cryptoPrice?: string;
  progress?: number;
  enrolled?: boolean;
}

interface CourseCardProps {
  course: Course;
}

export function CourseCard({ course }: CourseCardProps) {
  const levelColors = {
    Beginner: "success",
    Intermediate: "warning",
    Advanced: "destructive",
  } as const;

  return (
    <Card variant="glass" className="group hover:border-primary/30 transition-all duration-300 overflow-hidden">
      <div className="relative aspect-video overflow-hidden">
        <img
          src={course.thumbnail}
          alt={course.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
        
        {/* Play Button Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="w-14 h-14 rounded-full bg-primary/90 flex items-center justify-center shadow-lg shadow-primary/30">
            <Play className="w-6 h-6 text-primary-foreground ml-1" />
          </div>
        </div>

        {/* Level Badge */}
        <Badge 
          variant={levelColors[course.level]} 
          className="absolute top-3 left-3"
        >
          {course.level}
        </Badge>

        {/* Progress for enrolled courses */}
        {course.enrolled && course.progress !== undefined && (
          <div className="absolute bottom-0 left-0 right-0 p-3">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-foreground font-medium">{course.progress}% Complete</span>
            </div>
            <Progress value={course.progress} variant="gradient" className="h-2" />
          </div>
        )}
      </div>

      <CardHeader className="pb-2">
        <h3 className="font-display font-semibold text-lg line-clamp-2 group-hover:text-primary transition-colors">
          {course.title}
        </h3>
        <p className="text-sm text-muted-foreground">{course.instructor}</p>
      </CardHeader>

      <CardContent className="pb-3">
        <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
          {course.description}
        </p>
        
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            {course.duration}
          </div>
          <div className="flex items-center gap-1">
            <BookOpen className="w-3.5 h-3.5" />
            {course.modules} modules
          </div>
          <div className="flex items-center gap-1">
            <Users className="w-3.5 h-3.5" />
            {course.students.toLocaleString()}
          </div>
        </div>
      </CardContent>

      <CardFooter className="flex items-center justify-between pt-3 border-t border-border/50">
        <div className="flex flex-col">
          <span className="text-lg font-bold text-foreground">${course.price}</span>
          {course.cryptoPrice && (
            <span className="text-xs text-muted-foreground">{course.cryptoPrice}</span>
          )}
        </div>
        <Link to={`/courses/${course.id}`}>
          <Button variant={course.enrolled ? "outline" : "gradient"} size="sm">
            {course.enrolled ? "Continue" : "Enroll Now"}
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}

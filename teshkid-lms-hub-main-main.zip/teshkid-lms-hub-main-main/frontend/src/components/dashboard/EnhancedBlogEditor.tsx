import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Upload, X, Plus, Copy } from "lucide-react";
import api from "@/lib/api";

interface ContentBlock {
  type: "text" | "heading" | "section" | "quote" | "table" | "tradingplan" | "chart";
  content: string;
  data?: Record<string, any>;
}

interface EnhancedBlog {
  id?: string;
  title: string;
  slug?: string;
  description?: string;
  category: string;
  tags?: string[];
  featuredImage?: string;
  author?: string;
  reviewer?: string;
  contentBlocks: ContentBlock[];
  status?: string;
  publishedAt?: string;
  isPublished?: boolean;
}

interface EnhancedBlogEditorProps {
  blog?: EnhancedBlog;
  onSave: (blog: EnhancedBlog) => void;
  onCancel: () => void;
}

const EnhancedBlogEditor: React.FC<EnhancedBlogEditorProps> = ({
  blog,
  onSave,
  onCancel,
}) => {
  const [title, setTitle] = useState(blog?.title || "");
  const [description, setDescription] = useState(blog?.description || "");
  const [category, setCategory] = useState(blog?.category || "admin-thoughts");
  const [author, setAuthor] = useState(blog?.author || "Teshkid Crypto");
  const [reviewer, setReviewer] = useState(blog?.reviewer || "");
  const [tags, setTags] = useState<string[]>(blog?.tags || []);
  const [tagInput, setTagInput] = useState("");
  const [featuredImage, setFeaturedImage] = useState(blog?.featuredImage || "");
  const [status, setStatus] = useState(blog?.status || "published");
  const [contentBlocks, setContentBlocks] = useState<ContentBlock[]>(
    blog?.contentBlocks || [{ type: "text", content: "" }]
  );
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const [importText, setImportText] = useState("");
  const [showImportModal, setShowImportModal] = useState(false);

  const handleAddBlock = (type: ContentBlock["type"]) => {
    setContentBlocks([
      ...contentBlocks,
      {
        type,
        content: type === "heading" ? "# Section Title" : "",
        data: type === "table" ? { rows: 3, cols: 2 } : undefined,
      },
    ]);
  };

  const handleUpdateBlock = (index: number, content: string) => {
    const updated = [...contentBlocks];
    updated[index].content = content;
    setContentBlocks(updated);
  };

  const handleRemoveBlock = (index: number) => {
    setContentBlocks(contentBlocks.filter((_, i) => i !== index));
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setUploadError("Please select a valid image file");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setUploadError("Image must be less than 5MB");
      return;
    }

    setUploading(true);
    setUploadError("");

    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await api.post("/upload/image", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      if (response.data.url) {
        setFeaturedImage(response.data.url);
      }
    } catch (err: any) {
      setUploadError(
        err.response?.data?.error || "Failed to upload image. Please try again."
      );
    } finally {
      setUploading(false);
    }
  };

  const handleImportContent = () => {
    if (!importText.trim()) return;

    // Parse imported content into blocks
    const paragraphs = importText.split("\n\n").filter((p) => p.trim());
    const newBlocks: ContentBlock[] = [];

    paragraphs.forEach((para) => {
      if (para.startsWith("# ")) {
        newBlocks.push({ type: "heading", content: para.replace("# ", "") });
      } else if (para.startsWith("> ")) {
        newBlocks.push({ type: "quote", content: para.replace("> ", "") });
      } else if (para.includes("|")) {
        newBlocks.push({ type: "table", content: para });
      } else {
        newBlocks.push({ type: "text", content: para });
      }
    });

    setContentBlocks(newBlocks);
    setImportText("");
    setShowImportModal(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      id: blog?.id,
      title,
      description,
      category,
      author,
      reviewer,
      tags,
      featuredImage,
      contentBlocks,
      status,
    });
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput("");
    }
  };

  const handleRemoveTag = (index: number) => {
    setTags(tags.filter((_, i) => i !== index));
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-4 p-4 bg-card rounded-lg shadow-lg max-h-[90vh] overflow-y-auto border border-border"
    >
      {/* Featured Image Preview */}
      {featuredImage && (
        <div className="rounded-lg overflow-hidden border border-border relative">
          <img
            src={featuredImage}
            alt="Featured"
            className="w-full h-48 object-cover"
          />
          <button
            type="button"
            onClick={() => setFeaturedImage("")}
            className="absolute top-2 right-2 bg-destructive text-destructive-foreground p-1 rounded hover:opacity-90"
          >
            <X size={16} />
          </button>
        </div>
      )}

      {/* Featured Image Upload */}
      <div className="space-y-2">
        <label className="block text-sm font-semibold">Featured Image</label>
        <div className="border-2 border-dashed border-border rounded-lg p-4 text-center hover:border-primary/50 transition-colors">
          <input
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            disabled={uploading}
            className="hidden"
            id="image-upload"
          />
          <label htmlFor="image-upload" className="cursor-pointer block">
            <Upload className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
            <p className="text-sm font-medium">
              {uploading ? "Uploading..." : "Click to upload"}
            </p>
          </label>
        </div>
        {uploadError && (
          <div className="bg-destructive/10 text-destructive text-sm p-2 rounded">
            {uploadError}
          </div>
        )}
      </div>

      {/* Title */}
      <div className="space-y-2">
        <label className="block text-sm font-semibold">Title *</label>
        <input
          className="w-full border border-input p-2 rounded bg-background text-foreground"
          placeholder="Blog Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
      </div>

      {/* Description */}
      <div className="space-y-2">
        <label className="block text-sm font-semibold">Description (SEO) *</label>
        <textarea
          className="w-full border border-input p-2 rounded bg-background text-foreground min-h-[60px]"
          placeholder="Brief description (50-160 characters)"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          maxLength={160}
          required
        />
        <p className="text-xs text-muted-foreground">
          {description.length}/160 characters
        </p>
      </div>

      {/* Author & Reviewer */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="block text-sm font-semibold">Author</label>
          <input
            className="w-full border border-input p-2 rounded bg-background text-foreground"
            placeholder="e.g., Teshkid Crypto"
            value={author}
            onChange={(e) => setAuthor(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-semibold">Reviewer</label>
          <input
            className="w-full border border-input p-2 rounded bg-background text-foreground"
            placeholder="Optional reviewer name"
            value={reviewer}
            onChange={(e) => setReviewer(e.target.value)}
          />
        </div>
      </div>

      {/* Category */}
      <div className="space-y-2">
        <label className="block text-sm font-semibold">Category</label>
        <select
          className="w-full border border-input p-2 rounded bg-background text-foreground"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="admin-thoughts">Admin Thoughts</option>
          <option value="mcrypto-analysis">MCrypto Analysis</option>
          <option value="previous-day">Previous Day Blog</option>
          <option value="trading-ideas">Trading Ideas & Strategies</option>
        </select>
      </div>

      {/* Tags */}
      <div className="space-y-2">
        <label className="block text-sm font-semibold">Tags</label>
        <div className="flex gap-2">
          <input
            type="text"
            className="flex-1 border border-input p-2 rounded bg-background text-foreground"
            placeholder="Add tag"
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                handleAddTag();
              }
            }}
          />
          <Button type="button" variant="outline" onClick={handleAddTag}>
            Add
          </Button>
        </div>
        {Array.isArray(tags) && tags.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {tags.map((tag, i) => (
              <span
                key={i}
                className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm flex items-center gap-2"
              >
                {tag}
                <button
                  type="button"
                  onClick={() => handleRemoveTag(i)}
                  className="text-primary font-bold cursor-pointer hover:opacity-70"
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Content Blocks */}
      <div className="space-y-4 border-t pt-4">
        <div className="flex items-center justify-between">
          <label className="block text-sm font-semibold">Content Blocks</label>
          <div className="flex gap-2 flex-wrap">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => handleAddBlock("text")}
              className="gap-1"
            >
              <Plus size={14} /> Text
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => handleAddBlock("heading")}
              className="gap-1"
            >
              <Plus size={14} /> Heading
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => handleAddBlock("quote")}
              className="gap-1"
            >
              <Plus size={14} /> Quote
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => handleAddBlock("tradingplan")}
              className="gap-1"
            >
              <Plus size={14} /> Trading Plan
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setShowImportModal(true)}
              className="gap-1"
            >
              <Copy size={14} /> Import
            </Button>
          </div>
        </div>

        {contentBlocks.map((block, idx) => (
          <div key={idx} className="border border-border rounded-lg p-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-muted-foreground uppercase">
                {block.type}
              </span>
              <button
                type="button"
                onClick={() => handleRemoveBlock(idx)}
                className="text-destructive hover:opacity-70"
              >
                <X size={16} />
              </button>
            </div>

            {block.type === "heading" ? (
              <input
                type="text"
                value={block.content}
                onChange={(e) => handleUpdateBlock(idx, e.target.value)}
                placeholder="Section Title"
                className="w-full border border-input p-2 rounded bg-background text-foreground font-bold"
              />
            ) : block.type === "quote" ? (
              <textarea
                value={block.content}
                onChange={(e) => handleUpdateBlock(idx, e.target.value)}
                placeholder="Quote text"
                className="w-full border border-input p-2 rounded bg-background text-foreground min-h-[80px] italic"
              />
            ) : block.type === "tradingplan" ? (
              <textarea
                value={block.content}
                onChange={(e) => handleUpdateBlock(idx, e.target.value)}
                placeholder="Trading Plan: Entry point | Take Profit | Stop Loss"
                className="w-full border border-input p-2 rounded bg-background text-foreground min-h-[120px] font-mono text-sm"
              />
            ) : (
              <textarea
                value={block.content}
                onChange={(e) => handleUpdateBlock(idx, e.target.value)}
                placeholder="Block content..."
                className="w-full border border-input p-2 rounded bg-background text-foreground min-h-[120px]"
              />
            )}
          </div>
        ))}
      </div>

      {/* Import Modal */}
      {showImportModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-card rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-bold mb-4">Import Blog Content</h3>
            <textarea
              value={importText}
              onChange={(e) => setImportText(e.target.value)}
              placeholder="Paste your blog content here. Use:
- # for headings
- > for quotes
- Text for paragraphs
Separate sections with blank lines"
              className="w-full border border-input p-3 rounded bg-background text-foreground min-h-[300px] font-mono text-sm"
            />
            <div className="flex gap-2 mt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowImportModal(false)}
              >
                Cancel
              </Button>
              <Button
                type="button"
                variant="default"
                onClick={handleImportContent}
              >
                Import & Parse
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Status */}
      <div className="space-y-2">
        <label className="block text-sm font-semibold">Status</label>
        <select
          className="w-full border border-input p-2 rounded bg-background text-foreground"
          value={status}
          onChange={(e) => setStatus(e.target.value)}
        >
          <option value="draft">Draft (Hidden)</option>
          <option value="published">Published (Visible)</option>
        </select>
      </div>

      {/* Form Actions */}
      <div className="flex gap-2 pt-4 border-t border-border">
        <Button type="submit" className="flex-1">
          {blog ? "Update Blog" : "Publish Blog"}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  );
};

export default EnhancedBlogEditor;

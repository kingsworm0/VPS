import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Upload, X, Plus, Copy, Image as ImageIcon, List, Save, Eye } from "lucide-react";
import api from "@/lib/api";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
interface Blog {
  id?: string;
  title: string;
  slug?: string;
  content: string;
  description?: string;
  category: string;
  tags?: string[];
  featuredImage?: string;
  coverImage?: string;
  status?: string;
  publishedAt?: string;
  isPublished?: boolean;
  keyTakeaways?: string[];
  gallery?: string[];
  author?: string;
}

interface BlogEditorProps {
  blog?: Blog;
  onSave: (blog: Partial<Blog>) => void;
  onCancel: () => void;
}

const BlogEditor: React.FC<BlogEditorProps> = ({ blog, onSave, onCancel }) => {
  // Helper to parse array fields that might be JSON strings from the DB
  const getArrayField = (field: any) => {
    if (!field) return [];
    if (typeof field === "string") {
      try {
        return JSON.parse(field);
      } catch {
        return [];
      }
    }
    return Array.isArray(field) ? field : [];
  };

  const [title, setTitle] = useState(blog?.title || "");
  const [author, setAuthor] = useState(blog?.author || "Teshkid is Crypto");
  const [description, setDescription] = useState(blog?.description || "");
  const [content, setContent] = useState(blog?.content || "");
  const [category, setCategory] = useState(blog?.category || "admin-thoughts");
  const [tags, setTags] = useState<string[]>(getArrayField(blog?.tags));
  const [tagInput, setTagInput] = useState("");
  const [featuredImage, setFeaturedImage] = useState(blog?.featuredImage || blog?.coverImage || "");
  const [keyTakeaways, setKeyTakeaways] = useState<string[]>(getArrayField(blog?.keyTakeaways));
  const [newTakeaway, setNewTakeaway] = useState("");
  const [gallery, setGallery] = useState<string[]>(getArrayField(blog?.gallery));
  const [status, setStatus] = useState(blog?.status || "published");
  const [uploading, setUploading] = useState(false);
  const [galleryUploading, setGalleryUploading] = useState(false);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, target: "featured" | "gallery") => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Please select a valid image file");
      return;
    }

    if (target === "featured") setUploading(true);
    else setGalleryUploading(true);

    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await api.post("/upload/image", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      if (response.data.url) {
        if (target === "featured") {
          setFeaturedImage(response.data.url);
          toast.success("Featured image uploaded");
        } else {
          setGallery([...gallery, response.data.url]);
          toast.success("Image added to gallery");
        }
      }
    } catch (err: any) {
      toast.error(err.response?.data?.error || "Failed to upload image");
    } finally {
      if (target === "featured") setUploading(false);
      else setGalleryUploading(false);
    }
  };

  const handleRemoveGalleryImage = (index: number) => {
    setGallery(gallery.filter((_, i) => i !== index));
  };

  const handleAddTakeaway = () => {
    if (newTakeaway.trim()) {
      setKeyTakeaways([...keyTakeaways, newTakeaway.trim()]);
      setNewTakeaway("");
    }
  };

  const handleRemoveTakeaway = (index: number) => {
    setKeyTakeaways(keyTakeaways.filter((_, i) => i !== index));
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("URL copied! You can paste this in the content editor.");
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput("");
    }
  };

  const handleRemoveTag = (index: number) => {
    setTags(tags.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      title,
      description,
      content,
      category,
      tags,
      featuredImage,
      status,
      gallery,
      author
    });
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-8 p-6 bg-card rounded-2xl shadow-2xl border border-border text-foreground max-h-[90vh] overflow-y-auto"
    >
      <div className="flex items-center justify-between border-b border-border pb-4">
        <div>
          <h2 className="text-2xl font-black">{blog ? "Edit Post" : "Create New Post"}</h2>
          <p className="text-sm text-muted-foreground">Draft and publish your market insights</p>
        </div>
        <div className="flex gap-2">
          <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
          <Button type="submit" className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground font-bold">
            <Save className="w-4 h-4" />
            {blog ? "Save Changes" : "Publish Post"}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">

        {/* Left Column: Core Info */}
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Blog Title</label>
            <Input
              placeholder="The October 10 Crypto Market Flash Crash..."
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              className="bg-muted/30 border-border h-12 text-lg font-bold"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Publisher (Author)</label>
            <Input
              placeholder="Teshkid is Crypto"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              className="bg-muted/30 border-border h-12 text-lg"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">SEO Description</label>
            <Textarea
              placeholder="A brief summary for search engines and social sharing..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={160}
              className="bg-muted/30 border-border min-h-[80px] resize-none"
            />
            <p className="text-[10px] text-right text-muted-foreground">{description.length}/160</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Category</label>
              <select
                className="w-full bg-muted/30 border border-border rounded-md px-3 h-10 text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
              >
                <option value="admin-thoughts">Admin Thoughts</option>
                <option value="mcrypto-analysis">MCrypto Analysis</option>
                <option value="previous-day">Previous Day Blog</option>
                <option value="trading-ideas">Trading Ideas</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Status</label>
              <select
                className="w-full bg-muted/30 border border-border rounded-md px-3 h-10 text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                value={status}
                onChange={(e) => setStatus(e.target.value)}
              >
                <option value="published">Published</option>
                <option value="draft">Draft</option>
              </select>
            </div>
          </div>

          {/* Tags */}
          <div className="space-y-3">
            <label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Tags</label>
            <div className="flex gap-2">
              <Input
                placeholder="Add tag..."
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), handleAddTag())}
                className="bg-muted/30 border-border"
              />
              <Button type="button" variant="outline" onClick={handleAddTag}>Add</Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {tags.map((tag, i) => (
                <span key={i} className="bg-primary/10 text-primary px-3 py-1 rounded-full text-xs flex items-center gap-2 border border-primary/20">
                  {tag}
                  <X className="w-3 h-3 cursor-pointer hover:text-destructive" onClick={() => handleRemoveTag(i)} />
                </span>
              ))}
            </div>
          </div>

        </div>

        {/* Right Column: Visuals & Content */}
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Featured Image</label>
            <div className="relative aspect-video rounded-xl bg-muted/30 border border-dashed border-border flex items-center justify-center overflow-hidden group">
              {featuredImage ? (
                <>
                  <img src={featuredImage} alt="Featured" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <label htmlFor="bg-upload" className="cursor-pointer bg-white text-black px-4 py-2 rounded-lg font-bold text-sm hover:bg-white/90">Change Image</label>
                    <button type="button" onClick={() => setFeaturedImage("")} className="bg-destructive text-white p-2 rounded-lg"><X className="w-5 h-5" /></button>
                  </div>
                </>
              ) : (
                <label htmlFor="bg-upload" className="cursor-pointer flex flex-col items-center gap-2 text-muted-foreground hover:text-primary transition-colors">
                  <Upload className="w-8 h-8" />
                  <span className="text-xs font-bold uppercase">Upload Main Banner</span>
                </label>
              )}
              <input id="bg-upload" type="file" className="hidden" onChange={(e) => handleImageUpload(e, "featured")} />
              {uploading && <div className="absolute inset-0 bg-black/40 flex items-center justify-center"><div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin"></div></div>}
            </div>
          </div>

          {/* GALLERY PANEL (THE "MORE PAN" REQUEST) */}
          <div className="space-y-4 bg-muted/20 p-5 rounded-2xl border border-border">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-primary" /> Image Panel (Gallery)
              </label>
              <label htmlFor="gallery-upload" className="cursor-pointer bg-primary/10 hover:bg-primary/20 text-primary px-3 py-1.5 rounded-lg text-xs font-bold border border-primary/20 transition-colors flex items-center gap-2">
                <Plus className="w-3 h-3" /> Add Image
              </label>
              <input id="gallery-upload" type="file" multiple className="hidden" onChange={(e) => handleImageUpload(e, "gallery")} />
            </div>

            <div className="grid grid-cols-4 gap-3 max-h-[220px] overflow-y-auto pr-2">
              {gallery.map((url, idx) => (
                <div key={idx} className="relative aspect-square rounded-lg bg-muted border border-border group overflow-hidden">
                  <img src={url} alt="Gallery" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1">
                    <button type="button" onClick={() => copyToClipboard(url)} className="text-[10px] bg-white text-black px-1.5 py-0.5 rounded font-bold flex items-center gap-1">
                      <Copy className="w-3 h-3" /> URL
                    </button>
                    <button type="button" onClick={() => handleRemoveGalleryImage(idx)} className="text-white hover:text-destructive">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
              {galleryUploading && (
                <div className="aspect-square rounded-lg border border-dashed border-border flex items-center justify-center">
                  <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
              {gallery.length === 0 && !galleryUploading && (
                <div className="col-span-4 py-8 text-center text-xs text-muted-foreground italic border border-dashed border-white/5 rounded-xl">
                  No images in panel. Upload images to easily use them in your content.
                </div>
              )}
            </div>
            <p className="text-[10px] text-muted-foreground italic flex items-center gap-1">
              <Eye className="w-3 h-3" /> Tip: Click 'URL' to copy an image link and paste it into the HTML editor below.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <label className="text-sm font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
          Content Editor (Rich Text)
        </label>
        <div className="bg-white text-black rounded-xl overflow-hidden border border-border">
          <ReactQuill
            theme="snow"
            value={content}
            onChange={setContent}
            className="min-h-[400px]"
            modules={{
              toolbar: [
                [{ 'header': [1, 2, 3, false] }],
                ['bold', 'italic', 'underline', 'strike'],
                [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                ['link', 'image', 'video'],
                ['clean']
              ]
            }}
          />
        </div>
        <div className="flex gap-4 p-4 bg-primary/5 border border-primary/10 rounded-xl mt-4">
          <div className="text-xl">💡</div>
          <div className="text-xs text-muted-foreground leading-relaxed">
            <span className="font-bold text-primary block mb-1">Editor Guide:</span>
            Use the toolbar above to style your text. To add images, upload them to your gallery panel first, copy the URL, and click the Image icon in the toolbar to insert it!
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-6 border-t border-border">
        <Button type="button" variant="outline" onClick={onCancel}>Discard Changes</Button>
        <Button type="submit" className="px-10 h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-black text-lg shadow-xl shadow-primary/20 transition-all hover:scale-[1.02] active:scale-95">
          {blog ? "Update & Sync" : "Launch Post"}
        </Button>
      </div>
    </form>
  );
};

export default BlogEditor;

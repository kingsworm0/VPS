import React, { useEffect, useState } from "react";
import BlogEditor from "./BlogEditor";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { ConfirmDialog } from "@/components/ui/ConfirmDialog";
import { toast } from "sonner";
import {
  Plus,
  Search,
  Eye,
  ThumbsUp,
  ThumbsDown,
  Edit,
  Trash2,
  Tag,
  Calendar,
  MoreVertical,
  ChevronRight,
  Loader2
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

interface Blog {
  id: string;
  title: string;
  slug?: string;
  content: string;
  category: string;
  tags?: string[];
  featuredImage?: string;
  coverImage?: string;
  publishedAt?: string;
  createdAt?: string;
  status?: string;
  isPublished?: boolean;
  viewCount?: number;
  likeCount?: number;
  dislikeCount?: number;
}

const categoryLabels: Record<string, string> = {
  "admin-thoughts": "Admin Thoughts",
  "mcrypto-analysis": "MCrypto Analysis",
  "previous-day": "Previous Day Blog",
  "trading-ideas": "Trading Ideas & Strategies",
};

const AdminBlogManager: React.FC = () => {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [filteredBlogs, setFilteredBlogs] = useState<Blog[]>([]);
  const [editingBlog, setEditingBlog] = useState<Blog | null>(null);
  const [showEditor, setShowEditor] = useState(false);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [confirmState, setConfirmState] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    onConfirm: () => void;
    variant?: "default" | "destructive";
  }>({
    isOpen: false,
    title: "",
    description: "",
    onConfirm: () => { },
  });

  const fetchBlogs = async () => {
    setLoading(true);
    try {
      const res = await api.get('/blogs/admin/all');
      const data = res.data;
      setBlogs(Array.isArray(data) ? data : []);
      setFilteredBlogs(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error('Failed to fetch blogs', err);
      setBlogs([]);
      setFilteredBlogs([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBlogs();
  }, []);

  useEffect(() => {
    const query = searchQuery.toLowerCase();
    const filtered = blogs.filter(blog =>
      blog.title.toLowerCase().includes(query) ||
      (blog.category && blog.category.toLowerCase().includes(query))
    );
    setFilteredBlogs(filtered);
  }, [searchQuery, blogs]);

  const handleEdit = (blog: Blog) => {
    setEditingBlog(blog);
    setShowEditor(true);
  };

  const handleDelete = async (id: string) => {
    setConfirmState({
      isOpen: true,
      title: "Delete Blog",
      description: "Are you sure you want to delete this blog post? This action cannot be undone.",
      variant: "destructive",
      onConfirm: async () => {
        try {
          await api.delete(`/blogs/${id}`);
          toast.success("Blog deleted successfully");
          fetchBlogs();
        } catch (err) {
          console.error('Failed to delete blog', err);
          toast.error("Failed to delete blog post");
        }
      },
    });
  };

  const handleSave = async (blog: Partial<Blog>) => {
    try {
      if (editingBlog) {
        await api.put(`/blogs/${editingBlog.id}`, blog);
        toast.success('Blog updated successfully');
      } else {
        await api.post(`/blogs`, blog);
        toast.success('Blog created successfully');
      }
      setShowEditor(false);
      setEditingBlog(null);
      fetchBlogs();
    } catch (err) {
      console.error('Failed to save blog', err);
      toast.error('Failed to save blog');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-black gradient-text">Blog Management</h2>
          <p className="text-sm text-muted-foreground">Create, edit and manage your crypto publication.</p>
        </div>
        <Button
          onClick={() => {
            setEditingBlog(null);
            setShowEditor(true);
          }}
          className="gap-2 shadow-lg shadow-primary/20"
        >
          <Plus className="w-4 h-4" />
          New Publication
        </Button>
      </div>

      <div className="flex items-center gap-2 max-w-md bg-card/50 backdrop-blur-sm border rounded-xl px-3 py-1">
        <Search className="w-4 h-4 text-muted-foreground" />
        <Input
          className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 px-0 h-9"
          placeholder="Search by title or category..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {showEditor && (
        <BlogEditor
          blog={editingBlog || undefined}
          onSave={handleSave}
          onCancel={() => {
            setShowEditor(false);
            setEditingBlog(null);
          }}
        />
      )}

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid gap-4">
          <div className="hidden md:grid grid-cols-12 gap-4 px-4 py-2 text-xs font-bold uppercase tracking-wider text-muted-foreground bg-muted/30 rounded-lg">
            <div className="col-span-6">Publication Title</div>
            <div className="col-span-2 text-center">Stats</div>
            <div className="col-span-2 text-center">Status</div>
            <div className="col-span-2 text-right">Actions</div>
          </div>

          {filteredBlogs.length === 0 ? (
            <div className="text-center py-20 border-2 border-dashed rounded-2xl bg-muted/10">
              <p className="text-muted-foreground">No blog posts found matching your criteria.</p>
            </div>
          ) : (
            filteredBlogs.map((blog) => (
              <Card key={blog.id} className="group overflow-hidden border-border/50 hover:border-primary/50 transition-all hover:shadow-md bg-card/50 backdrop-blur-sm">
                <CardContent className="p-0">
                  <div className="grid md:grid-cols-12 items-center gap-4 p-4">
                    <div className="col-span-12 md:col-span-6 flex items-center gap-4">
                      <div className="hidden sm:block w-16 h-16 rounded-xl overflow-hidden bg-muted/30 border border-border/50 shrink-0">
                        {blog.featuredImage ? (
                          <img src={blog.featuredImage} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                            <Tag className="w-6 h-6" />
                          </div>
                        )}
                      </div>
                      <div className="space-y-1 overflow-hidden">
                        <h3 className="font-bold text-lg truncate group-hover:text-primary transition-colors">{blog.title}</h3>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground font-medium">
                          <span className="flex items-center gap-1 bg-primary/5 text-primary px-2 py-0.5 rounded-full border border-primary/10">
                            {categoryLabels[blog.category] || blog.category}
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {blog.createdAt ? new Date(blog.createdAt).toLocaleDateString() : 'Draft'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="col-span-12 md:col-span-2 flex justify-center md:justify-around items-center border-y md:border-y-0 py-3 md:py-0 border-border/50">
                      <div className="text-center px-2">
                        <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
                          <Eye className="w-3 h-3 text-blue-500" />
                          <span className="text-[10px] uppercase font-bold tracking-tighter">Views</span>
                        </div>
                        <span className="font-black text-sm">{blog.viewCount || 0}</span>
                      </div>
                      <div className="text-center px-2 border-x border-border/50">
                        <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
                          <ThumbsUp className="w-3 h-3 text-emerald-500" />
                          <span className="text-[10px] uppercase font-bold tracking-tighter text-emerald-600/70">Likes</span>
                        </div>
                        <span className="font-black text-sm">{blog.likeCount || 0}</span>
                      </div>
                      <div className="text-center px-2">
                        <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
                          <ThumbsDown className="w-3 h-3 text-rose-500" />
                          <span className="text-[10px] uppercase font-bold tracking-tighter text-rose-600/70">Dislikes</span>
                        </div>
                        <span className="font-black text-sm">{blog.dislikeCount || 0}</span>
                      </div>
                    </div>

                    <div className="col-span-6 md:col-span-2 text-left md:text-center">
                      <Badge
                        variant={blog.status === "published" || blog.isPublished ? "outline" : "secondary"}
                        className={`font-black uppercase tracking-widest text-[10px] border-none px-3 py-1 ${blog.status === "published" || blog.isPublished
                            ? "bg-emerald-500/10 text-emerald-600"
                            : "bg-amber-500/10 text-amber-600"
                          }`}
                      >
                        {blog.status === "published" || blog.isPublished ? "Live" : "Draft"}
                      </Badge>
                    </div>

                    <div className="col-span-6 md:col-span-2 flex justify-end gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(blog)}
                        className="h-8 w-8 p-0 sm:h-auto sm:w-auto sm:px-3 hover:bg-primary/10 hover:text-primary hover:border-primary/30"
                      >
                        <Edit className="w-4 h-4 sm:mr-2" />
                        <span className="hidden sm:inline">Edit</span>
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDelete(blog.id)}
                        className="h-8 w-8 p-0 sm:h-auto sm:w-auto sm:px-3 hover:bg-destructive/10 hover:text-destructive hover:border-destructive/30"
                      >
                        <Trash2 className="w-4 h-4 sm:mr-2" />
                        <span className="hidden sm:inline">Delete</span>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}
      <ConfirmDialog
        isOpen={confirmState.isOpen}
        onOpenChange={(open) => setConfirmState(prev => ({ ...prev, isOpen: open }))}
        title={confirmState.title}
        description={confirmState.description}
        onConfirm={confirmState.onConfirm}
        variant={confirmState.variant}
      />
    </div>
  );
};

export default AdminBlogManager;

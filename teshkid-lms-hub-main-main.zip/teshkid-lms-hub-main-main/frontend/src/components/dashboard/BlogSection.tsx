import React, { useEffect, useState } from "react";
import api from "@/lib/api";

interface Blog {
  id: string;
  title: string;
  content: string;
  category: string;
  coverImage?: string;
  publishedAt: string;
}

const categoryLabels: Record<string, string> = {
  "admin-thoughts": "Admin Thoughts",
  "mcrypto-analysis": "MCrypto Analysis",
  "previous-day": "Previous Day Blog",
  "trading-ideas": "Trading Ideas & Strategies",
};

const BlogSection: React.FC = () => {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    api.get("/blogs")
      .then((res) => {
        setBlogs(res.data);
        setLoading(false);
      })
      .catch(() => {
        setLoading(false);
      });
  }, []);

  // Group blogs by category
  const grouped: Record<string, Blog[]> = {};
  blogs.forEach((blog) => {
    if (!grouped[blog.category]) grouped[blog.category] = [];
    grouped[blog.category].push(blog);
  });

  return (
    <section className="my-8 sm:my-12 lg:my-16 px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {/* Left: Trading Ideas & Strategies */}
        <div className="lg:col-span-1">
          <h3 className="font-bold mb-3 sm:mb-4 text-base sm:text-lg text-foreground">Trading Ideas & Strategies</h3>
          <div className="space-y-3">
            {grouped["trading-ideas"]?.map((blog) => (
              <div key={blog.id} className="p-3 sm:p-4 bg-card rounded-lg shadow hover:shadow-md transition-shadow border border-border">
                <div className="font-semibold text-sm sm:text-base text-foreground line-clamp-2">{blog.title}</div>
                <div className="text-xs text-muted-foreground mb-2 mt-1">
                  {new Date(blog.publishedAt).toLocaleDateString()}
                </div>
                <div className="text-xs sm:text-sm text-muted-foreground line-clamp-2">{blog.content}</div>
              </div>
            )) || <div className="text-muted-foreground text-sm">No ideas yet.</div>}
          </div>
        </div>
        {/* Center: Admin Thoughts & MCrypto Analysis */}
        <div className="md:col-span-2 lg:col-span-2">
          {/* Admin Thoughts */}
          <div className="mb-8 sm:mb-12">
            <h3 className="font-bold mb-3 sm:mb-4 text-lg sm:text-xl text-foreground">Admin Thoughts</h3>
            <div className="space-y-4 sm:space-y-6">
              {grouped["admin-thoughts"]?.map((blog) => (
                <div key={blog.id} className="p-4 sm:p-5 bg-card rounded-lg shadow hover:shadow-md transition-shadow border border-border">
                  <div className="font-semibold text-lg sm:text-xl text-foreground mb-2 line-clamp-2">{blog.title}</div>
                  <div className="text-xs sm:text-sm text-muted-foreground mb-3">
                    {new Date(blog.publishedAt).toLocaleDateString()}
                  </div>
                  <div className="text-sm sm:text-base text-muted-foreground line-clamp-3">{blog.content}</div>
                </div>
              )) || <div className="text-muted-foreground text-sm">No admin thoughts yet.</div>}
            </div>
          </div>
          {/* MCrypto Analysis */}
          <div>
            <h3 className="font-bold mb-3 sm:mb-4 text-lg sm:text-xl text-foreground">MCrypto Analysis</h3>
            <div className="space-y-4 sm:space-y-6">
              {grouped["mcrypto-analysis"]?.map((blog) => (
                <div key={blog.id} className="p-4 sm:p-5 bg-card rounded-lg shadow hover:shadow-md transition-shadow border border-border">
                  <div className="font-semibold text-lg sm:text-xl text-foreground mb-2 line-clamp-2">{blog.title}</div>
                  <div className="text-xs sm:text-sm text-muted-foreground mb-3">
                    {new Date(blog.publishedAt).toLocaleDateString()}
                  </div>
                  <div className="text-sm sm:text-base text-muted-foreground line-clamp-3">{blog.content}</div>
                </div>
              )) || <div className="text-muted-foreground text-sm">No analysis yet.</div>}
            </div>
          </div>
        </div>
        {/* Right: Previous Day Blogs */}
        <div className="md:col-span-2 lg:col-span-1">
          <h3 className="font-bold mb-3 sm:mb-4 text-base sm:text-lg text-foreground">Previous Day Blogs</h3>
          <div className="space-y-3">
            {grouped["previous-day"]?.map((blog) => (
              <div key={blog.id} className="p-3 sm:p-4 bg-card rounded-lg shadow hover:shadow-md transition-shadow border border-border">
                <div className="font-semibold text-sm sm:text-base text-foreground line-clamp-2">{blog.title}</div>
                <div className="text-xs text-muted-foreground mb-2 mt-1">
                  {new Date(blog.publishedAt).toLocaleDateString()}
                </div>
                <div className="text-xs sm:text-sm text-muted-foreground line-clamp-2">{blog.content}</div>
              </div>
            )) || <div className="text-muted-foreground text-sm">No previous day blogs.</div>}
          </div>
        </div>
      </div>
    </section>
  );
};

export default BlogSection;

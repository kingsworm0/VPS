import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Play, Clock, CheckCircle2 } from "lucide-react";

interface CourseProgressProps {
  course: {
    id: string;
    title: string;
    thumbnail: string;
    progress: number;
    currentModule: string;
    currentLesson: string;
    timeRemaining: string;
    completedLessons: number;
    totalLessons: number;
  };
}

export function CourseProgress({ course }: CourseProgressProps) {
  return (
    <Card variant="glass" className="overflow-hidden">
      <div className="flex flex-col md:flex-row">
        {/* Thumbnail */}
        <div className="relative w-full md:w-48 h-32 md:h-auto flex-shrink-0">
          <img
            src={course.thumbnail}
            alt={course.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-transparent to-card md:bg-gradient-to-l" />
        </div>

        <div className="flex-1 p-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <Badge variant="level" className="mb-2">In Progress</Badge>
              <h3 className="font-display font-semibold text-lg mb-1">
                {course.title}
              </h3>
              <p className="text-sm text-muted-foreground mb-3">
                {course.currentModule} • {course.currentLesson}
              </p>
            </div>
            <Link to={`/courses/${course.id}/learn`}>
              <Button variant="gradient" size="sm" className="gap-2">
                <Play className="w-4 h-4" />
                Continue
              </Button>
            </Link>
          </div>

          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">
                {course.completedLessons} of {course.totalLessons} lessons
              </span>
              <span className="font-medium text-primary">{course.progress}%</span>
            </div>
            <Progress value={course.progress} variant="gradient" />
          </div>

          {/* Stats */}
          <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              {course.timeRemaining} remaining
            </div>
            <div className="flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-success" />
              {course.completedLessons} completed
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}

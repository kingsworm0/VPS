import axios from 'axios';

const getDynamicBaseUrl = () => {
  const envUrl = import.meta.env.VITE_API_BASE_URL || import.meta.env.VITE_BACKEND_URL || '/api';
  
  if (typeof window !== 'undefined' && window.location) {
    const currentHostname = window.location.hostname;
    // Rewrite localhost API targets to the current host IP/domain if accessed over network
    if (currentHostname && currentHostname !== 'localhost' && currentHostname !== '127.0.0.1') {
      try {
        if (envUrl.startsWith('http')) {
          const url = new URL(envUrl);
          if (url.hostname === 'localhost' || url.hostname === '127.0.0.1') {
            url.hostname = currentHostname;
            return url.toString();
          }
        }
      } catch (e) {
        // ignore parsing error
      }
    }
  }
  return envUrl;
};

const rawBaseUrl = getDynamicBaseUrl();
const baseURL = rawBaseUrl.replace(/\/$/, '');

const api = axios.create({ baseURL });

export const getApiUrl = (path: string) => {
  const normalized = path.startsWith('/') ? path : '/' + path;
  return baseURL + normalized;
};

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  config.headers = config.headers || {};
  if (token) {
    (config.headers as any).Authorization = 'Bearer ' + token;
  }
  (config.headers as any)['Cache-Control'] = 'no-cache, no-store, must-revalidate';
  (config.headers as any)['Pragma'] = 'no-cache';
  (config as any)._startTime = performance.now();
  if (import.meta.env.DEV) {
    console.log('[API REQ] ' + ((config.method || '').toUpperCase()) + ' ' + (config.url || ''));
  }
  return config;
});

api.interceptors.response.use(
  (response) => {
    if (import.meta.env.DEV) {
      const duration = (config: any) => (config && config._startTime ? (performance.now() - config._startTime).toFixed(0) + 'ms' : '');
      console.log('[API RES] ' + response.status + ' ' + (response.config.url || '') + ' ' + duration(response.config));
    }
    return response;
  },
  (error) => {
    if (import.meta.env.DEV) {
      const status = error.response && error.response.status ? error.response.status : 'NET_ERR';
      const url = (error.config && error.config.url) ? error.config.url : '';
      console.error('[API ERR] ' + status + ' ' + url, error.response && error.response.data ? error.response.data : error.message);
    }
    return Promise.reject(error);
  }
);

export default api;
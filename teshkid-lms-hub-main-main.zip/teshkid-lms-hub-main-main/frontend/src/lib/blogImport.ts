/**
 * Blog Content Import Utilities
 * Parse blog content from various external sources and formats
 */

interface ContentBlock {
  type: "text" | "heading" | "section" | "quote" | "table" | "tradingplan" | "chart";
  content: string;
  data?: Record<string, any>;
}

/**
 * Parse raw text content into structured blocks
 * Supports markdown-like formatting
 */
export const parseTextContent = (text: string): ContentBlock[] => {
  const blocks: ContentBlock[] = [];
  const lines = text.split("\n");
  let currentBlock: string[] = [];
  let currentType: ContentBlock["type"] = "text";

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Check for heading (# at start)
    if (line.startsWith("# ")) {
      if (currentBlock.length > 0) {
        blocks.push({
          type: currentType,
          content: currentBlock.join("\n").trim(),
        });
        currentBlock = [];
      }
      blocks.push({
        type: "heading",
        content: line.replace(/^#+\s/, "").trim(),
      });
      currentType = "text";
      continue;
    }

    // Check for trading plan (contains |)
    if (
      line.includes("|") &&
      (line.includes("Sell") || line.includes("Buy") || line.includes("Take Profit"))
    ) {
      if (currentBlock.length > 0) {
        blocks.push({
          type: currentType,
          content: currentBlock.join("\n").trim(),
        });
        currentBlock = [];
      }
      blocks.push({
        type: "tradingplan",
        content: line.trim(),
      });
      currentType = "text";
      continue;
    }

    // Check for quote (> at start)
    if (line.startsWith("> ")) {
      if (currentBlock.length > 0) {
        blocks.push({
          type: currentType,
          content: currentBlock.join("\n").trim(),
        });
        currentBlock = [];
      }
      const quoteContent = line.replace(/^>\s/, "").trim();
      blocks.push({
        type: "quote",
        content: quoteContent,
      });
      currentType = "text";
      continue;
    }

    // Check for blank line (block separator)
    if (line.trim() === "") {
      if (currentBlock.length > 0) {
        blocks.push({
          type: currentType,
          content: currentBlock.join("\n").trim(),
        });
        currentBlock = [];
        currentType = "text";
      }
      continue;
    }

    currentBlock.push(line);
  }

  // Add remaining block
  if (currentBlock.length > 0) {
    blocks.push({
      type: currentType,
      content: currentBlock.join("\n").trim(),
    });
  }

  return blocks.filter((block) => block.content.trim() !== "");
};

/**
 * Extract trading plans from text
 * Looks for patterns like "Sell X | Target Y | SL Z"
 */
export const extractTradingPlans = (text: string): ContentBlock[] => {
  const plans: ContentBlock[] = [];
  const lines = text.split("\n");

  lines.forEach((line) => {
    if (line.includes("|") && (line.includes("Sell") || line.includes("Buy"))) {
      plans.push({
        type: "tradingplan",
        content: line.trim(),
      });
    }
  });

  return plans;
};

/**
 * Convert HTML to content blocks
 * Useful for parsing web content
 */
export const parseHTMLContent = (html: string): ContentBlock[] => {
  const blocks: ContentBlock[] = [];

  // Simple regex-based parsing (for production, use proper HTML parser)
  const headingRegex = /<h[1-6]>(.*?)<\/h[1-6]>/gi;
  const paragraphRegex = /<p>(.*?)<\/p>/gi;
  const quoteRegex = /<blockquote>(.*?)<\/blockquote>/gi;

  let match;

  // Extract headings
  while ((match = headingRegex.exec(html))) {
    blocks.push({
      type: "heading",
      content: match[1].replace(/<[^>]*>/g, "").trim(),
    });
  }

  // Extract paragraphs
  while ((match = paragraphRegex.exec(html))) {
    const content = match[1].replace(/<[^>]*>/g, "").trim();
    if (content) {
      blocks.push({
        type: "text",
        content,
      });
    }
  }

  // Extract quotes
  while ((match = quoteRegex.exec(html))) {
    const content = match[1].replace(/<[^>]*>/g, "").trim();
    if (content) {
      blocks.push({
        type: "quote",
        content,
      });
    }
  }

  return blocks;
};

/**
 * Format trading plan for display
 * Converts pipe-delimited format to readable trading plan
 */
export const formatTradingPlan = (plan: string): string[] => {
  return plan
    .split("|")
    .map((item) => item.trim())
    .filter((item) => item.length > 0);
};

/**
 * Extract title from content
 * Looks for first heading or first line
 */
export const extractTitle = (text: string): string => {
  const lines = text.split("\n");

  for (const line of lines) {
    if (line.startsWith("# ")) {
      return line.replace(/^#+\s/, "").trim();
    }
    if (line.trim().length > 0 && line.length > 10) {
      return line.trim().substring(0, 100);
    }
  }

  return "Untitled Article";
};

/**
 * Extract description/summary from content
 * Gets first substantial paragraph
 */
export const extractDescription = (text: string): string => {
  const lines = text.split("\n");
  let description = "";

  for (const line of lines) {
    const trimmed = line.trim();
    if (
      trimmed.length > 0 &&
      !trimmed.startsWith("#") &&
      !trimmed.startsWith(">") &&
      !trimmed.includes("|")
    ) {
      description = trimmed;
      break;
    }
  }

  return description.substring(0, 160);
};

/**
 * Estimate read time in minutes
 */
export const estimateReadTime = (blocks: ContentBlock[]): number => {
  const wordsPerMinute = 200;
  let wordCount = 0;

  blocks.forEach((block) => {
    wordCount += block.content.split(/\s+/).length;
  });

  return Math.ceil(wordCount / wordsPerMinute);
};

/**
 * Create a blog preview from blocks
 */
export const createPreview = (
  blocks: ContentBlock[],
  maxLength: number = 160
): string => {
  for (const block of blocks) {
    if (block.type === "text") {
      const text = block.content.replace(/<[^>]*>/g, "").trim();
      if (text.length > 0) {
        return text.substring(0, maxLength) + "...";
      }
    }
  }
  return "Blog preview not available";
};

export default {
  parseTextContent,
  extractTradingPlans,
  parseHTMLContent,
  formatTradingPlan,
  extractTitle,
  extractDescription,
  estimateReadTime,
  createPreview,
};

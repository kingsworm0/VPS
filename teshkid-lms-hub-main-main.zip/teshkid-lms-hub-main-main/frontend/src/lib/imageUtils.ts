/**
 * Utility functions for handling image URLs consistently across the application
 */

/**
 * Constructs a full image URL from a relative path or returns null if invalid
 * @param path - The image path (can be relative or absolute URL)
 * @returns Full URL string or null
 */
export function getImageUrl(path: string | null | undefined): string | null {
  if (!path) return null;
  
  // If it's already a full URL, return as is
  if (path.startsWith('http://') || path.startsWith('https://')) {
    return path;
  }
  
  // If it's a data URL (base64), return as is
  if (path.startsWith('data:')) {
    return path;
  }
  
  // Construct URL relative to API base
  const baseUrl = import.meta.env.VITE_BACKEND_URL || 'http://localhost:3000';
  
  // Ensure the path starts with a slash
  const cleanPath = path.startsWith('/') ? path : `/${path}`;
  
  return `${baseUrl}${cleanPath}`;
}

/**
 * Gets initials from a name for avatar fallback
 * @param name - User's name
 * @returns Initials (1-2 characters)
 */
export function getInitials(name: string | undefined | null): string {
  if (!name) return '?';
  
  const parts = name.trim().split(/\s+/);
  
  if (parts.length === 1) {
    return parts[0].charAt(0).toUpperCase();
  }
  
  return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
}

/**
 * Validates if an image path/URL is likely valid
 * @param path - The image path to validate
 * @returns true if the path seems valid
 */
export function isValidImagePath(path: string | null | undefined): boolean {
  if (!path) return false;
  
  // Check if it's a valid URL
  if (path.startsWith('http://') || path.startsWith('https://')) {
    try {
      new URL(path);
      return true;
    } catch {
      return false;
    }
  }
  
  // Check if it's a data URL
  if (path.startsWith('data:image/')) {
    return true;
  }
  
  // Check if it's a relative path with common image extensions
  const imageExtensions = /\.(jpg|jpeg|png|gif|webp|svg)$/i;
  return imageExtensions.test(path);
}

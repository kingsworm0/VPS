// Utility function to update document title and meta tags
export const updateMetaTags = (
  title: string,
  description: string,
  url: string,
  image?: string
) => {
  // Update title
  document.title = title;

  // Update or create meta tags
  updateMetaTag("description", description);
  updateMetaTag("og:title", title);
  updateMetaTag("og:description", description);
  updateMetaTag("og:url", url);
  updateMetaTag("twitter:title", title);
  updateMetaTag("twitter:description", description);

  if (image) {
    updateMetaTag("og:image", image);
    updateMetaTag("twitter:image", image);
  }

  // Add canonical URL
  let canonical = document.querySelector('link[rel="canonical"]');
  if (!canonical) {
    canonical = document.createElement("link");
    canonical.setAttribute("rel", "canonical");
    document.head.appendChild(canonical);
  }
  (canonical as HTMLLinkElement).href = url;
};

const updateMetaTag = (name: string, content: string) => {
  let tag = document.querySelector(`meta[property="${name}"]`) ||
    document.querySelector(`meta[name="${name}"]`);

  if (!tag) {
    tag = document.createElement("meta");
    const isProperty = name.startsWith("og:") || name.startsWith("twitter:");
    if (isProperty) {
      tag.setAttribute("property", name);
    } else {
      tag.setAttribute("name", name);
    }
    document.head.appendChild(tag);
  }

  tag.setAttribute("content", content);
};

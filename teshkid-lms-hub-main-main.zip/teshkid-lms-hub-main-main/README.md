# Teshkid LMS Hub

A modern, full-featured Learning Management System (LMS) built with React, TypeScript, Node.js, Express, and MySQL. Designed for cryptocurrency and blockchain education with comprehensive course management, student progress tracking, gamification, and administrative tools.

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Node](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen.svg)
![React](https://img.shields.io/badge/react-18.x-blue.svg)
![TypeScript](https://img.shields.io/badge/typescript-5.x-blue.svg)

## 🌟 Features

### For Students
- **Course Enrollment & Management** - Browse, enroll, and track progress across multiple courses
- **Interactive Learning** - Video lessons, quizzes, assignments, and downloadable materials
- **Progress Tracking** - Visual progress indicators for courses, modules, and lessons
- **Gamification** - XP points, level progression, daily streaks, and achievement system
- **Personalized Dashboard** - Overview of enrolled courses, completion rates, and learning stats
- **Certificate Generation** - Earn certificates upon course completion
- **Note-Taking** - Take timestamped notes during video lessons
- **Live Sessions** - Join scheduled live sessions with instructors
- **Blog & Resources** - Access educational blog posts and trading insights

### For Administrators
- **Course Management** - Create, edit, and organize courses with modules and lessons
- **Content Upload** - Upload videos, documents, and course materials
- **Student Management** - View student enrollments, progress, and activity
- **Enrollment Approval** - Review and approve/reject course enrollment requests
- **Analytics Dashboard** - Track platform metrics, user activity, and course performance
- **Blog Management** - Create and publish educational blog posts
- **Announcements** - Send system-wide announcements to users
- **User Management** - Manage user accounts, roles, and permissions
- **Live Session Scheduling** - Create and manage live sessions

### Technical Features
- **RESTful API** - Well-structured backend API with Express.js
- **JWT Authentication** - Secure authentication and authorization
- **Role-Based Access Control (RBAC)** - Separate permissions for students and admins
- **File Upload Management** - Secure file uploads with validation
- **Rate Limiting** - API rate limiting to prevent abuse
- **Security Headers** - Helmet.js for enhanced security
- **CORS Configuration** - Configurable CORS for frontend integration
- **Database Migrations** - Version-controlled database schema changes
- **Responsive Design** - Mobile-first, responsive UI with Tailwind CSS
- **Dark Mode** - Built-in dark mode support

---

## 📋 Table of Contents

- [Tech Stack](#-tech-stack)
- [Prerequisites](#-prerequisites)
- [Installation](#-installation)
- [Configuration](#-configuration)
- [Running the Application](#-running-the-application)
- [Project Structure](#-project-structure)
- [API Documentation](#-api-documentation)
- [Database Schema](#-database-schema)
- [Deployment](#-deployment)
- [Contributing](#-contributing)
- [License](#-license)

---

## 🛠 Tech Stack

### Frontend
- **React 18** - UI library
- **TypeScript** - Type-safe JavaScript
- **Vite** - Fast build tool and dev server
- **React Router** - Client-side routing
- **Tailwind CSS** - Utility-first CSS framework
- **Axios** - HTTP client
- **React Icons** - Icon library
- **Lucide React** - Modern icon set

### Backend
- **Node.js 18+** - JavaScript runtime
- **Express 5** - Web framework
- **TypeScript** - Type-safe backend development
- **MySQL 8** - Relational database
- **JWT** - Authentication tokens
- **bcrypt.js** - Password hashing
- **Multer** - File upload handling
- **Helmet** - Security headers
- **CORS** - Cross-origin resource sharing
- **express-rate-limit** - Rate limiting

### Development Tools
- **ESLint** - Code linting
- **Prettier** - Code formatting
- **ts-node** - TypeScript execution
- **PM2** - Process management (production)
- **Concurrently** - Run multiple scripts

---

## 📦 Prerequisites

Before you begin, ensure you have the following installed:

- **Node.js** >= 18.0.0 ([Download](https://nodejs.org/))
- **npm** >= 9.0.0 (comes with Node.js)
- **MySQL** >= 8.0 ([Download](https://dev.mysql.com/downloads/mysql/))
- **Git** ([Download](https://git-scm.com/downloads))

Verify installation:
```bash
node --version  # Should be v18.0.0 or higher
npm --version   # Should be 9.0.0 or higher
mysql --version # Should be 8.0 or higher
```

---

## 🚀 Installation

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/teshkid-lms-hub.git
cd teshkid-lms-hub
```

### 2. Install Dependencies

Install dependencies for both frontend and backend:

```bash
# Install all dependencies (frontend + backend)
npm run install:all

# Or install individually
cd frontend && npm install
cd ../backend && npm install
```

### 3. Database Setup

Create a MySQL database:

```bash
# Login to MySQL
mysql -u root -p

# Create database
CREATE DATABASE teshkid_lms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# Exit MySQL
EXIT;
```

Import the database schema:

```bash
# From the root directory
mysql -u root -p teshkid_lms < create.sql
```

---

## ⚙️ Configuration

### Backend Configuration

1. Copy the environment example file:
```bash
cd backend
cp .env.example .env
```

2. Edit `.env` with your configuration:
```env
# Environment
NODE_ENV=development

# Server
PORT=3000

# Database
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=teshkid_lms

# JWT Secret (generate a strong random string)
JWT_SECRET=your_super_secure_random_jwt_secret_at_least_32_chars

# CORS
ALLOWED_ORIGINS=http://localhost:5173
FRONTEND_URL=http://localhost:5173

# Admin Account (for initial setup)
ADMIN_EMAIL=admin@teshkid.com
ADMIN_PASSWORD=Admin123!@#
ADMIN_NAME=Teshkid Is Crypto
```

3. Generate a secure JWT secret:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

4. Create admin account:
```bash
npm run create-admin
```

### Frontend Configuration

1. Copy the environment example file:
```bash
cd frontend
cp .env.example .env
```

2. Edit `.env` with your configuration:
```env
# Backend API URL (for development)
VITE_BACKEND_URL=http://127.0.0.1:3000

# API Base URL (used in production)
VITE_API_BASE_URL=/api
```

---

## 🏃 Running the Application

### Development Mode

Run both frontend and backend concurrently:

```bash
# From root directory
npm run dev
```

Or run them separately:

```bash
# Terminal 1 - Backend
cd backend
npm run dev

# Terminal 2 - Frontend
cd frontend
npm run dev
```

The application will be available at:
- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:3000

### Production Mode

1. Build the applications:
```bash
# Build backend
cd backend
npm run build

# Build frontend
cd frontend
npm run build
```

2. Start the backend:
```bash
cd backend
npm start

# Or use PM2 for process management
pm2 start dist/index.js --name teshkid-backend
```

3. Serve the frontend:
   - Deploy the `frontend/dist` folder to a web server (Nginx, Apache)
   - Or use a static hosting service (Netlify, Vercel, S3 + CloudFront)

---

## 📁 Project Structure

```
teshkid-lms-hub/
├── backend/                    # Backend application
│   ├── src/
│   │   ├── routes/            # API route handlers
│   │   ├── middleware/        # Express middleware
│   │   ├── migrations/        # Database migrations
│   │   ├── utils/             # Utility functions
│   │   ├── config.ts          # Configuration management
│   │   ├── database.ts        # Database connection
│   │   └── index.ts           # Application entry point
│   ├── scripts/               # Utility scripts
│   ├── uploads/               # User uploaded files
│   ├── logs/                  # Application logs
│   ├── .env.example           # Environment variables template
│   ├── package.json           # Backend dependencies
│   └── tsconfig.json          # TypeScript configuration
│
├── frontend/                   # Frontend application
│   ├── src/
│   │   ├── components/        # React components
│   │   ├── pages/             # Page components
│   │   ├── contexts/          # React contexts
│   │   ├── types/             # TypeScript type definitions
│   │   ├── lib/               # Utility libraries
│   │   ├── App.tsx            # Main app component
│   │   └── main.tsx           # Application entry point
│   ├── public/                # Static assets
│   ├── .env.example           # Environment variables template
│   ├── package.json           # Frontend dependencies
│   ├── tsconfig.json          # TypeScript configuration
│   ├── tailwind.config.ts     # Tailwind CSS configuration
│   └── vite.config.ts         # Vite configuration
│
├── create.sql                 # Database schema
├── .env.example               # Root environment template
├── .gitignore                 # Git ignore rules
├── package.json               # Root package.json for scripts
├── DEPLOYMENT.md              # Deployment guide
└── README.md                  # This file
```

---

## 📚 API Documentation

### Authentication Endpoints

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/api/auth/register` | Register new user | No |
| POST | `/api/auth/login` | User login | No |
| GET | `/api/auth/profile` | Get user profile | Yes |
| PUT | `/api/auth/profile` | Update profile | Yes |

### Course Endpoints

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/api/courses` | Get all courses | No |
| GET | `/api/courses/:id` | Get course details | No |
| POST | `/api/courses` | Create course | Admin |
| PUT | `/api/courses/:id` | Update course | Admin |
| DELETE | `/api/courses/:id` | Delete course | Admin |

### Enrollment Endpoints

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/api/enrollments` | Enroll in course | Student |
| GET | `/api/enrollments/my` | Get my enrollments | Student |
| PUT | `/api/enrollments/:id` | Update enrollment | Student |

### Admin Endpoints

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/api/admin/users` | Get all users | Admin |
| GET | `/api/admin/enrollments` | Get all enrollments | Admin |
| PUT | `/api/admin/enrollments/:id/approve` | Approve enrollment | Admin |
| PUT | `/api/admin/enrollments/:id/reject` | Reject enrollment | Admin |
| GET | `/api/admin/stats` | Get platform stats | Admin |

For complete API documentation, see the individual route files in `backend/src/routes/`.

---

## 🗄 Database Schema

The database consists of the following main tables:

- **users** - User accounts (students, admins)
- **courses** - Course information
- **modules** - Course modules
- **lessons** - Individual lessons within modules
- **enrollments** - Student course enrollments
- **lesson_progress** - Student progress tracking
- **quizzes** - Quiz information
- **quiz_questions** - Quiz questions
- **quiz_attempts** - Student quiz attempts
- **assignments** - Course assignments
- **assignment_submissions** - Student submissions
- **certificates** - Issued certificates
- **blogs** - Blog posts
- **announcements** - System announcements
- **messages** - User messages
- **notes** - Student notes
- **live_sessions** - Live session information

For the complete schema with relationships, see `create.sql`.

---

## 🚢 Deployment

For detailed deployment instructions, see [DEPLOYMENT.md](DEPLOYMENT.md).

### Quick Deployment Steps

1. **Prepare Server**
   - Ubuntu 20.04+ or similar
   - Node.js 18+, MySQL 8+, Nginx
   - SSL certificate for HTTPS

2. **Configure Environment**
   - Set production environment variables
   - Generate strong JWT secret
   - Configure database credentials

3. **Build Applications**
   ```bash
   cd backend && npm run build
   cd ../frontend && npm run build
   ```

4. **Deploy Backend**
   ```bash
   pm2 start dist/index.js --name teshkid-backend
   pm2 save
   ```

5. **Deploy Frontend**
   - Copy `frontend/dist` to web root
   - Configure Nginx reverse proxy
   - Enable HTTPS

6. **Verify Deployment**
   - Test all major features
   - Check logs for errors
   - Monitor performance

---

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Development Guidelines

- Follow the existing code style
- Write meaningful commit messages
- Add tests for new features
- Update documentation as needed
- Ensure all tests pass before submitting PR

---

## 🐛 Bug Reports & Feature Requests

Please use the [GitHub Issues](https://github.com/yourusername/teshkid-lms-hub/issues) page to report bugs or request features.

When reporting bugs, please include:
- Operating system and version
- Node.js and npm versions
- Steps to reproduce the issue
- Expected vs actual behavior
- Screenshots (if applicable)

---

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 👥 Authors

- **Teshkid Team** - Initial work

---

## 🙏 Acknowledgments

- React and TypeScript communities
- Express.js team
- All contributors and supporters

---

## 📞 Support

For support and questions:
- **Email**: support@teshkid.com
- **Documentation**: See [DEPLOYMENT.md](DEPLOYMENT.md)
- **Issues**: [GitHub Issues](https://github.com/yourusername/teshkid-lms-hub/issues)

---

## 🔒 Security

For security concerns, please email security@teshkid.com instead of using the public issue tracker.

### Security Features

- JWT-based authentication
- Password hashing with bcrypt
- Rate limiting on API endpoints
- CORS protection
- Security headers via Helmet
- Input validation and sanitization
- SQL injection prevention
- XSS protection

---

## 📊 System Requirements

### Development
- **OS**: Windows 10+, macOS 10.15+, Ubuntu 20.04+
- **CPU**: 2+ cores
- **RAM**: 4GB minimum, 8GB recommended
- **Storage**: 10GB free space

### Production
- **OS**: Ubuntu 20.04+ LTS (recommended)
- **CPU**: 2-4+ cores
- **RAM**: 4-8GB minimum
- **Storage**: 20GB+ SSD
- **Network**: 100Mbps+ bandwidth

---

## 🗺 Roadmap

- [ ] Real-time notifications
- [ ] Video conferencing integration
- [ ] Mobile application (React Native)
- [ ] Discussion forums
- [ ] Payment gateway integration
- [ ] Advanced analytics dashboard
- [ ] Multi-language support
- [ ] Automated testing suite
- [ ] Docker containerization
- [ ] Kubernetes deployment configs

---

**Made with ❤️ by the Teshkid Team**

-- Create Database
CREATE DATABASE IF NOT EXISTS teshkid_lms;
USE teshkid_lms;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(36) PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  username VARCHAR(255) UNIQUE,
  password VARCHAR(255) NOT NULL,
  name VARCHAR(255) NOT NULL,
  firstName VARCHAR(255) NOT NULL,
  lastName VARCHAR(255),
  role VARCHAR(50) DEFAULT 'STUDENT',
  profilePicture VARCHAR(500),
  bio LONGTEXT,
  timezone VARCHAR(100) DEFAULT 'Europe/Amsterdam',
  language VARCHAR(50) DEFAULT 'English (UK)',
  courseReminders BOOLEAN DEFAULT TRUE,
  privacyVisibility VARCHAR(20) DEFAULT 'public',
  privacyActivityStatus BOOLEAN DEFAULT TRUE,
  privacyAppearInSearch BOOLEAN DEFAULT TRUE,
  privacyAnalyticsTracking BOOLEAN DEFAULT TRUE,
  creditCard VARCHAR(100),
  mpesaPhone VARCHAR(50),
  phone VARCHAR(50),
  address VARCHAR(255),
  city VARCHAR(100),
  state VARCHAR(100),
  country VARCHAR(100),
  postalCode VARCHAR(20),
  xp INT DEFAULT 0,
  streak INT DEFAULT 0,
  lastLoginDate DATE,
  dailyGoalLessons INT DEFAULT 3,
  isBlocked BOOLEAN DEFAULT FALSE,
  isPremium BOOLEAN DEFAULT FALSE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_username (username),
  INDEX idx_role (role)
);

-- Live Sessions Table (admin-created, student-viewable)
CREATE TABLE IF NOT EXISTS live_sessions (
  id VARCHAR(36) PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description LONGTEXT,
  hostName VARCHAR(255),
  meetingLink VARCHAR(500),
  scheduledAt DATETIME NOT NULL,
  durationMinutes INT DEFAULT 60,
  status VARCHAR(30) DEFAULT 'UPCOMING',
  courseId VARCHAR(36),
  createdBy VARCHAR(36),
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_status (status),
  INDEX idx_scheduledAt (scheduledAt)
);

-- Courses Table
CREATE TABLE IF NOT EXISTS courses (
  id VARCHAR(36) PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description LONGTEXT,
  instructor VARCHAR(255),
  thumbnail VARCHAR(500),
  level VARCHAR(50),
  duration VARCHAR(50),
  price FLOAT DEFAULT 0,
  cryptoPrice VARCHAR(100),
  bannerUrl VARCHAR(500),
  previewVideoUrl VARCHAR(500),
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_title (title)
);

-- Modules Table
CREATE TABLE IF NOT EXISTS modules (
  id VARCHAR(36) PRIMARY KEY,
  courseId VARCHAR(36) NOT NULL,
  title VARCHAR(255) NOT NULL,
  description LONGTEXT,
  `order` INT DEFAULT 0,
  sortOrder INT DEFAULT 0,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (courseId) REFERENCES courses(id) ON DELETE CASCADE,
  INDEX idx_courseId (courseId),
  INDEX idx_order (`order`),
  INDEX idx_sortOrder (sortOrder)
);

-- Lessons Table
CREATE TABLE IF NOT EXISTS lessons (
  id VARCHAR(36) PRIMARY KEY,
  moduleId VARCHAR(36) NOT NULL,
  title VARCHAR(255) NOT NULL,
  duration VARCHAR(50),
  type VARCHAR(50),
  content LONGTEXT,
  videoUrl VARCHAR(500),
  description LONGTEXT,
  `order` INT DEFAULT 0,
  sortOrder INT DEFAULT 0,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (moduleId) REFERENCES modules(id) ON DELETE CASCADE,
  INDEX idx_moduleId (moduleId),
  INDEX idx_order (`order`),
  INDEX idx_sortOrder (sortOrder)
);

-- Enrollments Table
CREATE TABLE IF NOT EXISTS enrollments (
  id VARCHAR(36) PRIMARY KEY,
  userId VARCHAR(36) NOT NULL,
  courseId VARCHAR(36) NOT NULL,
  progress INT DEFAULT 0,
  status ENUM('PENDING', 'APPROVED', 'REJECTED') DEFAULT 'PENDING',
  studentMessage TEXT,
  transactionId VARCHAR(255),
  paymentStatus ENUM('PENDING', 'COMPLETED', 'FAILED') DEFAULT 'PENDING',
  amount DECIMAL(10, 2),
  enrolledAt TIMESTAMP NULL,
  approvedAt TIMESTAMP NULL,
  rejectionReason TEXT NULL,
  paymentMethod VARCHAR(50),
  paymentId VARCHAR(100),
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (courseId) REFERENCES courses(id) ON DELETE CASCADE,
  UNIQUE KEY unique_enrollment (userId, courseId),
  INDEX idx_userId (userId),
  INDEX idx_courseId (courseId),
  INDEX idx_status (status),
  INDEX idx_paymentStatus (paymentStatus)
);

-- Messages Table
CREATE TABLE IF NOT EXISTS messages (
  id VARCHAR(36) PRIMARY KEY,
  userId VARCHAR(36) NOT NULL,
  subject VARCHAR(255),
  content LONGTEXT,
  reply LONGTEXT,
  isRead BOOLEAN DEFAULT FALSE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_userId (userId),
  INDEX idx_isRead (isRead)
);

-- Announcements Table
CREATE TABLE IF NOT EXISTS announcements (
  id VARCHAR(36) PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  content LONGTEXT,
  type VARCHAR(50) DEFAULT 'info',
  isActive BOOLEAN DEFAULT TRUE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_isActive (isActive)
);

-- Course Contents Table
CREATE TABLE IF NOT EXISTS course_contents (
  id VARCHAR(36) PRIMARY KEY,
  courseId VARCHAR(36),
  title VARCHAR(255),
  description LONGTEXT,
  fileUrl VARCHAR(500),
  fileType VARCHAR(50),
  uploadedBy VARCHAR(36),
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (courseId) REFERENCES courses(id) ON DELETE CASCADE,
  INDEX idx_courseId (courseId)
);

-- Lesson Progress Table
CREATE TABLE IF NOT EXISTS lesson_progress (
  id VARCHAR(36) PRIMARY KEY,
  userId VARCHAR(36) NOT NULL,
  lessonId VARCHAR(36) NOT NULL,
  completed BOOLEAN DEFAULT FALSE,
  timeSpent INT DEFAULT 0,
  lastPosition INT DEFAULT 0,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (lessonId) REFERENCES lessons(id) ON DELETE CASCADE,
  UNIQUE KEY unique_progress (userId, lessonId),
  INDEX idx_userId (userId),
  INDEX idx_completed (completed)
);

-- Quizzes Table
CREATE TABLE IF NOT EXISTS quizzes (
  id VARCHAR(36) PRIMARY KEY,
  moduleId VARCHAR(36) NOT NULL,
  title VARCHAR(255) NOT NULL,
  description LONGTEXT,
  passingScore INT DEFAULT 70,
  timeLimit INT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (moduleId) REFERENCES modules(id) ON DELETE CASCADE,
  INDEX idx_moduleId (moduleId)
);

-- Quiz Questions Table
CREATE TABLE IF NOT EXISTS quiz_questions (
  id VARCHAR(36) PRIMARY KEY,
  quizId VARCHAR(36) NOT NULL,
  question LONGTEXT NOT NULL,
  questionType VARCHAR(50),
  options JSON,
  correctAnswer LONGTEXT,
  explanation LONGTEXT,
  points INT DEFAULT 1,
  `order` INT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (quizId) REFERENCES quizzes(id) ON DELETE CASCADE,
  INDEX idx_quizId (quizId)
);

-- Quiz Attempts Table
CREATE TABLE IF NOT EXISTS quiz_attempts (
  id VARCHAR(36) PRIMARY KEY,
  userId VARCHAR(36) NOT NULL,
  quizId VARCHAR(36) NOT NULL,
  answers JSON,
  score INT,
  passed BOOLEAN,
  timeSpent INT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (quizId) REFERENCES quizzes(id) ON DELETE CASCADE,
  INDEX idx_userId (userId),
  INDEX idx_quizId (quizId)
);

-- Assignments Table
CREATE TABLE IF NOT EXISTS assignments (
  id VARCHAR(36) PRIMARY KEY,
  moduleId VARCHAR(36) NOT NULL,
  title VARCHAR(255) NOT NULL,
  description LONGTEXT,
  dueDate DATETIME,
  maxPoints INT DEFAULT 100,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (moduleId) REFERENCES modules(id) ON DELETE CASCADE,
  INDEX idx_moduleId (moduleId)
);

-- Assignment Submissions Table
CREATE TABLE IF NOT EXISTS assignment_submissions (
  id VARCHAR(36) PRIMARY KEY,
  assignmentId VARCHAR(36) NOT NULL,
  userId VARCHAR(36) NOT NULL,
  content LONGTEXT,
  fileUrl VARCHAR(500),
  score INT,
  feedback LONGTEXT,
  submittedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  gradedAt DATETIME,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (assignmentId) REFERENCES assignments(id) ON DELETE CASCADE,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_submission (assignmentId, userId),
  INDEX idx_userId (userId)
);

-- Notes Table
CREATE TABLE IF NOT EXISTS notes (
  id VARCHAR(36) PRIMARY KEY,
  userId VARCHAR(36) NOT NULL,
  lessonId VARCHAR(36) NOT NULL,
  content LONGTEXT,
  timestamp INT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (lessonId) REFERENCES lessons(id) ON DELETE CASCADE,
  INDEX idx_userId (userId)
);

-- Certificates Table
CREATE TABLE IF NOT EXISTS certificates (
  id VARCHAR(36) PRIMARY KEY,
  userId VARCHAR(36) NOT NULL,
  courseId VARCHAR(36) NOT NULL,
  certificateUrl VARCHAR(500),
  issuedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (courseId) REFERENCES courses(id) ON DELETE CASCADE,
  UNIQUE KEY unique_certificate (userId, courseId),
  INDEX idx_userId (userId)
);

-- Blogs Table
CREATE TABLE IF NOT EXISTS blogs (
  id VARCHAR(36) PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  slug VARCHAR(255) UNIQUE NOT NULL,
  content LONGTEXT NOT NULL,
  description VARCHAR(500),
  category VARCHAR(100),
  tags JSON,
  featuredImage VARCHAR(500),
  coverImage VARCHAR(500),
  author VARCHAR(255),
  reviewer VARCHAR(255),
  authorId VARCHAR(36),
  contentBlocks JSON,
  keyTakeaways JSON,
  gallery JSON,
  status ENUM('draft', 'published') DEFAULT 'published',
  viewCount INT DEFAULT 0,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deletedAt TIMESTAMP NULL,
  publishedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  isPublished BOOLEAN DEFAULT TRUE,
  INDEX idx_slug (slug),
  INDEX idx_category (category),
  INDEX idx_status (status),
  INDEX idx_viewCount (viewCount),
  INDEX idx_createdAt (createdAt),
  INDEX idx_deletedAt (deletedAt),
  INDEX idx_isPublished (isPublished),
  INDEX idx_authorId (authorId)
);

-- Course Materials Table
CREATE TABLE IF NOT EXISTS course_materials (
  id VARCHAR(36) PRIMARY KEY,
  courseId VARCHAR(36) NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  type ENUM('VIDEO', 'PDF', 'DOCUMENT', 'LINK') NOT NULL,
  filePath VARCHAR(255),
  fileUrl VARCHAR(255),
  duration INT COMMENT 'Video duration in seconds',
  isVisible BOOLEAN DEFAULT 1,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (courseId) REFERENCES courses(id) ON DELETE CASCADE,
  INDEX idx_courseId (courseId),
  INDEX idx_type (type),
  INDEX idx_isVisible (isVisible)
);

-- Course Material Access Table
CREATE TABLE IF NOT EXISTS course_material_access (
  id INT AUTO_INCREMENT PRIMARY KEY,
  materialId VARCHAR(36) NOT NULL,
  userId VARCHAR(36),
  grantedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (materialId) REFERENCES course_materials(id) ON DELETE CASCADE,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_access (materialId, userId),
  INDEX idx_materialId (materialId),
  INDEX idx_userId (userId)
) COMMENT 'NULL userId means all enrolled students have access';

-- Course Progress Table
CREATE TABLE IF NOT EXISTS course_progress (
  id VARCHAR(36) PRIMARY KEY,
  enrollmentId VARCHAR(36) NOT NULL,
  materialId VARCHAR(36) NOT NULL,
  completedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  watchTime INT COMMENT 'Watch time in seconds for videos',
  progressPercentage INT DEFAULT 100,
  FOREIGN KEY (enrollmentId) REFERENCES enrollments(id) ON DELETE CASCADE,
  FOREIGN KEY (materialId) REFERENCES course_materials(id) ON DELETE CASCADE,
  UNIQUE KEY unique_progress (enrollmentId, materialId),
  INDEX idx_enrollmentId (enrollmentId),
  INDEX idx_materialId (materialId)
);

-- Password Reset Tokens Table
CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id VARCHAR(36) PRIMARY KEY,
  userId VARCHAR(36) NOT NULL,
  token VARCHAR(255) NOT NULL UNIQUE,
  expiresAt DATETIME NOT NULL,
  isUsed BOOLEAN DEFAULT FALSE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_token (token),
  INDEX idx_userId (userId),
  INDEX idx_expiresAt (expiresAt)
);

-- Seed Master Admin Account
INSERT INTO users (id, email, password, name, firstName, lastName, role, createdAt, updatedAt)
VALUES ('33f86e88-3482-4f36-9791-6c4b2ffb3846', 'admin@teshkid.com', '$2b$10$qjwZocN.hRPtJRFIB9YZqexqNFSLgq5AzURA0yuJ5L14J/c0Rj/wG', 'Teshkid Is Crypto', 'Teshkid Is', 'Crypto', 'ADMIN', NOW(), NOW())
ON DUPLICATE KEY UPDATE name = 'Teshkid Is Crypto', firstName = 'Teshkid Is', lastName = 'Crypto', role = 'ADMIN';


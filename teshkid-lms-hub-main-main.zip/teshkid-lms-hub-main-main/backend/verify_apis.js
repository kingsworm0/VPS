const API_BASE = "http://localhost:3000/api";

const endpoints = [
  "/admin/stats",
  "/admin/users",
  "/admin/enrollments/pending",
  "/admin/system/metrics",
  "/admin/progress/analytics/courses",
  "/admin/progress/analytics/system",
  "/admin/progress/students/progress",
  "/student/profile",
  "/student/dashboard",
  "/student/courses",
  "/student/resources",
  "/courses",
  "/blogs",
  "/announcements"
];

async function verifyAPIs() {
  console.log("Verifying APIs...");
  let errors = 0;

  for (const endpoint of endpoints) {
    try {
      const res = await fetch(API_BASE + endpoint);
      if (res.status === 500) {
        console.error("X " + endpoint + " returned 500 Internal Server Error");
        errors++;
      } else {
        console.log("OK " + endpoint + " returned " + res.status);
      }
    } catch (err) {
      console.error("X " + endpoint + " failed to connect: " + err.message);
      errors++;
    }
  }

  if (errors > 0) {
    console.error("\\n" + errors + " endpoints failed.");
    process.exit(1);
  } else {
    console.log("\\nAll APIs verified successfully (no 500 errors).");
    process.exit(0);
  }
}

verifyAPIs();

import { query } from "../src/database";

async function run() {
  try {
    console.log("Altering live_sessions table...");
    await query("ALTER TABLE live_sessions ADD COLUMN bannerUrl VARCHAR(255) DEFAULT NULL;");
    console.log("Column bannerUrl added successfully.");
  } catch (error: any) {
    if (error.message.includes("Duplicate column name")) {
      console.log("Column bannerUrl already exists.");
    } else {
      console.error("Error altering table:", error);
    }
  }
  process.exit(0);
}

run();

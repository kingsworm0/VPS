import mysql from "mysql2/promise";
import fs from "fs";
import path from "path";
import bcrypt from "bcryptjs";
import { v4 as uuidv4 } from "uuid";
import dotenv from "dotenv";

// Load environment variables
const envPath = path.resolve(__dirname, "../../.env");
dotenv.config({ path: envPath });

const DB_HOST = process.env.DB_HOST || "127.0.0.1";
const DB_PORT = parseInt(process.env.DB_PORT || "3306");
const DB_USER = process.env.DB_USER || "root";
const DB_PASSWORD = process.env.DB_PASSWORD || "";
const DB_NAME = process.env.DB_NAME || "teshkid_lms";

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "admin@teshkid.com";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "TeshkidAdmin2026!";
const ADMIN_NAME = process.env.ADMIN_NAME || "Teshkid Is Crypto";

async function resetDatabase() {
  let connection;
  try {
    console.log("🔄 Starting database reset and fresh setup...");
    console.log(`Connecting to MySQL server at ${DB_HOST}:${DB_PORT} as ${DB_USER}...`);

    // 1. Connect without database to drop and recreate it
    connection = await mysql.createConnection({
      host: DB_HOST,
      port: DB_PORT,
      user: DB_USER,
      password: DB_PASSWORD,
      multipleStatements: true,
    });

    console.log("✅ Connected to MySQL server.");

    // 2. Drop and recreate database
    console.log(`🗑️ Dropping database ${DB_NAME} if exists...`);
    await connection.query(`DROP DATABASE IF EXISTS \`${DB_NAME}\``);

    console.log(`🏗️ Creating database ${DB_NAME}...`);
    await connection.query(`CREATE DATABASE \`${DB_NAME}\``);
    await connection.query(`USE \`${DB_NAME}\``);

    // 3. Read and parse schema file
    const schemaPath = path.resolve(__dirname, "../prisma/schema.sql");
    console.log(`📄 Reading schema from ${schemaPath}...`);
    const schemaSql = fs.readFileSync(schemaPath, "utf8");

    // Split SQL by semicolons, filter out comments and empty statements
    const statements = schemaSql
      .split(/;\s*$/m)
      .map((statement) => statement.trim())
      .filter((statement) => statement.length > 0 && !statement.startsWith("--"));

    console.log(`⚙️ Executing ${statements.length} schema statements...`);
    for (const statement of statements) {
      // Skip the default seed admin query if it is in the schema, as we do it dynamically
      if (statement.includes("INSERT INTO users") && statement.includes("admin@teshkid.com")) {
        continue;
      }
      await connection.query(statement);
    }
    console.log("✅ Schema initialized successfully.");

    // 4. Create master admin user dynamically using .env configuration
    console.log("👤 Seeding master administrator account...");
    
    // Hash password
    const hashedPassword = await bcrypt.hash(ADMIN_PASSWORD, 10);
    const adminId = "33f86e88-3482-4f36-9791-6c4b2ffb3846"; // Constant ID for seed admin

    await connection.query(
      `INSERT INTO users (id, email, password, name, role, createdAt, updatedAt) 
       VALUES (?, ?, ?, ?, 'ADMIN', NOW(), NOW())
       ON DUPLICATE KEY UPDATE email = ?, password = ?, name = ?`,
      [adminId, ADMIN_EMAIL, hashedPassword, ADMIN_NAME, ADMIN_EMAIL, hashedPassword, ADMIN_NAME]
    );

    console.log(`🎉 Master Admin seeded:`);
    console.log(`   Email: ${ADMIN_EMAIL}`);
    console.log(`   Name:  ${ADMIN_NAME}`);

  } catch (error) {
    console.error("❌ Database reset failed:", error);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
      console.log("🔌 Connection closed.");
    }
  }
}

// Execute the reset
resetDatabase()
  .then(() => {
    console.log("🏁 Database setup complete. Initializing course seed...");
    // Run the course seed process
    require("../seed-courses");
  })
  .catch((err) => {
    console.error("❌ Reset script execution failed:", err);
    process.exit(1);
  });

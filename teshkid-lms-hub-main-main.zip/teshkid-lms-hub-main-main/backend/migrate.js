const mysql = require('mysql2/promise');
const dotenv = require('dotenv');
const path = require('path');
dotenv.config({ path: path.resolve(__dirname, '.env') });

async function migrate() {
  const connection = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'teshkid_lms'
  });

  try {
    console.log("Adding columns to courses...");
    await connection.query('ALTER TABLE courses ADD COLUMN bannerUrl VARCHAR(500)');
    await connection.query('ALTER TABLE courses ADD COLUMN previewVideoUrl VARCHAR(500)');
  } catch (e) {
    console.log("courses error (maybe already exists):", e.message);
  }

  try {
    console.log("Adding columns to blogs...");
    try {
      await connection.query('ALTER TABLE blogs ADD COLUMN author VARCHAR(255)');
    } catch (e) {
      console.log("blogs: author column add error (may already exist):", e.message);
    }
    try {
      await connection.query('ALTER TABLE blogs ADD COLUMN reviewer VARCHAR(255)');
    } catch (e) {
      console.log("blogs: reviewer column add error (may already exist):", e.message);
    }
    try {
      await connection.query('ALTER TABLE blogs ADD COLUMN contentBlocks JSON');
    } catch (e) {
      console.log("blogs: contentBlocks column add error (may already exist):", e.message);
    }
    try {
      await connection.query('ALTER TABLE blogs ADD COLUMN keyTakeaways JSON');
    } catch (e) {
      console.log("blogs: keyTakeaways column add error (may already exist):", e.message);
    }
    try {
      await connection.query('ALTER TABLE blogs ADD COLUMN gallery JSON');
    } catch (e) {
      console.log("blogs: gallery column add error (may already exist):", e.message);
    }
  } catch (e) {
    console.log("blogs error (unexpected):", e.message);
  }

  // Ensure blog_likes and blog_dislikes tables exist. These are small join tables that
  // track which user liked/disliked which blog. Create them if missing to avoid runtime 500s.
  try {
    console.log("Ensuring blog_likes and blog_dislikes tables exist...");
    await connection.query(`
      CREATE TABLE IF NOT EXISTS blog_likes (
        id VARCHAR(36) NOT NULL PRIMARY KEY,
        blogId VARCHAR(36) NOT NULL,
        userId VARCHAR(36) NOT NULL,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX (blogId),
        INDEX (userId)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);

    await connection.query(`
      CREATE TABLE IF NOT EXISTS blog_dislikes (
        id VARCHAR(36) NOT NULL PRIMARY KEY,
        blogId VARCHAR(36) NOT NULL,
        userId VARCHAR(36) NOT NULL,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX (blogId),
        INDEX (userId)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
  } catch (e) {
    console.log("Error ensuring blog_likes/blog_dislikes tables:", e.message);
  }

  console.log("Done");
  await connection.end();
}

migrate();

import express from "express";
import cors from "cors";
import path from "path";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import { config } from "./config";
import authRoutes from "./routes/authRoutes";
import courseRoutes from "./routes/courseRoutes";
import adminRoutes from "./routes/adminRoutes";
import adminProgressRoutes from "./routes/adminProgressRoutes";
import announcementsRoutes from "./routes/announcementRoutes";
import studentRoutes from "./routes/studentRoutes";
import messageRoutes from "./routes/messageRoutes";
import blogRoutes from "./routes/blogRoutes";
import uploadRoutes from "./routes/uploadRoutes";
import apiRouter from "./routes/apiRouter";
import { query } from "./database";
import { authenticateToken } from "./middleware/authMiddleware";
import { validateRequestParams, sanitizeBody } from "./middleware/validationMiddleware";
import { runMigrations } from "./migrations";
import { logger } from "./utils/logger";

const app = express();
const PORT = config.PORT;

// Disable etag caching for dynamic API responses to prevent stale 304 responses
app.disable("etag");

// Hide Express fingerprint
app.disable("x-powered-by");

// ============================================
// 1. CORS Configuration - Applied First
// ============================================
// Allow requests from any origin and support credentials by echoing the
// origin back. This makes the API accessible from other machines on the
// network while still allowing cookies/auth headers when credentials are used.
app.set('trust proxy', 1); // trust first proxy

const corsOptions: cors.CorsOptions = {
  // Reflect the request origin (allows credentials and cross-origin calls)
  origin: true,
  credentials: true,
  optionsSuccessStatus: 200,
  methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
  allowedHeaders: [
    "Content-Type",
    "Authorization",
    "Cache-Control",
    "Pragma",
    "Expires",
    "X-Requested-With",
    "Accept",
  ],
};

app.use(cors(corsOptions));
// Preflight is handled by the CORS middleware above
// Ensure dynamic API routes do not cache
app.use("/api", (req, res, next) => {
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.setHeader("Pragma", "no-cache");
  res.setHeader("Expires", "0");
  next();
});

// ============================================
// 2. SECURITY MIDDLEWARE
// ============================================

// Helmet - Set security HTTP headers
app.use(helmet({
  originAgentCluster: config.NODE_ENV === "production" ? true : false,
  crossOriginOpenerPolicy: config.NODE_ENV === "production" ? { policy: "same-origin" } : false,
  crossOriginResourcePolicy: false,
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'", "*"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "*"],
      styleSrc: ["'self'", "'unsafe-inline'", "*"],
      imgSrc: ["'self'", "data:", "blob:", "https:", "*"],
      connectSrc: ["'self'", "*"],
    },
  },
  hsts: config.NODE_ENV === "production" ? {
    maxAge: config.SECURITY.HSTS_MAX_AGE,
    includeSubDomains: true,
    preload: true,
  } : false,
  frameguard: { action: "deny" },
  noSniff: true,
  xssFilter: true,
  referrerPolicy: { policy: "strict-origin-when-cross-origin" },
}));

// Rate limiting - Prevent brute force attacks
const limiter = rateLimit({
  windowMs: config.SECURITY.RATE_LIMIT_WINDOW_MS,
  max: config.SECURITY.RATE_LIMIT_MAX_REQUESTS,
  message: "Too many requests from this IP, please try again later.",
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => {
    // Don't rate limit health checks or preflight OPTIONS requests
    return req.method === "OPTIONS" || req.path === "/health";
  },
});

// Apply rate limiting
app.use(limiter);

// HTTP Request Terminal Logger
app.use((req, res, next) => {
  const start = performance.now();
  res.on("finish", () => {
    const duration = performance.now() - start;
    logger.http(req.method, req.originalUrl || req.url, res.statusCode, duration);
  });
  next();
});

// ============================================
// Body Parser & Validation Middleware
// ============================================
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ limit: "10mb", extended: true }));

// Sanitize request body to prevent XSS
app.use(sanitizeBody);

// Validate request parameters
app.use(validateRequestParams);

// ============================================
// Static Files - RESTRICTED
// ============================================
// Serve uploaded files with Content-Security-Policy
app.use("/uploads", (req, res, next) => {
  res.setHeader("Cache-Control", "public, max-age=86400");
  res.setHeader("X-Content-Type-Options", "nosniff");
  next();
}, express.static(path.join(__dirname, "../uploads")));

// ============================================
// API Routes
// ============================================
const apiBasePath = config.API_BASE_PATH.startsWith("/") ? config.API_BASE_PATH : `/${config.API_BASE_PATH}`;

app.use(`${apiBasePath}/auth`, authRoutes);
app.use(`${apiBasePath}/courses`, courseRoutes);
app.use(`${apiBasePath}/admin/progress`, adminProgressRoutes);
app.use(`${apiBasePath}/admin`, adminRoutes);
app.use(`${apiBasePath}/announcements`, announcementsRoutes);
app.use(`${apiBasePath}/blogs`, blogRoutes);
app.use(`${apiBasePath}/student`, studentRoutes);
app.use(`${apiBasePath}/messages`, messageRoutes);
app.use(`${apiBasePath}/upload`, uploadRoutes);
app.use(apiBasePath, apiRouter);

// ============================================
// Health Check Endpoint
// ============================================
app.get("/health", (req: express.Request, res: express.Response) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// ============================================
// Error Handling Middleware
// ============================================
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error("Unhandled error:", err);

  // Don't expose error details in production
  const isDev = config.NODE_ENV === "development";
  const message = isDev ? err.message : "Internal Server Error";

  res.status(err.status || 500).json({
    error: message,
    ...(isDev && { stack: err.stack }),
  });
});

// ============================================
// 404 Handler
// ============================================
app.use((req: express.Request, res: express.Response) => {
  res.status(404).json({ error: "Endpoint not found" });
});

// ============================================
// Initialize and Start Server
// ============================================
runMigrations().catch((error) => {
  console.error("Error initializing migrations:", error);
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`
╔════════════════════════════════════════════╗
║    🚀 LMS Backend Server Started           ║
╠════════════════════════════════════════════╣
║ Port:       ${PORT}
║ Environment: ${config.NODE_ENV.toUpperCase()}
║ Secure:     ${config.NODE_ENV_IS_PRODUCTION ? "✅ Production Mode" : "⚠️  Development Mode"}
╚════════════════════════════════════════════╝
  `);
});

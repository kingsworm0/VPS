import dotenv from "dotenv";
import path from "path";

const envFiles = [
    path.resolve(__dirname, "../../.env"),
    path.resolve(__dirname, "../.env"),
    path.resolve(process.cwd(), ".env"),
];

envFiles.forEach((envFile) => {
    dotenv.config({ path: envFile });
});

const JWT_SECRET = process.env.JWT_SECRET;
const NODE_ENV = process.env.NODE_ENV || "development";
const isDevelopment = NODE_ENV === "development";
const isProduction = NODE_ENV === "production";

/**
 * SECURITY: Validate critical configuration on startup
 */
const validateConfig = () => {
    const errors: string[] = [];

    // JWT Secret validation
    if (!JWT_SECRET) {
        errors.push('CRITICAL: JWT_SECRET environment variable is not set');
    } else if (JWT_SECRET === "secret" || JWT_SECRET === "replace_this_with_a_strong_secret_at_least_32_chars") {
        errors.push('CRITICAL: JWT_SECRET is using a default/placeholder value. This is insecure for production!');
    } else if (JWT_SECRET.length < 32) {
        errors.push('CRITICAL: JWT_SECRET must be at least 32 characters long');
    } else if (!/[A-Z]/.test(JWT_SECRET) || !/[0-9]/.test(JWT_SECRET) || !/[!@#$%^&*]/.test(JWT_SECRET)) {
        errors.push('CRITICAL: JWT_SECRET must contain uppercase letters, numbers, and special characters');
    }

    // Database password validation
    if (!process.env.DB_PASSWORD && isProduction) {
        errors.push('CRITICAL: DB_PASSWORD must be set in production');
    }

    // Database host validation
    if (process.env.DB_HOST === "127.0.0.1" && isProduction) {
        errors.push('WARNING: Database host is localhost in production. Consider using a private network address');
    }

    if (errors.length > 0) {
        console.error('\n' + '='.repeat(60));
        console.error('CONFIGURATION ERRORS:');
        errors.forEach(err => console.error('  ❌ ' + err));
        console.error('='.repeat(60) + '\n');

        if (isProduction && errors.some(e => e.startsWith('CRITICAL'))) {
            throw new Error('Cannot start server: Critical configuration errors detected. See logs above.');
        }
    }
};

validateConfig();

const defaultOrigins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "http://192.168.100.4:5173",
];

// SECURITY: Parse and validate allowed origins
const getAllowedOrigins = (): string[] => {
    if (!process.env.ALLOWED_ORIGINS) {
        if (isProduction) {
            console.warn('WARNING: ALLOWED_ORIGINS not configured. Using defaults for development.');
        }
        return defaultOrigins;
    }

    return process.env.ALLOWED_ORIGINS
        .split(",")
        .map(origin => origin.trim())
        .filter(origin => origin.length > 0);
};

export const config = {
    // Server config
    JWT_SECRET: JWT_SECRET || "development-only-secret",
    PORT: parseInt(process.env.PORT || "3000"),
    NODE_ENV,
    NODE_ENV_IS_PRODUCTION: isProduction,
    API_BASE_PATH: process.env.API_BASE_PATH || "/api",
    FRONTEND_URL: process.env.FRONTEND_URL || "http://localhost:5173",
    ALLOWED_ORIGINS: getAllowedOrigins(),

    // Database Config
    DB: {
        HOST: process.env.DB_HOST || "127.0.0.1",
        PORT: parseInt(process.env.DB_PORT || "3306"),
        USER: process.env.DB_USER || "root",
        PASSWORD: process.env.DB_PASSWORD || "",
        NAME: process.env.DB_NAME || "teshkid_lms",
        CONNECTION_LIMIT: 10,
        WAIT_FOR_CONNECTIONS: true,
        QUEUE_LIMIT: 0,
    },

    // Security config
    SECURITY: {
        // Rate limiting
        RATE_LIMIT_WINDOW_MS: 15 * 60 * 1000, // 15 minutes
        RATE_LIMIT_MAX_REQUESTS: 100,
        TTL: 900, // 15 minutes in seconds

        // Password policy
        MIN_PASSWORD_LENGTH: 12,
        REQUIRE_PASSWORD_UPPERCASE: true,
        REQUIRE_PASSWORD_NUMBERS: true,
        REQUIRE_PASSWORD_SPECIAL_CHARS: true,

        // Session config
        JWT_EXPIRES_IN: "24h",
        SESSION_MAX_AGE: 24 * 60 * 60 * 1000, // 24 hours

        // File upload restrictions
        MAX_FILE_SIZE: 20 * 1024 * 1024, // 20MB
        ALLOWED_FILE_TYPES: [
            'image/jpeg', 'image/png', 'image/gif', 'image/webp',
            'application/pdf', 'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'text/plain', 'application/zip'
        ],

        // Headers
        HSTS_MAX_AGE: 31536000, // 1 year
    },

    // Paths
    UPLOAD_DIR: path.resolve(__dirname, "../uploads"),
    LOG_DIR: path.resolve(__dirname, "../logs"),
    ERROR_LOG: path.resolve(__dirname, "../logs/error.log"),
    SECURITY_LOG: path.resolve(__dirname, "../logs/security.log"),
};

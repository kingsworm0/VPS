import mysql from "mysql2/promise";
import { config } from "./config";
import { logger } from "./utils/logger";

const pool = mysql.createPool({
  host: config.DB.HOST,
  port: config.DB.PORT,
  user: config.DB.USER,
  password: config.DB.PASSWORD,
  database: config.DB.NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

export const db = pool;

export const query = async (sql: string, values?: any[]) => {
  const start = performance.now();
  const connection = await pool.getConnection();
  try {
    const [results] = await connection.execute(sql, values || []);
    const duration = performance.now() - start;
    logger.db(sql, duration);
    return results;
  } catch (err: any) {
    logger.error("DB_ERROR", `Failed SQL: ${sql} | Error: ${err.message}`);
    throw err;
  } finally {
    connection.release();
  }
};

export const execute = async (sql: string, values?: any[]) => {
  return query(sql, values);
};

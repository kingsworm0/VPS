export async function up(query: any) {
  const safeAddColumn = async (table: string, columnDef: string) => {
    try {
      await query(`ALTER TABLE ${table} ADD COLUMN ${columnDef}`);
    } catch (err: any) {
      if (err.code !== 'ER_DUP_FIELDNAME') {
        console.error(`Failed to add column to ${table}: ${columnDef}`, err.message);
      }
    }
  };

  // users table missing columns
  await safeAddColumn("users", "xp INT DEFAULT 0");
  await safeAddColumn("users", "username VARCHAR(255) UNIQUE DEFAULT NULL");
  await safeAddColumn("users", "streak INT DEFAULT 0");
  await safeAddColumn("users", "lastLoginDate TIMESTAMP NULL DEFAULT NULL");
  await safeAddColumn("users", "dailyGoalLessons INT DEFAULT 1");
  await safeAddColumn("users", "timezone VARCHAR(64) DEFAULT NULL");
  await safeAddColumn("users", "language VARCHAR(32) DEFAULT 'en'");
  await safeAddColumn("users", "courseReminders TINYINT(1) DEFAULT 1");
  await safeAddColumn("users", "privacyVisibility VARCHAR(32) DEFAULT 'public'");
  await safeAddColumn("users", "privacyActivityStatus TINYINT(1) DEFAULT 1");
  await safeAddColumn("users", "privacyAppearInSearch TINYINT(1) DEFAULT 1");
  await safeAddColumn("users", "privacyAnalyticsTracking TINYINT(1) DEFAULT 1");
  await safeAddColumn("users", "creditCard VARCHAR(255) DEFAULT NULL");
  await safeAddColumn("users", "mpesaPhone VARCHAR(32) DEFAULT NULL");
  
  // enrollments table missing columns (found during auditing)
  await safeAddColumn("enrollments", "studentMessage TEXT DEFAULT NULL");
  await safeAddColumn("enrollments", "transactionId VARCHAR(100) DEFAULT NULL");
  await safeAddColumn("enrollments", "amount DECIMAL(10,2) DEFAULT NULL");
  await safeAddColumn("enrollments", "paymentStatus VARCHAR(50) DEFAULT NULL");
  await safeAddColumn("enrollments", "paymentMethod VARCHAR(50) DEFAULT NULL");
  await safeAddColumn("enrollments", "paymentId VARCHAR(100) DEFAULT NULL");
  await safeAddColumn("enrollments", "progress INT DEFAULT 0");
  await safeAddColumn("enrollments", "createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
  await safeAddColumn("enrollments", "updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
  
  // announcements
  await safeAddColumn("announcements", "content TEXT");
  await safeAddColumn("announcements", "type VARCHAR(64) DEFAULT 'info'");

  // lesson_progress
  await safeAddColumn("lesson_progress", "createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
}

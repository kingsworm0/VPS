import { query } from "../database";

export async function up() {
  console.log("Running migration: Add billing and contact fields to users table");
  
  try {
    // Add phone number field
    await query(`
      ALTER TABLE users 
      ADD COLUMN IF NOT EXISTS phone VARCHAR(50) AFTER mpesaPhone
    `).catch(err => {
      if (!err.message.includes('Duplicate column')) throw err;
    });

    // Add address fields
    await query(`
      ALTER TABLE users 
      ADD COLUMN IF NOT EXISTS address VARCHAR(255) AFTER phone,
      ADD COLUMN IF NOT EXISTS city VARCHAR(100) AFTER address,
      ADD COLUMN IF NOT EXISTS state VARCHAR(100) AFTER city,
      ADD COLUMN IF NOT EXISTS country VARCHAR(100) AFTER state,
      ADD COLUMN IF NOT EXISTS postalCode VARCHAR(20) AFTER country
    `).catch(err => {
      if (!err.message.includes('Duplicate column')) throw err;
    });

    console.log("✓ Billing and contact fields added successfully");
  } catch (error) {
    console.error("Migration failed:", error);
    throw error;
  }
}

export async function down() {
  console.log("Rolling back migration: Remove billing and contact fields");
  
  try {
    await query(`
      ALTER TABLE users 
      DROP COLUMN IF EXISTS phone,
      DROP COLUMN IF EXISTS address,
      DROP COLUMN IF EXISTS city,
      DROP COLUMN IF EXISTS state,
      DROP COLUMN IF EXISTS country,
      DROP COLUMN IF EXISTS postalCode
    `);

    console.log("✓ Billing and contact fields removed successfully");
  } catch (error) {
    console.error("Rollback failed:", error);
    throw error;
  }
}

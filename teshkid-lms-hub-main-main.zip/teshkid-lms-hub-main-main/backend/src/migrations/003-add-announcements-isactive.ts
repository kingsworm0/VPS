export async function up(query: any) {
  try {
    await query("ALTER TABLE announcements ADD COLUMN isActive BOOLEAN DEFAULT TRUE");
  } catch (err: any) {
    if (err.code !== 'ER_DUP_FIELDNAME') {
      console.error("Failed to add isActive to announcements", err.message);
    }
  }
}

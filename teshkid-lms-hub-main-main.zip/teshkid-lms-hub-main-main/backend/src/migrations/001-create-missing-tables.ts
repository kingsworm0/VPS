export async function up(query: any) {
  const tables = [
    `CREATE TABLE IF NOT EXISTS course_contents (
      id VARCHAR(36) PRIMARY KEY,
      courseId VARCHAR(36),
      title VARCHAR(255),
      description TEXT,
      fileUrl VARCHAR(255),
      fileType VARCHAR(64),
      uploadedBy VARCHAR(36),
      isPremiumOnly TINYINT(1) DEFAULT 0,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_courseId (courseId)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS lesson_progress (
      id VARCHAR(36) PRIMARY KEY,
      lessonId VARCHAR(36) NOT NULL,
      userId VARCHAR(36) NOT NULL,
      completed TINYINT(1) DEFAULT 0,
      timeSpent INT DEFAULT 0,
      lastPosition INT DEFAULT 0,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_lessonId (lessonId),
      INDEX idx_userId (userId)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS notes (
      id VARCHAR(36) PRIMARY KEY,
      lessonId VARCHAR(36) NOT NULL,
      userId VARCHAR(36) NOT NULL,
      content TEXT,
      timestamp INT DEFAULT 0,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_lessonId (lessonId),
      INDEX idx_userId (userId)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS messages (
      id VARCHAR(36) PRIMARY KEY,
      userId VARCHAR(36) NOT NULL,
      subject VARCHAR(255),
      content TEXT,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_userId (userId)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS quiz_attempts (
      id VARCHAR(36) PRIMARY KEY,
      userId VARCHAR(36) NOT NULL,
      quizId VARCHAR(36) NOT NULL,
      score INT DEFAULT 0,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_userId (userId)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS assignment_submissions (
      id VARCHAR(36) PRIMARY KEY,
      userId VARCHAR(36) NOT NULL,
      assignmentId VARCHAR(36) NOT NULL,
      score INT DEFAULT 0,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_userId (userId)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS course_materials (
      id VARCHAR(36) PRIMARY KEY,
      courseId VARCHAR(36) NOT NULL,
      title VARCHAR(255) NOT NULL,
      description TEXT,
      type ENUM('VIDEO', 'PDF', 'DOCUMENT', 'LINK') NOT NULL,
      filePath VARCHAR(255),
      fileUrl VARCHAR(255),
      duration INT COMMENT 'Video duration in seconds',
      isVisible BOOLEAN DEFAULT 1,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_courseId (courseId)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS course_material_access (
      id INT AUTO_INCREMENT PRIMARY KEY,
      materialId VARCHAR(36) NOT NULL,
      userId VARCHAR(36),
      grantedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_materialId (materialId)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS course_progress (
      id VARCHAR(36) PRIMARY KEY,
      enrollmentId VARCHAR(36) NOT NULL,
      materialId VARCHAR(36) NOT NULL,
      completedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      watchTime INT,
      progressPercentage INT DEFAULT 100,
      INDEX idx_enrollmentId (enrollmentId)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`
  ];

  for (const sql of tables) {
    await query(sql);
  }
}

import { query } from "../database";

async function columnExists(table: string, column: string): Promise<boolean> {
  const rows: any = await query(
    `SELECT COUNT(*) as cnt FROM INFORMATION_SCHEMA.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
    [table, column]
  );
  return rows[0]?.cnt > 0;
}

async function tableExists(table: string): Promise<boolean> {
  const rows: any = await query(
    `SELECT COUNT(*) as cnt FROM INFORMATION_SCHEMA.TABLES
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?`,
    [table]
  );
  return rows[0]?.cnt > 0;
}

export async function up() {
  console.log("Running migration 008: Add streaming fields to live_sessions");

  if (!(await columnExists("live_sessions", "streamUrl"))) {
    await query(`ALTER TABLE live_sessions ADD COLUMN streamUrl VARCHAR(512) DEFAULT NULL`);
    console.log("✓ Added live_sessions.streamUrl");
  }
  if (!(await columnExists("live_sessions", "recordingUrl"))) {
    await query(`ALTER TABLE live_sessions ADD COLUMN recordingUrl VARCHAR(512) DEFAULT NULL`);
    console.log("✓ Added live_sessions.recordingUrl");
  }
  if (!(await columnExists("live_sessions", "maxAttendees"))) {
    await query(`ALTER TABLE live_sessions ADD COLUMN maxAttendees INT DEFAULT NULL`);
    console.log("✓ Added live_sessions.maxAttendees");
  }

  if (!(await tableExists("live_session_rsvps"))) {
    await query(`
      CREATE TABLE live_session_rsvps (
        id          VARCHAR(36) NOT NULL PRIMARY KEY,
        sessionId   VARCHAR(36) NOT NULL,
        userId      VARCHAR(36) NOT NULL,
        createdAt   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_rsvp (sessionId, userId),
        FOREIGN KEY (sessionId) REFERENCES live_sessions(id) ON DELETE CASCADE,
        FOREIGN KEY (userId)    REFERENCES users(id)         ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);
    console.log("✓ Created live_session_rsvps table");
  }

  console.log("✅ Migration 008 completed");
}

export async function down() {
  await query(`DROP TABLE IF EXISTS live_session_rsvps`);
  await query(`ALTER TABLE live_sessions DROP COLUMN IF EXISTS maxAttendees`);
  await query(`ALTER TABLE live_sessions DROP COLUMN IF EXISTS recordingUrl`);
  await query(`ALTER TABLE live_sessions DROP COLUMN IF EXISTS streamUrl`);
}

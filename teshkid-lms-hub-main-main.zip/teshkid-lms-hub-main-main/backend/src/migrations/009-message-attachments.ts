import { query } from "../database";

async function columnExists(table: string, column: string): Promise<boolean> {
  const rows: any = await query(
    `SELECT COUNT(*) as cnt
     FROM INFORMATION_SCHEMA.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = ?
       AND COLUMN_NAME = ?`,
    [table, column]
  );
  return rows[0]?.cnt > 0;
}

export async function up() {
  console.log("Running migration 009: Add message attachments & remove ticket fields");

  // Add attachmentUrl
  if (!(await columnExists("messages", "attachmentUrl"))) {
    await query(`ALTER TABLE messages ADD COLUMN attachmentUrl VARCHAR(255) DEFAULT NULL`);
    console.log("✓ Added messages.attachmentUrl");
  }

  // Add replyAttachmentUrl
  if (!(await columnExists("messages", "replyAttachmentUrl"))) {
    await query(`ALTER TABLE messages ADD COLUMN replyAttachmentUrl VARCHAR(255) DEFAULT NULL`);
    console.log("✓ Added messages.replyAttachmentUrl");
  }

  // Drop message_notes table
  await query(`DROP TABLE IF EXISTS message_notes`);
  console.log("✓ Dropped message_notes table");

  // Drop ticket fields if they exist
  const fieldsToDrop = ["status", "priority", "assignedTo", "resolvedAt"];
  for (const field of fieldsToDrop) {
    if (await columnExists("messages", field)) {
      await query(`ALTER TABLE messages DROP COLUMN ${field}`);
      console.log(`✓ Dropped messages.${field}`);
    }
  }

  console.log("✅ Migration 009 completed");
}

export async function down() {
  console.log("Rolling back migration 009");
  try {
    await query(`ALTER TABLE messages DROP COLUMN IF EXISTS attachmentUrl`);
    await query(`ALTER TABLE messages DROP COLUMN IF EXISTS replyAttachmentUrl`);
    // Note: Re-creating message_notes and ticket fields is skipped for brevity in down() since data is lost anyway.
    console.log("✅ Migration 009 rollback completed");
  } catch (error) {
    console.error("❌ Migration 009 rollback failed:", error);
    throw error;
  }
}

export async function up(query: Function) {
  console.log("Creating password_reset_tokens table...");
  
  await query(`
    CREATE TABLE IF NOT EXISTS password_reset_tokens (
      id VARCHAR(36) PRIMARY KEY,
      userId VARCHAR(36) NOT NULL,
      token VARCHAR(255) NOT NULL UNIQUE,
      expiresAt DATETIME NOT NULL,
      isUsed BOOLEAN DEFAULT FALSE,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_token (token),
      INDEX idx_userId (userId),
      INDEX idx_expiresAt (expiresAt)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  console.log("password_reset_tokens table created successfully.");
}

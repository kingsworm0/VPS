import { query } from "../database";

async function columnExists(table: string, column: string): Promise<boolean> {
  const rows: any = await query(
    `SELECT COUNT(*) as cnt
     FROM INFORMATION_SCHEMA.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = ?
       AND COLUMN_NAME = ?`,
    [table, column]
  );
  return rows[0]?.cnt > 0;
}

async function tableExists(table: string): Promise<boolean> {
  const rows: any = await query(
    `SELECT COUNT(*) as cnt
     FROM INFORMATION_SCHEMA.TABLES
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = ?`,
    [table]
  );
  return rows[0]?.cnt > 0;
}

export async function up() {
  console.log("Running migration: Add ticket fields to messages + create message_notes");

  // --- messages: priority ---
  if (!(await columnExists("messages", "priority"))) {
    await query(`ALTER TABLE messages ADD COLUMN priority VARCHAR(16) NOT NULL DEFAULT 'normal'`);
    console.log("✓ Added messages.priority");
  } else {
    console.log("✓ messages.priority already exists, skipping");
  }

  // --- messages: status ---
  if (!(await columnExists("messages", "status"))) {
    await query(`ALTER TABLE messages ADD COLUMN status VARCHAR(32) NOT NULL DEFAULT 'open'`);
    console.log("✓ Added messages.status");
  } else {
    console.log("✓ messages.status already exists, skipping");
  }

  // --- messages: assignedTo ---
  if (!(await columnExists("messages", "assignedTo"))) {
    await query(`ALTER TABLE messages ADD COLUMN assignedTo VARCHAR(36) DEFAULT NULL`);
    console.log("✓ Added messages.assignedTo");
  } else {
    console.log("✓ messages.assignedTo already exists, skipping");
  }

  // --- messages: resolvedAt ---
  if (!(await columnExists("messages", "resolvedAt"))) {
    await query(`ALTER TABLE messages ADD COLUMN resolvedAt TIMESTAMP NULL DEFAULT NULL`);
    console.log("✓ Added messages.resolvedAt");
  } else {
    console.log("✓ messages.resolvedAt already exists, skipping");
  }

  // --- message_notes table ---
  if (!(await tableExists("message_notes"))) {
    await query(`
      CREATE TABLE message_notes (
        id VARCHAR(36) PRIMARY KEY,
        messageId VARCHAR(36) NOT NULL,
        adminId VARCHAR(36) NOT NULL,
        adminName VARCHAR(255) NOT NULL DEFAULT 'Admin',
        note TEXT NOT NULL,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (messageId) REFERENCES messages(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);
    console.log("✓ Created message_notes table");
  } else {
    console.log("✓ message_notes table already exists, skipping");
  }

  console.log("✅ Migration 006 completed: ticket fields added");
}

export async function down() {
  console.log("Rolling back migration 006");
  try {
    await query(`DROP TABLE IF EXISTS message_notes`);
    await query(`ALTER TABLE messages DROP COLUMN IF EXISTS resolvedAt`);
    await query(`ALTER TABLE messages DROP COLUMN IF EXISTS assignedTo`);
    await query(`ALTER TABLE messages DROP COLUMN IF EXISTS status`);
    await query(`ALTER TABLE messages DROP COLUMN IF EXISTS priority`);
    console.log("✅ Migration 006 rollback completed");
  } catch (error) {
    console.error("❌ Migration 006 rollback failed:", error);
    throw error;
  }
}

import { query } from "../database";

async function columnExists(table: string, column: string): Promise<boolean> {
  const rows: any = await query(
    `SELECT COUNT(*) as cnt
     FROM INFORMATION_SCHEMA.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = ?
       AND COLUMN_NAME = ?`,
    [table, column]
  );
  return rows[0]?.cnt > 0;
}

export async function up() {
  console.log("Running migration: Add studentIsRead column to messages");

  if (!(await columnExists("messages", "studentIsRead"))) {
    await query(`ALTER TABLE messages ADD COLUMN studentIsRead TINYINT(1) NOT NULL DEFAULT 1`);
    // Existing messages without a reply → student hasn't seen a reply yet, mark 1 (already read their own send)
    // When admin sends a reply, backend will set studentIsRead = 0 to notify the student of new reply
    await query(`UPDATE messages SET studentIsRead = 0 WHERE reply IS NOT NULL AND reply != ''`);
    console.log("✓ Added messages.studentIsRead");
  } else {
    console.log("✓ messages.studentIsRead already exists, skipping");
  }

  console.log("✅ Migration 007 completed");
}

export async function down() {
  await query(`ALTER TABLE messages DROP COLUMN IF EXISTS studentIsRead`);
}

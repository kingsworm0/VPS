import { query } from "../database";

async function columnExists(table: string, column: string): Promise<boolean> {
  const rows: any = await query(
    `SELECT COUNT(*) as cnt
     FROM INFORMATION_SCHEMA.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = ?
       AND COLUMN_NAME = ?`,
    [table, column]
  );
  return rows[0]?.cnt > 0;
}

export async function up() {
  console.log("Running migration: Add firstName and lastName columns");

  try {
    const hasFirstName = await columnExists("users", "firstName");
    const hasLastName = await columnExists("users", "lastName");

    if (!hasFirstName && !hasLastName) {
      await query(`
        ALTER TABLE users
        ADD COLUMN firstName VARCHAR(255) DEFAULT NULL AFTER name,
        ADD COLUMN lastName VARCHAR(255) DEFAULT NULL AFTER firstName
      `);
      console.log("✓ Added firstName and lastName columns");
    } else if (!hasFirstName) {
      await query(`
        ALTER TABLE users
        ADD COLUMN firstName VARCHAR(255) DEFAULT NULL AFTER name
      `);
      console.log("✓ Added firstName column");
    } else if (!hasLastName) {
      await query(`
        ALTER TABLE users
        ADD COLUMN lastName VARCHAR(255) DEFAULT NULL AFTER firstName
      `);
      console.log("✓ Added lastName column");
    } else {
      console.log("✓ firstName and lastName columns already exist, skipping ALTER");
    }

    // Split existing name field into firstName and lastName where not yet populated
    await query(`
      UPDATE users
      SET 
        firstName = SUBSTRING_INDEX(name, ' ', 1),
        lastName = CASE
          WHEN LOCATE(' ', name) > 0 THEN SUBSTRING(name, LOCATE(' ', name) + 1)
          ELSE ''
        END
      WHERE firstName IS NULL OR firstName = ''
    `);

    console.log("✓ Split existing names into firstName and lastName");

    // Make firstName required (after populating it)
    await query(`
      ALTER TABLE users
      MODIFY COLUMN firstName VARCHAR(255) NOT NULL
    `);

    console.log("✓ Made firstName required");

    console.log("✅ Migration 005 completed: firstName and lastName added");
  } catch (error) {
    console.error("❌ Migration 005 failed:", error);
    throw error;
  }
}

export async function down() {
  console.log("Rolling back migration: Add firstName and lastName columns");

  try {
    // Remove firstName and lastName columns
    await query(`
      ALTER TABLE users
      DROP COLUMN firstName,
      DROP COLUMN lastName
    `);

    console.log("✅ Migration 005 rollback completed");
  } catch (error) {
    console.error("❌ Migration 005 rollback failed:", error);
    throw error;
  }
}

import fs from "fs";
import path from "path";
import { query } from "../database";

export async function runMigrations() {
  console.log("Starting migration process...");
  
  // 1. Ensure migrations table exists
  await query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      id INT AUTO_INCREMENT PRIMARY KEY,
      migration_name VARCHAR(255) NOT NULL UNIQUE,
      executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  const migrationsDir = __dirname;
  const files = fs.readdirSync(migrationsDir)
    .filter(f => f.endsWith(".ts") && f !== "index.ts" && f !== "run.ts")
    .sort(); // Run in alphabetical/numerical order

  for (const file of files) {
    const migrationName = file.replace(".ts", "");
    
    const executed: any = await query(
      "SELECT id FROM schema_migrations WHERE migration_name = ?",
      [migrationName]
    );

    if (executed && executed.length > 0) {
      console.log(`Migration ${migrationName} already executed. Skipping.`);
      continue;
    }

    console.log(`Executing migration: ${migrationName}`);
    try {
      const migrationModule = await import(path.join(migrationsDir, file));
      if (typeof migrationModule.up === "function") {
        await migrationModule.up(query);
        await query(
          "INSERT INTO schema_migrations (migration_name) VALUES (?)",
          [migrationName]
        );
        console.log(`Successfully executed migration: ${migrationName}`);
      } else {
        console.log(`Migration ${migrationName} has no 'up' export. Skipping.`);
      }
    } catch (error) {
      console.error(`Failed to execute migration ${migrationName}:`, error);
      throw error;
    }
  }
  
  console.log("Migration process completed.");
}

import express from "express";
import { authenticateToken } from "../middleware/authMiddleware";
import { query } from "../database";

const router = express.Router();

/**
 * PROGRESS TRACKING
 */

// Get course progress for student
router.get("/progress/:courseId", authenticateToken, async (req: any, res) => {
  try {
    const { courseId } = req.params;
    const userId = req.user.userId;

    // Admin has full access without enrollment
    if (req.user.role !== "ADMIN") {
      // Verify enrollment for students
      const enrollment: any = await query(
        "SELECT id FROM enrollments WHERE userId = ? AND courseId = ?",
        [userId, courseId]
      );

      if (!enrollment || enrollment.length === 0) {
        return res.status(403).json({ error: "Not enrolled" });
      }
    }

    // For students, get their enrollment
    let enrollmentId = null;
    if (req.user.role !== "ADMIN") {
      const enrollment: any = await query(
        "SELECT id FROM enrollments WHERE userId = ? AND courseId = ?",
        [userId, courseId]
      );
      enrollmentId = enrollment[0].id;
    }

    // Get progress (only for students with enrollment)
    let progress: any = [];
    if (enrollmentId) {
      progress = await query(
        `SELECT cp.*, cm.title as materialTitle, cm.type, cm.duration
         FROM course_progress cp
         INNER JOIN course_materials cm ON cp.materialId = cm.id
         WHERE cp.enrollmentId = ?
         ORDER BY cp.completedAt DESC`,
        [enrollmentId]
      );
    }

    // Get total materials
    const totalMaterials: any = await query(
      `SELECT COUNT(*) as total FROM course_materials WHERE courseId = ? AND isVisible = 1`,
      [courseId]
    );

    // Get completion stats
    const stats = {
      completedCount: progress.length,
      totalCount: totalMaterials[0].total,
      completionPercentage: totalMaterials[0].total > 0 
        ? Math.round((progress.length / totalMaterials[0].total) * 100)
        : 0,
      lastAccessed: progress.length > 0 ? progress[0].completedAt : null
    };

    res.json({
      progress,
      stats
    });
  } catch (error) {
    console.error("Error fetching progress:", error);
    res.status(500).json({ error: "Error fetching progress" });
  }
});

// Mark material as completed
router.post("/material/:materialId/complete", authenticateToken, async (req: any, res) => {
  try {
    const { materialId } = req.params;
    const userId = req.user.userId;
    const { watchTime } = req.body;

    // Get material and verify access
    const material: any = await query(
      "SELECT courseId FROM course_materials WHERE id = ?",
      [materialId]
    );

    if (!material || material.length === 0) {
      return res.status(404).json({ error: "Material not found" });
    }

    // Verify enrollment
    const enrollment: any = await query(
      "SELECT id FROM enrollments WHERE userId = ? AND courseId = ? AND status = 'APPROVED'",
      [userId, material[0].courseId]
    );

    if (!enrollment || enrollment.length === 0) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const enrollmentId = enrollment[0].id;

    // Check if already completed
    const existing: any = await query(
      "SELECT * FROM course_progress WHERE enrollmentId = ? AND materialId = ?",
      [enrollmentId, materialId]
    );

    if (existing && existing.length > 0) {
      // Update completion time
      await query(
        "UPDATE course_progress SET completedAt = NOW(), watchTime = ? WHERE enrollmentId = ? AND materialId = ?",
        [watchTime || null, enrollmentId, materialId]
      );
    } else {
      // Insert new completion record
      const progressId = Math.random().toString(36).substr(2, 9);
      await query(
        `INSERT INTO course_progress (id, enrollmentId, materialId, completedAt, watchTime)
         VALUES (?, ?, ?, NOW(), ?)`,
        [progressId, enrollmentId, materialId, watchTime || null]
      );
    }

    res.json({ success: true });
  } catch (error) {
    console.error("Error marking complete:", error);
    res.status(500).json({ error: "Error marking complete" });
  }
});

// Get admin course progress report
router.get("/admin/course/:courseId", authenticateToken, async (req: any, res) => {
  try {
    const adminCheck: any = await query(
      "SELECT role FROM users WHERE id = ?",
      [req.user.userId]
    );

    if (!adminCheck || adminCheck.length === 0 || adminCheck[0].role.toUpperCase() !== "ADMIN") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const { courseId } = req.params;

    // Get all enrollments with progress
    const enrollments: any = await query(
      `SELECT e.id as enrollmentId, u.id as userId, u.name, SUBSTRING_INDEX(u.name, ' ', 1) AS firstName, IF(LOCATE(' ', u.name) > 0, SUBSTRING_INDEX(u.name, ' ', -1), '') AS lastName, u.email,
              COUNT(DISTINCT cp.materialId) as completedCount,
              (SELECT COUNT(*) FROM course_materials WHERE courseId = ? AND isVisible = 1) as totalCount,
              MAX(cp.completedAt) as lastActivity
       FROM enrollments e
       INNER JOIN users u ON e.userId = u.id
       LEFT JOIN course_progress cp ON e.id = cp.enrollmentId
       WHERE e.courseId = ? AND e.status = 'APPROVED'
       GROUP BY e.id, u.id
       ORDER BY e.enrolledAt DESC`,
      [courseId, courseId]
    );

    // Calculate completion percentages
    const enrollmentsWithProgress = enrollments.map((e: any) => ({
      ...e,
      completionPercentage: e.totalCount > 0 
        ? Math.round((e.completedCount / e.totalCount) * 100)
        : 0
    }));

    res.json(enrollmentsWithProgress);
  } catch (error) {
    console.error("Error fetching progress report:", error);
    res.status(500).json({ error: "Error fetching progress report" });
  }
});

// Get student progress report
router.get("/admin/student/:studentId", authenticateToken, async (req: any, res) => {
  try {
    const adminCheck: any = await query(
      "SELECT role FROM users WHERE id = ?",
      [req.user.userId]
    );

    if (!adminCheck || adminCheck.length === 0 || adminCheck[0].role.toUpperCase() !== "ADMIN") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const { studentId } = req.params;

    // Get all enrollments for student
    const enrollments: any = await query(
      `SELECT e.id as enrollmentId, c.id, c.title, c.description,
              COUNT(DISTINCT cp.materialId) as completedCount,
              (SELECT COUNT(*) FROM course_materials WHERE courseId = c.id AND isVisible = 1) as totalCount,
              MAX(cp.completedAt) as lastActivity,
              e.status as enrollmentStatus,
              e.enrolledAt
       FROM enrollments e
       INNER JOIN courses c ON e.courseId = c.id
       LEFT JOIN course_progress cp ON e.id = cp.enrollmentId
       WHERE e.userId = ?
       GROUP BY e.id, c.id
       ORDER BY e.enrolledAt DESC`,
      [studentId]
    );

    const enrollmentsWithProgress = enrollments.map((e: any) => ({
      ...e,
      completionPercentage: e.totalCount > 0 
        ? Math.round((e.completedCount / e.totalCount) * 100)
        : 0
    }));

    res.json(enrollmentsWithProgress);
  } catch (error) {
    console.error("Error fetching student progress:", error);
    res.status(500).json({ error: "Error fetching student progress" });
  }
});

export default router;

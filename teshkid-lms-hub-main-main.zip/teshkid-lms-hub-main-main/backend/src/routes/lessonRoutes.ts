import express from "express";
import { authenticateToken } from "../middleware/authMiddleware";
import { query } from "../database";
import { v4 as uuidv4 } from "uuid";

const router = express.Router();

// Get notes for a lesson
router.get("/:id/notes", authenticateToken, async (req: any, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.userId;

        const notes: any = await query(
            "SELECT * FROM notes WHERE userId = ? AND lessonId = ? ORDER BY createdAt DESC",
            [userId, id]
        );

        res.json(notes);
    } catch (error) {
        console.error("Error fetching notes:", error);
        res.status(500).json({ error: "Error fetching notes" });
    }
});

// Mark lesson as complete
router.post("/:id/complete", authenticateToken, async (req: any, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.userId;
        const { timeSpent, lastPosition } = req.body;

        // Check if progress already exists
        const existing: any = await query(
            "SELECT id FROM lesson_progress WHERE userId = ? AND lessonId = ?",
            [userId, id]
        );

        if (existing && existing.length > 0) {
            await query(
                "UPDATE lesson_progress SET completed = 1, timeSpent = ?, lastPosition = ? WHERE id = ?",
                [timeSpent || 0, lastPosition || 0, existing[0].id]
            );
        } else {
            await query(
                "INSERT INTO lesson_progress (id, userId, lessonId, completed, timeSpent, lastPosition) VALUES (?, ?, ?, 1, ?, ?)",
                [uuidv4(), userId, id, timeSpent || 0, lastPosition || 0]
            );
        }

        res.json({ success: true });
    } catch (error) {
        console.error("Error marking lesson complete:", error);
        res.status(500).json({ error: "Error marking lesson complete" });
    }
});

export default router;

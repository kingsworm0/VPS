import express from "express";
import { query } from "../database";
import { v4 as uuidv4 } from "uuid";
import {
  authenticateToken,
  requireAdmin,
  AuthRequest,
} from "../middleware/authMiddleware";

const router = express.Router();

// ─── Student: Send a new message ────────────────────────────────────────────
router.post("/", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { subject, message, attachmentUrl } = req.body;
    const userId = req.user?.userId;

    if (!userId) return res.status(401).json({ message: "Unauthorized" });

    const id = uuidv4();
    await query(
      "INSERT INTO messages (id, userId, subject, content, attachmentUrl) VALUES (?, ?, ?, ?, ?)",
      [id, userId, subject, message, attachmentUrl || null],
    );

    res.status(201).json({ success: true, message: "Message sent" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error sending message" });
  }
});

// ─── Admin: Get all messages (ticket list) ───────────────────────────────────
router.get("/", authenticateToken, requireAdmin, async (req, res) => {
  try {
    const messages: any = await query(`
      SELECT
        m.*,
        m.content AS message,
        u.name    AS userName,
        u.email   AS userEmail,
        u.profilePicture AS userProfilePicture
      FROM messages m
      JOIN users u ON m.userId = u.id
      ORDER BY m.createdAt DESC
    `);
    res.json(messages);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching messages" });
  }
});

// ─── Student: Get own messages ───────────────────────────────────────────────
router.get("/my", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const userId = req.user?.userId;
    const messages: any = await query(
      `SELECT *, content AS message,
              studentIsRead AS isRead
       FROM messages
       WHERE userId = ?
       ORDER BY createdAt DESC`,
      [userId],
    );
    res.json(messages);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching your messages" });
  }
});

// ─── Admin: Get single ticket with full user info ────────────────────────────
router.get("/:id", authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const rows: any = await query(`
      SELECT
        m.*,
        m.content AS message,
        u.name    AS userName,
        u.email   AS userEmail,
        u.profilePicture AS userProfilePicture
      FROM messages m
      JOIN users u ON m.userId = u.id
      WHERE m.id = ?
    `, [id]);

    if (!rows || rows.length === 0) {
      return res.status(404).json({ error: "Message not found" });
    }
    res.json(rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching message" });
  }
});

// ─── Admin: Reply to a ticket ────────────────────────────────────────────────
router.put("/:id/reply", authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { reply, replyAttachmentUrl } = req.body;

    // isRead = admin has read it; studentIsRead = 0 means student has a new reply to read
    await query(
      "UPDATE messages SET reply = ?, replyAttachmentUrl = ?, isRead = TRUE, studentIsRead = 0 WHERE id = ?",
      [reply, replyAttachmentUrl || null, id],
    );

    res.json({ success: true, message: "Reply sent" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error sending reply" });
  }
});



// ─── Mark message read/unread ─────────────────────────────────────────────────
router.put("/:id/read", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { isRead } = req.body;
    const userId   = req.user?.userId;
    const userRole = req.user?.role;

    const message: any = await query("SELECT userId FROM messages WHERE id = ?", [id]);
    if (!message || message.length === 0) return res.status(404).json({ error: "Message not found" });
    if (userRole !== "ADMIN" && message[0].userId !== userId) return res.status(403).json({ error: "Unauthorized" });

    // Admins control isRead (admin-side); students control studentIsRead
    if (userRole === "ADMIN") {
      await query("UPDATE messages SET isRead = ? WHERE id = ?", [isRead ? 1 : 0, id]);
    } else {
      await query("UPDATE messages SET studentIsRead = ? WHERE id = ?", [isRead ? 1 : 0, id]);
    }

    res.json({ success: true, message: "Message status updated" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error updating message status" });
  }
});

// ─── Star message ─────────────────────────────────────────────────────────────
router.put("/:id/star", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { isStarred } = req.body;
    const userId   = req.user?.userId;
    const userRole = req.user?.role;

    const message: any = await query("SELECT userId FROM messages WHERE id = ?", [id]);
    if (!message || message.length === 0) return res.status(404).json({ error: "Message not found" });
    if (userRole !== "ADMIN" && message[0].userId !== userId) return res.status(403).json({ error: "Unauthorized" });

    await query("UPDATE messages SET isStarred = ? WHERE id = ?", [isStarred ? 1 : 0, id]);
    res.json({ success: true, message: "Star status updated" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error starring message" });
  }
});

// ─── Archive message ──────────────────────────────────────────────────────────
router.put("/:id/archive", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { isArchived } = req.body;
    const userId   = req.user?.userId;
    const userRole = req.user?.role;

    const message: any = await query("SELECT userId FROM messages WHERE id = ?", [id]);
    if (!message || message.length === 0) return res.status(404).json({ error: "Message not found" });
    if (userRole !== "ADMIN" && message[0].userId !== userId) return res.status(403).json({ error: "Unauthorized" });

    await query("UPDATE messages SET isArchived = ? WHERE id = ?", [isArchived ? 1 : 0, id]);
    res.json({ success: true, message: "Archive status updated" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error archiving message" });
  }
});

// ─── Delete message ───────────────────────────────────────────────────────────
router.delete("/:id", authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId   = req.user?.userId;
    const userRole = req.user?.role;

    const message: any = await query("SELECT userId FROM messages WHERE id = ?", [id]);
    if (!message || message.length === 0) return res.status(404).json({ error: "Message not found" });
    if (userRole !== "ADMIN" && message[0].userId !== userId) return res.status(403).json({ error: "Unauthorized" });

    await query("DELETE FROM messages WHERE id = ?", [id]);
    res.json({ success: true, message: "Message deleted" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error deleting message" });
  }
});

export default router;

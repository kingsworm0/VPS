import express, { Request, Response } from "express";
import enrollmentRoutes from "./enrollmentRoutes";
import contentAccessRoutes from "./contentAccessRoutes";
import progressRoutes from "./progressRoutes";
import lessonRoutes from "./lessonRoutes";
import noteRoutes from "./noteRoutes";
import certificateRoutes from "./certificateRoutes";
import { query } from "../database";
import { authenticateToken } from "../middleware/authMiddleware";
import liveSessionRoutes from "./liveSessionRoutes";

const apiRouter = express.Router();

// Base API route
apiRouter.get("/", (req: Request, res: Response) => {
    res.json({ status: "ok", message: "API is running and accessible" });
});

// Mount all course-related API routes
apiRouter.use("/enrollments", enrollmentRoutes);
apiRouter.use("/content", contentAccessRoutes);
apiRouter.use("/progress", progressRoutes);
apiRouter.use("/lessons", lessonRoutes);
apiRouter.use("/notes", noteRoutes);
apiRouter.use("/certificates", certificateRoutes);
apiRouter.use("/", liveSessionRoutes);

// Consolidated Student Dashboard API
apiRouter.get("/dashboard", authenticateToken, async (req: any, res: any) => {
    try {
        const enrolledResult: any = await query(
            "SELECT COUNT(*) as count FROM enrollments WHERE userId = ?",
            [req.user.userId],
        );
        const enrolledCourses = enrolledResult[0]?.count || 0;

        const completedResult: any = await query(
            "SELECT COUNT(DISTINCT lessonId) as count FROM lesson_progress WHERE userId = ?",
            [req.user.userId],
        );
        const completedLessons = completedResult[0]?.count || 0;

        const totalResult: any = await query(
            `SELECT COUNT(DISTINCT l.id) as count 
       FROM lessons l
       JOIN modules m ON l.moduleId = m.id
       JOIN enrollments e ON m.courseId = e.courseId
       WHERE e.userId = ?`,
            [req.user.userId],
        );
        const totalLessons = totalResult[0]?.count || 0;

        const recentCourses: any = await query(
            `SELECT c.*, e.enrolledAt, e.status,
              COUNT(DISTINCT lp.id) as lessonsCompleted,
              COUNT(DISTINCT l.id) as totalLessons
       FROM courses c
       JOIN enrollments e ON c.id = e.courseId
       LEFT JOIN modules m ON c.id = m.courseId
       LEFT JOIN lessons l ON m.id = l.moduleId
       LEFT JOIN lesson_progress lp ON l.id = lp.lessonId AND lp.userId = ?
       WHERE e.userId = ? AND e.status != 'FORFEITED'
       GROUP BY c.id
       ORDER BY e.enrolledAt DESC
       LIMIT 5`,
            [req.user.userId, req.user.userId],
        );

        // Gamification data
        const userResult: any = await query(
            "SELECT xp, streak, lastLoginDate, dailyGoalLessons, createdAt FROM users WHERE id = ?",
            [req.user.userId],
        );
        const userData = userResult[0] || {};
        const xp = userData.xp || 0;
        const streak = userData.streak || 0;
        const dailyGoalLessons = userData.dailyGoalLessons || 3;
        const memberSince = userData.createdAt;

        // XP Level calculation: every 500 XP = 1 level, starting at level 1
        const level = Math.floor(xp / 500) + 1;
        const xpForCurrentLevel = (level - 1) * 500;
        const xpForNextLevel = level * 500;

        // Today's lessons completed
        const todayResult: any = await query(
            `SELECT COUNT(DISTINCT lessonId) as count FROM lesson_progress 
             WHERE userId = ? AND DATE(updatedAt) = CURDATE()`,
            [req.user.userId],
        );
        const lessonsToday = todayResult[0]?.count || 0;

        // Streak logic: increment if not already logged today
        const today = new Date().toISOString().split('T')[0];
        const lastLogin = userData.lastLoginDate
            ? new Date(userData.lastLoginDate).toISOString().split('T')[0]
            : null;
        let newStreak = streak;
        if (lastLogin !== today) {
            const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
            newStreak = lastLogin === yesterday ? streak + 1 : 1;
            await query(
                "UPDATE users SET streak = ?, lastLoginDate = CURDATE() WHERE id = ?",
                [newStreak, req.user.userId],
            );
        }

        res.json({
            stats: {
                enrolledCourses,
                completedLessons,
                totalLessons,
                completionPercentage:
                    totalLessons > 0
                        ? Math.round((completedLessons / totalLessons) * 100)
                        : 0,
            },
            recentCourses,
            gamification: {
                xp,
                streak: newStreak,
                level,
                xpForCurrentLevel,
                xpForNextLevel,
                dailyGoalLessons,
                lessonsToday,
                memberSince,
            },
        });
    } catch (error) {
        console.error("Dashboard error:", error);
        res.status(500).json({ error: "Error fetching dashboard" });
    }
});

export default apiRouter;

import express, { Response, RequestHandler } from "express";
import multer from "multer";
import path from "path";
import bcrypt from "bcryptjs";
import { v4 as uuidv4 } from "uuid";
import { query } from "../database";
import {
  authenticateToken,
  AuthenticatedRequest,
  requireStudent,
} from "../middleware/authMiddleware";
import fs from "fs";
import { config } from "../config";

const router = express.Router();

// Configure multer for profile picture uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(config.UPLOAD_DIR, "profiles");
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${uuidv4()}${ext}`);
  },
});

const uploadProfile = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif/;
    const extname = allowedTypes.test(
      path.extname(file.originalname).toLowerCase(),
    );
    const mimetype = allowedTypes.test(file.mimetype);
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error("Only image files are allowed"));
    }
  },
});

// Protect all student routes
router.use(authenticateToken);

// Get student profile
router.get("/profile", async (req: any, res) => {
  try {
    const results: any = await query(
      `SELECT id, name, email, role, profilePicture, bio, createdAt,
              username, timezone, language, courseReminders, 
              privacyVisibility, privacyActivityStatus, 
              privacyAppearInSearch, privacyAnalyticsTracking,
              creditCard, mpesaPhone, phone, address, city, state, country, postalCode
       FROM users WHERE id = ?`,
      [req.user.userId],
    );

    if (!results || results.length === 0) {
      return res.status(404).json({ message: "Profile not found" });
    }

    const profile = results[0];
    res.json({
      id: profile.id,
      name: profile.name,
      email: profile.email,
      username: profile.username,
      profilePicture: profile.profilePicture,
      bio: profile.bio,
      timezone: profile.timezone,
      language: profile.language,
      courseReminders: !!profile.courseReminders,
      privacyVisibility: profile.privacyVisibility,
      privacyActivityStatus: !!profile.privacyActivityStatus,
      privacyAppearInSearch: !!profile.privacyAppearInSearch,
      privacyAnalyticsTracking: !!profile.privacyAnalyticsTracking,
      creditCard: profile.creditCard,
      mpesaPhone: profile.mpesaPhone,
      phone: profile.phone,
      address: profile.address,
      city: profile.city,
      state: profile.state,
      country: profile.country,
      postalCode: profile.postalCode,
      joinedAt: profile.createdAt,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching profile" });
  }
});

// Update student profile
router.put("/profile", async (req: any, res) => {
  try {
    const { 
      name, bio, username, timezone, language, 
      courseReminders, privacyVisibility, 
      privacyActivityStatus, privacyAppearInSearch, privacyAnalyticsTracking,
      creditCard, mpesaPhone, phone, address, city, state, country, postalCode
    } = req.body;

    const updateData = [];
    const params: any[] = [];

    if (username) {
      const existing: any = await query("SELECT id FROM users WHERE username = ? AND id != ?", [username, req.user.userId]);
      if (existing && existing.length > 0) {
        return res.status(400).json({ message: "Username is already taken" });
      }
      updateData.push("username = ?");
      params.push(username);
    }

    if (name !== undefined) {
      updateData.push("name = ?");
      params.push(name);
    }
    if (bio !== undefined) {
      updateData.push("bio = ?");
      params.push(bio);
    }
    if (timezone !== undefined) {
      updateData.push("timezone = ?");
      params.push(timezone);
    }
    if (language !== undefined) {
      updateData.push("language = ?");
      params.push(language);
    }
    if (courseReminders !== undefined) {
      updateData.push("courseReminders = ?");
      params.push(courseReminders ? 1 : 0);
    }
    if (privacyVisibility !== undefined) {
      updateData.push("privacyVisibility = ?");
      params.push(privacyVisibility);
    }
    if (privacyActivityStatus !== undefined) {
      updateData.push("privacyActivityStatus = ?");
      params.push(privacyActivityStatus ? 1 : 0);
    }
    if (privacyAppearInSearch !== undefined) {
      updateData.push("privacyAppearInSearch = ?");
      params.push(privacyAppearInSearch ? 1 : 0);
    }
    if (privacyAnalyticsTracking !== undefined) {
      updateData.push("privacyAnalyticsTracking = ?");
      params.push(privacyAnalyticsTracking ? 1 : 0);
    }
    if (creditCard !== undefined) {
      updateData.push("creditCard = ?");
      params.push(creditCard);
    }
    if (mpesaPhone !== undefined) {
      updateData.push("mpesaPhone = ?");
      params.push(mpesaPhone);
    }
    if (phone !== undefined) {
      updateData.push("phone = ?");
      params.push(phone);
    }
    if (address !== undefined) {
      updateData.push("address = ?");
      params.push(address);
    }
    if (city !== undefined) {
      updateData.push("city = ?");
      params.push(city);
    }
    if (state !== undefined) {
      updateData.push("state = ?");
      params.push(state);
    }
    if (country !== undefined) {
      updateData.push("country = ?");
      params.push(country);
    }
    if (postalCode !== undefined) {
      updateData.push("postalCode = ?");
      params.push(postalCode);
    }

    if (updateData.length === 0) {
      return res.status(400).json({ message: "No data to update" });
    }

    params.push(req.user.userId);

    await query(
      `UPDATE users SET ${updateData.join(", ")} WHERE id = ?`,
      params,
    );

    res.json({ message: "Profile updated successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error updating profile" });
  }
});

// Change Password
router.put("/password", async (req: any, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const userId = req.user.userId;

    if (!currentPassword || !newPassword) {
      return res
        .status(400)
        .json({ message: "Current and new password are required" });
    }

    // Get user's current password
    const results: any = await query(
      "SELECT password FROM users WHERE id = ?",
      [userId],
    );
    if (!results || results.length === 0) {
      return res.status(401).json({ message: "User not found" });
    }

    const match = await bcrypt.compare(currentPassword, results[0].password);
    if (!match) {
      return res.status(400).json({ message: "Current password is incorrect" });
    }

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    await query("UPDATE users SET password = ? WHERE id = ?", [
      hashedPassword,
      userId,
    ]);

    res.json({ message: "Password updated successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error updating password" });
  }
});

// Upload profile picture
router.post(
  "/profile-picture",
  uploadProfile.single("profilePicture"),
  async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const picturePath = `/uploads/profiles/${req.file.filename}`;

      // Get old profile picture and delete it
      const oldProfileResult: any = await query(
        "SELECT profilePicture FROM users WHERE id = ?",
        [req.user.userId],
      );

      if (
        oldProfileResult &&
        oldProfileResult[0]?.profilePicture &&
        oldProfileResult[0].profilePicture !== "/uploads/profiles/default.png"
      ) {
        const oldPath = path.join(
          config.UPLOAD_DIR,
          "..",
          oldProfileResult[0].profilePicture,
        );
        if (fs.existsSync(oldPath)) {
          fs.unlinkSync(oldPath);
        }
      }

      // Update user profile picture
      await query("UPDATE users SET profilePicture = ? WHERE id = ?", [
        picturePath,
        req.user.userId,
      ]);

      res.json({
        message: "Profile picture updated successfully",
        profilePicture: picturePath,
      });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Error uploading profile picture" });
    }
  },
);

// Get enrollment status for a specific course
router.get("/course/:courseId/status", async (req: any, res) => {
  try {
    const { courseId } = req.params;
    const userId = req.user.userId;

    const enrollment: any = await query(
      "SELECT status, paymentStatus, transactionId FROM enrollments WHERE userId = ? AND courseId = ?",
      [userId, courseId],
    );

    if (!enrollment || enrollment.length === 0) {
      return res.json({ isEnrolled: false, status: null });
    }

    res.json({
      isEnrolled: true,
      status: enrollment[0].status,
      paymentStatus: enrollment[0].paymentStatus,
      transactionId: enrollment[0].transactionId,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error checking enrollment status" });
  }
});

// Enroll in a course (Students only - Admins cannot enroll)
router.post("/enroll/:courseId", requireStudent, async (req: any, res) => {
  try {
    const { courseId } = req.params;
    const userId = req.user.userId;
    const { studentMessage, transactionId, amount } = req.body;

    // Check if already enrolled
    const existing: any = await query(
      "SELECT * FROM enrollments WHERE userId = ? AND courseId = ?",
      [userId, courseId],
    );

    if (existing && existing.length > 0) {
      return res
        .status(400)
        .json({ message: "Already enrolled in this course" });
    }

    const id = uuidv4();
    await query(
      `INSERT INTO enrollments 
       (id, userId, courseId, progress, status, studentMessage, transactionId, amount, paymentStatus) 
       VALUES (?, ?, ?, 0, 'PENDING', ?, ?, ?, ?)`,
      [
        id,
        userId,
        courseId,
        studentMessage || null,
        transactionId || null,
        amount || null,
        transactionId ? "COMPLETED" : "PENDING",
      ],
    );

    res.json({
      message: "Enrollment request submitted successfully!",
      enrollmentId: id,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error enrolling in course" });
  }
});

// Get student's enrolled courses
router.get("/courses", async (req: any, res) => {
  try {
    const courses: any = await query(
      `SELECT c.*, e.status as enrollmentStatus, e.enrolledAt,
              COUNT(DISTINCT lp.id) as lessonsCompleted,
              COUNT(DISTINCT l.id) as totalLessons
       FROM courses c
       JOIN enrollments e ON c.id = e.courseId
       LEFT JOIN modules m ON c.id = m.courseId
       LEFT JOIN lessons l ON m.id = l.moduleId
       LEFT JOIN lesson_progress lp ON l.id = lp.lessonId AND lp.userId = ?
       WHERE e.userId = ?
       GROUP BY c.id
       ORDER BY e.enrolledAt DESC`,
      [req.user.userId, req.user.userId],
    );

    res.json(courses);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching enrolled courses" });
  }
});

// Get single course details (student - must be enrolled, admin - full access)
router.get("/courses/:id", async (req: any, res) => {
  try {
    const { id } = req.params;

    // Admin has full access without enrollment
    if (req.user.role !== "ADMIN") {
      // Verify enrollment for students
      const enrollment: any = await query(
        "SELECT * FROM enrollments WHERE userId = ? AND courseId = ?",
        [req.user.userId, id],
      );

      if (!enrollment || enrollment.length === 0) {
        return res.status(403).json({ message: "Not enrolled in this course" });
      }
    }

    const courseResults: any = await query(
      "SELECT * FROM courses WHERE id = ?",
      [id],
    );

    if (!courseResults || courseResults.length === 0) {
      return res.status(404).json({ message: "Course not found" });
    }

    const course = courseResults[0];
    const modules: any = await query(
      "SELECT * FROM modules WHERE courseId = ? ORDER BY sortOrder ASC",
      [id],
    );

    const modulesWithLessons = await Promise.all(
      modules.map(async (module: any) => {
        const lessons: any = await query(
          "SELECT * FROM lessons WHERE moduleId = ? ORDER BY sortOrder ASC",
          [module.id],
        );
        return { ...module, lessons };
      }),
    );

    res.json({ ...course, modules: modulesWithLessons });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching course" });
  }
});

// Get course progress
router.get("/course/:courseId/progress", async (req: any, res) => {
  try {
    const { courseId } = req.params;

    // Admin has full access without enrollment
    if (req.user.role !== "ADMIN") {
      // Verify enrollment for students
      const enrollment: any = await query(
        "SELECT * FROM enrollments WHERE userId = ? AND courseId = ?",
        [req.user.userId, courseId],
      );

      if (!enrollment || enrollment.length === 0) {
        return res.status(403).json({ message: "Not enrolled in this course" });
      }
    }

    // Get course details
    const course: any = await query(
      `SELECT id, title, description FROM courses WHERE id = ?`,
      [courseId],
    );

    // Get module progress
    const modules: any = await query(
      `SELECT m.id, m.title, m.sortOrder,
              COUNT(DISTINCT l.id) as totalLessons,
              COUNT(DISTINCT CASE WHEN lp.id IS NOT NULL THEN l.id END) as completedLessons
       FROM modules m
       LEFT JOIN lessons l ON m.id = l.moduleId
       LEFT JOIN lesson_progress lp ON l.id = lp.lessonId AND lp.userId = ?
       WHERE m.courseId = ?
       GROUP BY m.id, m.title, m.sortOrder
       ORDER BY m.sortOrder`,
      [req.user.userId, courseId],
    );

    // Get overall progress
    const progressData: any = await query(
      `SELECT COUNT(DISTINCT l.id) as totalLessons,
              COUNT(DISTINCT lp.id) as completedLessons
       FROM modules m
       JOIN lessons l ON m.id = l.moduleId
       LEFT JOIN lesson_progress lp ON l.id = lp.lessonId AND lp.userId = ?
       WHERE m.courseId = ?`,
      [req.user.userId, courseId],
    );

    const totalLessons = progressData[0]?.totalLessons || 0;
    const completedLessons = progressData[0]?.completedLessons || 0;
    const progressPercentage =
      totalLessons > 0
        ? Math.round((completedLessons / totalLessons) * 100)
        : 0;

    res.json({
      course: course[0],
      modules,
      progress: {
        totalLessons,
        completedLessons,
        percentage: progressPercentage,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching course progress" });
  }
});

// Mark lesson as complete
router.post(
  "/course/:courseId/lesson/:lessonId/complete",
  async (req: any, res) => {
    try {
      const { courseId, lessonId } = req.params;

      // Admin has full access without enrollment (but won't mark lessons as complete)
      if (req.user.role !== "ADMIN") {
        // Verify enrollment for students
        const enrollment: any = await query(
          "SELECT * FROM enrollments WHERE userId = ? AND courseId = ?",
          [req.user.userId, courseId],
        );

        if (!enrollment || enrollment.length === 0) {
          return res.status(403).json({ message: "Not enrolled in this course" });
        }
      } else {
        // Admins can view but shouldn't mark lessons as complete
        return res.status(400).json({ message: "Admins cannot mark lessons as complete. This is for enrolled students only." });
      }

      // Check if already completed
      const existing: any = await query(
        "SELECT id FROM lesson_progress WHERE userId = ? AND lessonId = ?",
        [req.user.userId, lessonId],
      );

      if (existing && existing.length > 0) {
        return res.status(400).json({ message: "Lesson already completed" });
      }

      // Add lesson progress
      const progressId = uuidv4();
      await query(
        `INSERT INTO lesson_progress (id, lessonId, userId) VALUES (?, ?, ?)`,
        [progressId, lessonId, req.user.userId],
      );

      // Recalculate enrollment progress
      const progressData: any = await query(
        `SELECT COUNT(DISTINCT l.id) as totalLessons,
                COUNT(DISTINCT lp.id) as completedLessons
         FROM modules m
         JOIN lessons l ON m.id = l.moduleId
         LEFT JOIN lesson_progress lp ON l.id = lp.lessonId AND lp.userId = ?
         WHERE m.courseId = ?`,
        [req.user.userId, courseId],
      );

      const totalLessons = progressData[0]?.totalLessons || 0;
      const completedLessons = progressData[0]?.completedLessons || 0;
      const progressPercentage =
        totalLessons > 0
          ? Math.round((completedLessons / totalLessons) * 100)
          : 0;

      await query(
        "UPDATE enrollments SET progress = ? WHERE userId = ? AND courseId = ?",
        [progressPercentage, req.user.userId, courseId],
      );

      res.json({
        message: "Lesson marked as complete",
        progress: progressPercentage,
      });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Error marking lesson complete" });
    }
  },
);

// Get student dashboard
router.get("/dashboard", async (req: any, res) => {
  try {
    // Enrolled courses count
    const enrolledResult: any = await query(
      "SELECT COUNT(*) as count FROM enrollments WHERE userId = ?",
      [req.user.userId],
    );
    const enrolledCourses = enrolledResult[0]?.count || 0;

    // Completed lessons count
    const completedResult: any = await query(
      "SELECT COUNT(DISTINCT lessonId) as count FROM lesson_progress WHERE userId = ?",
      [req.user.userId],
    );
    const completedLessons = completedResult[0]?.count || 0;

    // Total lessons count for enrollment
    const totalResult: any = await query(
      `SELECT COUNT(DISTINCT l.id) as count 
       FROM lessons l
       JOIN modules m ON l.moduleId = m.id
       JOIN enrollments e ON m.courseId = e.courseId
       WHERE e.userId = ?`,
      [req.user.userId],
    );
    const totalLessons = totalResult[0]?.count || 0;

    // Get recent courses
    const recentCourses: any = await query(
      `SELECT c.*, e.enrolledAt, e.status,
              COUNT(DISTINCT lp.id) as lessonsCompleted,
              COUNT(DISTINCT l.id) as totalLessons
       FROM courses c
       JOIN enrollments e ON c.id = e.courseId
       LEFT JOIN modules m ON c.id = m.courseId
       LEFT JOIN lessons l ON m.id = l.moduleId
       LEFT JOIN lesson_progress lp ON l.id = lp.lessonId AND lp.userId = ?
       WHERE e.userId = ?
       GROUP BY c.id
       ORDER BY e.enrolledAt DESC
       LIMIT 5`,
      [req.user.userId, req.user.userId],
    );

    res.json({
      stats: {
        enrolledCourses,
        completedLessons,
        totalLessons,
        completionPercentage:
          totalLessons > 0
            ? Math.round((completedLessons / totalLessons) * 100)
            : 0,
      },
      recentCourses,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching dashboard" });
  }
});

// Get content resources
router.get("/resources", async (req: any, res) => {
  try {
    // Check if user is premium
    const userResult: any = await query(
      "SELECT isPremium, role FROM users WHERE id = ?",
      [req.user.userId],
    );
    const isPremium =
      userResult[0]?.isPremium || userResult[0]?.role === "PREMIUM";

    let sql = `SELECT cc.*, c.title as courseTitle 
               FROM course_contents cc
               LEFT JOIN courses c ON cc.courseId = c.id`;

    // If not premium, filter out premium-only content
    if (!isPremium) {
      sql += " WHERE cc.isPremiumOnly = 0";
    }

    sql += " ORDER BY cc.createdAt DESC";

    const contents: any = await query(sql);
    res.json({ contents, isPremium });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching resources" });
  }
});

export default router;

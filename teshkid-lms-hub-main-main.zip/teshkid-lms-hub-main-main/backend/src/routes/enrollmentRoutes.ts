import express from "express";
import { authenticateToken } from "../middleware/authMiddleware";
import { query } from "../database";

const router = express.Router();

/**
 * STUDENT ENROLLMENT ENDPOINTS
 */

// Get student's enrolled courses
router.get("/my-courses", authenticateToken, async (req: any, res) => {
  try {
    const userId = req.user.userId;

    const enrolledCourses: any = await query(
      `SELECT c.*, e.status as enrollmentStatus, e.enrolledAt, e.id as enrollmentId,
              (SELECT COUNT(*) FROM course_progress WHERE enrollmentId = e.id) as lessonsCompleted,
              (SELECT COUNT(*) FROM lessons l
               INNER JOIN modules m ON l.moduleId = m.id
               WHERE m.courseId = c.id) as totalLessons
       FROM enrollments e
       INNER JOIN courses c ON e.courseId = c.id
       WHERE e.userId = ? AND e.status != 'FORFEITED'
       ORDER BY e.enrolledAt DESC`,
      [userId]
    );

    res.json(enrolledCourses);
  } catch (error) {
    console.error("Error fetching enrolled courses:", error);
    res.status(500).json({ error: "Error fetching enrolled courses" });
  }
});

// Request course enrollment
router.post("/enroll/:courseId", authenticateToken, async (req: any, res) => {
  try {
    const { courseId } = req.params;
    const userId = req.user.userId;
    const { paymentMethod, paymentId } = req.body;

    // Check if already enrolled
    const existing: any = await query(
      "SELECT * FROM enrollments WHERE userId = ? AND courseId = ?",
      [userId, courseId]
    );

    if (existing && existing.length > 0) {
      return res.status(400).json({ error: "Already enrolled in this course" });
    }

    // Get course pricing info
    const courseInfo: any = await query(
      "SELECT * FROM courses WHERE id = ?",
      [courseId]
    );

    if (!courseInfo || courseInfo.length === 0) {
      return res.status(404).json({ error: "Course not found" });
    }

    const course = courseInfo[0];

    // If course is free or payment successful
    const status = course.price === 0 || paymentMethod === "admin_approved" ? "APPROVED" : "PENDING";
    const enrollmentId = Math.random().toString(36).substr(2, 9);

    await query(
      `INSERT INTO enrollments 
       (id, userId, courseId, status, enrolledAt, paymentMethod, paymentId)
       VALUES (?, ?, ?, ?, NOW(), ?, ?)`,
      [enrollmentId, userId, courseId, status, paymentMethod || "manual", paymentId || null]
    );

    res.json({
      success: true,
      enrollmentId,
      status,
      message: status === "APPROVED" ? "Enrollment successful!" : "Enrollment request submitted for approval"
    });
  } catch (error) {
    console.error("Error enrolling in course:", error);
    res.status(500).json({ error: "Error processing enrollment" });
  }
});

/**
 * ADMIN ENROLLMENT MANAGEMENT
 */

// Get pending enrollment requests
router.get("/admin/pending", authenticateToken, async (req: any, res) => {
  try {
    // Verify admin
    const adminCheck: any = await query(
      "SELECT role FROM users WHERE id = ?",
      [req.user.userId]
    );

    if (!adminCheck || adminCheck.length === 0 || adminCheck[0].role.toUpperCase() !== "ADMIN") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const pendingEnrollments: any = await query(
      `SELECT e.*, u.name, SUBSTRING_INDEX(u.name, ' ', 1) AS firstName, IF(LOCATE(' ', u.name) > 0, SUBSTRING_INDEX(u.name, ' ', -1), '') AS lastName, u.email, c.title as courseTitle
       FROM enrollments e
       INNER JOIN users u ON e.userId = u.id
       INNER JOIN courses c ON e.courseId = c.id
       WHERE e.status = 'PENDING'
       ORDER BY e.enrolledAt ASC`
    );

    res.json(pendingEnrollments);
  } catch (error) {
    console.error("Error fetching pending enrollments:", error);
    res.status(500).json({ error: "Error fetching enrollments" });
  }
});

// Approve/Reject enrollment
router.post("/admin/:enrollmentId/approve", authenticateToken, async (req: any, res) => {
  try {
    // Verify admin
    const adminCheck: any = await query(
      "SELECT role FROM users WHERE id = ?",
      [req.user.userId]
    );

    if (!adminCheck || adminCheck.length === 0 || adminCheck[0].role.toUpperCase() !== "ADMIN") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const { enrollmentId } = req.params;
    const { approved, reason } = req.body;

    const status = approved ? "APPROVED" : "REJECTED";

    await query(
      `UPDATE enrollments 
       SET status = ?, approvedAt = NOW(), rejectionReason = ?
       WHERE id = ?`,
      [status, reason || null, enrollmentId]
    );

    res.json({ success: true, status });
  } catch (error) {
    console.error("Error updating enrollment:", error);
    res.status(500).json({ error: "Error updating enrollment" });
  }
});

// Get course enrollments (admin)
router.get("/admin/course/:courseId", authenticateToken, async (req: any, res) => {
  try {
    const adminCheck: any = await query(
      "SELECT role FROM users WHERE id = ?",
      [req.user.userId]
    );

    if (!adminCheck || adminCheck.length === 0 || adminCheck[0].role.toUpperCase() !== "ADMIN") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const { courseId } = req.params;

    const enrollments: any = await query(
      `SELECT e.*, u.name, SUBSTRING_INDEX(u.name, ' ', 1) AS firstName, IF(LOCATE(' ', u.name) > 0, SUBSTRING_INDEX(u.name, ' ', -1), '') AS lastName, u.email,
              (SELECT COUNT(*) FROM course_progress WHERE enrollmentId = e.id) as lessonsCompleted
       FROM enrollments e
       INNER JOIN users u ON e.userId = u.id
       WHERE e.courseId = ?
       ORDER BY e.enrolledAt DESC`,
      [courseId]
    );

    res.json(enrollments);
  } catch (error) {
    console.error("Error fetching course enrollments:", error);
    res.status(500).json({ error: "Error fetching enrollments" });
  }
});

// Forfeit course enrollment (student)
router.post("/forfeit/:courseId", authenticateToken, async (req: any, res) => {
  try {
    const { courseId } = req.params;
    const userId = req.user.userId;

    const existing: any = await query(
      "SELECT * FROM enrollments WHERE userId = ? AND courseId = ?",
      [userId, courseId]
    );

    if (!existing || existing.length === 0) {
      return res.status(404).json({ error: "Enrollment not found" });
    }

    await query(
      "UPDATE enrollments SET status = 'FORFEITED' WHERE userId = ? AND courseId = ?",
      [userId, courseId]
    );

    res.json({ success: true, message: "Course forfeited successfully" });
  } catch (error) {
    console.error("Error forfeiting course:", error);
    res.status(500).json({ error: "Error forfeiting course" });
  }
});

export default router;

import express from "express";
import { authenticateToken, optionalAuth } from "../middleware/authMiddleware";
import { query } from "../database";
import { v4 as uuidv4 } from "uuid";

const router = express.Router();

// Get all certificates for current user
router.get("/", authenticateToken, async (req: any, res) => {
    try {
        const userId = req.user.userId;
        const certificates: any = await query(
            `SELECT cert.*, c.title as courseTitle, c.instructor, c.thumbnail
             FROM certificates cert
             JOIN courses c ON cert.courseId = c.id
             WHERE cert.userId = ?
             ORDER BY cert.issuedAt DESC`,
            [userId]
        );
        res.json(certificates);
    } catch (error) {
        console.error("Error fetching certificates:", error);
        res.status(500).json({ error: "Error fetching certificates" });
    }
});

// Claim a certificate for a course
router.post("/claim/:courseId", authenticateToken, async (req: any, res) => {
    try {
        const { courseId } = req.params;
        const userId = req.user.userId;

        // 1. Check if already issued
        const existing: any = await query(
            "SELECT id FROM certificates WHERE userId = ? AND courseId = ?",
            [userId, courseId]
        );
        if (existing && existing.length > 0) {
            return res.json({ success: true, message: "Certificate already issued", id: existing[0].id });
        }

        // 2. Verify completion
        // Get total lessons in course
        const totalResult: any = await query(
            `SELECT COUNT(l.id) as count 
             FROM lessons l
             JOIN modules m ON l.moduleId = m.id
             WHERE m.courseId = ?`,
            [courseId]
        );
        const totalLessons = totalResult[0]?.count || 0;

        // Get completed lessons by user
        const completedResult: any = await query(
            `SELECT COUNT(lp.id) as count
             FROM lesson_progress lp
             JOIN lessons l ON lp.lessonId = l.id
             JOIN modules m ON l.moduleId = m.id
             WHERE lp.userId = ? AND m.courseId = ? AND lp.completed = 1`,
            [userId, courseId]
        );
        const completedLessons = completedResult[0]?.count || 0;

        if (totalLessons === 0 || completedLessons < totalLessons) {
            return res.status(400).json({
                error: "Course not completed",
                progress: { completed: completedLessons, total: totalLessons }
            });
        }

        // 3. Issue certificate
        const certId = uuidv4();
        await query(
            "INSERT INTO certificates (id, userId, courseId, issuedAt) VALUES (?, ?, ?, NOW())",
            [certId, userId, courseId]
        );

        res.json({ success: true, id: certId });
    } catch (error) {
        console.error("Error claiming certificate:", error);
        res.status(500).json({ error: "Error claiming certificate" });
    }
});

// Get a specific certificate detail
router.get("/:id", optionalAuth, async (req: any, res) => {
    try {
        const { id } = req.params;
        const certs: any = await query(
            `SELECT cert.*, c.title as courseTitle, c.instructor, u.name, u.firstName, u.lastName
             FROM certificates cert
             JOIN courses c ON cert.courseId = c.id
             JOIN users u ON cert.userId = u.id
             WHERE cert.id = ?`,
            [id]
        );

        if (!certs || certs.length === 0) {
            return res.status(404).json({ error: "Certificate not found" });
        }

        res.json(certs[0]);
    } catch (error) {
        console.error("Error fetching certificate detail:", error);
        res.status(500).json({ error: "Error fetching certificate detail" });
    }
});

export default router;

import express from "express";
import { v4 as uuidv4 } from "uuid";
import { query } from "../database";
import {
  authenticateToken,
  requireAdmin,
  AuthenticatedRequest,
} from "../middleware/authMiddleware";

const router = express.Router();

// Protect all routes
router.use(authenticateToken);
router.use(requireAdmin);

/**
 * Get all enrollments with progress
 */
router.get("/", async (req, res) => {
  try {
    const enrollments: any = await query(
      `SELECT e.*, 
              u.name as userName, u.email as userEmail, 
              c.title as courseTitle
       FROM enrollments e
       JOIN users u ON e.userId = u.id
       JOIN courses c ON e.courseId = c.id
       ORDER BY e.updatedAt DESC`
    );

    const formatted = enrollments.map((e: any) => ({
      id: e.id,
      progress: e.progress,
      updatedAt: e.updatedAt,
      user: {
        name: e.userName,
        email: e.userEmail
      },
      course: {
        title: e.courseTitle
      }
    }));

    res.json(formatted);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching enrollments" });
  }
});
router.get("/students/progress", async (req, res) => {
  try {
    const students: any = await query(
      `SELECT u.id, u.name, u.email, u.profilePicture,
              COUNT(DISTINCT e.courseId) as enrolledCourses,
              COUNT(DISTINCT lp.id) as completedLessons
       FROM users u
       LEFT JOIN enrollments e ON u.id = e.userId
       LEFT JOIN modules m ON e.courseId = m.courseId
       LEFT JOIN lessons l ON m.id = l.moduleId
       LEFT JOIN lesson_progress lp ON l.id = lp.lessonId AND lp.userId = u.id
       WHERE u.role = 'STUDENT'
       GROUP BY u.id, u.name, u.email, u.profilePicture
       ORDER BY u.name ASC`,
    );

    const studentProgress = await Promise.all(
      students.map(async (student: any) => {
        // Get total lessons for progress calculation
        const totalLessons: any = await query(
          `SELECT COUNT(*) as count FROM lessons WHERE moduleId IN (
            SELECT id FROM modules WHERE courseId IN (
              SELECT courseId FROM enrollments WHERE userId = ?
            )
          )`,
          [student.id],
        );

        const progressPercentage =
          totalLessons[0]?.count > 0
            ? Math.round(
              (student.completedLessons / totalLessons[0].count) * 100,
            )
            : 0;

        return {
          id: student.id,
          name: student.name,
          email: student.email,
          profilePicture: student.profilePicture,
          enrolledCourses: student.enrolledCourses || 0,
          completedLessons: student.completedLessons || 0,
          totalLessons: totalLessons[0]?.count || 0,
          progressPercentage,
        };
      }),
    );

    res.json(studentProgress);
  } catch (error) {
    console.error("Student Progress Error:", error);
    res.status(500).json({ error: "Error fetching student progress", details: error instanceof Error ? error.message : String(error) });
  }
});

/**
 * Get detailed progress for a specific student
 */
router.get("/students/:studentId/progress", async (req, res) => {
  try {
    const { studentId } = req.params;

    // Get student info
    const student: any = await query(
      "SELECT id, name, email, profilePicture, bio, createdAt FROM users WHERE id = ? AND role = 'STUDENT'",
      [studentId],
    );

    if (!student || student.length === 0) {
      return res.status(404).json({ message: "Student not found" });
    }

    // Get enrolled courses with progress
    const courseProgress: any = await query(
      `SELECT c.id, c.title, c.description, e.enrolledAt,
              COUNT(DISTINCT l.id) as totalLessons,
              COUNT(DISTINCT CASE WHEN lp.id IS NOT NULL THEN l.id END) as completedLessons
       FROM courses c
       JOIN enrollments e ON c.id = e.courseId
       LEFT JOIN modules m ON c.id = m.courseId
       LEFT JOIN lessons l ON m.id = l.moduleId
       LEFT JOIN lesson_progress lp ON l.id = lp.lessonId AND lp.userId = ?
       WHERE e.userId = ?
       GROUP BY c.id, c.title, c.description, e.enrolledAt
       ORDER BY e.enrolledAt DESC`,
      [studentId, studentId],
    );

    const coursesWithProgress = courseProgress.map((course: any) => ({
      ...course,
      progressPercentage:
        course.totalLessons > 0
          ? Math.round((course.completedLessons / course.totalLessons) * 100)
          : 0,
    }));

    // Get learning activities
    const activities: any = await query(
      `SELECT lp.id, l.title as lessonTitle, m.title as moduleTitle, c.title as courseTitle,
              lp.createdAt as completedAt
       FROM lesson_progress lp
       JOIN lessons l ON lp.lessonId = l.id
       JOIN modules m ON l.moduleId = m.id
       JOIN courses c ON m.courseId = c.id
       WHERE lp.userId = ?
       ORDER BY lp.createdAt DESC
       LIMIT 20`,
      [studentId],
    );

    // Get summary stats
    const totalEnrolled = coursesWithProgress.length;
    const totalCompleted = coursesWithProgress.filter(
      (c: any) => c.progressPercentage === 100,
    ).length;
    const totalLessonsCompleted = activities.length;

    res.json({
      student: student[0],
      stats: {
        totalEnrolledCourses: totalEnrolled,
        completedCourses: totalCompleted,
        totalLessonsCompleted,
        averageProgress:
          coursesWithProgress.length > 0
            ? Math.round(
              coursesWithProgress.reduce(
                (acc: number, c: any) => acc + c.progressPercentage,
                0,
              ) / coursesWithProgress.length,
            )
            : 0,
      },
      courses: coursesWithProgress,
      recentActivities: activities,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching student details" });
  }
});

/**
 * Get course-wise student analytics
 */
router.get("/analytics/courses", async (req, res) => {
  try {
    const courseAnalytics: any = await query(
      `SELECT c.id, c.title, c.description,
              COUNT(DISTINCT e.userId) as totalStudents,
              COUNT(DISTINCT CASE WHEN lp.id IS NOT NULL THEN e.userId END) as activeStudents,
              ROUND(AVG(CASE WHEN lp.id IS NOT NULL THEN 1 ELSE 0 END) * 100, 2) as completionRate,
              COUNT(DISTINCT l.id) as totalLessons
       FROM courses c
       LEFT JOIN enrollments e ON c.id = e.courseId
       LEFT JOIN modules m ON c.id = m.courseId
       LEFT JOIN lessons l ON m.id = l.moduleId
       LEFT JOIN lesson_progress lp ON l.id = lp.lessonId
       GROUP BY c.id
       ORDER BY totalStudents DESC`,
    );

    res.json(courseAnalytics);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching course analytics" });
  }
});

/**
 * Get system-wide analytics
 */
router.get("/analytics/system", async (req, res) => {
  try {
    // Total students
    const totalStudents: any = await query(
      "SELECT COUNT(*) as count FROM users WHERE role = 'STUDENT'",
    );

    // Total courses
    const totalCourses: any = await query(
      "SELECT COUNT(*) as count FROM courses",
    );

    // Total enrollments (Approved)
    const approvedEnrollments: any = await query(
      "SELECT COUNT(*) as count FROM enrollments WHERE status = 'APPROVED'",
    );

    // Pending enrollments
    const pendingEnrollments: any = await query(
      "SELECT COUNT(*) as count FROM enrollments WHERE status = 'PENDING'",
    );

    // Active students (with at least one lesson completed)
    const activeStudents: any = await query(
      "SELECT COUNT(DISTINCT userId) as count FROM lesson_progress",
    );

    // Average completion rate across all enrollments
    const avgCompletion: any = await query(
      `SELECT ROUND(AVG(progress), 1) as rate FROM enrollments WHERE status = 'APPROVED'`,
    );

    // Most popular courses
    const popularCourses: any = await query(
      `SELECT c.id, c.title, COUNT(DISTINCT e.userId) as enrollmentCount
       FROM courses c
       LEFT JOIN enrollments e ON c.id = e.courseId AND e.status = 'APPROVED'
       GROUP BY c.id
       ORDER BY enrollmentCount DESC
       LIMIT 5`,
    );

    // Forfeited enrollments
    const forfeitedEnrollments: any = await query(
      "SELECT COUNT(*) as count FROM enrollments WHERE status = 'FORFEITED'",
    );

    res.json({
      totalStudents: totalStudents[0]?.count || 0,
      totalCourses: totalCourses[0]?.count || 0,
      totalEnrollments: approvedEnrollments[0]?.count || 0,
      pendingEnrollments: pendingEnrollments[0]?.count || 0,
      forfeitedEnrollments: forfeitedEnrollments[0]?.count || 0,
      activeStudents: activeStudents[0]?.count || 0,
      averageCompletionRate: avgCompletion[0]?.rate || 0,
      popularCourses,
    });
  } catch (error) {
    console.error("System Analytics Error:", error);
    res.status(500).json({ error: "Error fetching system analytics", details: error instanceof Error ? error.message : String(error) });
  }
});

/**
 * Get student activity timeline
 */
router.get("/students/:studentId/activity", async (req, res) => {
  try {
    const { studentId } = req.params;

    const activities: any = await query(
      `SELECT 'lesson_completed' as activityType, 
              lp.createdAt as timestamp,
              l.title as lessonTitle,
              m.title as moduleTitle,
              c.title as courseTitle
       FROM lesson_progress lp
       JOIN lessons l ON lp.lessonId = l.id
       JOIN modules m ON l.moduleId = m.id
       JOIN courses c ON m.courseId = c.id
       WHERE lp.userId = ?
       
       UNION ALL
       
       SELECT 'course_enrolled' as activityType,
              e.enrolledAt as timestamp,
              c.title as lessonTitle,
              'Course' as moduleTitle,
              c.description as courseTitle
       FROM enrollments e
       JOIN courses c ON e.courseId = c.id
       WHERE e.userId = ?
       
       ORDER BY timestamp DESC`,
      [studentId, studentId],
    );

    res.json(activities);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching student activity" });
  }
});

/**
 * Get student performance metrics
 */
router.get("/students/:studentId/metrics", async (req, res) => {
  try {
    const { studentId } = req.params;

    // Get quiz performance
    const quizzes: any = await query(
      `SELECT AVG(qa.score) as avgScore, COUNT(*) as totalAttempts,
              MAX(qa.score) as maxScore, MIN(qa.score) as minScore
       FROM quiz_attempts qa
       WHERE qa.userId = ?`,
      [studentId],
    );

    // Get assignment performance
    const assignments: any = await query(
      `SELECT AVG(asub.score) as avgScore, COUNT(*) as totalSubmitted,
              MAX(asub.score) as maxScore
       FROM assignment_submissions asub
       WHERE asub.userId = ?`,
      [studentId],
    );

    // Get learning pace (lessons per week)
    const learningPace: any = await query(
      `SELECT COUNT(*) as lessonsCompleted,
              DATEDIFF(MAX(createdAt), MIN(createdAt)) as daysActive,
              ROUND(COUNT(*) / (DATEDIFF(MAX(createdAt), MIN(createdAt)) + 1) * 7, 2) as lessonsPerWeek
       FROM lesson_progress
       WHERE userId = ?`,
      [studentId],
    );

    res.json({
      quizPerformance: {
        averageScore: quizzes[0]?.avgScore || 0,
        totalAttempts: quizzes[0]?.totalAttempts || 0,
        maxScore: quizzes[0]?.maxScore || 0,
        minScore: quizzes[0]?.minScore || 0,
      },
      assignmentPerformance: {
        averageScore: assignments[0]?.avgScore || 0,
        totalSubmitted: assignments[0]?.totalSubmitted || 0,
        maxScore: assignments[0]?.maxScore || 0,
      },
      learningPace: {
        lessonsCompleted: learningPace[0]?.lessonsCompleted || 0,
        daysActive: learningPace[0]?.daysActive || 0,
        lessonsPerWeek: learningPace[0]?.lessonsPerWeek || 0,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching student metrics" });
  }
});

export default router;

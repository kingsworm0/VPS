import express from "express";
import { query } from "../database";

const router = express.Router();

// Public: list active announcements
router.get("/", async (req, res) => {
  try {
    const announcements: any = await query(
      "SELECT * FROM announcements WHERE isActive = TRUE ORDER BY createdAt DESC",
    );
    res.json(announcements);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching announcements" });
  }
});

export default router;

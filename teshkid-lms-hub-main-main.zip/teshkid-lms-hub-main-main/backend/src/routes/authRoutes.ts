import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { v4 as uuidv4 } from "uuid";
import crypto from "crypto";
import { query } from "../database";
import { db } from "../database";
import { authenticateToken, AuthRequest } from "../middleware/authMiddleware";
import { config } from "../config";
import { 
  sanitizeInput, 
  validatePasswordStrength, 
  logSecurityEvent 
} from "../utils/security";
import { isValidEmail } from "../middleware/validationMiddleware";
import { sendPasswordResetEmail } from "../services/emailService";

const router = express.Router();
const JWT_SECRET = config.JWT_SECRET;
const PASSWORD_RESET_TTL_MS = 60 * 60 * 1000;

const hashResetToken = (token: string) =>
  crypto.createHash("sha256").update(token).digest("hex");

// Signup
router.post("/signup", async (req, res) => {
  try {
    const { email, password, firstName, lastName } = req.body;
    
    // Validate inputs
    if (!email || !password || !firstName) {
      return res.status(400).json({ error: "Email, password, and first name are required" });
    }

    if (!isValidEmail(email)) {
      return res.status(400).json({ error: "Invalid email format" });
    }

    // SECURITY: Validate password strength
    const passwordValidation = validatePasswordStrength(password);
    if (!passwordValidation.isValid) {
      return res.status(400).json({ 
        error: "Password does not meet security requirements",
        details: passwordValidation.errors 
      });
    }

    // Sanitize inputs
    const sanitizedEmail = sanitizeInput(email);
    const sanitizedFirstName = sanitizeInput(firstName);
    const sanitizedLastName = lastName ? sanitizeInput(lastName) : '';
    const fullName = sanitizedLastName 
      ? `${sanitizedFirstName} ${sanitizedLastName}` 
      : sanitizedFirstName;

    // Check if user exists
    const existing: any = await query("SELECT id FROM users WHERE email = ?", [
      sanitizedEmail,
    ]);
    if (existing && existing.length > 0) {
      logSecurityEvent("signup_attempt", {
        email: sanitizedEmail,
        result: "failure",
        reason: "user_already_exists",
        ip: req.ip,
      }, config.LOG_DIR);
      return res.status(409).json({ error: "User already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 12); // Increased salt rounds for security
    const userId = uuidv4();

    await query(
      "INSERT INTO users (id, email, password, name, firstName, lastName, role, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())",
      [userId, sanitizedEmail, hashedPassword, fullName, sanitizedFirstName, sanitizedLastName, "STUDENT"],
    );

    logSecurityEvent("signup_success", {
      userId,
      email: sanitizedEmail,
      result: "success",
      ip: req.ip,
    }, config.LOG_DIR);

    const token = jwt.sign({ userId, email: sanitizedEmail, role: "STUDENT" }, JWT_SECRET, {
      expiresIn: config.SECURITY.JWT_EXPIRES_IN as any,
      algorithm: "HS256",
    });

    res.status(201).json({
      token,
      user: {
        id: userId,
        name: fullName,
        firstName: sanitizedFirstName,
        lastName: sanitizedLastName,
        email: sanitizedEmail,
        role: "STUDENT",
      },
    });
  } catch (error) {
    console.error("Signup error:", error);
    res.status(500).json({ error: "Error creating account" });
  }
});

// Login
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required" });
    }

    if (!isValidEmail(email)) {
      return res.status(400).json({ error: "Invalid email format" });
    }

    const sanitizedEmail = sanitizeInput(email);

    const results: any = await query(
      "SELECT id, email, password, name, firstName, lastName, role, isBlocked, profilePicture FROM users WHERE email = ?",
      [sanitizedEmail],
    );

    if (!results || results.length === 0) {
      // SECURITY: Log failed login attempt
      logSecurityEvent("login_failed", {
        email: sanitizedEmail,
        result: "failure",
        reason: "user_not_found",
        ip: req.ip,
      }, config.LOG_DIR);
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const user = results[0];
    const match = await bcrypt.compare(password, user.password);
    
    if (!match) {
      logSecurityEvent("login_failed", {
        userId: user.id,
        email: sanitizedEmail,
        result: "failure",
        reason: "invalid_password",
        ip: req.ip,
      }, config.LOG_DIR);
      return res.status(401).json({ error: "Invalid credentials" });
    }

    if (user.isBlocked) {
      logSecurityEvent("login_blocked", {
        userId: user.id,
        email: sanitizedEmail,
        result: "failure",
        reason: "user_blocked",
        ip: req.ip,
      }, config.LOG_DIR);
      return res.status(403).json({ error: "Account is blocked. Contact administrator." });
    }

    logSecurityEvent("login_success", {
      userId: user.id,
      email: sanitizedEmail,
      result: "success",
      ip: req.ip,
    }, config.LOG_DIR);

    const token = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      JWT_SECRET,
      { 
        expiresIn: config.SECURITY.JWT_EXPIRES_IN as any,
        algorithm: "HS256",
      },
    );

    res.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        role: user.role,
        profilePicture: user.profilePicture,
      },
    });

  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ error: "Error logging in" });
  }
});

// Request a password reset. Always return the same response to avoid revealing
// whether an email address belongs to an account.
router.post("/forgot-password", async (req, res) => {
  try {
    const email = typeof req.body?.email === "string" ? req.body.email.trim().toLowerCase() : "";
    if (!isValidEmail(email)) {
      return res.status(400).json({ error: "Please provide a valid email address" });
    }

    const users: any = await query(
      "SELECT id, email, name FROM users WHERE email = ? LIMIT 1",
      [sanitizeInput(email)],
    );

    if (users.length > 0) {
      const rawToken = crypto.randomBytes(32).toString("hex");
      const tokenHash = hashResetToken(rawToken);
      const expiresAt = new Date(Date.now() + PASSWORD_RESET_TTL_MS);

      await query("UPDATE password_reset_tokens SET isUsed = TRUE WHERE userId = ? AND isUsed = FALSE", [users[0].id]);
      await query(
        "INSERT INTO password_reset_tokens (id, userId, token, expiresAt, isUsed) VALUES (?, ?, ?, ?, FALSE)",
        [uuidv4(), users[0].id, tokenHash, expiresAt],
      );

      const resetUrl = `${config.FRONTEND_URL.replace(/\/$/, "")}/reset-password/${rawToken}`;
      await sendPasswordResetEmail({
        toEmail: users[0].email,
        recipientName: users[0].name || "there",
        resetUrl,
      });
    }

    res.json({ message: "If an account exists for that email, a password reset link has been sent." });
  } catch (error) {
    console.error("Forgot password error:", error);
    res.status(500).json({ error: "Unable to process password reset request" });
  }
});

// Validate a reset token without consuming it.
router.get("/verify-reset-token/:token", async (req, res) => {
  try {
    const token = req.params.token;
    if (!/^[a-f0-9]{64}$/i.test(token)) {
      return res.status(400).json({ valid: false, error: "Invalid reset token" });
    }

    const results: any = await query(
      "SELECT expiresAt FROM password_reset_tokens WHERE token = ? AND isUsed = FALSE LIMIT 1",
      [hashResetToken(token)],
    );
    const valid = results.length > 0 && new Date(results[0].expiresAt).getTime() > Date.now();
    res.json({ valid });
  } catch (error) {
    console.error("Verify reset token error:", error);
    res.status(500).json({ valid: false, error: "Unable to verify reset token" });
  }
});

// Set a new password and consume the token atomically.
router.post("/reset-password", async (req, res) => {
  const connection = await db.getConnection();
  try {
    const { token, password, confirmPassword } = req.body || {};
    if (typeof token !== "string" || !/^[a-f0-9]{64}$/i.test(token)) {
      return res.status(400).json({ error: "Invalid or expired reset token" });
    }
    if (typeof password !== "string" || typeof confirmPassword !== "string" || password !== confirmPassword) {
      return res.status(400).json({ error: "Passwords do not match" });
    }

    const passwordValidation = validatePasswordStrength(password);
    if (!passwordValidation.isValid) {
      return res.status(400).json({
        error: "Password does not meet security requirements",
        details: passwordValidation.errors,
      });
    }

    await connection.beginTransaction();
    const [tokens]: any = await connection.execute(
      "SELECT id, userId FROM password_reset_tokens WHERE token = ? AND isUsed = FALSE AND expiresAt > NOW() LIMIT 1 FOR UPDATE",
      [hashResetToken(token)],
    );
    if (!tokens.length) {
      await connection.rollback();
      return res.status(400).json({ error: "Invalid or expired reset token" });
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    await connection.execute(
      "UPDATE users SET password = ?, updatedAt = NOW() WHERE id = ?",
      [hashedPassword, tokens[0].userId],
    );
    await connection.execute(
      "UPDATE password_reset_tokens SET isUsed = TRUE WHERE id = ?",
      [tokens[0].id],
    );
    await connection.commit();

    res.json({ message: "Password reset successfully. You can now sign in." });
  } catch (error) {
    await connection.rollback();
    console.error("Reset password error:", error);
    res.status(500).json({ error: "Unable to reset password" });
  } finally {
    connection.release();
  }
});

// Get current user (No cache to prevent 304 stale auth status)
router.get("/me", authenticateToken, async (req: AuthRequest, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");

    const results: any = await query(
      "SELECT id, name, firstName, lastName, email, role, profilePicture, bio FROM users WHERE id = ?",
      [req.user.userId],
    );

    if (!results || results.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    const user = results[0];
    res.json({
      id: user.id,
      name: user.name,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      role: user.role,
      profilePicture: user.profilePicture,
      bio: user.bio,
    });
  } catch (error) {
    console.error("Error fetching user:", error);
    res.status(500).json({ error: "Error fetching user" });
  }
});

// Change Password - SECURITY IMPROVED
router.post("/change-password", authenticateToken, async (req: AuthRequest, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const { currentPassword, newPassword, confirmPassword } = req.body;

    // Validate inputs
    if (!currentPassword || !newPassword || !confirmPassword) {
      return res.status(400).json({ error: "All password fields are required" });
    }

    // Validate passwords match
    if (newPassword !== confirmPassword) {
      return res.status(400).json({ error: "New passwords do not match" });
    }

    // Prevent using same password
    if (currentPassword === newPassword) {
      return res.status(400).json({ error: "New password must be different from current password" });
    }

    // SECURITY: Validate new password strength
    const passwordValidation = validatePasswordStrength(newPassword);
    if (!passwordValidation.isValid) {
      return res.status(400).json({
        error: "New password does not meet security requirements",
        details: passwordValidation.errors,
      });
    }

    // Get current password from database
    const results: any = await query(
      "SELECT password FROM users WHERE id = ?",
      [req.user.userId],
    );

    if (!results || results.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    // Verify current password
    const match = await bcrypt.compare(currentPassword, results[0].password);
    if (!match) {
      logSecurityEvent("password_change_failed", {
        userId: req.user.userId,
        email: req.user.email,
        result: "failure",
        reason: "invalid_current_password",
        ip: req.ip,
      }, config.LOG_DIR);
      return res.status(401).json({ error: "Current password is incorrect" });
    }

    // Hash new password with stronger salt rounds
    const hashedPassword = await bcrypt.hash(newPassword, 12);

    // Update password
    await query(
      "UPDATE users SET password = ?, updatedAt = NOW() WHERE id = ?",
      [hashedPassword, req.user.userId],
    );

    logSecurityEvent("password_change_success", {
      userId: req.user.userId,
      email: req.user.email,
      result: "success",
      ip: req.ip,
    }, config.LOG_DIR);

    res.json({ message: "Password changed successfully" });
  } catch (error) {
    console.error("Change password error:", error);
    res.status(500).json({ error: "Error changing password" });
  }
});

export default router;

import express from "express";
import { authenticateToken } from "../middleware/authMiddleware";
import { query } from "../database";

const router = express.Router();

// Get all courses
router.get("/", async (req, res) => {
  try {
    const courses: any = await query(
      `SELECT c.*, 
                    (SELECT COUNT(*) FROM modules WHERE courseId = c.id) as modules,
                    (SELECT COUNT(*) FROM enrollments WHERE courseId = c.id) as students
             FROM courses c`,
    );
    res.json(courses);
  } catch (error) {
    console.error("Error fetching courses:", error);
    res.status(500).json({ error: "Error fetching courses" });
  }
});

// Get single course
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const courseResults: any = await query(
      "SELECT * FROM courses WHERE id = ?",
      [id],
    );

    if (!courseResults || courseResults.length === 0) {
      return res.status(404).json({ message: "Course not found" });
    }

    const course = courseResults[0];

    // Get modules with lessons
    const modules: any = await query(
      `SELECT m.*, (SELECT COUNT(*) FROM lessons WHERE moduleId = m.id) as lessonCount
             FROM modules m WHERE m.courseId = ? ORDER BY m.sortOrder ASC`,
      [id],
    );

    const modulesWithLessons = await Promise.all(
      modules.map(async (module: any) => {
        const lessons: any = await query(
          "SELECT * FROM lessons WHERE moduleId = ? ORDER BY sortOrder ASC",
          [module.id],
        );
        return { ...module, lessons };
      }),
    );

    res.json({ ...course, modules: modulesWithLessons });
  } catch (error) {
    console.error("Error fetching course:", error);
    res.status(500).json({ error: "Error fetching course" });
  }
});

// Get course for learning (Protected)
router.get("/:id/learn", authenticateToken, async (req: any, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.userId;
    const isAdmin = req.user.role === "ADMIN";

    // Admin has full access without enrollment
    let isApproved = isAdmin;
    let enrollmentStatus = null;

    if (!isAdmin) {
      // Verify enrollment for students
      const enrollment: any = await query(
        "SELECT status FROM enrollments WHERE userId = ? AND courseId = ?",
        [userId, id],
      );

      isApproved = enrollment && enrollment.length > 0 && enrollment[0].status === 'APPROVED';
      enrollmentStatus = enrollment && enrollment.length > 0 ? enrollment[0].status : null;
    }

    // Fetch course details
    const courseResults: any = await query(
      "SELECT * FROM courses WHERE id = ?",
      [id],
    );

    if (!courseResults || courseResults.length === 0) {
      return res.status(404).json({ message: "Course not found" });
    }

    const course = courseResults[0];

    // If not approved and not admin, return basic course info only
    if (!isApproved && !isAdmin) {
      return res.json({
        ...course,
        modules: [],
        isApproved: false,
        enrollmentStatus: enrollmentStatus
      });
    }

    const modules: any = await query(
      `SELECT m.* FROM modules m WHERE m.courseId = ? ORDER BY m.sortOrder ASC`,
      [id],
    );

    const modulesWithLessons = await Promise.all(
      modules.map(async (module: any) => {
        const lessons: any = await query(
          `SELECT l.*, 
                  (SELECT COUNT(*) FROM lesson_progress WHERE lessonId = l.id AND userId = ?) as isCompleted
           FROM lessons l WHERE l.moduleId = ? ORDER BY l.sortOrder ASC`,
          [userId, module.id],
        );

        const formattedLessons = lessons.map((l: any) => ({
          ...l,
          progress: [{ completed: !!l.isCompleted }]
        }));

        return { ...module, lessons: formattedLessons };
      }),
    );

    res.json({ 
      ...course, 
      modules: modulesWithLessons,
      isApproved: true,  // Admin always gets approved access
      enrollmentStatus: isAdmin ? 'ADMIN_ACCESS' : enrollmentStatus
    });
  } catch (error) {
    console.error("Error fetching course for learning:", error);
    res.status(500).json({ error: "Error fetching course content" });
  }
});

export default router;

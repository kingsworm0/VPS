import express from "express";
import { authenticateToken } from "../middleware/authMiddleware";
import { query } from "../database";
import { v4 as uuidv4 } from "uuid";

const router = express.Router();

// Save a note
router.post("/", authenticateToken, async (req: any, res) => {
    try {
        const userId = req.user.userId;
        const { lessonId, content, timestamp } = req.body;

        if (!lessonId || !content) {
            return res.status(400).json({ error: "lessonId and content are required" });
        }

        const noteId = uuidv4();
        await query(
            "INSERT INTO notes (id, userId, lessonId, content, timestamp) VALUES (?, ?, ?, ?, ?)",
            [noteId, userId, lessonId, content, timestamp || null]
        );

        res.json({ id: noteId, success: true });
    } catch (error) {
        console.error("Error saving note:", error);
        res.status(500).json({ error: "Error saving note" });
    }
});

export default router;

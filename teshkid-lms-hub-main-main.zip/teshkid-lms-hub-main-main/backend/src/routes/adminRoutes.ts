import express, { Response, RequestHandler } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import os from "os";
import { v4 as uuidv4 } from "uuid";
import bcrypt from "bcryptjs";
import { query } from "../database";
import { config } from "../config";

const ERROR_LOG = config.ERROR_LOG;
const logError = (msg: string, err: any) => {
  const data = `[${new Date().toISOString()}] ${msg}\n${err instanceof Error ? err.stack : JSON.stringify(err)}\n\n`;
  try {
    const logDir = path.dirname(ERROR_LOG);
    if (!fs.existsSync(logDir)) {
      fs.mkdirSync(logDir, { recursive: true });
    }
    fs.appendFileSync(ERROR_LOG, data);
  } catch (e) {
    console.error("Failed to write to log file", e);
  }
};
import {
  authenticateToken,
  requireAdmin,
  AuthenticatedRequest,
} from "../middleware/authMiddleware";

const router = express.Router();

// Configure multer to preserve file extensions for uploaded files
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = config.UPLOAD_DIR;
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${uuidv4()}${ext}`);
  },
});
const upload = multer({ storage });

// Protect all admin routes
router.use(authenticateToken);
router.use(requireAdmin);

// Get Dashboard Stats
router.get("/stats", async (req, res) => {
  try {
    const totalUsersResult: any = await query(
      "SELECT COUNT(*) as count FROM users WHERE role = 'STUDENT'",
    );
    const totalUsers = totalUsersResult[0]?.count || 0;

    const totalCoursesResult: any = await query(
      "SELECT COUNT(*) as count FROM courses",
    );
    const totalCourses = totalCoursesResult[0]?.count || 0;

    const totalEnrollmentsResult: any = await query(
      "SELECT COUNT(*) as count FROM enrollments WHERE status = 'APPROVED'",
    );
    const totalEnrollments = totalEnrollmentsResult[0]?.count || 0;

    const pendingEnrollmentsResult: any = await query(
      "SELECT COUNT(*) as count FROM enrollments WHERE status = 'PENDING'",
    );
    const pendingEnrollments = pendingEnrollmentsResult[0]?.count || 0;

    // Revenue calculation
    const enrollmentsWithPrices: any = await query(
      `SELECT c.price FROM enrollments e 
       JOIN courses c ON e.courseId = c.id
       WHERE e.status = 'APPROVED'`,
    );
    const totalRevenue = enrollmentsWithPrices.reduce(
      (acc: number, curr: any) => acc + (curr.price || 0),
      0,
    );

    // Recent activity
    const recentActivity: any = await query(
      `SELECT e.*, u.name as userName, u.email as userEmail, u.profilePicture as userProfilePicture, c.title as courseTitle
       FROM enrollments e
       JOIN users u ON e.userId = u.id
       JOIN courses c ON e.courseId = c.id
       ORDER BY e.createdAt DESC LIMIT 5`,
    );

    const formattedRecentActivity = recentActivity.map((e: any) => ({
      id: e.id,
      userId: e.userId,
      createdAt: e.createdAt,
      user: {
        name: e.userName,
        email: e.userEmail,
        profilePicture: e.userProfilePicture
      },
      course: {
        title: e.courseTitle
      }
    }));

    res.json({
      totalUsers,
      totalCourses,
      totalEnrollments,
      pendingEnrollments,
      totalRevenue,
      recentActivity: formattedRecentActivity,
    });
  } catch (error) {
    res.status(500).json({ error: "Error fetching admin stats" });
  }
});

// System Metrics (admin-only)
router.get("/system/metrics", async (req, res) => {
  try {
    // Basic OS-level metrics
    const cpus = os.cpus();
    const cpuInfo = {
      count: cpus.length,
      model: cpus[0]?.model || null,
      speedMHz: cpus[0]?.speed || null,
      perCpu: cpus.map((c) => ({ model: c.model, speed: c.speed })),
    };

    const loadavg = os.loadavg();
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const memUsagePercent = totalMem > 0 ? Math.round((usedMem / totalMem) * 10000) / 100 : 0;
    const uptime = os.uptime();

    // Helper: compute directory size and file count
    const getDirStats = async (dirPath: string) => {
      let total = 0;
      let count = 0;
      const walk = async (p: string) => {
        try {
          const entries = await fs.promises.readdir(p, { withFileTypes: true });
          for (const e of entries) {
            const full = path.join(p, e.name);
            if (e.isDirectory()) {
              await walk(full);
            } else if (e.isFile()) {
              try {
                const st = await fs.promises.stat(full);
                total += st.size;
                count++;
              } catch (err) {
                /* ignore individual file errors */
              }
            }
          }
        } catch (err) {
          // Directory may not exist or permission denied
        }
      };
      await walk(dirPath);
      return { path: dirPath, sizeBytes: total, fileCount: count };
    };

    const uploadStats = await getDirStats(config.UPLOAD_DIR).catch(() => ({ path: config.UPLOAD_DIR, sizeBytes: 0, fileCount: 0 }));
    const logStats = await getDirStats(path.resolve(__dirname, "../logs")).catch(() => ({ path: path.resolve(__dirname, "../logs"), sizeBytes: 0, fileCount: 0 }));
    const projectStats = await getDirStats(process.cwd()).catch(() => ({ path: process.cwd(), sizeBytes: 0, fileCount: 0 }));

    res.json({
      cpu: cpuInfo,
      loadavg,
      memory: { total: totalMem, free: freeMem, used: usedMem, usedPercent: memUsagePercent },
      uptime,
      nodeVersion: process.version,
      platform: process.platform,
      directories: {
        uploads: uploadStats,
        logs: logStats,
        project: projectStats,
      },
    });
  } catch (error) {
    console.error("Error fetching system metrics:", error);
    res.status(500).json({ error: "Error fetching system metrics" });
  }
});

// Force-change administrator password (admin-only)
router.put("/administrator/:id/change-password", async (req, res) => {
  try {
    const { id } = req.params;
    const { newPassword } = req.body;

    if (!newPassword || typeof newPassword !== "string") {
      return res.status(400).json({ error: "newPassword is required" });
    }

    if (newPassword.length < (config.SECURITY?.MIN_PASSWORD_LENGTH || 8)) {
      return res.status(400).json({ error: `Password must be at least ${(config.SECURITY?.MIN_PASSWORD_LENGTH || 8)} characters` });
    }

    const hashed = await bcrypt.hash(newPassword, 12);
    await query("UPDATE users SET password = ?, updatedAt = NOW() WHERE id = ?", [hashed, id]);

    res.json({ success: true, message: "Password updated successfully" });
  } catch (error) {
    console.error("Error changing administrator password:", error);
    res.status(500).json({ error: "Error changing administrator password" });
  }
});

// List Users
router.get("/users", async (req, res) => {
  try {
    const users: any = await query(
      `SELECT u.id, u.name, u.email, u.role, u.isBlocked, u.isPremium, u.profilePicture, u.bio, u.createdAt, 
              COUNT(DISTINCT e.id) as enrollmentsCount,
              ROUND(COALESCE(AVG(e.progress), 0)) as averageProgress
       FROM users u
       LEFT JOIN enrollments e ON u.id = e.userId
       GROUP BY u.id
       ORDER BY u.createdAt DESC`,
    );

    res.json(users);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching users" });
  }
});

// Get single user details
router.get("/users/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const userResults: any = await query(
      "SELECT id, name, email, role, isBlocked, isPremium, profilePicture, bio, createdAt FROM users WHERE id = ?",
      [id],
    );

    if (!userResults || userResults.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    const user = userResults[0];
    const enrollments: any = await query(
      `SELECT e.*, c.title as courseTitle FROM enrollments e 
       JOIN courses c ON e.courseId = c.id WHERE e.userId = ?`,
      [id],
    );

    res.json({ ...user, enrollments });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching user" });
  }
});

// Update user (e.g., role)
router.put("/users/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { role, isPremium } = req.body;

    const updates = [];
    const params = [];

    if (role) {
      updates.push("role = ?");
      params.push(role);
    }
    if (isPremium !== undefined) {
      updates.push("isPremium = ?");
      params.push(isPremium ? 1 : 0);
    }

    if (updates.length > 0) {
      params.push(id);
      await query(`UPDATE users SET ${updates.join(", ")} WHERE id = ?`, params);
    }

    const updated: any = await query(
      "SELECT id, name, email, role, isPremium FROM users WHERE id = ?",
      [id],
    );
    res.json(updated[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error updating user" });
  }
});

// Delete user
router.delete("/users/:id", async (req, res) => {
  try {
    const { id } = req.params;
    await query("DELETE FROM users WHERE id = ?", [id]);
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error deleting user" });
  }
});

// Block / Unblock user
router.put("/users/:id/block", async (req, res) => {
  try {
    const { id } = req.params;
    const { blocked } = req.body;

    await query("UPDATE users SET isBlocked = ? WHERE id = ?", [
      blocked ? 1 : 0,
      id,
    ]);

    const updated: any = await query(
      "SELECT id, isBlocked FROM users WHERE id = ?",
      [id],
    );
    res.json(updated[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error updating user block status" });
  }
});

// Change user password
router.put("/users/:id/change-password", async (req, res) => {
  try {
    const { id } = req.params;
    const { password } = req.body;

    if (!password || password.length < 6) {
      return res
        .status(400)
        .json({ error: "Password must be at least 6 characters" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    await query("UPDATE users SET password = ? WHERE id = ?", [
      hashedPassword,
      id,
    ]);

    res.json({
      success: true,
      message: "Password changed successfully",
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error changing password" });
  }
});

// List Pending Enrollments
router.get("/enrollments/pending", async (req, res) => {
  try {
    const enrollments: any = await query(
      `SELECT e.*, 
              u.name as userName, u.email as userEmail, u.profilePicture as userProfilePicture, u.bio as userBio,
              c.title as courseTitle 
       FROM enrollments e 
       JOIN users u ON e.userId = u.id 
       JOIN courses c ON e.courseId = c.id 
       WHERE e.status = 'PENDING'
       ORDER BY e.createdAt DESC`,
    );

    const formatted = enrollments.map((e: any) => ({
      ...e,
      user: {
        name: e.userName,
        email: e.userEmail,
        profilePicture: e.userProfilePicture,
        bio: e.userBio
      },
      course: { title: e.courseTitle },
      studentMessage: e.studentMessage
    }));

    res.json(formatted);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching pending enrollments" });
  }
});

// Approve/Reject Enrollment
router.put("/enrollments/:id/status", async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!['APPROVED', 'REJECTED'].includes(status)) {
      return res.status(400).json({ message: "Invalid status" });
    }

    await query("UPDATE enrollments SET status = ?, enrolledAt = ? WHERE id = ?", [
      status,
      status === 'APPROVED' ? new Date() : null,
      id,
    ]);

    res.json({ success: true, status });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error updating enrollment status" });
  }
});

// Update enrollment progress
router.put("/enrollments/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { progress } = req.body;

    await query("UPDATE enrollments SET progress = ? WHERE id = ?", [
      progress,
      id,
    ]);

    res.json({ success: true, progress });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error updating enrollment" });
  }
});

// Course Content endpoints
router.get("/content", async (req, res) => {
  try {
    const contents: any = await query(
      `SELECT cc.*, c.title as courseTitle FROM course_contents cc
       LEFT JOIN courses c ON cc.courseId = c.id
       ORDER BY cc.createdAt DESC`,
    );
    res.json(contents);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching content" });
  }
});

router.post("/content", (async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { courseId, title, description, fileUrl, fileType, isPremiumOnly } = req.body;
    const id = uuidv4();

    await query(
      `INSERT INTO course_contents (id, courseId, title, description, fileUrl, fileType, uploadedBy, isPremiumOnly)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        courseId || null,
        title,
        description,
        fileUrl,
        fileType,
        req.user.userId,
        isPremiumOnly ? 1 : 0,
      ],
    );

    const created: any = await query(
      "SELECT * FROM course_contents WHERE id = ?",
      [id],
    );
    res.json(created[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error creating content" });
  }
}) as unknown as RequestHandler);

// Upload endpoint (multipart/form-data: field 'file')
router.post("/content/upload", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: "No file uploaded" });
    const filePath = `/uploads/${req.file.filename}`;
    res.json({ fileUrl: filePath });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error uploading file" });
  }
});

router.delete("/content/:id", async (req, res) => {
  try {
    const { id } = req.params;
    await query("DELETE FROM course_contents WHERE id = ?", [id]);
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error deleting content" });
  }
});

// Admin announcements
router.post("/announcements", async (req, res) => {
  try {
    const { title, content, type } = req.body;
    const id = uuidv4();

    await query(
      `INSERT INTO announcements (id, title, content, type) VALUES (?, ?, ?, ?)`,
      [id, title, content, type || "info"],
    );

    const created: any = await query(
      "SELECT * FROM announcements WHERE id = ?",
      [id],
    );
    res.json(created[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error creating announcement" });
  }
});

router.delete("/announcements/:id", async (req, res) => {
  try {
    const { id } = req.params;
    await query("DELETE FROM announcements WHERE id = ?", [id]);
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error deleting announcement" });
  }
});

// Courses CRUD
router.get("/courses", async (req, res) => {
  try {
    const courses: any = await query(
      `SELECT c.*, 
              (SELECT COUNT(*) FROM modules WHERE courseId = c.id) as modulesCount,
              (SELECT COUNT(*) FROM enrollments WHERE courseId = c.id) as students
       FROM courses c
       ORDER BY c.createdAt DESC`,
    );

    res.json(courses);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching courses" });
  }
});

router.post("/courses", async (req, res) => {
  try {
    const {
      title,
      description,
      instructor,
      thumbnail,
      level,
      duration,
      price,
      cryptoPrice,
      bannerUrl,
      previewVideoUrl,
      modules,
    } = req.body;

    const courseId = uuidv4();

    // Sanitize values
    const insertValues = [
      courseId,
      title || "",
      description || null,
      instructor || "Teshkid Admin",
      thumbnail || null,
      level || "Beginner",
      duration || null,
      Number(price) || 0,
      cryptoPrice || null,
      bannerUrl || null,
      previewVideoUrl || null,
    ];

    await query(
      `INSERT INTO courses (id, title, description, instructor, thumbnail, level, duration, price, cryptoPrice, bannerUrl, previewVideoUrl)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      insertValues,
    );

    // Create modules if provided
    if (modules && Array.isArray(modules)) {
      for (let i = 0; i < modules.length; i++) {
        const moduleId = uuidv4();
        const m = modules[i];

        await query(
          `INSERT INTO modules (id, courseId, title, description, sortOrder)
           VALUES (?, ?, ?, ?, ?)`,
          [moduleId, courseId, m.title || "Untitled Module", m.description || null, m.order || i + 1],
        );

        // Create lessons if provided
        if (m.lessons && Array.isArray(m.lessons)) {
          for (let j = 0; j < m.lessons.length; j++) {
            const lessonId = uuidv4();
            const l = m.lessons[j];

            await query(
              `INSERT INTO lessons (id, moduleId, title, duration, type, content, videoUrl, description, sortOrder)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
              [
                lessonId,
                moduleId,
                l.title || "Untitled Lesson",
                l.duration || null,
                l.type || "video",
                l.content || null,
                l.videoUrl || null,
                l.description || null,
                l.order || j + 1,
              ],
            );
          }
        }
      }
    }

    const created: any = await query(
      `SELECT c.*, 
              (SELECT COUNT(*) FROM modules WHERE courseId = c.id) as modulesCount
       FROM courses c WHERE c.id = ?`,
      [courseId],
    );

    if (!created || created.length === 0) {
      logError("POST /courses: Course created but could not be retrieved", { courseId });
      return res.json({ id: courseId, title, success: true });
    }

    res.json(created[0]);
  } catch (error: any) {
    logError("CRITICAL ERROR in POST /courses", error);
    res.status(500).json({
      error: "Error creating course",
      message: "An internal error occurred while saving the course."
    });
  }
});

router.get("/courses/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const courseResults: any = await query(
      "SELECT * FROM courses WHERE id = ?",
      [id],
    );

    if (!courseResults || courseResults.length === 0) {
      return res.status(404).json({ message: "Course not found" });
    }

    const course = courseResults[0];
    const modules: any = await query(
      "SELECT * FROM modules WHERE courseId = ? ORDER BY sortOrder ASC",
      [id],
    );

    const modulesWithLessons = await Promise.all(
      modules.map(async (module: any) => {
        const lessons: any = await query(
          "SELECT * FROM lessons WHERE moduleId = ? ORDER BY sortOrder ASC",
          [module.id],
        );
        return { ...module, lessons };
      }),
    );

    res.json({ ...course, modules: modulesWithLessons });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error fetching course" });
  }
});

router.put("/courses/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const {
      title,
      description,
      instructor,
      thumbnail,
      level,
      duration,
      price,
      cryptoPrice,
      bannerUrl,
      previewVideoUrl,
    } = req.body;

    await query(
      `UPDATE courses SET title = ?, description = ?, instructor = ?, thumbnail = ?, level = ?, duration = ?, price = ?, cryptoPrice = ?, bannerUrl = ?, previewVideoUrl = ?
       WHERE id = ?`,
      [
        title || "",
        description || null,
        instructor || null,
        thumbnail || null,
        level || null,
        duration || null,
        Number(price) || 0,
        cryptoPrice || null,
        bannerUrl || null,
        previewVideoUrl || null,
        id,
      ],
    );

    const updated: any = await query("SELECT * FROM courses WHERE id = ?", [
      id,
    ]);
    res.json(updated[0]);
  } catch (error: any) {
    logError("CRITICAL ERROR in PUT /courses", error);
    res.status(500).json({
      error: "Error updating course",
      message: "An internal error occurred while updating the course."
    });
  }
});

router.delete("/courses/:id", async (req, res) => {
  try {
    const { id } = req.params;
    await query("DELETE FROM courses WHERE id = ?", [id]);
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error deleting course" });
  }
});

// Modules
router.post("/courses/:courseId/modules", async (req, res) => {
  try {
    const { courseId } = req.params;
    const { title, description, order } = req.body;
    const moduleId = uuidv4();

    await query(
      `INSERT INTO modules (id, courseId, title, description, sortOrder) VALUES (?, ?, ?, ?, ?)`,
      [moduleId, courseId, title, description, Number(order) || 0],
    );

    const created: any = await query("SELECT * FROM modules WHERE id = ?", [
      moduleId,
    ]);
    res.json(created[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error creating module" });
  }
});

router.put("/modules/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, order } = req.body;

    await query(
      `UPDATE modules SET title = ?, description = ?, sortOrder = ? WHERE id = ?`,
      [title, description, Number(order), id],
    );

    const updated: any = await query("SELECT * FROM modules WHERE id = ?", [
      id,
    ]);
    res.json(updated[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error updating module" });
  }
});

router.delete("/modules/:id", async (req, res) => {
  try {
    const { id } = req.params;
    await query("DELETE FROM modules WHERE id = ?", [id]);
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error deleting module" });
  }
});

// Lessons
router.post("/modules/:moduleId/lessons", async (req, res) => {
  try {
    const { moduleId } = req.params;
    const { title, duration, type, content, videoUrl, description, order } = req.body;
    const lessonId = uuidv4();

    await query(
      `INSERT INTO lessons (id, moduleId, title, duration, type, content, videoUrl, description, sortOrder) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [lessonId, moduleId, title, duration, type, content, videoUrl, description, Number(order) || 0],
    );

    const created: any = await query("SELECT * FROM lessons WHERE id = ?", [
      lessonId,
    ]);
    res.json(created[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error creating lesson" });
  }
});

router.put("/lessons/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { title, duration, type, content, videoUrl, description, order } = req.body;

    await query(
      `UPDATE lessons SET title = ?, duration = ?, type = ?, content = ?, videoUrl = ?, description = ?, sortOrder = ? WHERE id = ?`,
      [title, duration, type, content, videoUrl, description, Number(order), id],
    );

    const updated: any = await query("SELECT * FROM lessons WHERE id = ?", [
      id,
    ]);
    res.json(updated[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error updating lesson" });
  }
});

router.delete("/lessons/:id", async (req, res) => {
  try {
    const { id } = req.params;
    await query("DELETE FROM lessons WHERE id = ?", [id]);
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error deleting lesson" });
  }
});

// ── System Control Panel & Optimization Endpoints ──

// GET System Health, DB Stats, Environment, & Security Logs
router.get("/system-status", async (req, res) => {
  try {
    const start = performance.now();
    
    // DB Table metrics
    const userCount: any = await query("SELECT COUNT(*) as c FROM users");
    const courseCount: any = await query("SELECT COUNT(*) as c FROM courses");
    const enrollmentCount: any = await query("SELECT COUNT(*) as c FROM enrollments");
    const progressCount: any = await query("SELECT COUNT(*) as c FROM lesson_progress");
    const sessionCount: any = await query("SELECT COUNT(*) as c FROM live_sessions");
    const certCount: any = await query("SELECT COUNT(*) as c FROM certificates");
    const blockedUserCount: any = await query("SELECT COUNT(*) as c FROM users WHERE isBlocked = TRUE");

    const latencyMs = Math.round(performance.now() - start);

    // Fetch recent user activity / attempt logs
    const recentAttempts: any = await query(
      `SELECT id, name, email, profilePicture, role, isBlocked, lastLoginDate, createdAt
       FROM users 
       ORDER BY updatedAt DESC 
       LIMIT 50`
    );

    res.json({
      status: "HEALTHY",
      uptimeSeconds: Math.floor(process.uptime()),
      dbLatencyMs: latencyMs,
      nodeVersion: process.version,
      env: config.NODE_ENV,
      metrics: {
        users: userCount[0]?.c || 0,
        courses: courseCount[0]?.c || 0,
        enrollments: enrollmentCount[0]?.c || 0,
        lessonProgress: progressCount[0]?.c || 0,
        liveSessions: sessionCount[0]?.c || 0,
        certificates: certCount[0]?.c || 0,
        blockedUsers: blockedUserCount[0]?.c || 0,
      },
      recentAttempts: recentAttempts,
    });
  } catch (error: any) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch system status" });
  }
});

// POST System Optimization
router.post("/system-optimize", async (req, res) => {
  try {
    const start = performance.now();
    
    // Execute table optimizations
    await query("OPTIMIZE TABLE users, courses, modules, lessons, enrollments, lesson_progress, live_sessions");
    
    const timeTakenMs = Math.round(performance.now() - start);
    res.json({
      message: "System and database tables optimized successfully!",
      timeTakenMs,
      optimizedAt: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error(error);
    res.status(500).json({ error: "Failed to optimize system database" });
  }
});

export default router;


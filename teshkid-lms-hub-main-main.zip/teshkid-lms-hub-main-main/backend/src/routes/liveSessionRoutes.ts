import express from "express";
import { v4 as uuidv4 } from "uuid";
import { query } from "../database";
import { authenticateToken } from "../middleware/authMiddleware";

const router = express.Router();

// ─── helpers ─────────────────────────────────────────────────────────────────
function isAdmin(req: any) { return req.user?.role === "ADMIN"; }

// ─── Student: GET all live sessions (with RSVP status + counts) ──────────────
router.get("/live-sessions", authenticateToken, async (req: any, res) => {
  try {
    const userId = req.user.userId;
    const sessions: any = await query(
      `SELECT
         ls.*,
         c.title                                    AS courseName,
         COUNT(DISTINCT r.id)                       AS rsvpCount,
         MAX(CASE WHEN r.userId = ? THEN 1 ELSE 0 END) AS hasRsvp
       FROM live_sessions ls
       LEFT JOIN courses c               ON ls.courseId  = c.id
       LEFT JOIN live_session_rsvps r    ON ls.id        = r.sessionId
       GROUP BY ls.id
       ORDER BY
         CASE ls.status WHEN 'LIVE' THEN 0 WHEN 'UPCOMING' THEN 1 ELSE 2 END,
         ls.scheduledAt ASC`,
      [userId]
    );
    res.json(sessions);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch live sessions" });
  }
});

// ─── Student: RSVP toggle ─────────────────────────────────────────────────────
router.post("/live-sessions/:id/rsvp", authenticateToken, async (req: any, res) => {
  try {
    const { id } = req.params;
    const userId  = req.user.userId;

    const existing: any = await query(
      "SELECT id FROM live_session_rsvps WHERE sessionId = ? AND userId = ?",
      [id, userId]
    );

    if (existing && existing.length > 0) {
      // Cancel RSVP
      await query("DELETE FROM live_session_rsvps WHERE sessionId = ? AND userId = ?", [id, userId]);
      return res.json({ rsvped: false, message: "RSVP cancelled" });
    }

    // Add RSVP
    await query(
      "INSERT INTO live_session_rsvps (id, sessionId, userId) VALUES (?, ?, ?)",
      [uuidv4(), id, userId]
    );
    res.json({ rsvped: true, message: "RSVP confirmed" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to update RSVP" });
  }
});

// ─── Leaderboard (shares this router file) ────────────────────────────────────
router.get("/leaderboard", authenticateToken, async (req: any, res) => {
  try {
    const rows: any = await query(
      `SELECT u.id AS userId, u.name, u.profilePicture, u.xp, u.streak,
              FLOOR(u.xp / 500) + 1 AS level,
              COUNT(DISTINCT lp.lessonId) AS lessonsCompleted
       FROM users u
       LEFT JOIN lesson_progress lp ON u.id = lp.userId
       WHERE u.role = 'STUDENT'
       GROUP BY u.id
       ORDER BY u.xp DESC
       LIMIT 20`,
      []
    );
    res.json(rows.map((r: any, i: number) => ({ ...r, rank: i + 1, profilePicture: r.profilePicture || null })));
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch leaderboard" });
  }
});

// ─── Admin: GET all (with RSVP count) ────────────────────────────────────────
router.get("/admin/live-sessions", authenticateToken, async (req: any, res) => {
  if (!isAdmin(req)) return res.status(403).json({ message: "Forbidden" });
  try {
    const sessions: any = await query(
      `SELECT ls.*, c.title AS courseName, COUNT(DISTINCT r.id) AS rsvpCount
       FROM live_sessions ls
       LEFT JOIN courses c            ON ls.courseId = c.id
       LEFT JOIN live_session_rsvps r ON ls.id       = r.sessionId
       GROUP BY ls.id
       ORDER BY CASE ls.status WHEN 'LIVE' THEN 0 WHEN 'UPCOMING' THEN 1 ELSE 2 END,
                ls.scheduledAt ASC`,
      []
    );
    res.json(sessions);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch sessions" });
  }
});

// ─── Admin: GET single session with RSVP attendee list ───────────────────────
router.get("/admin/live-sessions/:id", authenticateToken, async (req: any, res) => {
  if (!isAdmin(req)) return res.status(403).json({ message: "Forbidden" });
  try {
    const rows: any = await query(
      `SELECT ls.*, c.title AS courseName FROM live_sessions ls
       LEFT JOIN courses c ON ls.courseId = c.id WHERE ls.id = ?`,
      [req.params.id]
    );
    if (!rows?.length) return res.status(404).json({ message: "Not found" });

    const attendees: any = await query(
      `SELECT u.id, u.name, u.email, u.profilePicture, r.createdAt AS rsvpAt
       FROM live_session_rsvps r
       JOIN users u ON r.userId = u.id
       WHERE r.sessionId = ?
       ORDER BY r.createdAt ASC`,
      [req.params.id]
    );
    res.json({ ...rows[0], attendees });
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch session" });
  }
});

// ─── Admin: CREATE ────────────────────────────────────────────────────────────
router.post("/admin/live-sessions", authenticateToken, async (req: any, res) => {
  if (!isAdmin(req)) return res.status(403).json({ message: "Forbidden" });
  const {
    title, description, hostName, meetingLink, streamUrl,
    recordingUrl, scheduledAt, durationMinutes, status,
    courseId, bannerUrl, maxAttendees,
  } = req.body;

  if (!title || !scheduledAt) return res.status(400).json({ message: "title and scheduledAt are required" });

  try {
    const id = uuidv4();
    await query(
      `INSERT INTO live_sessions
         (id, title, description, hostName, meetingLink, streamUrl, recordingUrl,
          scheduledAt, durationMinutes, status, courseId, bannerUrl, maxAttendees, createdBy)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id, title, description || null, hostName || null,
        meetingLink || null, streamUrl || null, recordingUrl || null,
        scheduledAt, durationMinutes || 60, status || "UPCOMING",
        courseId || null, bannerUrl || null, maxAttendees || null,
        req.user.userId,
      ]
    );
    res.status(201).json({ id, message: "Session created" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to create session" });
  }
});

// ─── Admin: UPDATE ────────────────────────────────────────────────────────────
router.put("/admin/live-sessions/:id", authenticateToken, async (req: any, res) => {
  if (!isAdmin(req)) return res.status(403).json({ message: "Forbidden" });
  const { id } = req.params;
  const allowed = [
    "title","description","hostName","meetingLink","streamUrl","recordingUrl",
    "scheduledAt","durationMinutes","status","courseId","bannerUrl","maxAttendees",
  ];
  const updates: string[] = [];
  const params: any[]     = [];

  for (const key of allowed) {
    if (req.body[key] !== undefined) {
      updates.push(`${key} = ?`);
      params.push(req.body[key]);
    }
  }
  if (!updates.length) return res.status(400).json({ message: "Nothing to update" });

  params.push(id);
  try {
    await query(`UPDATE live_sessions SET ${updates.join(", ")} WHERE id = ?`, params);
    res.json({ message: "Session updated" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to update session" });
  }
});

// ─── Admin: DELETE ────────────────────────────────────────────────────────────
router.delete("/admin/live-sessions/:id", authenticateToken, async (req: any, res) => {
  if (!isAdmin(req)) return res.status(403).json({ message: "Forbidden" });
  try {
    await query("DELETE FROM live_sessions WHERE id = ?", [req.params.id]);
    res.json({ message: "Session deleted" });
  } catch (err) {
    res.status(500).json({ message: "Failed to delete session" });
  }
});

export default router;

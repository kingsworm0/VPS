import express from "express";
import { v4 as uuidv4 } from "uuid";
import { query } from "../database";
import {
  authenticateToken,
  optionalAuth,
  requireAdmin,
  AuthRequest,
} from "../middleware/authMiddleware";

const router = express.Router();

// Helper to generate slug from title
const generateSlug = (title: string): string => {
  return title
    .toLowerCase()
    .replace(/[^\w\s-]/g, "")
    .replace(/[\s_]+/g, "-")
    .replace(/^-+|-+$/g, "");
};

// Public: Get all published blogs
router.get("/", optionalAuth, async (req: AuthRequest, res) => {
  try {
    // Build SQL and params safely to avoid interpolation bugs
    const params: any[] = [];
    let userLikeSelect = "0 as userLiked, 0 as userDisliked";
    if (req.user) {
      userLikeSelect = `(SELECT COUNT(*) FROM blog_likes WHERE blogId = b.id AND userId = ?) as userLiked, (SELECT COUNT(*) FROM blog_dislikes WHERE blogId = b.id AND userId = ?) as userDisliked`;
      params.push(req.user.userId, req.user.userId);
    }

    const sql = `SELECT b.*,
                u.name as authorName, u.profilePicture as authorProfilePicture,
                (SELECT COUNT(*) FROM blog_likes WHERE blogId = b.id) as likeCount,
                (SELECT COUNT(*) FROM blog_dislikes WHERE blogId = b.id) as dislikeCount,
                ${userLikeSelect}
         FROM blogs b 
         LEFT JOIN users u ON b.authorId = u.id
         WHERE b.status = 'published' AND b.deletedAt IS NULL 
         ORDER BY b.createdAt DESC`;

    const blogs: any = await query(sql, params);

    // Format results
    const formattedBlogs = Array.isArray(blogs) ? blogs.map((blog: any) => ({
      ...blog,
      content: blog.content || "",
      description: blog.description || "",
      category: blog.category || "uncategorized",
      likeCount: blog.likeCount || 0,
      dislikeCount: blog.dislikeCount || 0,
      userLiked: !!blog.userLiked,
      userDisliked: !!blog.userDisliked
    })) : [];

    res.json(formattedBlogs);
  } catch (err: any) {
    console.error('Fetch blogs error:', err);
    res.status(500).json({ error: "Failed to fetch blogs" });
  }
});

// Public: Get trending blogs
router.get("/trending", optionalAuth, async (req: AuthRequest, res) => {
  try {
    const limit = parseInt(req.query.limit as string) || 5;
    const params: any[] = [];
    let userLikeSelect = "0 as userLiked, 0 as userDisliked";
    if (req.user) {
      userLikeSelect = `(SELECT COUNT(*) FROM blog_likes WHERE blogId = b.id AND userId = ?) as userLiked, (SELECT COUNT(*) FROM blog_dislikes WHERE blogId = b.id AND userId = ?) as userDisliked`;
      params.push(req.user.userId, req.user.userId);
    }

    // push limit as last param
    params.push(limit);

    const sql = `SELECT b.*,
                u.name as authorName, u.profilePicture as authorProfilePicture,
                (SELECT COUNT(*) FROM blog_likes WHERE blogId = b.id) as likeCount,
                (SELECT COUNT(*) FROM blog_dislikes WHERE blogId = b.id) as dislikeCount,
                ${userLikeSelect}
         FROM blogs b 
         LEFT JOIN users u ON b.authorId = u.id
         WHERE b.status = 'published' AND b.deletedAt IS NULL 
         ORDER BY b.viewCount DESC, b.createdAt DESC 
         LIMIT ?`;

    const blogs: any = await query(sql, params);

    const formattedBlogs = Array.isArray(blogs) ? blogs.map((blog: any) => ({
      ...blog,
      content: blog.content || "",
      description: blog.description || "",
      category: blog.category || "uncategorized",
      likeCount: blog.likeCount || 0,
      dislikeCount: blog.dislikeCount || 0,
      userLiked: !!blog.userLiked,
      userDisliked: !!blog.userDisliked
    })) : [];

    res.json(formattedBlogs);
  } catch (err: any) {
    console.error('Fetch trending blogs error:', err);
    res.status(500).json([]);
  }
});

// Public: Get blogs by category
router.get("/category/:category", optionalAuth, async (req: AuthRequest, res) => {
  try {
    const params: any[] = [req.params.category];
    let userLikeSelect = "0 as userLiked, 0 as userDisliked";
    if (req.user) {
      userLikeSelect = `(SELECT COUNT(*) FROM blog_likes WHERE blogId = b.id AND userId = ?) as userLiked, (SELECT COUNT(*) FROM blog_dislikes WHERE blogId = b.id AND userId = ?) as userDisliked`;
      // put user checks before category param
      params.unshift(req.user.userId, req.user.userId);
    }

    const sql = `SELECT b.*,
                u.name as authorName, u.profilePicture as authorProfilePicture,
                (SELECT COUNT(*) FROM blog_likes WHERE blogId = b.id) as likeCount,
                (SELECT COUNT(*) FROM blog_dislikes WHERE blogId = b.id) as dislikeCount,
                ${userLikeSelect}
         FROM blogs b 
         LEFT JOIN users u ON b.authorId = u.id
         WHERE b.category = ? AND b.status = 'published' AND b.deletedAt IS NULL 
         ORDER BY b.createdAt DESC`;

    const blogs: any = await query(sql, params);

    const formattedBlogs = Array.isArray(blogs) ? blogs.map((blog: any) => ({
      ...blog,
      content: blog.content || "",
      description: blog.description || "",
      category: blog.category || "uncategorized",
      likeCount: blog.likeCount || 0,
      dislikeCount: blog.dislikeCount || 0,
      userLiked: !!blog.userLiked,
      userDisliked: !!blog.userDisliked
    })) : [];

    res.json(formattedBlogs);
  } catch (err: any) {
    console.error('Fetch blogs by category error:', err);
    res.status(500).json({ error: "Failed to fetch blogs by category" });
  }
});

// Admin: Get all blogs (including drafts) - MUST BE BEFORE /:slug
router.get("/admin/all", authenticateToken, requireAdmin, async (req, res) => {
  try {
    const blogs = await query(
      `SELECT b.*,
              (SELECT COUNT(*) FROM blog_likes WHERE blogId = b.id) as likeCount,
              (SELECT COUNT(*) FROM blog_dislikes WHERE blogId = b.id) as dislikeCount
       FROM blogs b 
       WHERE b.deletedAt IS NULL 
       ORDER BY b.createdAt DESC`
    );
    res.json(Array.isArray(blogs) ? blogs : []);
  } catch (err) {
    console.error("Admin fetch blogs error:", err);
    res.status(500).json({ error: "Failed to fetch blogs" });
  }
});

// Public: Get single blog by slug (increments view count)
router.get("/:slug", optionalAuth, async (req: AuthRequest, res) => {
  try {
    const params: any[] = [req.params.slug];
    let userLikeSelect = "0 as userLiked, 0 as userDisliked";
    if (req.user) {
      userLikeSelect = `(SELECT COUNT(*) FROM blog_likes WHERE blogId = b.id AND userId = ?) as userLiked, (SELECT COUNT(*) FROM blog_dislikes WHERE blogId = b.id AND userId = ?) as userDisliked`;
      // ensure user params come before slug
      params.unshift(req.user.userId, req.user.userId);
    }

    const sql = `SELECT b.*,
                u.name as authorName, u.profilePicture as authorProfilePicture,
                (SELECT COUNT(*) FROM blog_likes WHERE blogId = b.id) as likeCount,
                (SELECT COUNT(*) FROM blog_dislikes WHERE blogId = b.id) as dislikeCount,
                ${userLikeSelect}
         FROM blogs b 
         LEFT JOIN users u ON b.authorId = u.id
         WHERE b.slug = ? AND b.status = 'published' AND b.deletedAt IS NULL`;

    const blogs: any = await query(sql, params);

    const blog = blogs && blogs.length > 0 ? blogs[0] : null;
    if (!blog) return res.status(404).json({ error: "Blog not found" });

    // Increment view count
    await query("UPDATE blogs SET viewCount = viewCount + 1 WHERE id = ?", [
      blog.id,
    ]);

    // Return blog with like/dislike counts
    res.json({
      ...blog,
      content: blog.content || "",
      description: blog.description || "",
      category: blog.category || "uncategorized",
      likeCount: blog.likeCount || 0,
      dislikeCount: blog.dislikeCount || 0,
      userLiked: !!blog.userLiked,
      userDisliked: !!blog.userDisliked
    });
  } catch (err: any) {
    console.error('Fetch single blog error:', err);
    res.status(500).json({ error: "Failed to fetch blog" });
  }
});

// Admin: Create new blog
router.post("/", authenticateToken, requireAdmin, async (req: AuthRequest, res) => {
  try {
    const { title, content, description, category, tags, featuredImage, author, reviewer, contentBlocks, status, keyTakeaways, gallery } =
      req.body;
    const id = uuidv4();
    const slug = generateSlug(title);
    const tagsJson = JSON.stringify(Array.isArray(tags) ? tags : []);
    const contentBlocksJson = JSON.stringify(Array.isArray(contentBlocks) ? contentBlocks : []);
    const keyTakeawaysJson = JSON.stringify(Array.isArray(keyTakeaways) ? keyTakeaways : []);
    const galleryJson = JSON.stringify(Array.isArray(gallery) ? gallery : []);

    // For backward compatibility, if content is provided, use it as first block
    let finalContentBlocks = contentBlocksJson;
    if (req.body.content && !contentBlocks) {
      const defaultBlocks = [{ type: "text", content: req.body.content }];
      finalContentBlocks = JSON.stringify(defaultBlocks);
    }

    await query(
      `INSERT INTO blogs (id, title, slug, content, description, category, tags, featuredImage, author, reviewer, contentBlocks, authorId, status, createdAt, keyTakeaways, gallery) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?)`,
      [
        id,
        title,
        slug,
        content || "",
        description || "",
        category || "",
        tagsJson,
        featuredImage || null,
        author || "Teshkid is Crypto",
        reviewer || "",
        finalContentBlocks,
        req.user?.userId || null,
        status ?? "published",
        keyTakeawaysJson,
        galleryJson,
      ]
    );

    res.status(201).json({ id, slug });
  } catch (err) {
    console.error("Blog creation error:", err);
    res.status(500).json({ error: "Failed to create blog" });
  }
});

// Admin: Update blog
router.put("/:id", authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { title, content, description, category, tags, featuredImage, status, keyTakeaways, gallery, author } =
      req.body;
    const slug = title ? generateSlug(title) : undefined;
    const tagsJson = tags ? JSON.stringify(Array.isArray(tags) ? tags : []) : undefined;
    const keyTakeawaysJson = keyTakeaways ? JSON.stringify(Array.isArray(keyTakeaways) ? keyTakeaways : []) : undefined;
    const galleryJson = gallery ? JSON.stringify(Array.isArray(gallery) ? gallery : []) : undefined;

    let updateQuery = "UPDATE blogs SET ";
    let updateValues: any[] = [];
    const updates: string[] = [];

    if (title) {
      updates.push("title = ?");
      updateValues.push(title);
    }
    if (slug) {
      updates.push("slug = ?");
      updateValues.push(slug);
    }
    if (content !== undefined) {
      updates.push("content = ?");
      updateValues.push(content);
    }
    if (description !== undefined) {
      updates.push("description = ?");
      updateValues.push(description);
    }
    if (category) {
      updates.push("category = ?");
      updateValues.push(category);
    }
    if (tagsJson) {
      updates.push("tags = ?");
      updateValues.push(tagsJson);
    }
    if (featuredImage) {
      updates.push("featuredImage = ?");
      updateValues.push(featuredImage);
    }
    if (status) {
      updates.push("status = ?");
      updateValues.push(status);
    }
    if (keyTakeawaysJson) {
      updates.push("keyTakeaways = ?");
      updateValues.push(keyTakeawaysJson);
    }
    if (galleryJson) {
      updates.push("gallery = ?");
      updateValues.push(galleryJson);
    }
    if (author !== undefined) {
      updates.push("author = ?");
      updateValues.push(author);
    }

    updates.push("updatedAt = NOW()");
    updateQuery += updates.join(", ") + " WHERE id = ?";
    updateValues.push(req.params.id);

    await query(updateQuery, updateValues);
    res.json({ success: true });
  } catch (err) {
    console.error("Blog update error:", err);
    res.status(500).json({ error: "Failed to update blog" });
  }
});

// Admin: Delete blog (soft delete)
router.delete("/:id", authenticateToken, requireAdmin, async (req, res) => {
  try {
    await query("UPDATE blogs SET deletedAt = NOW() WHERE id = ?", [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    console.error("Blog delete error:", err);
    res.status(500).json({ error: "Failed to delete blog" });
  }
});

// Like a blog (requires auth)
router.post("/:id/like", authenticateToken, async (req: AuthRequest, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const likeId = req.params.id || uuidv4();

    // Remove dislike if it exists (can't like and dislike at the same time)
    await query(
      "DELETE FROM blog_dislikes WHERE blogId = ? AND userId = ?",
      [req.params.id, req.user.userId]
    );

    // Insert like if it doesn't already exist
    await query(
      "INSERT IGNORE INTO blog_likes (id, blogId, userId, createdAt) VALUES (?, ?, ?, NOW())",
      [uuidv4(), req.params.id, req.user.userId]
    );

    // Get updated counts
    const likeResult: any = await query(
      "SELECT COUNT(*) as count FROM blog_likes WHERE blogId = ?",
      [req.params.id]
    );
    const dislikeResult: any = await query(
      "SELECT COUNT(*) as count FROM blog_dislikes WHERE blogId = ?",
      [req.params.id]
    );

    res.json({
      success: true,
      likeCount: likeResult[0]?.count || 0,
      dislikeCount: dislikeResult[0]?.count || 0
    });
  } catch (err) {
    console.error("Like error:", err);
    res.status(500).json({ error: "Failed to like blog" });
  }
});

// Unlike a blog (requires auth)
router.post("/:id/unlike", authenticateToken, async (req: AuthRequest, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    // Delete like
    await query(
      "DELETE FROM blog_likes WHERE blogId = ? AND userId = ?",
      [req.params.id, req.user.userId]
    );

    // Get updated like count
    const result: any = await query(
      "SELECT COUNT(*) as count FROM blog_likes WHERE blogId = ?",
      [req.params.id]
    );

    res.json({ success: true, likeCount: result[0]?.count || 0 });
  } catch (err) {
    console.error("Unlike error:", err);
    res.status(500).json({ error: "Failed to unlike blog" });
  }
});

// Dislike a blog (requires auth)
router.post("/:id/dislike", authenticateToken, async (req: AuthRequest, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    // Remove like if it exists (can't like and dislike at the same time)
    await query(
      "DELETE FROM blog_likes WHERE blogId = ? AND userId = ?",
      [req.params.id, req.user.userId]
    );

    // Insert dislike if it doesn't already exist
    await query(
      "INSERT IGNORE INTO blog_dislikes (id, blogId, userId, createdAt) VALUES (?, ?, ?, NOW())",
      [uuidv4(), req.params.id, req.user.userId]
    );

    // Get updated counts
    const likeResult: any = await query(
      "SELECT COUNT(*) as count FROM blog_likes WHERE blogId = ?",
      [req.params.id]
    );
    const dislikeResult: any = await query(
      "SELECT COUNT(*) as count FROM blog_dislikes WHERE blogId = ?",
      [req.params.id]
    );

    res.json({
      success: true,
      likeCount: likeResult[0]?.count || 0,
      dislikeCount: dislikeResult[0]?.count || 0
    });
  } catch (err) {
    console.error("Dislike error:", err);
    res.status(500).json({ error: "Failed to dislike blog" });
  }
});

// Undislike a blog (requires auth)
router.post("/:id/undislike", authenticateToken, async (req: AuthRequest, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    // Delete dislike
    await query(
      "DELETE FROM blog_dislikes WHERE blogId = ? AND userId = ?",
      [req.params.id, req.user.userId]
    );

    // Get updated counts
    const likeResult: any = await query(
      "SELECT COUNT(*) as count FROM blog_likes WHERE blogId = ?",
      [req.params.id]
    );
    const dislikeResult: any = await query(
      "SELECT COUNT(*) as count FROM blog_dislikes WHERE blogId = ?",
      [req.params.id]
    );

    res.json({
      success: true,
      likeCount: likeResult[0]?.count || 0,
      dislikeCount: dislikeResult[0]?.count || 0
    });
  } catch (err) {
    console.error("Undislike error:", err);
    res.status(500).json({ error: "Failed to undislike blog" });
  }
});

export default router;

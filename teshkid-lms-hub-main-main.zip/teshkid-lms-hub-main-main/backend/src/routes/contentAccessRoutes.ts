import express from "express";
import { authenticateToken } from "../middleware/authMiddleware";
import { query } from "../database";
import path from "path";
import fs from "fs";

const router = express.Router();

/**
 * STUDENT CONTENT ACCESS
 */

// Get course materials (protected - enrollment required)
router.get("/materials/:courseId", authenticateToken, async (req: any, res) => {
  try {
    const { courseId } = req.params;
    const userId = req.user.userId;

    // Check if user is admin
    const userRoleQuery: any = await query(
      "SELECT role FROM users WHERE id = ?",
      [userId]
    );
    const isAdmin = userRoleQuery && userRoleQuery.length > 0 && userRoleQuery[0].role.toUpperCase() === "ADMIN";

    if (!isAdmin) {
      // Verify enrollment
      const enrollment: any = await query(
        "SELECT status FROM enrollments WHERE userId = ? AND courseId = ?",
        [userId, courseId]
      );

      if (!enrollment || enrollment.length === 0) {
        return res.status(403).json({ error: "Not enrolled in this course" });
      }

      if (enrollment[0].status !== "APPROVED") {
        return res.status(403).json({ error: "Enrollment not approved yet" });
      }
    }

    // Get accessible materials
    const materials: any = await query(
      `SELECT cm.* 
       FROM course_materials cm
       INNER JOIN course_material_access cma ON cm.id = cma.materialId
       WHERE cm.courseId = ? 
       AND (cma.userId = ? OR cma.userId IS NULL)
       AND cm.isVisible = 1
       ORDER BY cm.createdAt DESC`,
      [courseId, userId]
    );

    res.json(materials);
  } catch (error) {
    console.error("Error fetching materials:", error);
    res.status(500).json({ error: "Error fetching materials" });
  }
});

// Get single material details (protected)
router.get("/material/:materialId", authenticateToken, async (req: any, res) => {
  try {
    const { materialId } = req.params;
    const userId = req.user.userId;

    // Get material
    const material: any = await query(
      "SELECT * FROM course_materials WHERE id = ?",
      [materialId]
    );

    if (!material || material.length === 0) {
      return res.status(404).json({ error: "Material not found" });
    }

    const mat = material[0];

    // Check if user is admin
    const userRoleQuery: any = await query(
      "SELECT role FROM users WHERE id = ?",
      [userId]
    );
    const isAdmin = userRoleQuery && userRoleQuery.length > 0 && userRoleQuery[0].role.toUpperCase() === "ADMIN";

    if (!isAdmin) {
      // Verify enrollment
      const enrollment: any = await query(
        "SELECT status FROM enrollments WHERE userId = ? AND courseId = ?",
        [userId, mat.courseId]
      );

      if (!enrollment || enrollment.length === 0 || enrollment[0].status !== "APPROVED") {
        return res.status(403).json({ error: "Unauthorized" });
      }

      // Check access permissions
      const access: any = await query(
        "SELECT * FROM course_material_access WHERE materialId = ? AND (userId = ? OR userId IS NULL)",
        [materialId, userId]
      );

      if (!access || access.length === 0) {
        return res.status(403).json({ error: "You don't have access to this material" });
      }
    }

    res.json(mat);
  } catch (error) {
    console.error("Error fetching material:", error);
    res.status(500).json({ error: "Error fetching material" });
  }
});

// Stream video (protected)
router.get("/video/:videoId/stream", authenticateToken, async (req: any, res) => {
  try {
    const { videoId } = req.params;
    const userId = req.user.userId;

    // Verify access
    const video: any = await query(
      "SELECT * FROM course_materials WHERE id = ? AND type = 'VIDEO'",
      [videoId]
    );

    if (!video || video.length === 0) {
      return res.status(404).json({ error: "Video not found" });
    }

    // Check if user is admin
    const userRoleQuery: any = await query(
      "SELECT role FROM users WHERE id = ?",
      [userId]
    );
    const isAdmin = userRoleQuery && userRoleQuery.length > 0 && userRoleQuery[0].role.toUpperCase() === "ADMIN";

    if (!isAdmin) {
      const enrollment: any = await query(
        "SELECT status FROM enrollments WHERE userId = ? AND courseId = ?",
        [userId, video[0].courseId]
      );

      if (!enrollment || enrollment.length === 0 || enrollment[0].status !== "APPROVED") {
        return res.status(403).json({ error: "Unauthorized" });
      }
    }

    const filePath = path.join(process.cwd(), "uploads", video[0].filePath);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: "Video file not found" });
    }

    res.setHeader("Content-Type", "video/mp4");
    res.setHeader("Content-Disposition", `inline; filename="${video[0].title}.mp4"`);
    
    const stream = fs.createReadStream(filePath);
    stream.pipe(res);
  } catch (error) {
    console.error("Error streaming video:", error);
    res.status(500).json({ error: "Error streaming video" });
  }
});

// Download PDF (protected)
router.get("/pdf/:pdfId/download", authenticateToken, async (req: any, res) => {
  try {
    const { pdfId } = req.params;
    const userId = req.user.userId;

    const pdf: any = await query(
      "SELECT * FROM course_materials WHERE id = ? AND type = 'PDF'",
      [pdfId]
    );

    if (!pdf || pdf.length === 0) {
      return res.status(404).json({ error: "PDF not found" });
    }

    // Check if user is admin
    const userRoleQuery: any = await query(
      "SELECT role FROM users WHERE id = ?",
      [userId]
    );
    const isAdmin = userRoleQuery && userRoleQuery.length > 0 && userRoleQuery[0].role.toUpperCase() === "ADMIN";

    if (!isAdmin) {
      const enrollment: any = await query(
        "SELECT status FROM enrollments WHERE userId = ? AND courseId = ?",
        [userId, pdf[0].courseId]
      );

      if (!enrollment || enrollment.length === 0 || enrollment[0].status !== "APPROVED") {
        return res.status(403).json({ error: "Unauthorized" });
      }
    }

    const filePath = path.join(process.cwd(), "uploads", pdf[0].filePath);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: "PDF file not found" });
    }

    res.download(filePath, `${pdf[0].title}.pdf`);
  } catch (error) {
    console.error("Error downloading PDF:", error);
    res.status(500).json({ error: "Error downloading PDF" });
  }
});

/**
 * ADMIN CONTENT MANAGEMENT
 */

// Get all materials for a course (admin only)
router.get("/admin/course/:courseId/materials", authenticateToken, async (req: any, res) => {
  try {
    const adminCheck: any = await query(
      "SELECT role FROM users WHERE id = ?",
      [req.user.userId]
    );

    if (!adminCheck || adminCheck.length === 0 || adminCheck[0].role.toUpperCase() !== "ADMIN") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const { courseId } = req.params;

    const materials: any = await query(
      `SELECT 
        cm.id,
        cm.title,
        cm.description,
        cm.type,
        cm.filePath,
        cm.isVisible,
        COUNT(DISTINCT cp.id) as accessCount,
        COUNT(DISTINCT e.id) as studentCount
       FROM course_materials cm
       LEFT JOIN course_progress cp ON cm.id = cp.materialId
       LEFT JOIN enrollments e ON e.courseId = ? AND e.status = 'APPROVED'
       WHERE cm.courseId = ?
       GROUP BY cm.id
       ORDER BY cm.createdAt DESC`,
      [courseId, courseId]
    );

    res.json(materials);
  } catch (error) {
    console.error("Error fetching materials:", error);
    res.status(500).json({ error: "Error fetching materials" });
  }
});

// Upload course material
router.post("/admin/upload", authenticateToken, async (req: any, res) => {
  try {
    const adminCheck: any = await query(
      "SELECT role FROM users WHERE id = ?",
      [req.user.userId]
    );

    if (!adminCheck || adminCheck.length === 0 || adminCheck[0].role.toUpperCase() !== "ADMIN") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const { courseId, title, description, type, filePath, duration } = req.body;

    const materialId = Math.random().toString(36).substr(2, 9);

    await query(
      `INSERT INTO course_materials 
       (id, courseId, title, description, type, filePath, duration, isVisible, createdAt)
       VALUES (?, ?, ?, ?, ?, ?, ?, 1, NOW())`,
      [materialId, courseId, title, description, type, filePath, duration || null]
    );

    res.json({ success: true, materialId });
  } catch (error) {
    console.error("Error uploading material:", error);
    res.status(500).json({ error: "Error uploading material" });
  }
});

// Set material visibility
router.put("/admin/material/:materialId/visibility", authenticateToken, async (req: any, res) => {
  try {
    const adminCheck: any = await query(
      "SELECT role FROM users WHERE id = ?",
      [req.user.userId]
    );

    if (!adminCheck || adminCheck.length === 0 || adminCheck[0].role.toUpperCase() !== "ADMIN") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const { materialId } = req.params;
    const { isVisible } = req.body;

    await query(
      "UPDATE course_materials SET isVisible = ? WHERE id = ?",
      [isVisible ? 1 : 0, materialId]
    );

    res.json({ success: true });
  } catch (error) {
    console.error("Error updating visibility:", error);
    res.status(500).json({ error: "Error updating visibility" });
  }
});

// Set student-specific access
router.post("/admin/material/:materialId/access", authenticateToken, async (req: any, res) => {
  try {
    const adminCheck: any = await query(
      "SELECT role FROM users WHERE id = ?",
      [req.user.userId]
    );

    if (!adminCheck || adminCheck.length === 0 || adminCheck[0].role.toUpperCase() !== "ADMIN") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const { materialId } = req.params;
    const { userId, grantAccess } = req.body;

    if (grantAccess) {
      await query(
        `INSERT IGNORE INTO course_material_access (materialId, userId) VALUES (?, ?)`,
        [materialId, userId]
      );
    } else {
      await query(
        `DELETE FROM course_material_access WHERE materialId = ? AND userId = ?`,
        [materialId, userId]
      );
    }

    res.json({ success: true });
  } catch (error) {
    console.error("Error updating access:", error);
    res.status(500).json({ error: "Error updating access" });
  }
});

// Get material access list
router.get("/admin/material/:materialId/access", authenticateToken, async (req: any, res) => {
  try {
    const adminCheck: any = await query(
      "SELECT role FROM users WHERE id = ?",
      [req.user.userId]
    );

    if (!adminCheck || adminCheck.length === 0 || adminCheck[0].role.toUpperCase() !== "ADMIN") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const { materialId } = req.params;

    const access: any = await query(
      `SELECT u.id, u.name, SUBSTRING_INDEX(u.name, ' ', 1) AS firstName, IF(LOCATE(' ', u.name) > 0, SUBSTRING_INDEX(u.name, ' ', -1), '') AS lastName, u.email, cma.materialId
       FROM users u
       LEFT JOIN course_material_access cma ON u.id = cma.userId AND cma.materialId = ?
       WHERE u.role = 'STUDENT' OR u.role = 'student'
       ORDER BY firstName ASC`,
      [materialId]
    );

    res.json(access);
  } catch (error) {
    console.error("Error fetching access list:", error);
    res.status(500).json({ error: "Error fetching access list" });
  }
});

// Delete course material
router.delete("/admin/material/:materialId", authenticateToken, async (req: any, res) => {
  try {
    const adminCheck: any = await query(
      "SELECT role FROM users WHERE id = ?",
      [req.user.userId]
    );

    if (!adminCheck || adminCheck.length === 0 || adminCheck[0].role.toUpperCase() !== "ADMIN") {
      return res.status(403).json({ error: "Unauthorized" });
    }

    const { materialId } = req.params;

    // Get material info to delete file
    const material: any = await query(
      "SELECT filePath FROM course_materials WHERE id = ?",
      [materialId]
    );

    if (material && material.length > 0 && material[0].filePath) {
      // Delete file from uploads
      try {
        fs.unlinkSync(material[0].filePath);
      } catch (e) {
        console.log("File not found or already deleted:", material[0].filePath);
      }
    }

    // Delete material and related records
    await query(
      "DELETE FROM course_material_access WHERE materialId = ?",
      [materialId]
    );
    await query(
      "DELETE FROM course_progress WHERE materialId = ?",
      [materialId]
    );
    await query(
      "DELETE FROM course_materials WHERE id = ?",
      [materialId]
    );

    res.json({ success: true });
  } catch (error) {
    console.error("Error deleting material:", error);
    res.status(500).json({ error: "Error deleting material" });
  }
});

export default router;

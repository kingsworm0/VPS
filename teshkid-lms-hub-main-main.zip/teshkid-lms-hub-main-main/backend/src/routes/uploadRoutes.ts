import express from "express";
import multer from "multer";
import path from "path";
import { v4 as uuidv4 } from "uuid";
import fs from "fs";
import { authenticateToken, requireAdmin } from "../middleware/authMiddleware";
import { validateFileUpload } from "../middleware/validationMiddleware";
import { config } from "../config";

const router = express.Router();

// Configure multer for secure file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = config.UPLOAD_DIR;
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    // Use UUID instead of original filename to prevent directory traversal
    const ext = path.extname(file.originalname);
    const uniqueName = `${uuidv4()}${ext}`;
    cb(null, uniqueName);
  },
});

// SECURITY: Strict MIME type validation
const fileFilter = (req: any, file: any, cb: any) => {
  // Only allow safe image MIME types
  const allowedMimeTypes = config.SECURITY.ALLOWED_FILE_TYPES;
  
  if (allowedMimeTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error(`Invalid file type. Allowed types: ${allowedMimeTypes.join(", ")}`), false);
  }
};

// Configure multer with security settings
const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: config.SECURITY.MAX_FILE_SIZE,
  },
});

/**
 * Upload image endpoint
 * SECURITY: Requires authentication, validates file type and size
 */
router.post("/image", authenticateToken, upload.single("file"), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    // Additional validation using validation utility
    const validation = validateFileUpload(
      req.file,
      config.SECURITY.ALLOWED_FILE_TYPES,
      config.SECURITY.MAX_FILE_SIZE
    );

    if (!validation.valid) {
      // Delete the uploaded file if validation fails
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: validation.error });
    }

    // Return the URL path for the uploaded file (relative path for security)
    const fileUrl = `/uploads/${req.file.filename}`;
    
    res.json({
      success: true,
      url: fileUrl,
      filename: req.file.filename,
      size: req.file.size,
    });
  } catch (error: any) {
    console.error("Upload error:", error);
    
    // Clean up uploaded file on error
    if (req.file?.path && fs.existsSync(req.file.path)) {
      try {
        fs.unlinkSync(req.file.path);
      } catch (e) {
        console.error("Failed to clean up file:", e);
      }
    }

    // Don't expose detailed errors in production
    const isDev = process.env.NODE_ENV === "development";
    res.status(500).json({
      error: isDev ? error.message : "Failed to upload file",
    });
  }
});

/**
 * Upload generic file endpoint
 * SECURITY: Requires authentication, validates file type and size
 */
router.post("/file", authenticateToken, upload.single("file"), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    // Additional validation using validation utility
    const validation = validateFileUpload(
      req.file,
      config.SECURITY.ALLOWED_FILE_TYPES,
      config.SECURITY.MAX_FILE_SIZE
    );

    if (!validation.valid) {
      // Delete the uploaded file if validation fails
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: validation.error });
    }

    // Return the URL path for the uploaded file
    const fileUrl = `/uploads/${req.file.filename}`;
    
    res.json({
      success: true,
      url: fileUrl,
      filename: req.file.filename,
      size: req.file.size,
      mimetype: req.file.mimetype,
    });
  } catch (error: any) {
    console.error("Upload error:", error);
    
    if (req.file?.path && fs.existsSync(req.file.path)) {
      try { fs.unlinkSync(req.file.path); } catch (e) { }
    }

    const isDev = process.env.NODE_ENV === "development";
    res.status(500).json({
      error: isDev ? error.message : "Failed to upload file",
    });
  }
});

/**
 * Upload multiple images (admin only)
 * SECURITY: Admin only, validates each file
 */
router.post(
  "/images",
  authenticateToken,
  requireAdmin,
  upload.array("files", 10), // Max 10 files
  (req, res) => {
    try {
      if (!req.files || req.files.length === 0) {
        return res.status(400).json({ error: "No files uploaded" });
      }

      // Validate all files
      const uploadedFiles: any[] = [];
      const errors: any[] = [];

      (req.files as Express.Multer.File[]).forEach((file, index) => {
        const validation = validateFileUpload(
          file,
          config.SECURITY.ALLOWED_FILE_TYPES,
          config.SECURITY.MAX_FILE_SIZE
        );

        if (validation.valid) {
          uploadedFiles.push({
            url: `/uploads/${file.filename}`,
            filename: file.filename,
            size: file.size,
          });
        } else {
          errors.push({ file: file.originalname, error: validation.error });
          // Clean up invalid file
          if (fs.existsSync(file.path)) {
            fs.unlinkSync(file.path);
          }
        }
      });

      if (uploadedFiles.length === 0) {
        return res.status(400).json({
          error: "No files passed validation",
          details: errors,
        });
      }

      res.json({
        success: true,
        uploaded: uploadedFiles,
        errors: errors.length > 0 ? errors : undefined,
      });
    } catch (error: any) {
      console.error("Batch upload error:", error);

      // Clean up any uploaded files
      if (req.files) {
        (req.files as Express.Multer.File[]).forEach((file) => {
          if (fs.existsSync(file.path)) {
            try {
              fs.unlinkSync(file.path);
            } catch (e) {
              console.error("Failed to clean up file:", e);
            }
          }
        });
      }

      const isDev = process.env.NODE_ENV === "development";
      res.status(500).json({
        error: isDev ? error.message : "Batch upload failed",
      });
    }
  }
);

export default router;

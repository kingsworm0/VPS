// Terminal logger utility with ANSI color formatting
export const colors = {
  reset: "\x1b[0m",
  bright: "\x1b[1m",
  dim: "\x1b[2m",
  cyan: "\x1b[36m",
  green: "\x1b[32m",
  yellow: "\x1b[33m",
  red: "\x1b[31m",
  magenta: "\x1b[35m",
  blue: "\x1b[34m",
  gray: "\x1b[90m",
};

export const logger = {
  info: (tag: string, message: string, ...args: any[]) => {
    const time = new Date().toLocaleTimeString("en-US", { hour12: false });
    console.log(
      `${colors.gray}[${time}]${colors.reset} ${colors.bright}${colors.cyan}[${tag}]${colors.reset} ${message}`,
      ...args,
    );
  },

  success: (tag: string, message: string, ...args: any[]) => {
    const time = new Date().toLocaleTimeString("en-US", { hour12: false });
    console.log(
      `${colors.gray}[${time}]${colors.reset} ${colors.bright}${colors.green}[${tag}]${colors.reset} ${message}`,
      ...args,
    );
  },

  warn: (tag: string, message: string, ...args: any[]) => {
    const time = new Date().toLocaleTimeString("en-US", { hour12: false });
    console.warn(
      `${colors.gray}[${time}]${colors.reset} ${colors.bright}${colors.yellow}[${tag}]${colors.reset} ${message}`,
      ...args,
    );
  },

  error: (tag: string, message: string, ...args: any[]) => {
    const time = new Date().toLocaleTimeString("en-US", { hour12: false });
    console.error(
      `${colors.gray}[${time}]${colors.reset} ${colors.bright}${colors.red}[${tag}]${colors.reset} ${message}`,
      ...args,
    );
  },

  db: (sql: string, durationMs: number) => {
    const time = new Date().toLocaleTimeString("en-US", { hour12: false });
    const formattedSql = sql.replace(/\s+/g, " ").trim();
    const truncated = formattedSql.length > 100 ? `${formattedSql.slice(0, 100)}...` : formattedSql;
    const durColor = durationMs > 100 ? colors.yellow : colors.gray;

    console.log(
      `${colors.gray}[${time}]${colors.reset} ${colors.magenta}[SQL]${colors.reset} ${truncated} ${durColor}(${durationMs.toFixed(1)}ms)${colors.reset}`,
    );
  },

  http: (reqMethod: string, url: string, status: number, durationMs: number) => {
    const time = new Date().toLocaleTimeString("en-US", { hour12: false });
    let statusColor = colors.green;
    if (status >= 500) statusColor = colors.red;
    else if (status >= 400) statusColor = colors.yellow;
    else if (status >= 300) statusColor = colors.cyan;

    let methodColor = colors.blue;
    if (reqMethod === "POST") methodColor = colors.green;
    if (reqMethod === "PUT") methodColor = colors.yellow;
    if (reqMethod === "DELETE") methodColor = colors.red;

    console.log(
      `${colors.gray}[${time}]${colors.reset} ${colors.bright}${methodColor}${reqMethod.padEnd(6)}${colors.reset} ${url} ${statusColor}${status}${colors.reset} ${colors.gray}(${durationMs.toFixed(1)}ms)${colors.reset}`,
    );
  },
};

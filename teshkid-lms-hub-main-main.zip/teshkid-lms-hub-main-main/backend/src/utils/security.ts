/**
 * Security Utilities
 * Centralized security logging and sanitization
 */
import fs from 'fs';
import path from 'path';

const isDevelopment = process.env.NODE_ENV === 'development';

/**
 * Sanitize error messages to prevent information disclosure
 */
export const sanitizeError = (error: any, isDev: boolean = isDevelopment): string => {
  if (isDev) {
    return error instanceof Error ? error.message : JSON.stringify(error);
  }
  // In production, never expose technical details
  return 'An internal error occurred. Please try again later.';
};

/**
 * Log security events (authentication failures, access attempts, etc.)
 */
export const logSecurityEvent = (
  eventType: string,
  details: {
    userId?: string;
    email?: string;
    ip?: string;
    action?: string;
    result?: 'success' | 'failure';
    reason?: string;
  },
  logDir: string
) => {
  if (isDevelopment) return; // Skip in development to reduce noise

  const securityLogPath = path.join(logDir, 'security.log');
  const timestamp = new Date().toISOString();
  const logEntry = {
    timestamp,
    eventType,
    ...details,
  };

  try {
    if (!fs.existsSync(logDir)) {
      fs.mkdirSync(logDir, { recursive: true });
    }
    fs.appendFileSync(
      securityLogPath,
      JSON.stringify(logEntry) + '\n'
    );
  } catch (err) {
    console.error('Failed to write security log:', err);
  }
};

/**
 * Validate password strength
 */
export const validatePasswordStrength = (password: string): {
  isValid: boolean;
  errors: string[];
} => {
  const errors: string[] = [];

  if (password.length < 12) {
    errors.push('Password must be at least 12 characters long');
  }
  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain an uppercase letter');
  }
  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain a lowercase letter');
  }
  if (!/\d/.test(password)) {
    errors.push('Password must contain a number');
  }
  if (!/[!@#$%^&*]/.test(password)) {
    errors.push('Password must contain a special character (!@#$%^&*)');
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
};

/**
 * Sanitize user input to prevent XSS
 */
export const sanitizeInput = (input: any): any => {
  if (typeof input === 'string') {
    return input
      .replace(/[<>]/g, '') // Remove angle brackets
      .trim();
  }
  if (typeof input === 'object' && input !== null) {
    const sanitized: any = {};
    for (const key in input) {
      sanitized[key] = sanitizeInput(input[key]);
    }
    return sanitized;
  }
  return input;
};

/**
 * Check if JWT secret is secure
 */
export const isJWTSecretSecure = (secret?: string): boolean => {
  if (!secret || secret === 'secret') {
    return false;
  }
  // Should be at least 32 characters and contain mixed case + numbers + symbols
  if (secret.length < 32) {
    return false;
  }
  return /[A-Z]/.test(secret) && /[0-9]/.test(secret) && /[^A-Za-z0-9]/.test(secret);
};

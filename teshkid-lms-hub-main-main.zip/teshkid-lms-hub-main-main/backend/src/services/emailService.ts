import nodemailer from "nodemailer";
import { config } from "../config";
import { logger } from "../utils/logger";

interface SendPasswordResetParams {
  toEmail: string;
  recipientName: string;
  resetUrl: string;
}

/**
 * Creates and returns a configured nodemailer transporter.
 * Returns null if SMTP is not configured in the current environment.
 */
function createTransporter() {
  const host = process.env.SMTP_HOST;
  const port = parseInt(process.env.SMTP_PORT || "587");
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  const secure = process.env.SMTP_SECURE === "true" || port === 465;

  if (!host || !user || !pass) {
    return null;
  }

  return nodemailer.createTransport({
    host,
    port,
    secure,
    auth: {
      user,
      pass,
    },
  });
}

/**
 * Generates branded HTML for the Password Reset email.
 */
function getPasswordResetHtml(recipientName: string, resetUrl: string): string {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reset Your Password - Teshkid is Crypto</title>
</head>
<body style="margin: 0; padding: 0; background-color: #0f172a; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #0f172a; padding: 40px 15px;">
    <tr>
      <td align="center">
        <!-- Main Card -->
        <table role="presentation" width="100%" style="max-width: 560px; background-color: #1e293b; border-radius: 16px; overflow: hidden; border: 1px solid #334155; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);">
          <!-- Header -->
          <tr>
            <td style="padding: 36px 40px 20px 40px; text-align: center; border-bottom: 1px solid #334155;">
              <div style="font-size: 24px; font-weight: 900; letter-spacing: -0.5px; color: #ffffff;">
                TESHKID <span style="color: #10b981;">IS</span> <span style="color: #ef4444;">CRYPTO</span>
              </div>
              <p style="margin: 8px 0 0 0; font-size: 13px; color: #94a3b8; font-weight: 500;">Official Learning Management System</p>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="padding: 40px 40px 30px 40px;">
              <h1 style="margin: 0 0 16px 0; font-size: 20px; font-weight: 800; color: #ffffff;">Password Reset Request</h1>
              <p style="margin: 0 0 20px 0; font-size: 15px; line-height: 24px; color: #cbd5e1;">
                Hello <strong>${recipientName || "there"}</strong>,
              </p>
              <p style="margin: 0 0 24px 0; font-size: 15px; line-height: 24px; color: #cbd5e1;">
                We received a request to reset the password associated with your Teshkid is Crypto account. Click the button below to set a new password:
              </p>

              <!-- Action Button -->
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 32px 0;">
                <tr>
                  <td align="center">
                    <a href="${resetUrl}" target="_blank" style="display: inline-block; padding: 14px 36px; background-color: #10b981; color: #ffffff; text-decoration: none; font-size: 15px; font-weight: 700; border-radius: 12px; box-shadow: 0 4px 14px rgba(16, 185, 129, 0.4); text-align: center;">
                      Reset Password
                    </a>
                  </td>
                </tr>
              </table>

              <p style="margin: 0 0 12px 0; font-size: 13px; color: #94a3b8; line-height: 20px;">
                If the button above does not work, copy and paste this link into your web browser:
              </p>
              <p style="margin: 0 0 28px 0; font-size: 12px; color: #10b981; word-break: break-all; line-height: 18px;">
                <a href="${resetUrl}" style="color: #10b981; text-decoration: underline;">${resetUrl}</a>
              </p>

              <!-- Security Info Box -->
              <table role="presentation" width="100%" style="background-color: #0f172a; border-radius: 10px; border-left: 4px solid #ef4444; padding: 16px; margin-top: 10px;">
                <tr>
                  <td style="padding: 12px 16px;">
                    <p style="margin: 0; font-size: 13px; color: #cbd5e1; line-height: 20px;">
                      ⏳ <strong>This reset link will expire in 1 hour.</strong><br>
                      If you did not request a password reset, you can safely ignore this email. Your password will remain unchanged.
                    </p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="padding: 24px 40px; background-color: #0f172a; text-align: center; border-top: 1px solid #334155;">
              <p style="margin: 0; font-size: 12px; color: #64748b; line-height: 18px;">
                © ${new Date().getFullYear()} Teshkid is Crypto. All rights reserved.
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim();
}

/**
 * Sends a password reset email to the specified user.
 */
export async function sendPasswordResetEmail({
  toEmail,
  recipientName,
  resetUrl,
}: SendPasswordResetParams): Promise<{ success: boolean; messageId?: string }> {
  try {
    const transporter = createTransporter();
    const fromAddress = process.env.SMTP_FROM || '"Teshkid is Crypto" <no-reply@teshkidiscrypto.com>';
    const subject = "Password Reset Request - Teshkid is Crypto";
    const html = getPasswordResetHtml(recipientName, resetUrl);
    const text = `
Hello ${recipientName || "there"},

We received a request to reset your password for your Teshkid is Crypto account.
Please visit the following link to choose a new password (valid for 1 hour):

${resetUrl}

If you did not request this password reset, please ignore this email.

Best regards,
Teshkid is Crypto Team
    `.trim();

    if (!transporter) {
      // In development or when SMTP is not yet configured, log clearly
      console.log(`
╔════════════════════════════════════════════════════════════════════════════════╗
║ 📧 [PASSWORD RESET EMAIL - DEV / LOCAL MODE]                                   ║
╠════════════════════════════════════════════════════════════════════════════════╣
║ To:      ${toEmail}
║ Name:    ${recipientName}
║ URL:     ${resetUrl}
║ Note:    SMTP is not configured. The reset link above is ready to test!        ║
╚════════════════════════════════════════════════════════════════════════════════╝
      `);

      logger.info("EmailService", `Simulated Password Reset email to ${toEmail}`);
      return { success: true, messageId: "simulated-dev-id" };
    }

    const info = await transporter.sendMail({
      from: fromAddress,
      to: toEmail,
      subject,
      text,
      html,
    });

    logger.info("EmailService", `Password reset email sent to ${toEmail}: ${info.messageId}`);
    return { success: true, messageId: info.messageId };
  } catch (error: any) {
    logger.error(`[EmailService] Failed to send password reset email to ${toEmail}:`, error);
    // In dev, don't fail the request completely
    if (config.NODE_ENV !== "production") {
      console.warn("Email transport error in dev mode:", error.message);
      return { success: true, messageId: "fallback-dev-id" };
    }
    throw error;
  }
}

/**
 * Input Validation Middleware
 * Prevent common attacks: XSS, SQL injection patterns, etc.
 */
import { Request, Response, NextFunction } from 'express';

/**
 * Validate email format
 */
export const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email) && email.length <= 255;
};

/**
 * Validate UUID format
 */
export const isValidUUID = (uuid: string): boolean => {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return uuidRegex.test(uuid);
};

/**
 * Sanitize string to prevent XSS
 */
export const sanitizeString = (str: string, maxLength: number = 1000): string => {
  if (typeof str !== 'string') return '';
  return str
    .substring(0, maxLength)
    .replace(/[<>]/g, '') // Remove potential HTML tags
    .trim();
};

/**
 * Middleware to validate common request parameters
 */
export const validateRequestParams = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // Validate URL params - check for UUID format
  for (const key in req.params) {
    const value = req.params[key];
    // UUID patterns (with some flexibility for other ID formats)
    const isPasswordResetToken = key === 'token' && typeof value === 'string' && /^[a-f0-9]{64}$/i.test(value);
    if (typeof value === 'string' && value.length > 36 && !isPasswordResetToken) {
      return res.status(400).json({ error: 'Invalid parameter format' });
    }
  }

  // Check for suspicious patterns in query string (SQL injection attempts)
  for (const key in req.query) {
    const value = req.query[key];
    // Check for common SQL injection patterns: quotes, semicolons, comments
    if (typeof value === 'string' && /['";\\]|--|\/\*/g.test(value)) {
      console.warn(`Suspicious query parameter detected: ${key}`);
      return res.status(400).json({ error: 'Invalid request parameters' });
    }
  }

  next();
};

/**
 * Validate email in request body
 */
export const validateEmailBody = (fieldName: string = 'email') => {
  return (req: Request, res: Response, next: NextFunction) => {
    const email = req.body[fieldName];
    if (!email || !isValidEmail(email)) {
      return res.status(400).json({ error: `Invalid ${fieldName} format` });
    }
    next();
  };
};

/**
 * Sanitize request body to prevent XSS
 */
export const sanitizeBody = (req: Request, res: Response, next: NextFunction) => {
  if (req.body && typeof req.body === 'object') {
    req.body = sanitizeRequestBody(req.body);
  }
  next();
};

/**
 * Recursively sanitize object
 */
function sanitizeRequestBody(obj: any): any {
  if (typeof obj === 'string') {
    return sanitizeString(obj);
  }
  if (Array.isArray(obj)) {
    return obj.map(sanitizeRequestBody);
  }
  if (obj !== null && typeof obj === 'object') {
    const sanitized: any = {};
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        sanitized[key] = sanitizeRequestBody(obj[key]);
      }
    }
    return sanitized;
  }
  return obj;
}

/**
 * Validate file uploads
 */
export const validateFileUpload = (
  file: Express.Multer.File | undefined,
  allowedMimeTypes: string[],
  maxSizeBytes: number = 5 * 1024 * 1024 // 5MB default
): { valid: boolean; error?: string } => {
  if (!file) {
    return { valid: false, error: 'No file provided' };
  }

  if (!allowedMimeTypes.includes(file.mimetype)) {
    return { 
      valid: false, 
      error: `File type not allowed. Allowed types: ${allowedMimeTypes.join(', ')}` 
    };
  }

  if (file.size > maxSizeBytes) {
    return { 
      valid: false, 
      error: `File size exceeds maximum of ${maxSizeBytes / 1024 / 1024}MB` 
    };
  }

  // Check for suspicious filenames
  if (/[<>:"/\\|?*]/.test(file.originalname)) {
    return { valid: false, error: 'Invalid filename' };
  }

  return { valid: true };
};

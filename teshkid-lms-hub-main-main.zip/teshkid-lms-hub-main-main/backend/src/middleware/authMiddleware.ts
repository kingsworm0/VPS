import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { query } from "../database";

import { config } from "../config";

const JWT_SECRET = config.JWT_SECRET;

export interface AuthRequest extends Request {
  user?: {
    userId: string;
    email: string;
    role: string;
  };
  file?: Express.Multer.File;
}

export interface AuthenticatedRequest extends Request {
  user: {
    userId: string;
    email: string;
    role: string;
  };
  file?: Express.Multer.File;
}

export const authenticateToken = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) => {
  const authHeader = req.headers["authorization"] || req.headers["Authorization"];
  // Support common alternate header and cookie/query fallbacks
  let token = authHeader && typeof authHeader === 'string' ? authHeader.split(" ")[1] : undefined;
  if (!token && req.headers["x-access-token"]) token = req.headers["x-access-token"] as string;
  if (!token && (req as any).cookies && (req as any).cookies.token) token = (req as any).cookies.token;
  // Allow query param only in development for debugging (NOT recommended in production)
  if (!token && process.env.NODE_ENV !== 'production' && req.query && (req.query as any).token) token = (req.query as any).token as string;

  if (!token) {
    console.warn('Unauthenticated request to', req.method, req.originalUrl || req.url, '- no token provided');
    return res.sendStatus(401);
  }

  try {
    const payload: any = jwt.verify(token, JWT_SECRET);
    const results: any = await query(
      "SELECT id, email, role, isBlocked FROM users WHERE id = ?",
      [payload.userId],
    );

    if (!results || results.length === 0) return res.sendStatus(401);

    const dbUser = results[0];
    if (dbUser.isBlocked)
      return res.status(403).json({ message: "User is blocked" });

    req.user = { userId: dbUser.id, email: dbUser.email, role: dbUser.role };
    next();
  } catch (err) {
    console.error("Auth error:", err);
    return res.sendStatus(403);
  }
};

export const requireAdmin = (
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) => {
  if (!req.user || req.user.role !== "ADMIN") {
    return res.status(403).json({ message: "Admin access required" });
  }
  next();
};

export const requireStudent = (
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) => {
  if (!req.user || req.user.role !== "STUDENT") {
    return res
      .status(403)
      .json({
        message: "Student access required. Admins cannot enroll in courses.",
      });
  }
  next();
};

export const optionalAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) => {
  const authHeader = req.headers["authorization"] || req.headers["Authorization"];
  let token = authHeader && typeof authHeader === 'string' ? authHeader.split(" ")[1] : undefined;
  if (!token && req.headers["x-access-token"]) token = req.headers["x-access-token"] as string;
  if (!token && (req as any).cookies && (req as any).cookies.token) token = (req as any).cookies.token;
  if (!token && process.env.NODE_ENV !== 'production' && req.query && (req.query as any).token) token = (req.query as any).token as string;

  if (!token) {
    return next();
  }

  try {
    const payload: any = jwt.verify(token, JWT_SECRET);
    const results: any = await query(
      "SELECT id, email, role, isBlocked FROM users WHERE id = ?",
      [payload.userId],
    );

    if (results && results.length > 0) {
      const dbUser = results[0];
      if (!dbUser.isBlocked) {
        req.user = { userId: dbUser.id, email: dbUser.email, role: dbUser.role };
      }
    }
  } catch (err) {
    // Ignore invalid token
  }
  next();
};

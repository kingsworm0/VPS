const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

/**
 * Admin Account Setup Script
 * SECURITY: Never prints or logs passwords
 */

async function createAdminAccount() {
    let connection;

    try {
        // Create database connection
        connection = await mysql.createConnection({
            host: process.env.DB_HOST || '127.0.0.1',
            port: parseInt(process.env.DB_PORT || '3306'),
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASSWORD || '',
            database: process.env.DB_NAME || 'teshkid_lms',
        });

        console.log('✅ Connected to database');

        // Admin account details
        const adminEmail = process.env.ADMIN_EMAIL || 'admin@teshkid.com';
        const adminPassword = process.env.ADMIN_PASSWORD;
        const adminName = process.env.ADMIN_NAME || 'Teshkid Is Crypto';

        // SECURITY: Validate password is provided
        if (!adminPassword) {
            throw new Error(
                'ADMIN_PASSWORD environment variable is not set!\n' +
                'Please set ADMIN_PASSWORD in your .env file before running this script.\n' +
                'Password requirements:\n' +
                '  - At least 12 characters\n' +
                '  - At least 1 uppercase letter\n' +
                '  - At least 1 lowercase letter\n' +
                '  - At least 1 number\n' +
                '  - At least 1 special character (!@#$%^&*)'
            );
        }

        // Validate password strength
        const passwordRegex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{12,}$/;
        if (!passwordRegex.test(adminPassword)) {
            throw new Error(
                'ADMIN_PASSWORD does not meet security requirements:\n' +
                '  ✓ Must be at least 12 characters\n' +
                '  ✓ Must contain uppercase letter\n' +
                '  ✓ Must contain lowercase letter\n' +
                '  ✓ Must contain number\n' +
                '  ✓ Must contain special character (!@#$%^&*)'
            );
        }

        // Check if admin already exists
        const [existingAdmin] = await connection.execute(
            'SELECT id, email, role FROM users WHERE email = ?',
            [adminEmail]
        );

        if (existingAdmin.length > 0) {
            console.log('⚠️  Admin account already exists with email:', adminEmail);
            console.log('   User ID:', existingAdmin[0].id);
            console.log('   Name:', existingAdmin[0].role === 'ADMIN' ? '(Admin)' : '(User)');

            // Update role to ADMIN if it's not already
            if (existingAdmin[0].role !== 'ADMIN') {
                await connection.execute(
                    'UPDATE users SET role = ? WHERE email = ?',
                    ['ADMIN', adminEmail]
                );
                console.log('✅ Updated user role to ADMIN');
            }

            console.log('\n💡 To reset password, use the admin dashboard change password feature.');
            return;
        }

        // Hash the password
        const hashedPassword = await bcrypt.hash(adminPassword, 10);
        const adminId = uuidv4();

        // Insert admin user
        await connection.execute(
            `INSERT INTO users (id, email, password, name, role, createdAt, updatedAt) 
       VALUES (?, ?, ?, ?, ?, NOW(), NOW())`,
            [adminId, adminEmail, hashedPassword, adminName, 'ADMIN']
        );

        console.log('\n🎉 Admin account created successfully!');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log('📧 Email:', adminEmail);
        console.log('👤 Name:', adminName);
        console.log('🆔 User ID:', adminId);
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log('\n✅ Use the credentials you provided to log in');
        console.log('⚠️  Never share your password with anyone');
        const frontendUrl = process.env.FRONTEND_URL || 'http://127.0.0.1:8080';
        console.log(`🌐 Admin Login URL: ${frontendUrl}/admin/login`);
        console.log('\n');

    } catch (error) {
        console.error('❌ Error creating admin account:');
        if (error instanceof Error) {
            console.error(error.message);
        } else {
            console.error(error);
        }
        process.exit(1);
    } finally {
        if (connection) {
            await connection.end();
        }
    }
}

// Run the script
createAdminAccount()
    .then(() => {
        console.log('✅ Script completed successfully');
        process.exit(0);
    })
    .catch((error) => {
        console.error('❌ Script failed:', error);
        process.exit(1);
    });

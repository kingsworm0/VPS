import { runMigrations } from "./src/migrations/index";

async function verify() {
  try {
    await runMigrations();
    console.log("Migrations executed successfully.");
    process.exit(0);
  } catch (error) {
    console.error("Migration failed:", error);
    process.exit(1);
  }
}

verify();

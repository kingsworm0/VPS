import { query, db } from "./src/database";

async function verify() {
  try {
    console.log("Verifying courses...");
    const courses: any = await query("SELECT * FROM courses");
    console.log(`Found ${courses.length} courses.`);
    courses.forEach((c: any) => console.log(`- ${c.title}`));
  } catch (error) {
    console.error("Verification failed:", error);
  } finally {
    db.end();
  }
}

verify();

import { query, db } from "./src/database";
import { v4 as uuidv4 } from "uuid";

const courses = [
  {
    title: "Bitcoin Fundamentals: From Zero to Hero",
    description:
      "Master the basics of Bitcoin, blockchain technology, wallets, and secure storage practices. Perfect for complete beginners.",
    instructor: "Dr. Sarah Chen",
    thumbnail:
      "https://images.unsplash.com/photo-1518546305927-5a555bb7020d?w=800&q=80",
    level: "Beginner",
    duration: "8 hours",
    price: 49,
    cryptoPrice: "0.0012 BTC",
    modules: [
      {
        title: "Introduction to Bitcoin",
        description: "Understanding the revolutionary digital currency",
        lessons: [
          {
            title: "What is Bitcoin?",
            duration: "15 min",
            type: "video",
            content: "https://www.youtube.com/embed/Gc2en3nHxA4",
          },
          {
            title: "History of Cryptocurrency",
            duration: "20 min",
            type: "video",
            content: "https://www.youtube.com/embed/8o9Q6Y2n-e0",
          },
          {
            title: "How Bitcoin Works",
            duration: "25 min",
            type: "video",
            content: "https://www.youtube.com/embed/l9jOJk30eQs",
          },
        ],
      },
      {
        title: "Blockchain Technology",
        description: "Deep dive into the technology behind crypto",
        lessons: [
          {
            title: "What is Blockchain?",
            duration: "20 min",
            type: "video",
            content: "https://www.youtube.com/embed/SSo_EIwHSd4",
          },
          {
            title: "Consensus Mechanisms",
            duration: "30 min",
            type: "video",
            content: "https://www.youtube.com/embed/w9UDS0FfaMI",
          },
          {
            title: "Mining Explained",
            duration: "25 min",
            type: "video",
            content: "https://www.youtube.com/embed/GmOzih6I1zs",
          },
        ],
      },
      {
        title: "Wallets & Security",
        description: "Protect your digital assets",
        lessons: [
          {
            title: "Types of Wallets",
            duration: "20 min",
            type: "video",
            content: "https://www.youtube.com/embed/OFw0f0h619k",
          },
          {
            title: "Hot vs Cold Storage",
            duration: "15 min",
            type: "video",
            content: "https://www.youtube.com/embed/2Tj-3j8f8yY",
          },
          {
            title: "Security Best Practices",
            duration: "25 min",
            type: "video",
            content: "https://www.youtube.com/embed/P7wT4453G4E",
          },
        ],
      },
    ],
  },
  {
    title: "Ethereum & Smart Contracts Development",
    description:
      "Learn Solidity programming, deploy smart contracts, and build decentralized applications on Ethereum.",
    instructor: "Alex Thompson",
    thumbnail:
      "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=800&q=80",
    level: "Intermediate",
    duration: "16 hours",
    price: 129,
    cryptoPrice: "0.05 ETH",
    modules: [
      {
        title: "Introduction to Ethereum",
        description: "The world computer",
        lessons: [
          {
            title: "What is Ethereum?",
            duration: "20 min",
            type: "video",
            content: "https://www.youtube.com/embed/jxLkbJozKbY",
          },
          {
            title: "Smart Contracts Explained",
            duration: "25 min",
            type: "video",
            content: "https://www.youtube.com/embed/ZE2HxTmxfrI",
          },
        ],
      },
      {
        title: "Solidity Basics",
        description: "Programming for the EVM",
        lessons: [
          {
            title: "Solidity Syntax",
            duration: "30 min",
            type: "video",
            content: "https://www.youtube.com/embed/ipwxYa-F1uY",
          },
          {
            title: "Data Types and Variables",
            duration: "35 min",
            type: "video",
            content: "https://www.youtube.com/embed/vS97hG1Xz7E",
          },
        ],
      },
    ],
  },
  {
    title: "DeFi Mastery: Yield Farming & Liquidity",
    description:
      "Deep dive into decentralized finance protocols, yield optimization strategies, and risk management.",
    instructor: "Michael Roberts",
    thumbnail:
      "https://images.unsplash.com/photo-1642790106117-e829e14a795f?w=800&q=80",
    level: "Advanced",
    duration: "12 hours",
    price: 199,
    cryptoPrice: "0.08 ETH",
    modules: [
      {
        title: "DeFi Ecosystem",
        description: "Overview of Decentralized Finance",
        lessons: [
          {
            title: "What is DeFi?",
            duration: "20 min",
            type: "video",
            content: "https://www.youtube.com/embed/k9HYC0EJU6E",
          },
          {
            title: "DEXs vs CEXs",
            duration: "25 min",
            type: "video",
            content: "https://www.youtube.com/embed/17g1w3k1iTc",
          },
        ],
      },
      {
        title: "Yield Farming",
        description: "Maximizing returns",
        lessons: [
          {
            title: "Liquidity Pools",
            duration: "30 min",
            type: "video",
            content: "https://www.youtube.com/embed/cizLhxSKzoQ",
          },
          {
            title: "Impermanent Loss",
            duration: "25 min",
            type: "video",
            content: "https://www.youtube.com/embed/8XJ1MSTEuU0",
          },
        ],
      },
    ],
  },
  {
    title: "NFT Creation & Digital Art Marketplace",
    description:
      "Create, mint, and sell NFTs. Learn about digital art, metadata, and building on OpenSea and other marketplaces.",
    instructor: "Emma Wilson",
    thumbnail:
      "https://images.unsplash.com/photo-1646483236584-3f5b7a5e5c1e?w=800&q=80",
    level: "Beginner",
    duration: "6 hours",
    price: 79,
    cryptoPrice: "0.03 ETH",
    modules: [
      {
        title: "Understanding NFTs",
        description: "Non-Fungible Tokens explained",
        lessons: [
          {
            title: "What are NFTs?",
            duration: "15 min",
            type: "video",
            content: "https://www.youtube.com/embed/Oz9zw7-_vhM",
          },
          {
            title: "History of NFTs",
            duration: "20 min",
            type: "video",
            content: "https://www.youtube.com/embed/XqZsoesa55w",
          },
        ],
      },
      {
        title: "Creating and Minting",
        description: "Making your own NFTs",
        lessons: [
          {
            title: "Digital Art Tools",
            duration: "25 min",
            type: "video",
            content: "https://www.youtube.com/embed/9y7d56Zz5c0",
          },
          {
            title: "Minting on OpenSea",
            duration: "30 min",
            type: "video",
            content: "https://www.youtube.com/embed/3l3lQ3y3l3o",
          },
        ],
      },
    ],
  },
  {
    title: "Crypto Trading Strategies & Technical Analysis",
    description:
      "Master chart patterns, indicators, risk management, and develop your own trading strategy.",
    instructor: "James Liu",
    thumbnail:
      "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&q=80",
    level: "Intermediate",
    duration: "14 hours",
    price: 149,
    cryptoPrice: "0.0037 BTC",
    modules: [
      {
        title: "Technical Analysis Basics",
        description: "Reading the charts",
        lessons: [
          {
            title: "Candlestick Patterns",
            duration: "30 min",
            type: "video",
            content: "https://www.youtube.com/embed/C322NuZ7W2o",
          },
          {
            title: "Support and Resistance",
            duration: "25 min",
            type: "video",
            content: "https://www.youtube.com/embed/4gZ8z5z5z5o",
          },
        ],
      },
      {
        title: "Trading Psychology",
        description: "Mindset for success",
        lessons: [
          {
            title: "Risk Management",
            duration: "20 min",
            type: "video",
            content: "https://www.youtube.com/embed/7gZ8z5z5z5o",
          },
          {
            title: "Emotional Control",
            duration: "15 min",
            type: "video",
            content: "https://www.youtube.com/embed/8gZ8z5z5z5o",
          },
        ],
      },
    ],
  },
  {
    title: "Blockchain Security & Smart Contract Auditing",
    description:
      "Learn to identify vulnerabilities, audit smart contracts, and implement security best practices.",
    instructor: "Dr. David Park",
    thumbnail:
      "https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?w=800&q=80",
    level: "Advanced",
    duration: "20 hours",
    price: 299,
    cryptoPrice: "0.12 ETH",
    modules: [
      {
        title: "Common Vulnerabilities",
        description: "What can go wrong",
        lessons: [
          {
            title: "Reentrancy Attacks",
            duration: "30 min",
            type: "video",
            content: "https://www.youtube.com/embed/4gZ8z5z5z5o",
          },
          {
            title: "Overflow/Underflow",
            duration: "25 min",
            type: "video",
            content: "https://www.youtube.com/embed/5gZ8z5z5z5o",
          },
        ],
      },
      {
        title: "Auditing Process",
        description: "How to audit code",
        lessons: [
          {
            title: "Manual Review",
            duration: "40 min",
            type: "video",
            content: "https://www.youtube.com/embed/6gZ8z5z5z5o",
          },
          {
            title: "Automated Tools",
            duration: "35 min",
            type: "video",
            content: "https://www.youtube.com/embed/7gZ8z5z5z5o",
          },
        ],
      },
    ],
  },
];

async function seed() {
  try {
    console.log("Starting seed...");

    for (const course of courses) {
      const courseId = uuidv4();
      console.log(`Inserting course: ${course.title}`);

      await query(
        `INSERT INTO courses (id, title, description, instructor, thumbnail, level, duration, price, cryptoPrice) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          courseId,
          course.title,
          course.description,
          course.instructor,
          course.thumbnail,
          course.level,
          course.duration,
          course.price,
          course.cryptoPrice,
        ],
      );

      let moduleOrder = 0;
      for (const mod of course.modules) {
        const moduleId = uuidv4();
        moduleOrder++;

        await query(
          `INSERT INTO modules (id, courseId, title, description, \`order\`) 
           VALUES (?, ?, ?, ?, ?)`,
          [moduleId, courseId, mod.title, mod.description, moduleOrder],
        );

        let lessonOrder = 0;
        for (const lesson of mod.lessons) {
          const lessonId = uuidv4();
          lessonOrder++;

          await query(
            `INSERT INTO lessons (id, moduleId, title, duration, type, content, \`order\`) 
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
              lessonId,
              moduleId,
              lesson.title,
              lesson.duration,
              lesson.type,
              lesson.content,
              lessonOrder,
            ],
          );
        }
      }
    }

    console.log("Seed completed successfully!");
  } catch (error) {
    console.error("Seed failed:", error);
  } finally {
    // Close the pool
    db.end();
  }
}

seed();
